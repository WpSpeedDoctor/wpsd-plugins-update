<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: WPSD Admin Dark Mode
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Changes color scheme of the admin dashboard
* Version: 1.0
* Updated: 2026-06-21
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

if( isset($_COOKIE[LOGGED_IN_COOKIE]) && !wp_doing_ajax() && is_admin() ){

	defined('CONCATENATE_SCRIPTS') || define('CONCATENATE_SCRIPTS', false);
		
	defined('COMPRESS_SCRIPTS') || define('COMPRESS_SCRIPTS', false);

	defined('COMPRESS_CSS') || define('COMPRESS_CSS', false);


	if(!COMPRESS_CSS && !isset($_GET['css-test'])){

		require __DIR__ . '/main.php';
	}
}