<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

global $wp_version;

$wpsd_wp_version_slug = str_replace ( '.', '-', $wp_version );

define( 'WPSD_ADM_ASSETS_DIR', __DIR__ . '/assets/'.$wpsd_wp_version_slug  );

define( 'WPSD_ADM_URL',plugin_dir_url( __FILE__ ) . 'assets/' . $wpsd_wp_version_slug );

define( 'WPSD_ADM_REPLACE_COLORS', false );

unset($wpsd_wp_version_slug);

main();

function main() {

	ob_start( __NAMESPACE__ . '\process_admin_html' );

}

function process_admin_html( $html ) {

	$colors = [];

	$html = preg_replace_callback(
		'/<link\b[^>]*\bhref=(["\'])(.*?)\1[^>]*>/i',
		function( $matches ) use ( &$colors ) {

			$tag = $matches[0];

			$url = $matches[2];

			if ( str_contains( $url, '/assets/' ) ) {

				return $tag;

			}

			if ( false === str_contains( $url, '/wp-admin/' ) && false === str_contains( $url, '/wp-includes/' ) ) {

				return $tag;

			}

			$copied_url = copy_admin_style( $url, $colors );

			if ( false === $copied_url ) {

				return $tag;

			}

			return str_replace( $url, $copied_url, $tag );

		},
		$html
	);

	append_color_variables( $colors );

	return $html;

}

function copy_admin_style( $url, &$colors ) {

	global $wp_version;

	$path = wp_parse_url( $url, PHP_URL_PATH );

	if ( false === $path ) {

		return false;

	}

	$core_path = strstr( $path, '/wp-admin/' );

	if ( false === $core_path ) {

		$core_path = strstr( $path, '/wp-includes/' );

	}

	if ( false === $core_path || '.css' !== substr( $core_path, -4 ) ) {

		return false;

	}

	$original_path = ABSPATH . ltrim( $core_path, '/' );

	$source_path = str_replace( '.min.css', '.css', $original_path );

	if ( false === file_exists( $source_path ) ) {

		$source_path = $original_path;

	}

	if ( false === file_exists( $source_path ) ) {

		return false;

	}

	$relative_path = str_replace( '.min.css', '.css', $core_path );

	$destination_path = WPSD_ADM_ASSETS_DIR. $relative_path;

	$destination_url = WPSD_ADM_URL . $relative_path;

	if ( false === WPSD_ADM_REPLACE_COLORS && file_exists( $destination_path ) ) {

		return $destination_url;

	}

	$destination_dir = dirname( $destination_path );

	if ( false === wp_mkdir_p( $destination_dir ) ) {

		return false;

	}

	$css = file_get_contents( $source_path );

	if ( false === $css ) {

		return false;

	}

	if ( WPSD_ADM_REPLACE_COLORS ) {

		$css = preg_replace_callback(
			'/(\bbackground\b[^;{}]*?)?(?<![\w-])#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})(?![\w-])/i',
			function( $matches ) use ( &$colors ) {

				$prefix = $matches[1];

				$value = strtolower( $matches[2] );

				$name = empty( $prefix ) ? $value : 'bg-' . $value;

				$colors[ $name ] = get_darkmode_color( $name );

				return $prefix . 'var(--wpsd-dm-' . $name . ')';

			},
			$css
		);

	}

	if ( false === file_put_contents( $destination_path, $css ) ) {

		return false;

	}

	return $destination_url;

}

function get_darkmode_color( $name ) {

	static $colors=[
 	"f0f0f1" =>		"#181a1f",
 	"c3c4c7" =>		"#4b5058",
 	"bg-1d2327" =>		"#1d2327",
 	"bg-2c3338" =>		"#2c3338",
 	"72aee6" =>		"#7db9f0",
 	"a7aaad" =>		"#969ca5",
 	"bg-3c434a" =>		"#3c434a",
 	"bg-f0f0f1" =>		"#f0f0f1",
 	"2c3338" =>		"#d5d8dc",
 	"bg-fff" =>		"#202329",
 	"000" =>		"#f5f6f7",
 	"fff" =>		"#f5f5f5",
 	"bg-d63638" =>		"#d63638",
 	"8c8f94" =>		"#aeb3ba",
 	"2271b1" =>		"#5aa9e6",
 	"bg-ffffff" =>		"#1a1d22",
 	"3858e9" =>		"#2271b1",
 	"3c434a" =>		"#c4c8ce",
 	"135e96" =>		"#65afe7",
 	"043959" =>		"#9acdf1",
 	"1d2327" =>		"#b5bac1",
 	"646970" =>		"#b5bac1",
 	"50575e" =>		"#c4c8ce",
 	"f1f1f1" =>		"#1a1d22",
 	"0a4b78" =>		"#8bc5ee",
 	"3582c4" =>		"#68afe7",
 	"bg-c5d9ed" =>		"#c5d9ed",
 	"bg-f6f7f7" =>		"#1a1d22",
 	"bg-2271b1" =>		"#2271b1",
 	"d63638" =>		"#f06a6c",
 	"bg-c3c4c7" =>		"#c3c4c7",
 	"1e1e1e" =>		"#c5d9ed",
 	"dcdcde" =>		"#484d55",
 	"f6f7f7" =>		"#22252b",
 	"b32d2e" =>		"#ef6b6d",
 	"007017" =>		"#50bd6d",
 	"bg-646970" =>		"#646970",
 	"4ab866" =>		"#68d083",
 	"bg-eff9f1" =>		"#eff9f1",
 	"f0b849" =>		"#f2c45c",
 	"bg-fef8ee" =>		"#fef8ee",
 	"cc1818" =>		"#ff6b6b",
 	"bg-fcf0f0" =>		"#fcf0f0",
 	"68de7c" =>		"#76df89",
 	"9ec2e6" =>		"#77afd9",
 	"bg-dcdcde" =>		"#1a1d22",
 	"787c82" =>		"#aeb3ba",
 	"dba617" =>		"#e5bd4f",
 	"bg-f0c33c" =>		"#f0c33c",
 	"fafafa" =>		"#24272d",
 	"949494" =>		"#a9aeb5",
 	"bg-f0f0f0" =>		"#24272d",
 	"757575" =>		"#b1b6bd",
 	"cccccc" =>		"#555b64",
 	"bg-ffabaf" =>		"#ffabaf",
 	"e65054" =>		"#f06b70",
 	"bg-facfd2" =>		"#facfd2",
 	"f86368" =>		"#ff7479",
 	"bg-f5e6ab" =>		"#f5e6ab",
 	"f0c33c" =>		"#f2ca55",
 	"bg-b8e6bf" =>		"#b8e6bf",
 	"bg-fcf9e8" =>		"#fcf9e8",
 	"4f94d4" =>		"#72b5eb",
 	"fff972" =>		"#f6e76d",
 	"bg-151515" =>		"#151515",
 	"e9e9ed" =>		"#30333a",
 	"bg-b32d2e" =>		"#b32d2e",
 	"bg-3858e9" =>		"#3858e9",
 	"996800" =>		"#e3b94f",
 	"bg-000" =>		"#000",
 	"ddd" =>		"#454a52",
 	"bg-fcf0f1" =>		"#fcf0f1",
 	"00ba37" =>		"#57cf78",
 	"bg-edfaef" =>		"#edfaef",
 	"bg-68de7c" =>		"#68de7c",
 	"183ad6" =>		"#7690ff",
 	"83b4d8" =>		"#86bee6",
 	"bg-50575e" =>		"#50575e",
 	"bg-ebe8e5" =>		"#ebe8e5",
 	"bg-ececec" =>		"#ececec",
 	"bg-000000" =>		"#000000",
 	"000000" =>		"#f5f6f7",
 	"bg-0073aa" =>		"#0073aa",
 	"32373c" =>		"#d0d4d9",
 	"23282d" =>		"#dde0e4",
 	"555d66" =>		"#bdc2c9",
 	"bg-f86368" =>		"#f86368",
 	"111" =>		"#f0f1f3",
 	"0085ba" =>		"#66bee9",
 	"096484" =>		"#7fc5e5",
 	"46403c" =>		"#c8c4c1",
 	"523f6d" =>		"#c3a8e2",
 	"e14d43" =>		"#f47770",
 	"627c83" =>		"#aec5cb",
 	"dd823b" =>		"#eda35f",
 	"8a8a8a" =>		"#aeb3ba",
 	"d8d8d8" =>		"#484d55",
 	"bg-2145e6" =>		"#2145e6",
 	"2145e6" =>		"#7890ff",
 	"bg-183ad6" =>		"#183ad6",
 	"bg-e2e2e2" =>		"#e2e2e2",
 	"e2e2e2" =>		"#3d4249",
 	"ffffff" =>		"#202329",
 	"dddddd" =>		"#454a52",
 	"bg-1e1e1e" =>		"#1e1e1e",
 	"f0f0f0" =>		"#1c1f24",
 	"7b90ff" =>		"#91a2ff",
 	"bg-fbfbfc" =>		"#fbfbfc",
 	"2f2f2f" =>		"#d5d8dc",
 	"bg-ccc" =>		"#ccc",
 	"bg-949494" =>		"#949494",
 	"ccc" =>		"#555b64",
 	"bg-2f2f2f" =>		"#2f2f2f",
 	"bg-e0e0e0" =>		"#e0e0e0",
 	"e0e0e0" =>		"#41464e",
 	"bg-ddd" =>		"#ddd",
 	"bg-4ab866" =>		"#4ab866",
 	"bg-cc1818" =>		"#cc1818",
 	"7a00df" =>		"#c47cff",
 	"007cba" =>		"#69b9e8",
 	"005a87" =>		"#83c8ed",
];


	if ( false === isset( $colors[ $name ] ) ) {

		return '#' . $name;

	}

	return $colors[ $name ];

}

function append_color_variables( $colors ) {

	if ( empty( $colors ) ) {

		return false;

	}

	$path = WPSD_ADM_ASSETS_DIR . '/wp-admin/css/colors/modern/colors.css';

	$dir = dirname( $path );

	if ( false === wp_mkdir_p( $dir ) ) {

		return false;

	}

	$css = file_exists( $path ) ? file_get_contents( $path ) : '';

	if ( false === $css ) {

		return false;

	}

	$variables = "\n\n:root {\n";

	foreach ( $colors as $name => $value ) {

		$variables .= "\t--wpsd-dm-{$name}: {$value};\n";

	}

	// $variables .= <<<HTML
	//   --wp-admin-theme-color: #23368c;


	// HTML;
	$variables .= "}\n";

	return false !== file_put_contents( $path, $css . $variables );

}
