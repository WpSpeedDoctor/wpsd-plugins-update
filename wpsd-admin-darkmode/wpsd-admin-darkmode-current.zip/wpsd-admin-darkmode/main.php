<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

global $wp_version;

$wpsd_wp_version_slug = str_replace ( '.', '-', $wp_version );

define( 'WPSD_ADM_ASSETS_DIR', __DIR__ . '/assets/'.$wpsd_wp_version_slug  );

define( 'WPSD_ADM_URL',plugin_dir_url( __FILE__ ) . 'assets/' . $wpsd_wp_version_slug );

define( 'WPSD_ADM_REWRITE_CSS', true );

unset($wpsd_wp_version_slug);

main();

function main() {

	ob_start( __NAMESPACE__ . '\process_admin_html' );

}

function process_admin_html( $html ) {

	$colors = [];

	$html = preg_replace_callback(
		'/<link\b[^>]*\bhref=(["\'])(.*?)\1[^>]*>/i',
		function( $matches ) use ( &$colors ) {

			$tag = $matches[0];

			$url = $matches[2];

			if ( str_contains( $url, '/assets/' ) ) {

				return $tag;

			}

			if ( false === str_contains( $url, '/wp-admin/' ) && false === str_contains( $url, '/wp-includes/' ) ) {

				return $tag;

			}

			$copied_url = copy_admin_style( $url, $colors );

			if ( false === $copied_url ) {

				return $tag;

			}

			return str_replace( $url, $copied_url, $tag );

		},
		$html
	);

	append_color_variables( $colors );

	return $html;

}

function copy_admin_style( $url, &$colors ) {

	global $wp_version;

	$path = wp_parse_url( $url, PHP_URL_PATH );

	if ( false === $path ) {

		return false;

	}

	$core_path = strstr( $path, '/wp-admin/' );

	if ( false === $core_path ) {

		$core_path = strstr( $path, '/wp-includes/' );

	}

	if ( false === $core_path || '.css' !== substr( $core_path, -4 ) ) {

		return false;

	}

	$original_path = ABSPATH . ltrim( $core_path, '/' );

	$source_path = str_replace( '.min.css', '.css', $original_path );

	if ( false === file_exists( $source_path ) ) {

		$source_path = $original_path;

	}

	if ( false === file_exists( $source_path ) ) {

		return false;

	}

	$relative_path = str_replace( '.min.css', '.css', $core_path );

	$destination_path = WPSD_ADM_ASSETS_DIR. $relative_path;

	$destination_url = WPSD_ADM_URL . $relative_path;

	if ( false === WPSD_ADM_REWRITE_CSS && file_exists( $destination_path ) ) {

		return $destination_url;

	}

	$destination_dir = dirname( $destination_path );

	if ( false === wp_mkdir_p( $destination_dir ) ) {

		return false;

	}

	$css = file_get_contents( $source_path );

	if ( false === $css ) {

		return false;

	}


	$css = preg_replace_callback(
		'/(\bbackground\b[^;{}]*?)?(?<![\w-])#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})(?![\w-])/i',
		function( $matches ) use ( &$colors ) {

			$prefix = $matches[1];

			$value = strtolower( $matches[2] );

			$name = empty( $prefix ) ? $value : 'bg-' . $value;

			$colors[ $name ] = get_darkmode_color( $name );

			return $prefix . 'var(--wpsd-dm-' . $name . ')';

		},
		$css
	);


	if ( false === file_put_contents( $destination_path, $css ) ) {

		return false;

	}

	return $destination_url;

}

function get_darkmode_color( $name ) {

	static $colors;

	if ( null === $colors ) {

		$colors = json_decode( file_get_contents( __DIR__ . '/colors.json' ), true );

	}


	if ( false === isset( $colors[ $name ] ) ) {

		return '#' . $name;

	}

	return $colors[ $name ];

}

function append_color_variables( $colors ) {

	if ( empty( $colors ) ) {

		return false;

	}

	$path = WPSD_ADM_ASSETS_DIR . '/wp-admin/css/colors/modern/colors.css';

	$dir = dirname( $path );

	if ( false === wp_mkdir_p( $dir ) ) {

		return false;

	}

	$css = file_exists( $path ) ? file_get_contents( $path ) : '';

	if ( false === $css ) {

		return false;

	}

	$variables = "\n\n:root {\n";

	foreach ( $colors as $name => $value ) {

		$variables .= "\t--wpsd-dm-{$name}: {$value};\n";

	}

	// $variables .= <<<HTML
	//   --wp-admin-theme-color: #23368c;


	// HTML;
	$variables .= "}\n";

	return false !== file_put_contents( $path, $css . $variables );

}
