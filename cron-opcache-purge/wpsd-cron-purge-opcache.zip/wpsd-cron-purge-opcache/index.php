<?php

/*
* Plugin Name: TESTING VERSION OPcache purge with cron
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Purge OPcache periodically to avoid OPCache issues.
* Version: 1.0.2
* Updated: 2024-07-10
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: cron-purge-opcache
* License: GPLv3
* Requires at least: 5.0
* Requires PHP: 7.0.0
*/	

namespace WPSD\cron_purge_opcache;

defined( 'ABSPATH' ) || die;

add_action( 'upgrader_process_complete', __NAMESPACE__.'\save_update_data', 10, 2 );

register_deactivation_hook( __FILE__, __NAMESPACE__.'\plugin_deactivation_main' );
	
register_activation_hook( __FILE__, __NAMESPACE__.'\plugin_activation_main' );

function plugin_deactivation_main(){

	debl('deactivation');

}

function plugin_activation_main() {

	debl('activation');

}

function store_setup_hook($hook_name){

	$uri = $_SERVER['REQUEST_URI']??'no uri';

	$action  = isset($_POST['action']) ? " {$_POST['action']}" :'';

	$filename = date("Y-m-d_H:i:s");

	file_put_contents( __DIR__ .'/setup.log',"{$filename} {$hook_name} {$uri}{$action}\n", FILE_APPEND);
	
}

function save_update_data( $upgrader_object=false, $options=false ){

	ob_start();
	
	var_dump($upgrader_object);

	debl( ob_get_clean(), '$upgrader_object' );
	
	debl($options,'$options');
	
}


switch(true){

	case wp_doing_ajax():
	case wp_doing_cron():

		if( ($_POST['action']??'') === 'update-plugin' || wp_doing_cron() ){
			
			require_once __DIR__.'/update.php';
		}

	break;

	case is_admin():

		// run_cron_code();
		
		require_once __DIR__.'/update.php';

		break;
	
	// case defined( 'DOING_CRON'):
		
		//disabled
		//run_cron_code();
		
		// break;

}

//disabled

/*
function run_cron_code(){
	
	add_action('wp', __NAMESPACE__ . '\\schedule_opcache_purge');

	add_action('purge_opcache_cron', __NAMESPACE__ . '\\purge_opcache');

}

function schedule_opcache_purge() {

	if(wp_next_scheduled('purge_opcache_cron')) return;

	wp_schedule_event(time(), 'hourly', 'purge_opcache_cron');
}

function purge_opcache() {
	
	if( !function_exists('opcache_reset') ) return;

	opcache_reset();

	if( defined( 'WP_DEBUG') && WP_DEBUG ) {

		error_log('OPcache purged');
	} 

}

*/
