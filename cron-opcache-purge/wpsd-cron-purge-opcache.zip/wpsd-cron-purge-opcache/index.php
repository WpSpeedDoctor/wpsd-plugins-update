<?php

/*
* Plugin Name: OPcache purge with cron
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Purge OPcache periodically to avoid OPCache issues.
* Version: 1.0.1
* Updated: 2024-07-10
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: cron-purge-opcache
* License: GPLv3
* Requires at least: 5.0
* Requires PHP: 7.0.0
*/	

namespace WPSD\cron_purge_opcache;

defined( 'ABSPATH' ) || die;

switch(true){

	case defined( 'DOING_AJAX' ):
		

		if( ($_POST['action']??'') === 'update-plugin' ){
			
			require_once __DIR__.'/update.php';
		}

	break;

	case is_admin():

		run_cron_code();
		
		require_once __DIR__.'/update.php';

		break;
	
	case defined( 'DOING_CRON'):
		
		run_cron_code();
		
		break;

}

function run_cron_code(){
	
	add_action('wp', __NAMESPACE__ . '\\schedule_opcache_purge');

	add_action('purge_opcache_cron', __NAMESPACE__ . '\\purge_opcache');

}

function schedule_opcache_purge() {

	if(wp_next_scheduled('purge_opcache_cron')) return;

	wp_schedule_event(time(), 'hourly', 'purge_opcache_cron');
}

function purge_opcache() {
	
	if( !function_exists('opcache_reset') ) return;

	opcache_reset();

	if( defined( 'WP_DEBUG') && WP_DEBUG ) {

		error_log('OPcache purged');
	} 

}


