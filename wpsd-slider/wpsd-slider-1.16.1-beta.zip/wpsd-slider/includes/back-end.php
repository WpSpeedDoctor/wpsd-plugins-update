<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require WPSD_SLIDER_DIR.'includes/class.form-components.php';

require WPSD_SLIDER_DIR.'includes/class.slider-data.php';

add_action('admin_enqueue_scripts', __NAMESPACE__.'\\enqueue_htmx');

add_action('wp_enqueue_scripts', __NAMESPACE__.'\\wpsd_enqueue_splide');

add_action('admin_head', __NAMESPACE__.'\\print_admin_css');
add_action('admin_head', __NAMESPACE__.'\\print_admin_js');

/**
 * functions only beyond this point
 */

function add_slider_metabox() {
	add_meta_box(
		'wpsd_slider_settings',
		__('Slider Settings', 'wpsd-slider'),
		__NAMESPACE__.'\render_slider_metabox',
		'wpsd-slider',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', __NAMESPACE__.'\add_slider_metabox');

function render_slider_metabox($post) {

	$data = get_form_data($post);

	//just to make heredocs happy
	$form_json = $data['templates_json'];

	echo <<<HTML
	<script>
		const formData = {$form_json};
	</script>
	<p>
		<input type="text" name="shortcode" value="{$data['shortcode']}" readonly style="width:{$data['shortcode_length']}">
		<span class="wpsd-ver-mid">{$data['shortcode_description']}</span>
	</p>
	HTML;


	$args = [
		__('Slides', 'wpsd-slider') => $data['slides_and_button'],
		__('Breakpoint 1', 'wpsd-slider') => $data['settings-breakpoint-1'],
		__('Breakpoint 2', 'wpsd-slider') => $data['settings-breakpoint-2'],
		__('Slider Settings', 'wpsd-slider') => $data['settings-main'],
		__('Custom css', 'wpsd-slider') => $data['settings-css'],
	];

	echo display_slider_tabs($args);

}

function display_slider_tabs($args) {

	$tabs = '';
	$contents = '';
	
	$active_tab_id = $_COOKIE['wpsd-slider-tab']??'slides';
	
	foreach ($args as $title => $content) {
		$tab_id = sanitize_title($title);
		$active_class = $tab_id===$active_tab_id ? ' nav-tab-active' : '';
		$display_style = $tab_id===$active_tab_id ? 'block' : 'none';

		$tabs .= <<<HTML
			<li data-tab="{$tab_id}" class="wpsd-slider-tab nav-tab{$active_class}">{$title}</li>
			HTML;
		
		$contents .= <<<HTML
			<div id="{$tab_id}" class="tab-content" style="display: {$display_style};">{$content}</div>
			HTML;
	}

	$output = <<<HTML
	<div class="slider-tabs-container">
		<div class="slider-tabs">
			{$tabs}
		</div>
		<div class="slider-tabs-content">
			{$contents}
		</div>
	</div>
	<script>
	jQuery(document).ready(function($) {
		$('.slider-tabs li').click(function() {
			var tab_id = $(this).data('tab');

			// Store tab_id in a cookie only when a tab is clicked
			document.cookie = "wpsd-slider-tab=" + tab_id + "; path=/;";

			$('.tab-content').hide();
			$('#' + tab_id).show();
			$('.slider-tabs li').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
		});
	});

	</script>
	HTML;

	return $output;
}

function get_form_data($post){

	$data = new Slider_Data($post->ID);

	$settings = $data->get_settings();

	$shortcode = "[wpsd-slider id='{$post->ID}' cache='transient' ttl='84600']";

	require_once WPSD_SLIDER_DIR.'includes/splide-data.php';

	$template_data = [];

	foreach( get_splide_templates() as $key => $value ){

		unset( $value['name'] );

		$template_data[$key] = $value;
	} 
	
	$templates_json = json_encode($template_data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
	
	$data = [

		'settings-main'			=> get_settings_markup($settings,'main'),
		'settings-breakpoint-1'	=> get_settings_markup($settings,'bp1'),
		'settings-breakpoint-2'	=> get_settings_markup($settings,'bp2'),
		'settings-css'			=> get_settings_markup($settings,'custom-css'),
		'slides_and_button'		=> Form_Component::get_slides_markup($settings),
		'shortcode' 			=> $shortcode,
		'shortcode_length' 		=> (strlen($shortcode)-1).'ch',
		'shortcode_description'	=> __("Use object='object' if you have Redis or Memcached active.",'wpsd-slider'),
		'templates_json'    	=> $templates_json,
	];

	return $data;
}

function get_image_sizes_option(){

	static $options;

	if( $options ) return $options;

	$image_sizes = get_intermediate_image_sizes();

	$options = [
		
		'none' => __('None', 'wpsd-slider'),
		'full' => __('Full', 'wpsd-slider')

			];

	foreach($image_sizes as $size){
		
		if(isset(wp_get_additional_image_sizes()[$size])){

			$dimensions = wp_get_additional_image_sizes()[$size];
		
		}else{
			$dimensions = [
				'width'  => get_option("{$size}_size_w"),
				'height' => get_option("{$size}_size_h")
			];
		}

		$width = $dimensions['width'] ?? __('unknown', 'wpsd-slider');
		$height = $dimensions['height'] ?? __('unknown', 'wpsd-slider');

		$options[$size] = ucwords(str_replace(['-', '_'], ' ', $size)) . " ({$width}x{$height})";
	}

	return $options;
}

//MARK:Setting Element
function get_settings_markup( $settings, $type ){

	$form_elements = get_settings_elements( $type );
	
	$output = '';

	foreach($form_elements as $tag_args){
		
		$piece_markup = get_form_component($tag_args,$settings,$type);

		$output .= <<<HTML
		<div class="form-row">
			{$piece_markup}
		</div>

		HTML;
	}

	return $output;
}

function get_settings_elements( $type ){

	$form_elements = get_settings_elements_data();

	//TODO: redo tabs
	if( $type==='custom-css' ){
		return [
			['name'          => 'custom-css',
			'label'         => __('Custom CSS','wpsd-slider'),
			'type'          => 'textarea',
			'default'		=> false
			]
		];
	}

	remove_useless_elements( $form_elements, $type );

	if( $type !=='main' ) {

		remove_defaults_for_breakpoints( $form_elements );
	}

	return $form_elements;

}

function remove_defaults_for_breakpoints( &$form_elements ){

	foreach( array_keys($form_elements) as $key ){
	
		$form_elements[$key]['default'] = false;
	}

}

function remove_useless_elements( &$form_elements, $type ){

	if( $type == 'main' ){
		
		$excluded_elements = ['breakpoint'];

	} else {

		$excluded_elements = ['template', 'main-size','mobile-size','lazyLoad','type', 'first-eager','css'];
	}

	foreach( $form_elements as $key => $element){
		
		if( in_array( $element['name'], $excluded_elements ) ){

			unset($form_elements[$key]);
		}

	}
}

function get_settings_elements_data(){

	static $form_elements;

	if( $form_elements ) {

		return $form_elements;
	}
	
	$form_elements = [
		[
			'type'			=> 'select',
			'name'			=> 'template',
			'label' 		=> __('Template','wpsd-slider'),
			'options'		=> get_slider_templates_dropdown(),
			'default'		=> 'empty'
		],
		[
			'type'			=> 'select',
			'name'			=> 'main-size',
			'label' 		=> __('Main image Size','wpsd-slider'),
			'options'		=> get_image_sizes_option(),
			'default'		=> 'none'
		],
		[
			'type'			=> 'select',
			'name'			=> 'mobile-size',
			'label' 		=> __('Mobile image Size','wpsd-slider'),
			'options'		=> get_image_sizes_option(),
			'default'		=> 'none'
		],
		[
			'name'          => 'breakpoint',
			'label'         => __('Breakpoint width','wpsd-slider'),
			'type'          => 'number',
			'default'		=> 0
		],
		[
			'type'			=> 'select',
			'name'			=> 'type',
			'label' 		=> __('Type','wpsd-slider'),
			'options'		=> get_slider_types_dropdown(),
			'default'		=> 'slide'
		],
		[
			'name'          => 'first-eager',
			'label'         => __('First image loading="eager"','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => true
		],
		[
			'name'          => 'arrows',
			'label'         => __('Arrows','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'pagination',
			'label'         => __('Pagination','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'autoplay',
			'label'         => __('Autoplay','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		// [
		// 	'name'          => 'thumbnails',
		// 	'label'         => __('Thumbnails','wpsd-slider'),
		// 	'type'          => 'checkbox',
		// 	'default'       => false
		// ],
		[
			'name'          => 'perPage',
			'label'         => __('Items per Page','wpsd-slider'),
			'type'          => 'number',
			'default'		=> 1
		],
		[
			'name'          => 'perMove',
			'label'         => __('Items per Move','wpsd-slider'),
			'type'          => 'number',
			'default'		=> 1
		],
		[
			'name'          => 'focus',
			'label'         => __('Focus Position','wpsd-slider'),
			'type'          => 'text',
			'default'		=> 'center'
		],
		[
			'name'          => 'gap',
			'label'         => __('Gap between Items','wpsd-slider'),
			'type'          => 'text',
			'default'		=> '1rem'
		],
		[
			'name'          => 'padding',
			'label'         => __('Padding','wpsd-slider'),
			'type'          => 'text',
			'default'		=> false
		],
		[
			'name'          => 'width',
			'label'         => __('Width','wpsd-slider'),
			'type'          => 'text',
			'default'		=> ''
		],
		[
			'name'          => 'height',
			'label'         => __('Height','wpsd-slider'),
			'type'          => 'text',
			'default'		=> ''
		],
		[
			'name'          => 'fixedWidth',
			'label'         => __('Fixed Width','wpsd-slider'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'fixedHeight',
			'label'         => __('Fixed Height','wpsd-slider'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'autoWidth',
			'label'         => __('Auto Width','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'autoHeight',
			'label'         => __('Auto Height','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'rtl',
			'label'         => __('Right to Left','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'speed',
			'label'         => __('Animation Speed','wpsd-slider'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'interval',
			'label'         => __('Autoplay Interval','wpsd-slider'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'pauseOnHover',
			'label'         => __('Pause on Hover','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'pauseOnFocus',
			'label'         => __('Pause on Focus','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'drag',
			'label'         => __('Enable Drag','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'snap',
			'label'         => __('Snap to Items','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'keyboard',
			'label'         => __('Keyboard Navigation','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => true
		],
		// [
		// 	'name'          => 'lazyLoad',
		// 	'label'         => __('Lazy Load','wpsd-slider'),
		// 	'type'          => 'select',
		// 	'options'       => ['none' => 'None', 'nearby' => 'Nearby'],
		// 	'default'      => 'none'
		// ],
		[
			'name'          => 'rewind',
			'label'         => __('Rewind','wpsd-slider'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'rewindSpeed',
			'label'         => __('Rewind Speed','wpsd-slider'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'easing',
			'label'         => __('Easing Function','wpsd-slider'),
			'options'		=> get_easing_options(),
			'type'          => 'select',
			'default'		=> ''
		],
		// [
		// 	'name'          => 'content',
		// 	'label'         => 'empty-content',
		// 	'type'          => 'hidden',
		// 	'default'		=> 'empty'
		// ],
	
	];

	return $form_elements;
}

function get_slider_templates_dropdown(){

	static $slider_types_dropdown;

	if( $slider_types_dropdown ) return $slider_types_dropdown;

	$slider_types_dropdown = [];

	foreach( get_splide_templates() as $slider_name => $slider_data ){

		$slider_types_dropdown[ $slider_name ] = $slider_data['name'];
		
	}

	return $slider_types_dropdown;
}

function get_slider_types_dropdown(){

	return [
		'slide'	=> __('Slide','wpsd-slider'),
		'loop'	=> __('Loop','wpsd-slider'),
		'fade'	=> __('Fade','wpsd-slider'),
	];
}

function get_easing_options(){

	return [
		''				=> '',
		'ease'			=> __('Ease', 'wpsd-slider'),
		'linear'		=> __('Linear', 'wpsd-slider'),
		'ease-in'		=> __('Ease In', 'wpsd-slider'),
		'ease-out'		=> __('Ease Out', 'wpsd-slider'),
		'ease-in-out'	=> __('Ease In Out', 'wpsd-slider'),
		'step-start'	=> __('Step Start', 'wpsd-slider'),
		'step-end'		=> __('Step End', 'wpsd-slider'),
	];

}

function get_form_component( $args, $settings, $type ){

	$value = $settings[$type][$args['name']]??$args['default'];

	$selected = is_selected( $value, $args );
	
	switch( $args['type'] ){

		case 'select':

			$output = get_select_component($args,$settings,$type);
			break;
		
		case 'checkbox':
		
			$checked_markup = $selected ? ' checked' : '';

			$output = <<<HTML
			<span class="wpsd-label wpsd-label-checkbox">{$args['label']}</span>
				<input type="checkbox" name="{$type}[{$args['name']}]"{$checked_markup}>
			HTML;
			break;

		case 'number':
			
			$number_markup = $selected !==false ? ' value="'.$value.'"' : '';
			
			$output = <<<HTML
			<span class="wpsd-label wpsd-label-number">{$args['label']}</span>
				<input type="number" name="{$type}[{$args['name']}]"{$number_markup}>
			HTML;
			break;

		case 'text':

			$text_markup = $selected !==false ? ' value="'.$value.'"' : '';

			$output = <<<HTML
			<span class="wpsd-label wpsd-label-text">{$args['label']}</span>
				<input type="text" name="{$type}[{$args['name']}]" {$text_markup}>
			HTML;
			break;

		case 'textarea':

			$textarea_markup = esc_html($value);

			$name_markup = ( $args['name']==='main[custom-css]' ) ? 'custom-css' : "{$type}[{$args['name']}]";
			
			$output = <<<HTML
			<span class="wpsd-label wpsd-label-textarea">{$args['label']}</span>
				<textarea style="width:100%" name="{$name_markup}" rows="20">$textarea_markup</textarea>
			HTML;
			
			break;

		case 'hidden':
			$output = <<<HTML
			<input type="hidden" name="post_content" value="empty">
			HTML;
			break;

		default:
			$output = $args['type'];
			break;
	}

	return $output;
}

function is_selected( $value, $args ){

	return match( $args['type'] ){

		'select' 	=> !empty($value),
		'checkbox'	=> $value === 'on',
		'number'	=> is_numeric($value),
		'text'		=> $value !== '',
		'textarea'	=> $value !== '',
		default		=> false
	};

}

function get_select_component($args,$settings,$type){

	$options_html = '';

	$selected_from_settings = $settings[$type][$args['name']]??'';

	$selected = empty($selected_from_settings) ? $args['default'] : $selected_from_settings;

	foreach($args['options'] as $key => $value){
		
		$selected_markup = $key === $selected ? ' selected' : '';

		$options_html .= <<<HTML
		<option value="{$key}"{$selected_markup}>{$value}</option>
		HTML;
	}

	return <<<HTML
	<span for="{$args['name']}" class="wpsd-label wpsd-label-dropdown">{$args['label']}</span>
	<select name="{$type}[{$args['name']}]">
		{$options_html}
	</select>
	HTML;
	
}

//MARK: SAVE
add_action('save_post', __NAMESPACE__.'\\wpsd_save_slider_data');

function wpsd_save_slider_data($post_id){

	Slider_Data::save_settings($_POST);
	
}

function enqueue_htmx(){

	$url_dir = get_plugin_dir_url();

	wp_enqueue_script('htmx', "{$url_dir}assets/htmx.min.js", null, '2.1');

	wp_enqueue_media();

	wp_enqueue_script('wpsd-slider-admin', "{$url_dir}assets/wpsd-slider-backend.js", null, WPSD_SLIDER_VER);
}

//Life is too short to properly enqueue a very short admin scripts that are exclusive to my CPT
function print_admin_css(){

	?>
<style type="text/css">
<?php
echo file_get_contents( WPSD_SLIDER_DIR.'assets/wpsd-slider-backend.css' );
?>
</style>
	<?php
}

function print_admin_js(){

	?>
<script>
	document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("wpsd-slider-inner");

    if (!container) return;

    container.addEventListener("input", function (event) {
        const input = event.target;
        if (input.tagName === "INPUT" && input.name.includes("link")) {
            input.style.border = isValidLink(input.value.trim()) ? "" : "1px solid red";
        }
    });

    function isValidLink(value) {
		if(value==="") return true;
        const urlPattern = /^(https?:\/\/[^\s]+|#[a-zA-Z0-9_-]+)$/;
        return urlPattern.test(value);
    }
});
</script>
	<?php
}