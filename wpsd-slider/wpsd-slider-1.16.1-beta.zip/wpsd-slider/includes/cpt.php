<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

function register_wpsd_slider_cpt(){

	register_post_type('wpsd-slider', [
		'labels' => [
			'name' => __('Sliders', 'wpsd-slider'),
			'singular_name' => __('Slider', 'wpsd-slider'),
			'add_new' => __('Add New Slider', 'wpsd-slider'),
			'add_new_item' => __('Add New Slider', 'wpsd-slider'),
			'edit_item' => __('Edit Slider', 'wpsd-slider'),
			'new_item' => __('New Slider', 'wpsd-slider'),
			'view_item' => __('View Slider', 'wpsd-slider'),
			'search_items' => __('Search Sliders', 'wpsd-slider'),
			'not_found' => __('No Sliders found', 'wpsd-slider'),
			'not_found_in_trash' => __('No Sliders found in Trash', 'wpsd-slider'),
			'all_items' => __('All Sliders', 'wpsd-slider'),
		],
		'public' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => ['title'],
	]);

}
add_action('init', __NAMESPACE__.'\register_wpsd_slider_cpt');
