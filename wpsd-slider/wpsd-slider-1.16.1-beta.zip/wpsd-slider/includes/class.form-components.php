<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;


class Form_Component{

	private int $loop_key;

	private int $loop_last;

	private string $ajax_url;

	private $slides;

	public function __construct($post=[]){

		$this->slides = $post['wpsd-slide']??[];

		$this->ajax_url = admin_url('/admin-ajax.php?wpsd-slider-ajax');

		if(empty($_POST['wpsd-form-action'])){
			
			return;
		}

		$form_action = $_POST['wpsd-form-action'];

		if( $form_action === 'add-row'){
				
				$this->slides[] =  $this->get_empty_slide_array();
		}
		
		if( $form_action === 'move-slide' && is_numeric($_POST['wpsd-move-slide']??false) ){
			
			$this->move_action();

		}

		if(!empty($_POST)){

		// 	die( '<span style="white-space: pre;line-height: 2;">'.var_export( $this->slides ,true ).'</span>' );
		// 	// die( '<span style="white-space: pre;line-height: 2;">'.var_export( $_POST['wpsd-form-action']??'' ,true ).'</span>' );
		}
		
	}

	private function move_action(){
		
		$moved_slide = (int) $_POST['wpsd-move-slide'];
	
		$temp = $this->slides[$moved_slide];

		if( ($_POST['wpsd-move-direction']??'') === 'up' ){

			$this->slides[$moved_slide] = $this->slides[$moved_slide-1];
			$this->slides[$moved_slide-1] = $temp;

		}else{

			$this->slides[$moved_slide] = $this->slides[$moved_slide+1];
			$this->slides[$moved_slide+1] = $temp;
		}
		
	}

	static public function get_slides_markup($settings){

		$components = new Form_Component($settings);

		$slides_markup = $components->get_slides();

		$add_slide_button_markup = $components->get_the_add_button();

		return <<<HTML
		<div id="wpsd-slider-container">
			<div id="wpsd-slider-inner">
				{$slides_markup}
				{$add_slide_button_markup}
			</div>
		</div>
		HTML;
		

	}
	
	private function get_empty_slide_array(){

		return [ 
				 	'cta-link'=>'',
					'cta-makrup'=>'',
					'image-id'=>0
		];
	}

	public function get_slides(){

		if( empty($this->slides) ) return '';

		$output = '';
		
		$this->loop_last = key(array_slice($this->slides, -1, 1, true));

		foreach( $this->slides as $key => $slide ){
			
			$this->loop_key = $key;

			$row_markup = $this->get_a_row($slide, $key);
	
			$output .= <<<HTML
			<div class="wpsd-metabox-slide">
				{$row_markup}
			</div>
			HTML;
		}

		return $output;
	}

	public function get_the_add_button(){

		$button_text = __('Add slide', 'wpsd-slider');

		$output = <<<HTML
		<button class="button button-primary button-large wpsd-add-slide"
					hx-post='{$this->ajax_url}'
					hx-target="#wpsd-slider-inner"
					hx-swap="innerHTML">{$button_text}<input type="hidden" name="wpsd-form-action" value="add-row" />
			</button>
		HTML;

		return $output;
	}

	public function get_up_down_buttons(){

		if( $this->has_single_slide() ){
			return '';
		}

		$output = '';

		if( $this->loop_key !==0 ){

			$output .= $this->get_move_button( 'up' );

		}
		
		if( $this->loop_key !== $this->loop_last ){

			$output .= $this->get_move_button( 'down' );
			
		}

		return <<<HTML
		<div class="wpsd-move-button-container">
			{$output}
		</div>
		HTML;
	}

	private function get_move_button( $action_string ){
		
		$values = [
			'wpsd-form-action'		=> 'move-slide',
			'wpsd-move-direction'	=> $action_string,
			'wpsd-move-slide'		=> $this->loop_key
		];

		$htmx_values = $this->get_htmx_encoded_values($values);

		$icon = $action_string === 'up' ? '▲' : '▼';

		$title = $action_string === 'up' ? __('Move up', 'wpsd-slider') : __('Move down', 'wpsd-slider');

		return <<<HTML
				<button class="button wpsd-button-move" title="{$title}"
				hx-post='{$this->ajax_url}'
				hx-vals='{$htmx_values}'
				hx-target="#wpsd-slider-inner"
				hx-swap="innerHTML">
					{$icon}
			</button>
		HTML;
		
	}

	private function get_the_remove_button(){

	$button_text = __('Remove slide', 'wpsd-slider');

	$output = <<<HTML
	<button class="button wpsd-remove-slide">{$button_text}</button>
	HTML;

	return $output;

	}

	public function get_a_row( $slide_values, $key ){
	
		$row_data = $this->get_row_data($slide_values, $key);

		return <<<HTML
			<p>{$row_data['slide_number_text']}<span id="slider-position-{$row_data['slide_number']}">{$row_data['slide_number']}<span></p>
			<div class="wpsd-metabox-slide-content">
				<div class="wpsd-metabox-slide-left">{$row_data['cta_link_label']}<br>
					<input 	type="text"
							name="wpsd-slide[{$key}][cta-link]"
							value="{$row_data['cta_link']}"
							placeholder="{$row_data['input_link_placeholder']}">
					<br>{$row_data['cta_markup_label']}
					<textarea type="text" name="wpsd-slide[{$key}][cta-markup]" placeholder="{$row_data['cta_markup_placeholder']}"
					>{$row_data['cta_markup']}</textarea>
					<input type="hidden" name="wpsd-slide[{$key}][image-id]" value="{$row_data['image_id']}">
					{$row_data['remove_button_markup']}
					{$row_data['move_buttons']}
				</div>
				<div class="wpsd-metabox-slide-right">
					{$row_data['image_link_label']}<br>
					<input type="text" name="wpsd-slide[{$key}][image-link]" value="{$row_data['image_link']}" placeholder="{$row_data['input_link_placeholder']}">
					{$row_data['image_preview_markup']}
					<button type="button" class="button wpsd-upload-slide-image">
						{$row_data['upload_text']}
					</button>
				</div>
			</div>
		HTML;
	}
	
	private function get_row_data( $slide_values, $key ){

		return [
			
			'cta_link'					=> $slide_values['cta-link']??'',

			'cta_markup' 				=> htmlentities( $slide_values['cta-markup']??'' ),
			
			'image_id'					=> $slide_values['image-id']??0,
			
			'image_link' 				=> $slide_values['image-link']??'',
			
			'image_preview_markup' 		=> $this->get_image_preview_markup($slide_values['image-id']??0),
			
			'remove_button_markup'		=> $this->get_the_remove_button($key),

			'move_buttons'				=> $this->get_up_down_buttons(),
			
			'slide_number' 				=> $key+1,
			
			'upload_text' 				=> __('Upload Image', 'wpsd-slider'),
			
			'image_link_label' 			=> __('Image link', 'wpsd-slider'),
			
			'input_link_placeholder' 	=> __('URL or anchor( e.g. #offer )', 'wpsd-slider'),
			
			'cta_link_label' 			=> __('CTA link', 'wpsd-slider'),
			
			'cta_markup_label'			=> __('CTA markup', 'wpsd-slider'),

			'cta_markup_placeholder'	=> __('Text or HTML markup', 'wpsd-slider'),

			'slide_number_text'			=> __('Slide #', 'wpsd-slider'),
		
		];
	}
	
	private function get_image_preview_markup($image_id=0){

		if( empty($image_id)) return '';

		$image_src = wp_get_attachment_image_src( $image_id, 'full' )[0];

		if( empty($image_src) ) return '';

		return <<<HTML
		<img src='{$image_src}' class="wpsd-slide-preview">
		HTML;
		
	}

	private function has_single_slide(){
	
		return $this->loop_key === 0 && $this->loop_last === 0;
	}

	private function get_htmx_encoded_values($htmx_values){
	
		return json_encode($htmx_values, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
		
	}

}