<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

class Data_Validator {

	static public function get_validated_value($key,$value){

		$validation_type = self::get_field_validation_type($key);

		switch( $validation_type ) {

			case 'url':
				return self::get_validated_url($value);

			case 'number':
				return filter_var($value, FILTER_VALIDATE_INT);

			case 'checkbox':
				return empty($value) ? '': 'on';

			case 'focus':
				return (is_numeric($value) || $value==='center') ? $value : '';
			
			case 'css-value':
				return sanitize_text_field($value);
			
			case 'css-inline':
				return sanitize_textarea_field($value);

			case 'html':
				return wp_kses_post($value);
			
			case 'text':
				return sanitize_text_field($value);

			default:
				return $value;
		}
		
	}

	static function get_validated_url( $url) {
		
		switch( true ){

			case empty($url):
			case !is_string($url):

			case !($parsed_url = parse_url($url)):
				$result = false;
				break;

			//only fragment url e.g. #content
			case array_keys($parsed_url) === ['fragment']:
				$result = sanitize_text_field($url);
				break;

			case empty($url):
			case $url[0] !== 'h': //to disqualify ftp://
			case str_contains($url,'@'): //to early disqualify email
			case str_contains($url,'user:'): //to early disqualify login
			case str_contains($url,'..'): // 'http://example..com' will pass as a valid URL by var_filter() WTF?!
				$result = false;
				break;
			
			default:
				$result = filter_var($url, FILTER_VALIDATE_URL);
				break;
		}

		return $result;
	}

	static function get_field_validation_type($field_name){
	
		return match($field_name) {

			'cta-link',		'image-link'						=> 'url',

			'cta-markup'										=> 'html',

			'image-id',		'breakpoint',		'perPage',
			'perMove',		'fixedWidth',		'fixedHeight',
			'speed',		'interval',			'rewindSpeed'	=> 'number',

			'arrows',		'pagination',		'autoplay',
			'autoWidth',	'autoHeight',		'rtl',
			'pauseOnHover',	'pauseOnFocus',		'drag',
			'snap',			'keyboard',			'rewind',
			'first-eager'										=> 'checkbox',

			'focus'												=> 'focus',

			'gap',			'padding',			'width',
			'height',		'focus'								=> 'css-value',

			'easing',		'template',			'main-size',
			'mobile-size',	'type'								=> 'text',

			'css'												=> 'css-inline',

			default												=> null,
		};

	}

}