<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Lightweight slider using Splide.js by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/wpsd-slider/
* Description: Slider is a bad idea, but if you really need it, this is the your best choice for the performance.
* Version: 1.12
* Updated: 2025-03-02
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-log
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 8.0.0
*/	

require_once __DIR__.'/constants.php';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){
	
	switch( get_wp_request_type() ){

		case REQUEST_AJAX:
			
			if( isset($_GET['wpsd-slider-ajax']) ){

				require WPSD_SLIDER_DIR.'includes/ajax-handler.php';
			}

			if( ($_POST['action']??'') === 'delete-plugin' ){

				require WPSD_SLIDER_DIR.'includes/uninstall.php';
			}

			if( ($_POST['action']??'') === 'update-plugin' ) {
				
				require_once WPSD_SLIDER_DIR.'includes/update.php';
			}
			
			break;

		case REQUEST_ADMIN:
			
			require WPSD_SLIDER_DIR.'includes/cpt.php';

			add_action('load-post.php', __NAMESPACE__.'\load_cpt_admin');

			add_action('load-post-new.php', __NAMESPACE__.'\load_cpt_admin');

			require_once WPSD_SLIDER_DIR.'includes/update.php';

			break;
			
		case REQUEST_FRONTEND:
				
			add_shortcode('wpsd-slider', __NAMESPACE__.'\\execute_shortcode');

			break;

	}
		
}

function execute_shortcode($args){

	if( !is_numeric($args['id']??false) ) {

		return get_invalid_slider_id_response();
	}

	// add_filter( 'wp_content_img_tag', __NAMESPACE__.'\\remove_useless_wp_attr', 10, 3 );

	$result = empty($args['ttl']) ? false : get_cached_slider_markup($args);

	if( $result !== false ){
		
		wpsd_enqueue_splide();

		return $result;
	}

	require_once WPSD_SLIDER_DIR.'includes/main.php';
	
	$result = get_rendered_slider_main( $args );

	// remove_filter( 'wp_content_img_tag', __NAMESPACE__.'\\remove_useless_wp_attr' );

	return $result;
}

function remove_useless_wp_attr($filtered_image, $context, $attachment_id){

	if( $attachment_id === 0 && str_contains( $filtered_image,'fetchpriority="high"')){

		$filtered_image = str_replace(' decoding="async"','',$filtered_image);
	}
	
	return $filtered_image;

}

function get_invalid_slider_id_response(){

	$text = current_user_can('administrator') ? __( 'Invalid slider ID.','plugin-domain' ) : '';

	return $text;
}

function wpsd_enqueue_splide(){

	$url_dir = get_plugin_dir_url();

	$splide_version = '4.1.3';

	wp_enqueue_style('splide-css', "{$url_dir}assets/splide.min.css", null, $splide_version);
	wp_enqueue_script('splide-js', "{$url_dir}assets/splide.min.js", null, $splide_version);
}

function get_plugin_dir_url(){

	static $url_dir;

	$url_dir || $url_dir = plugin_dir_url(__FILE__);

	return $url_dir;
}

function get_cached_slider_markup($args){

	switch($args['cache']??false){

		case 'object':
			return wp_cache_get("wpsd-slider-{$args['id']}");

		case 'transient':
			return get_transient("wpsd-slider-{$args['id']}");
		
        default:
		    return false;
	}

}

function load_cpt_admin(){
	
    if( (get_current_screen()->post_type??'') !== 'wpsd-slider'){
		
		return;
	};

	require WPSD_SLIDER_DIR.'includes/back-end.php';
}


//https://www.scandinavianphoto.fi/
