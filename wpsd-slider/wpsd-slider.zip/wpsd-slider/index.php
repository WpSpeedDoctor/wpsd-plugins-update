<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Lightweight slider using Splide.js by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/wpsd-slider/
* Description: Slider is a bad idea, but if you really need it, this is the your best choice for the performance.
* Version: 1.19
* Updated: 2025-09-01
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-slider
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 8.0.0
*/	

require_once __DIR__.'/constants.php';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){
	
	require WPSD_SLIDER_DIR.'includes/cpt.php';

	switch( WPSD_REQUEST_TYPE ){

		case REQUEST_AJAX:
			
			if( isset($_GET['wpsd-slider-ajax']) ){

				require WPSD_SLIDER_DIR.'includes/ajax-handler.php';
			}

			if( ($_POST['action']??'') === 'update-plugin' ) {
				
				require_once WPSD_SLIDER_DIR.'includes/update.php';
			}
			
			break;

		case REQUEST_ADMIN:

			global $pagenow;

			$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

			if ( $page_now === 'plugins.php' ) {
			
				register_uninstall_hook( __FILE__, __NAMESPACE__.'\plugin_uninstall' );

			}
			
			add_action('load-post.php', __NAMESPACE__.'\load_cpt_admin');

			add_action('load-post-new.php', __NAMESPACE__.'\load_cpt_admin');

			require_once WPSD_SLIDER_DIR.'includes/update.php';

			//language domain
			add_action('plugins_loaded', __NAMESPACE__.'\load_language_domain');

			break;
			
		case REQUEST_FRONTEND:
				
			require WPSD_SLIDER_DIR.'includes/request-front-end.php';
			break;

	}
		
}

function load_cpt_admin(){
	
    if( (get_current_screen()->post_type??'') !== 'wpsd-slider'){
		
		return;
	};

	require WPSD_SLIDER_DIR.'includes/cpt-admin-menu.php';
}

function load_language_domain(){

	load_plugin_textdomain('advanced-plugin-filter', false, basename(WPSD_SLIDER_DIR) . '/languages/');
}

function plugin_uninstall(){

	$posts = get_posts([
		'post_type'			=> 'wpsd-slider',
		'posts_per_page'	=> -1,
		'post_status'		=> 'any',
	]);

	if(empty($posts)){

		return;
	}

	foreach($posts as $post){
		wp_delete_post( $post->ID, true );
	}
}