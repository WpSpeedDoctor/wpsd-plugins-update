<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require WPSD_SLIDER_DIR.'includes/class.data-validator.php';

class Slider_Data{

	public const DATA_POSTMETA_KEY = 'wpsd-slider';

	private array $settings = [];

	private int $post_id;

	public function __construct( $post_id ){
	
		$this->set_post_id($post_id);

		$this->set_slider_settings();
		
	}

	private function set_post_id( $post_id){
	
		if( !is_numeric( $post_id ) ){

			$post_id = 0;
		}

		$this->post_id = absint( $post_id );

	}

	private function set_slider_settings(){

		if( !$this->is_valid_id() ){
			
			$this->settings = [];
			
			return;
		}

		$settings_raw = get_post_meta( $this->post_id, self::DATA_POSTMETA_KEY, true );

		if( empty( $settings_raw) || !is_array($settings_raw)){

			$this->settings = [];
			
			return;
		}

		if( is_array( $settings_raw ) ){

			$this->settings = $settings_raw;

			return;
		}

		$settings = maybe_unserialize($settings_raw);

		$this->settings = ( !empty($settings) && is_array($settings) ) ? $settings : [];

	}

	private function is_valid_id(){
	
		return $this->post_id !== 0;
	}

	public function get_settings(){
	
		return $this->settings;
	}

	static function save_settings($post){
			
		static $is_saved;

		switch(true){

			case $is_saved:
			case defined('DOING_AUTOSAVE'):
			case empty($post['post_type']):
			case empty($post['_wpnonce']):
			case $post['post_type'] !== 'wpsd-slider':
			case !is_numeric($post['post_ID']):
			case !wp_verify_nonce( $post['_wpnonce'], 'update-post_' . $post['post_ID'] ):
			case !current_user_can('edit_post', $post['post_ID']):

				return;
			
		}

		$is_saved = true;

		$data_to_save = self::get_sanitized_slider_data($post);

		update_post_meta( $post['post_ID'], self::DATA_POSTMETA_KEY, $data_to_save );

		self::delete_cache($post['post_ID']);
	}
	
	static function get_sanitized_slider_data($post){
		
		$data_to_save['main'] = self::get_sanitized_slider_sub_data($post['main']??[]);

		$data_to_save['bp1'] = self::get_sanitized_slider_sub_data($post['bp1']??[]);

		$data_to_save['bp2'] = self::get_sanitized_slider_sub_data($post['bp2']??[]);

		$data_to_save['custom-css'] = self::get_sanitized_slider_sub_data($post['custom-css']??[]);

		$data_to_save['wpsd-slide'] = self::get_sanitized_slider_sub_data($post['wpsd-slide']??[]);

		return $data_to_save;
	}

	static function get_sanitized_slider_sub_data($post_category_array){
		
		if(empty($post_category_array) || !is_array($post_category_array) ){
			return [];
		}

		$post_category_array = self::validate_values_by_keys($post_category_array);

		return $post_category_array;

	}

	static function validate_values_by_keys($array){

		$array = self::remove_empty_value($array);

		foreach( $array as $key => $value ){

			if( is_array($value) ){

				$array[$key] = self::validate_values_by_keys($value);
			
			} else {

				$array[$key] = Data_Validator::get_validated_value($key,$value);
			}
		}

		return $array;
	}

	static function delete_cache($slider_id){

		if( !$slider_id || !is_numeric($slider_id) || $slider_id === 0 ){

			return;
		}

		$cache_key = "wpsd-slider-{$slider_id}";

		if( wp_cache_get( $cache_key ) ){

			wp_cache_delete( $cache_key );
		}

		if( get_transient( $cache_key ) ){

			delete_transient( $cache_key );
		}
	}

	static function remove_empty_value($array){

		$array = array_filter($array, function($value){
			return $value!== '' && $value!== false && $value!== null;
		});

		return $array;

	}
}