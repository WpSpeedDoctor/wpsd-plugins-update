<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require WPSD_SLIDER_DIR.'includes/class.form-components.php';

add_action('admin_enqueue_scripts', __NAMESPACE__.'\\enqueue_htmx');

add_action('wp_enqueue_scripts', __NAMESPACE__.'\\wpsd_enqueue_splide');

add_action('admin_head', __NAMESPACE__.'\\print_admin_css');
add_action('admin_head', __NAMESPACE__.'\\print_admin_js');

/**
 * functions only beyond this point
 */

function add_slider_metabox() {
	add_meta_box(
		'wpsd_slider_settings',
		__('Slider Settings', 'plugin-domain'),
		__NAMESPACE__.'\render_slider_metabox',
		'wpsd-slider',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', __NAMESPACE__.'\add_slider_metabox');

function render_slider_metabox($post) {

	$data = get_form_data($post);

	//just to make heredocs happy
	$form_json = $data['templates_json'];

	echo <<<HTML
	<script>
		const formData = {$form_json};
	</script>
	<p><input type="text" name="shortcode" value="{$data['shortcode']}" readonly style="width:{$data['shortcode_length']}"></p>
	HTML;


	$args = [
		__('Slides', 'plugin-domain') => $data['slides_and_button'],
		__('Settings', 'plugin-domain') => $data['settings-main'],
		__('Breakpoint 1', 'plugin-domain') => $data['settings-breakpoint-1'],
		__('Breakpoint 2', 'plugin-domain') => $data['settings-breakpoint-2'],
	];

	echo display_slider_tabs($args);

}

function display_slider_tabs($args) {

	$tabs = '';
	$contents = '';
	
	$active_tab_id = $_COOKIE['wpsd-slider-tab']??'settings';
	
	foreach ($args as $title => $content) {
		$tab_id = sanitize_title($title);
		$active_class = $tab_id===$active_tab_id ? 'nav-tab-active' : '';
		$display_style = $tab_id===$active_tab_id ? 'block' : 'none';
		$tabs .= "<li data-tab='{$tab_id}' class='nav-tab {$active_class}'>{$title}</li>";
		$contents .= "<div id='{$tab_id}' class='tab-content' style='display: {$display_style};'>{$content}</div>";
	}

	$output = <<<HTML
	<div class="slider-tabs-container">
		<div class="slider-tabs">
			{$tabs}
		</div>
		<div class="slider-tabs-content">
			{$contents}
		</div>
	</div>
	<script>
	jQuery(document).ready(function($) {
		$('.slider-tabs li').click(function() {
			var tab_id = $(this).data('tab');

			// Store tab_id in a cookie only when a tab is clicked
			document.cookie = "wpsd-slider-tab=" + tab_id + "; path=/;";

			$('.tab-content').hide();
			$('#' + tab_id).show();
			$('.slider-tabs li').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
		});
	});

	</script>
	HTML;

	return $output;
}

function get_form_data($post){

	$settings = empty( $post->post_content ) ? get_post_meta( $post->ID, 'wpsd-slider', true ) : json_decode( $post->post_content, true );

	$shortcode = "[wpsd-slider id='{$post->ID}' cache='object' ttl='84600']";

	require_once WPSD_SLIDER_DIR.'includes/splide-data.php';

	$template_data = [];

	foreach( get_splide_templates() as $key => $value ){

		unset( $value['name'] );

		$template_data[$key] = $value;
	} 
	
	$templates_json = json_encode($template_data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
	
	$data = [

		'settings-main'			=> get_settings_markup($settings,'main'),
		'settings-breakpoint-1'	=> get_settings_markup($settings,'bp1'),
		'settings-breakpoint-2'	=> get_settings_markup($settings,'bp2'),
		'slides_and_button'		=> Form_Component::get_slides_markup($settings),
		'shortcode' 			=> $shortcode,
		'shortcode_length' 		=> (strlen($shortcode)-1).'ch',
		'templates_json'    	=> $templates_json,
	];

	return $data;
}

function get_image_sizes_option(){

	static $options;

	if( $options ) return $options;

	$image_sizes = get_intermediate_image_sizes();

	$options = [
		
		'none' => __('None', 'plugin-domain'),
		'full' => __('Full', 'plugin-domain')

			];

	foreach($image_sizes as $size){
		
		if(isset(wp_get_additional_image_sizes()[$size])){

			$dimensions = wp_get_additional_image_sizes()[$size];
		
		}else{
			$dimensions = [
				'width'  => get_option("{$size}_size_w"),
				'height' => get_option("{$size}_size_h")
			];
		}

		$width = $dimensions['width'] ?? __('unknown', 'plugin-domain');
		$height = $dimensions['height'] ?? __('unknown', 'plugin-domain');

		$options[$size] = ucwords(str_replace(['-', '_'], ' ', $size)) . " ({$width}x{$height})";
	}

	return $options;
}

//MARK:Setting Element
function get_settings_markup( $settings, $type ){

	$form_elements = get_settings_elements( $type );
	
	$output = '';

	foreach($form_elements as $tag_args){
		
		$piece_markup = get_form_component($tag_args,$settings,$type);

		$output .= <<<HTML
		<div class="form-row">
			{$piece_markup}
		</div>

		HTML;
	}

	return $output;
}

function get_settings_elements( $type ){

	$form_elements = get_settings_elements_data( $type );

	remove_useless_elements( $form_elements, $type );

	if( $type !=='main' ) {

		remove_defaults_for_breakpoints( $form_elements );
	}

	return $form_elements;

}

function remove_defaults_for_breakpoints( &$form_elements ){

	foreach( array_keys($form_elements) as $key ){
	
		$form_elements[$key]['default'] = false;
	}

}

function remove_useless_elements( &$form_elements, $type ){

	if( $type == 'main' ){
		
		$excluded_elements = ['breakpoint'];

	} else {

		$excluded_elements = ['template', 'main-size','mobile-size','lazyLoad','type', 'first-eager','css'];
	}

	foreach( $form_elements as $key => $element){
		
		if( in_array( $element['name'], $excluded_elements ) ){

			unset($form_elements[$key]);
		}

	}
}

function get_settings_elements_data(){

	static $form_elements;

	if( $form_elements ) {

		return $form_elements;
	}
	
	$form_elements = [
		[
			'type'			=> 'select',
			'name'			=> 'template',
			'label' 		=> __('Template','plugin-domain'),
			'options'		=> get_slider_templates_dropdown(),
			'default'		=> 'empty'
		],
		[
			'type'			=> 'select',
			'name'			=> 'main-size',
			'label' 		=> __('Main image Size','plugin-domain'),
			'options'		=> get_image_sizes_option(),
			'default'		=> 'none'
		],
		[
			'type'			=> 'select',
			'name'			=> 'mobile-size',
			'label' 		=> __('Mobile image Size','plugin-domain'),
			'options'		=> get_image_sizes_option(),
			'default'		=> 'none'
		],
		[
			'name'          => 'breakpoint',
			'label'         => __('Breakpoint width','plugin-domain'),
			'type'          => 'number',
			'default'		=> 0
		],
		[
			'type'			=> 'select',
			'name'			=> 'type',
			'label' 		=> __('Type','plugin-domain'),
			'options'		=> get_slider_types_dropdown(),
			'default'		=> 'slide'
		],
		[
			'name'          => 'arrows',
			'label'         => __('Arrows','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'pagination',
			'label'         => __('Pagination','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'autoplay',
			'label'         => __('Autoplay','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		// [
		// 	'name'          => 'thumbnails',
		// 	'label'         => __('Thumbnails','plugin-domain'),
		// 	'type'          => 'checkbox',
		// 	'default'       => false
		// ],
		[
			'name'          => 'perPage',
			'label'         => __('Items per Page','plugin-domain'),
			'type'          => 'number',
			'default'		=> 1
		],
		[
			'name'          => 'perMove',
			'label'         => __('Items per Move','plugin-domain'),
			'type'          => 'number',
			'default'		=> 1
		],
		[
			'name'          => 'first-eager',
			'label'         => __('First image eager','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => true
		],
		[
			'name'          => 'focus',
			'label'         => __('Focus Position','plugin-domain'),
			'type'          => 'text',
			'default'		=> 'center'
		],
		[
			'name'          => 'gap',
			'label'         => __('Gap between Items','plugin-domain'),
			'type'          => 'text',
			'default'		=> '1rem'
		],
		[
			'name'          => 'padding',
			'label'         => __('Padding','plugin-domain'),
			'type'          => 'text',
			'default'		=> false
		],
		[
			'name'          => 'width',
			'label'         => __('Width','plugin-domain'),
			'type'          => 'text',
			'default'		=> ''
		],
		[
			'name'          => 'height',
			'label'         => __('Height','plugin-domain'),
			'type'          => 'text',
			'default'		=> ''
		],
		[
			'name'          => 'fixedWidth',
			'label'         => __('Fixed Width','plugin-domain'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'fixedHeight',
			'label'         => __('Fixed Height','plugin-domain'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'autoWidth',
			'label'         => __('Auto Width','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'autoHeight',
			'label'         => __('Auto Height','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'rtl',
			'label'         => __('Right to Left','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'speed',
			'label'         => __('Animation Speed','plugin-domain'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'interval',
			'label'         => __('Autoplay Interval','plugin-domain'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'pauseOnHover',
			'label'         => __('Pause on Hover','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'pauseOnFocus',
			'label'         => __('Pause on Focus','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'drag',
			'label'         => __('Enable Drag','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'snap',
			'label'         => __('Snap to Items','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'keyboard',
			'label'         => __('Keyboard Navigation','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => true
		],
		// [
		// 	'name'          => 'lazyLoad',
		// 	'label'         => __('Lazy Load','plugin-domain'),
		// 	'type'          => 'select',
		// 	'options'       => ['none' => 'None', 'nearby' => 'Nearby'],
		// 	'default'      => 'none'
		// ],
		[
			'name'          => 'rewind',
			'label'         => __('Rewind','plugin-domain'),
			'type'          => 'checkbox',
			'default'       => false
		],
		[
			'name'          => 'rewindSpeed',
			'label'         => __('Rewind Speed','plugin-domain'),
			'type'          => 'number',
			'default'		=> false
		],
		[
			'name'          => 'easing',
			'label'         => __('Easing Function','plugin-domain'),
			'options'		=> get_easing_options(),
			'type'          => 'select',
			'default'		=> ''
		],
		[
			'name'          => 'css',
			'label'         => __('CSS','plugin-domain'),
			'type'          => 'textarea',
			'default'		=> false
		]
	
	];

	return $form_elements;
}

function get_slider_templates_dropdown(){

	static $slider_types_dropdown;

	if( $slider_types_dropdown ) return $slider_types_dropdown;

	$slider_types_dropdown = [];

	foreach( get_splide_templates() as $slider_name => $slider_data ){

		$slider_types_dropdown[ $slider_name ] = $slider_data['name'];
		
	}

	return $slider_types_dropdown;
}

function get_slider_types_dropdown(){

	return [
		'slide'	=> __('Slide','plugin-domain'),
		'loop'	=> __('Loop','plugin-domain'),
		'fade'	=> __('Fade','plugin-domain'),
	];
}

function get_easing_options(){

	return [
		''				=> '',
		'ease'			=> __('Ease', 'plugin-domain'),
		'linear'		=> __('Linear', 'plugin-domain'),
		'ease-in'		=> __('Ease In', 'plugin-domain'),
		'ease-out'		=> __('Ease Out', 'plugin-domain'),
		'ease-in-out'	=> __('Ease In Out', 'plugin-domain'),
		'step-start'	=> __('Step Start', 'plugin-domain'),
		'step-end'		=> __('Step End', 'plugin-domain'),
	];

}

function get_form_component( $args, $settings, $type ){

	$value = $settings[$type][$args['name']]??$args['default'];

	$selected = is_selected( $value, $args );
	
	switch( $args['type'] ){

		case 'select':

			$output = get_select_component($args,$settings,$type);
			break;
		
		case 'checkbox':
		
			$checked_markup = $selected ? ' checked' : '';

			$output = <<<HTML
			<label class="wpsd-label wpsd-label-checkbox">{$args['label']}</label>
				<input type="checkbox" name="{$type}[{$args['name']}]"{$checked_markup}>
			HTML;
			break;

		case 'number':
			
			$number_markup = $selected !==false ? ' value="'.$value.'"' : '';
			
			$output = <<<HTML
			<label class="wpsd-label wpsd-label-number">{$args['label']}</label>
				<input type="number" name="{$type}[{$args['name']}]"{$number_markup}>
			HTML;
			break;

		case 'text':

			$text_markup = $selected !==false ? ' value="'.$value.'"' : '';

			$output = <<<HTML
			<label class="wpsd-label wpsd-label-text">{$args['label']}</label>
				<input type="text" name="{$type}[{$args['name']}]" {$text_markup}>
			HTML;
			break;

		case 'textarea':

			$textarea_markup = esc_html($value);

			$output = <<<HTML
			<label class="wpsd-label wpsd-label-textarea">{$args['label']}</label>
				<textarea style="width:100%" name="{$type}[{$args['name']}]" rows="4">$textarea_markup</textarea>
			HTML;
			
			break;

		default:
			$output = $args['type'];
			break;
	}

	return $output;
}

function is_selected( $value, $args ){

	return match( $args['type'] ){

		'select' 	=> !empty($value),
		'checkbox'	=> $value === 'on',
		'number'	=> is_numeric($value),
		'text'		=> $value !== '',
		'textarea'	=> $value !== '',
	};

}

function get_select_component($args,$settings,$type){

	//TODO: implement $value and $selected from previous code
	$options_html = '';

	$selected_from_settings = $settings[$type][$args['name']]??'';

	$selected = empty($selected_from_settings) ? $args['default'] : $selected_from_settings;

	foreach($args['options'] as $key => $value){
		
		$selected_markup = $key === $selected ? ' selected' : '';

		$options_html .= <<<HTML
		<option value="{$key}"{$selected_markup}>{$value}</option>
		HTML;
	}

	return <<<HTML
	<label for="{$args['name']}" class="wpsd-label wpsd-label-dropdown">{$args['label']}</label>
	<select name="{$type}[{$args['name']}]">
		{$options_html}
	</select>
	HTML;
	
}

//MARK: SAVE
add_action('save_post', __NAMESPACE__.'\\wpsd_save_slider_data');

function wpsd_save_slider_data($post_id){

	static $is_saved;

	switch(true){

		case $is_saved:
		case defined('DOING_AUTOSAVE'):
		case empty($_POST['post_type']):
		case empty($_POST['_wpnonce']):
		case $_POST['post_type'] !== 'wpsd-slider':
		case !wp_verify_nonce( $_POST['_wpnonce'], 'update-post_' . $post_id ):
		case !current_user_can('edit_post', $post_id):

			return;
		
	}

	$is_saved = true;
	
	$data_to_save['main'] = $_POST['main']??[];

	$data_to_save['bp1'] = remove_empty_value($_POST['bp1']??[]);

	$data_to_save['bp2'] = remove_empty_value($_POST['bp2']??[]);


	foreach( ($_POST['wpsd-slide']??[]) as $slide_data ){

		$data_to_save['wpsd-slide'][] = $slide_data;
	}
	
	update_post_meta( $post_id, 'wpsd-slider', $data_to_save );
	
	wp_update_post([
		'ID' => $post_id,
		'post_content' => '',

	]);

	delete_cache($post_id);
}

function delete_cache($slider_id){

	if( wp_cache_get("wpsd-slider-{$slider_id}") ){

		wp_cache_delete("wpsd-slider-{$slider_id}");
	}

	if( get_transient("wpsd-slider-{$slider_id}") ){

		delete_transient("wpsd-slider-{$slider_id}");
	}
}

function remove_empty_value($array){

	$array = array_filter($array, function($value){
        return $value!== '' && $value!== false && $value!== null;
    });

	return $array;

}

function enqueue_htmx(){

	$url_dir = get_plugin_dir_url();

	wp_enqueue_script('htmx', "{$url_dir}assets/htmx.min.js", null, '2.1');

	wp_enqueue_media();

	wp_enqueue_script('wpsd-slider-admin', "{$url_dir}assets/wpsd-slider-backend.js", null, WPSD_SLIDER_VER);
}

//Life is too short to properly enqueue a very short admin scripts that are exclusive to my CPT
function print_admin_css(){

	?>
<style type="text/css">
.wpsd-metabox-slide,
.vertical-tags{
	display: flex;
	flex-direction: column;
	row-gap: 10px;
}
.wpsd-metabox-slide {
    border-bottom: 1px grey solid;
    padding-bottom: 10px;
    margin-bottom: 10px;
}
.horizontal-tags{
	display: flex;
	flex-direction: row;
	row-gap: 10px;
}
.wpsd-upload-slide-image,
.wpsd-slide-preview,
.wpsd-remove-slide{
	max-width:fit-content;
}

.wpsd-slide-preview{
	max-height: 100px;
	height:auto;
	object-fit:contain;
}
.mt10,
#wpsd-slider-inner .wpsd-add-slide{
	margin-top:10px;
}
.mb10{
	margin-bottom: 10px;
}


.form-row {
    display: flex;
    justify-content: flex-start;
    margin-bottom: 20px;
    gap: 20px;
}

.form-column {
	display: flex;
	align-items: center;
}
.form-column-second{
	width:20%;
}

.form-column label {
	margin-right: 10px;
	font-weight: bold;
	white-space: nowrap;
}

.form-column select,
.form-column input[type="checkbox"] {
	flex-grow: 1;
}
.wpsd-label{
    min-width: 30ch;
}

/* Add numbers to pagination buttons by CSS */
.splide__pagination {
  counter-reset: pagination-num;
}

.splide__pagination__page:before {
  counter-increment: pagination-num;
  content: counter( pagination-num );
}
.slider-tabs {
	list-style: none;
	padding: 0;
	display: flex;
}

.slider-tabs li {
	cursor: pointer;
}

.slider-tabs li.nav-tab-active {
	background: #007cba;
	color: #fff;
}

.tab-content {
	padding: 15px;
	border: 1px solid #ddd;
}
</style>
	<?php
}

function print_admin_js(){

	?>
<script>
	document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("wpsd-slider-inner");

    if (!container) return;

    container.addEventListener("input", function (event) {
        const input = event.target;
        if (input.tagName === "INPUT" && input.name.includes("link")) {
            input.style.border = isValidLink(input.value.trim()) ? "" : "1px solid red";
        }
    });

    function isValidLink(value) {
		if(value==="") return true;
        const urlPattern = /^(https?:\/\/[^\s]+|#[a-zA-Z0-9_-]+)$/;
        return urlPattern.test(value);
    }
});
</script>
	<?php
}