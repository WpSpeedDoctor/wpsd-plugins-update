<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

add_shortcode('wpsd-slider', __NAMESPACE__.'\\execute_shortcode');

add_action('plugins_loaded', __NAMESPACE__.'\load_language_domain');

function execute_shortcode($args){

	if( !is_numeric($args['id']??false) ) {

		return get_invalid_slider_id_response();
	}

	if( !is_args_legit($args) ){

		return get_invalid_shortcode_response();
	}
	
	$result = get_cached_slider_markup($args);
	
	if( empty($result) ){

		require_once WPSD_SLIDER_DIR.'includes/main.php';
		
		$result = get_rendered_slider_main( $args );
	}
	
	if( empty($result) ){

		return get_invalid_slider_id_response();	
	}
	
	wpsd_enqueue_splide();
	
	static $is_splide_css_inlined;

	if( !defined('WPSD_SLIDER_SPLIDE_ENQUEUED') && is_null($is_splide_css_inlined) ){
		
		$is_splide_css_inlined = true;

		$splide_css = file_get_contents( WPSD_SLIDER_DIR.'assets/splide.min.css' );

		$result = <<<HTML
		<style id="splide-inlined-css">{$splide_css}</style>
		{$result}
		HTML;
	}

	return $result;
}

function get_invalid_slider_id_response(){

	$text = current_user_can('administrator') ? __( 'Invalid slider ID.','wpsd-slider' ) : '';

	return $text;
}

function get_invalid_shortcode_response(){

	$text = current_user_can('administrator') ? __( 'Invalid shortcode attributes.','wpsd-slider' ) : '';

	return $text;
}

function wpsd_enqueue_splide(){

	$url_dir = plugin_dir_url( WPSD_SLIDER_DIR.'a');

	$splide_version = '4.1.3';

	if( defined('WPSD_SLIDER_SPLIDE_ENQUEUED') ){

		wp_enqueue_style('splide', "{$url_dir}assets/splide.min.css", null, $splide_version);
	}

	wp_register_script('splide', "{$url_dir}assets/splide.min.js", null, $splide_version, array(
    'in_footer' => true,
    'strategy' => 'defer'
	));
	
	wp_enqueue_script('splide');

}

function is_args_legit($args){
	
	switch(true){

		case isset($args['ttl']) && !is_numeric($args['ttl']):

		case isset($args['cache']) && !( $args['cache'] === 'transient' || $args['cache'] === 'object' ):
			return false;
			break;
		default:
			return true;
	}

}

function get_cached_slider_markup($args){
	
	switch($args['cache']??''){

		case 'transient':
			return get_transient("wpsd-slider-{$args['id']}");

		case 'object':
			return wp_cache_get("wpsd-slider-{$args['id']}");

		default:
			return false;
	}

}