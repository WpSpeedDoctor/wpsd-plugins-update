<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

function register_wpsd_slider_cpt(){

	register_post_type('wpsd-slider', [
		'labels' => [
			'name' => __('Sliders', 'plugin-domain'),
			'singular_name' => __('Slider', 'plugin-domain'),
			'add_new' => __('Add New Slider', 'plugin-domain'),
			'add_new_item' => __('Add New Slider', 'plugin-domain'),
			'edit_item' => __('Edit Slider', 'plugin-domain'),
			'new_item' => __('New Slider', 'plugin-domain'),
			'view_item' => __('View Slider', 'plugin-domain'),
			'search_items' => __('Search Sliders', 'plugin-domain'),
			'not_found' => __('No Sliders found', 'plugin-domain'),
			'not_found_in_trash' => __('No Sliders found in Trash', 'plugin-domain'),
			'all_items' => __('All Sliders', 'plugin-domain'),
		],
		'public' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => ['title'],
	]);

}
add_action('init', __NAMESPACE__.'\register_wpsd_slider_cpt');
