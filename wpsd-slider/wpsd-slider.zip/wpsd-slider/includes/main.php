<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require_once WPSD_SLIDER_DIR.'includes/class.slider-render.php';

function get_rendered_slider_main( $args ){

	$slider = new WPSD_Slider_Render( $args['id'] );
	
	$slider->rendered_slider();

	if( !$slider->has_succeeded ){

		return get_invalid_slider_id_response();
	}
	
	if( empty($slider->slider_markup) ) return '';

	wpsd_enqueue_splide();

	record_slider_markup_to_cache( $slider->slider_markup, $args );
	
    return $slider->slider_markup;
}

function record_slider_markup_to_cache( $result, $args ){

	if( empty($args['ttl']) ){

		return;
	}

	switch($args['cache']??''){
		
		case 'object':
			
            wp_cache_set("wpsd-slider-{$args['id']}", $result, null, $args['ttl'] );
            break;
			
        case 'transient':
			set_transient("wpsd-slider-{$args['id']}", $result, $args['ttl'] );
			break;
	}
}

/**
 * this CSS has to be printed directly to have effect on the right moment.
 */
function get_inlined_general_css(){
	
	static $printed_general_css;

	//only once per page
	if( $printed_general_css ) {
		
		return '';

	}

	$printed_general_css = true;

	$inlined_css = <<<HTML
	<style id="wpsd-slider-inline-css">
		.wpsd-slide-wrap{
			position: relative;
		}
		a.wpsd-splide-link {
			height: 100%;
			display: block;
		}
		img.wpsd-slide-image {
			height: 100%;
			object-fit: cover;
		}
		.wpsd-slider-default-cta{
			position:absolute;
			top: 50%; 
			left: 50%;
			transform: translate(-50%, -50%);
			color: white;
			background-color: #000000b3;
			padding: 0 10px;
			border-radius: 5px;
		}
		.wpsd-slider-main.splide{
			visibility: visible;
		}
		.wpsd-slider-main .splide__slide {
	    	max-width: 100%;
		}
	</style>

	HTML;

	return apply_filters('wpsd-slider-css', $inlined_css);
}