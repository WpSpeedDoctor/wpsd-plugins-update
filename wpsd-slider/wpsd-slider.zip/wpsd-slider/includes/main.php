<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require_once WPSD_SLIDER_DIR.'includes/class.slider-render.php';

function get_rendered_slider_main( $args ){

	$slider = new WPSD_Slider_Render( $args['id'] );
	
	$slider->rendered_slider();

	if( !$slider->has_succeeded ){

		return get_invalid_slider_id_response();
	}
	
	if( empty($slider->slider_markup) ) return '';

	wpsd_enqueue_splide();

	record_slider_markup_to_cache( $slider->slider_markup, $args );
	
    return $slider->slider_markup;
}

function add_args_defaults( &$args,$image_id ){

	$args['main-size']		??= 'full';
	$args['mobile-size']	??= 'smartphone';
	$args['class']			??= 'wpsd-slide-img wp-image-'.$image_id;
	$args['priority']		??= false;
	$args['responsive']		= $args['main-size'] !== $args['mobile-size'];
}

function get_image_data( $image_id, $args ){
	
	$main_url = wp_get_attachment_url( $image_id );
	
	if( empty( $main_url ) ) return false;

	$alt_raw = get_post_meta( $image_id, '_wp_attachment_image_alt', true );

	$alt_markup = empty( $alt_raw )? '' : ' alt="'.esc_html($alt_raw).'" ';

	$image_data = [
		
		'main-url'			=> $main_url,

		'height'			=> wp_get_attachment_metadata( $image_id )['height'],

		'width'				=> wp_get_attachment_metadata( $image_id )['width'],

		'alt-markup'		=> $alt_markup,

	];

	if( !$args['responsive'] ) {
	
		return $image_data;

	}

	$image_data['mobile-url'] = wp_get_attachment_image_src( $image_id, 'smartphone' )[0];
	
	return $image_data;
}

function get_rendered_slider( $slides, $settings ){

	$slider_id = "wpsd-slider-{$settings['id']}";

	$slides_html = '';

	foreach ($slides as $key => $slide_markup) {
	
		$slides_html .= <<<HTML
		<li class='splide__slide wpsd-slide-{$key}'>{$slide_markup}</li>
		HTML;
	
	}
	
	foreach( $settings['wpsd-slider-settings'] as $key => $value){

		switch(true){

			// case $key === 'css':
			case $key === 'template':
			case $key === 'main-size':
			case $key === 'mobile-size':
			case $value === '':
			case $value === ' ':
				continue 2;
		}

		$splide_args[$key] = $value;
	}
	
	$splide_args['arrows']??=false;
	$splide_args['pagination']??=false;

	$args_json = empty( $splide_args ) ? '{}' : json_encode($splide_args, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

	$html = <<<HTML
	<div class="splide" id="{$slider_id}">
		<div class="splide__track">
			<ul class="splide__list">
				{$slides_html}
			</ul>
		</div>
	</div>
	<script id ="wpsd-{$slider_id}">
	document.addEventListener('DOMContentLoaded', function() {
		new Splide('#{$slider_id}', {$args_json}).mount();
	});
	</script>
	HTML;

	return $html;
}

function get_slider_id(){

	static $slider_id=0;

	return ++$slider_id;
}

function get_splide_type_args($type) {

	require_once WPSD_SLIDER_DIR.'includes/splide-data.php';

	return get_splide_templates()[$type]??false;
}

function record_slider_markup_to_cache( $result, $args ){

	if( empty($args['ttl']) || !is_numeric($args['ttl']) ){

		return;
	}

	switch($args['cache']??''){
		
		case 'object':
			
            wp_cache_set("wpsd-slider-{$args['id']}", $result, null, $args['ttl'] );
            break;
			
        case 'transient':
			set_transient("wpsd-slider-{$args['id']}", $result, $args['ttl'] );
			break;
	}
}

function get_inlined_general_css(){
	
	static $printed_general_css;

	//only once per page
	if( $printed_general_css ) {
		
		return '';

	}

	$printed_general_css = true;

	$inlined_css = <<<HTML
	<style id="wpsd-slider-inline-css">
		.wpsd-slide-wrap{
			position: relative;
		}
		a.wpsd-splide-link {
			height: 100%;
			display: block;
		}
		img.wpsd-slide-image {
			height: 100%;
			object-fit: cover;
		}
		.wpsd-slider-default-cta{
			position:absolute;
			top: 50%; 
			left: 50%;
			transform: translate(-50%, -50%);
			color: white;
			background-color: #000000b3;
			padding: 0 10px;
			border-radius: 5px;
		}
		.wpsd-slider-main.splide{
			visibility: visible;
		}
		.wpsd-slider-main .splide__slide {
	    	max-width: 100%;
		}
	</style>

	HTML;

	return apply_filters('wpsd-slider-css', $inlined_css);
}