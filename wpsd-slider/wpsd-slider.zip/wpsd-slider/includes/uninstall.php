<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

delete_wpsd_slider_posts();

function delete_wpsd_slider_posts(){
    $posts = get_posts(array(
        'post_type'      => 'wpsd-slider',
        'posts_per_page' => -1,
        'post_status'    => 'any',
    ));

    if(empty($posts)){
	
		return;
	}

    foreach($posts as $post){
        wp_delete_post($post->ID, true);
    }

}


