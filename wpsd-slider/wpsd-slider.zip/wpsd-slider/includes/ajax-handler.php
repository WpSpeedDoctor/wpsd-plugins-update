<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

require WPSD_SLIDER_DIR.'includes/class.form-components.php';

switch( $_POST['action']??'' ){

	case 'editpost':

		$components = new Form_Component( $_POST );

		$output = $components->get_slides();
	
		$output .= $components->get_the_add_button();

		break;
    default:

	    $output = 'Wrong action';
		break;
		
}

echo $output;

die;