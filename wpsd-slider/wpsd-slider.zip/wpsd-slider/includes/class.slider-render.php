<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

class WPSD_Slider_Render{

	private $slider_id;

	private $slider_instance;

	private $settings;

	private $slides_data;

	public $has_succeeded = true;

	public $slider_markup='';

	public function __construct( $slider_id ){

		$this->slider_id = $slider_id;
		
		$post = get_post( $slider_id) ;
		
		$settings = get_post_meta( $post->ID, 'wpsd-slider', true );

		if( !is_array($settings) || empty($settings) ){
			
			$this->has_succeeded = false;
            
			return;
		}

		$this->slider_instance = "{$slider_id}-".bin2hex(random_bytes(2));

		$this->slides_data = apply_filters( 'wpsd-slider-data', $settings['wpsd-slide'], $slider_id);

		unset( $settings['wpsd-slide'] );

		$this->settings = $settings;
				
	}
	
	private function render_images(){

		if( empty( $this->slides_data ) ) return false;

		$args = [];
		
		foreach ( $this->slides_data as $key => $slide_data) {

			$args['priority'] = !empty($this->settings['main']['first-eager'] ) && $key === 0;

			$args['class'] = "wpsd-slide-image slider-{$this->slider_id}-img-{$slide_data['image-id']}";

			$image_markup = $this->get_image_markup( $slide_data['image-id'], $args );

			$this->add_image_link( $image_markup, $slide_data);

			if (!$image_markup){

				continue;
			}

			$this->slides_data[$key]['image-markup'] = $image_markup;
			
		}

	}

	private function add_image_link( &$image_markup, $slide_data ){

		if( empty($slide_data['image-link']) ) return;
		


		$image_markup = <<<HTML
		<a href="{$slide_data['image-link']}" class="wpsd-slider-image-link">
			{$image_markup}
		</a>
		HTML;
	}

	private function get_slide_inner( $slide_data ){

		$cta_markup = $this->get_cta_markup( $slide_data );

		if(	empty($slide_data['cta-link'] ) ){

			return $slide_data['image-markup'].$cta_markup;

		}

		return <<<HTML
		{$slide_data['image-markup']}
		<a href="{$slide_data['cta-link']}" class="wpsd-splide-link">{$cta_markup}</a>
		HTML;

	}

	private function get_cta_markup( $slide_data ){
		
		if( empty($slide_data['cta-markup']) ) return '';

		$has_markup = strip_tags($slide_data['cta-markup']) !== $slide_data['cta-markup'];

		if( $has_markup ) {

			return $slide_data['cta-markup'];
		}

		return <<<HTML
		<div class="wpsd-slider-default-cta">{$slide_data['cta-markup']}</div>
		HTML;
	}

	public function rendered_slider(){
		
		if( !$this->has_succeeded ){
			
            return '';
		}

		$this->render_images();

		$slides_html = '';
	
		foreach ($this->slides_data as $key => $slide_data) {
		
			$slide_inner = $this->get_slide_inner( $slide_data );
			
			$slide_class_id = $key+1;

			$slides_html .= <<<HTML
			<li class='splide__slide wpsd-slide-{$slide_class_id}'>
				<div class="wpsd-slide-wrap">
					{$slide_inner}
				</div>
			</li>
			HTML;
		
		}
		
		$args_json = $this->get_splide_args(); 
		
		$slider_instance = "wpsd-slider-{$this->slider_instance}";

		$general_css = get_inlined_general_css();

		$slider_settings_css = $this->get_slider_settings_css();

		$html = <<<HTML
		{$general_css}{$slider_settings_css}
		<div class="wpsd-slider-main splide" id="{$slider_instance}">
			<div class="splide__track">
				<ul class="splide__list">
					{$slides_html}
				</ul>
			</div>
		</div>
		<script>
		document.addEventListener('DOMContentLoaded', function() {
			new Splide('#{$slider_instance}', {$args_json}).mount();
		});
		</script>
		HTML;
	
		$this->slider_markup = $html;

	}

	private function get_slider_settings_css(){
		
		if( empty($this->settings['main']['css']) ){
			
			return '';
		}

		return <<<HTML
		<style id="wpsd-slider-id-{$this->slider_id}-inline-css">
		{$this->settings['main']['css']}
		</style>
		HTML;

	}

	private function get_splide_args(){

		foreach( $this->settings['main'] as $key => $value){
	
			switch(true){
				case $key === 'css':
				case $key === 'template':
				case $key === 'main-size':
				case $key === 'mobile-size':
				case $key === 'first-eager':
				case $value === '':
				case $value === ' ':
					continue 2;
			}
	
			$splide_args[$key] = $value === 'on' ? true : $value;
		}
		
		$splide_args['arrows']??=false;

		$splide_args['pagination']??=false;
	

		$this->add_breakpoints_data( $splide_args );

		if(empty( $splide_args )) {

			return '{}';
		} 

		$splide_args = apply_filters('wpsd-slider-splide-args', $splide_args, $this->slider_id );

		return json_encode($splide_args, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);

	}

	private function add_breakpoints_data( &$splide_args ){

		$bp1_settings = $this->get_breakpoint_settings('bp1');

		$bp2_settings = $this->get_breakpoint_settings('bp2');

		if( !empty( $bp1_settings )) {

			$splide_args['breakpoints'] = $bp1_settings;
		}

		if( !empty( $bp2_settings )) {

			$splide_args['breakpoints'] = $bp2_settings;
		}

	}

	private function get_breakpoint_settings($breakpoint_key){

		$bp_settings = $this->settings[$breakpoint_key]??false;

		if( empty( $bp_settings['breakpoint'] ) || !is_numeric($bp_settings['breakpoint']) ){

			return false;
		} 

		$bp_value = (int) $bp_settings['breakpoint'];

		unset( $bp_settings['breakpoint'] );
		
		$result[ $bp_value ] = $bp_settings;
		
		return $result;
	}

	private function get_image_markup( $image_id, $args ){
	
		$img = $this->get_image_data( $image_id, $args );
	
		if( empty( $img['main-url']) ) {

			return false;
		} 

		$img['priority_markup']	= $args['priority'] ? 'fetchpriority="high" loading="eager"': 'loading="lazy" decoding="async"';
		
		if( empty($img['mobile-url']) ){

			$output = <<<HTML
			<picture class="wpsd-slide-picture" >
				<img src="{$img['main-url']}" width="{$img['width']}" height="{$img['height']}" class="{$args['class']}" {$img['priority_markup']}{$img['alt-markup']}>
			</picture>
			HTML;

		} else {

		$output = <<<HTML
		<picture class="wpsd-slide-picture" >
			<source media="(min-width: {$img['mobile-width']}px)" srcset="{$img['main-url']}">
			<img src="{$img['mobile-url']}" width="{$img['width']}" height="{$img['height']}" class="{$args['class']}" {$img['priority_markup']}{$img['alt-markup']}>
		</picture>
		HTML;

		}
		
		return $output;
	}
	
	private function get_image_data( $image_id, $args ){
		
		$cache_key = "wpsd-slide:".$image_id.$this->settings['main']['main-size'].$this->settings['main']['mobile-size'];

		$cached_data = wp_cache_get( $cache_key );

		if( !empty($cached_data) ){

			return $cached_data;
		}
		
		$this->add_args_defaults( $args, $image_id );

		$main_img = wp_get_attachment_image_src( $image_id, $this->settings['main']['main-size'] );

		$main_url = $main_img[0];
		
		if( empty( $main_url ) ) return false;
	
		$alt_raw = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
	
		$alt_markup = empty( $alt_raw )? '' : ' alt="'.esc_html($alt_raw).'" ';
		
		$mobile_img = $this->get_mobile_image_url( $image_id, $main_url );

		$image_data = apply_filters( 'wpsd-slider-image', [
			
			'main-url'			=> $main_url,
	
			'height'			=> $main_img[2],
	
			'width'				=> $main_img[1],
	
			'alt-markup'		=> $alt_markup,
				
			'mobile-url'		=> $mobile_img[0],
			
			//ADD 10% to the image width make it load right in the browser
			'mobile-width'		=> $mobile_img[1] === false ? false : intval($mobile_img[1]*1.1)
	
		], $image_id, $this->slider_id);

		wp_cache_set( $cache_key,$image_data);

		return $image_data;
	}

	private function get_mobile_image_url( $image_id, $main_url ){
		
		static $mobile_img_default = [ 0 => false, 1 => false ];

		$mobile_img = apply_filters( 'wpsd-slider-mobile-image', false, $image_id, $this->slider_id);

		if( $mobile_img !== false ){

			return $this->is_mobile_img_valid( $mobile_img ) ? $mobile_img : $mobile_img_default;
		}

		if( $this->settings['main']['mobile-size'] === 'none' ) {

			return $mobile_img_default;

		}

		$mobile_img = wp_get_attachment_image_src( $image_id, $this->settings['main']['mobile-size'] );

		return $this->is_mobile_size_valid( $mobile_img, $main_url ) ? $mobile_img : $mobile_img_default;
		
	}

	private function is_mobile_size_valid( $mobile_img, $main_url ){

		return $mobile_img[0] !== $main_url;
	}
	
	private function is_mobile_img_valid( $mobile_img ){

		switch(true){

			case !filter_var( $mobile_img[0]??false, FILTER_VALIDATE_URL):
			case !is_numeric( $mobile_img[1]??false ):
				
				return false;
            default:
			    return true;

		}
	}
	
	private function add_args_defaults( &$args,$image_id ){

		$args['main-size']		??= 'full';
		$args['mobile-size']	??= 'none';
		$args['class']			??= 'wpsd-slide-img image-'.$image_id;
		$args['priority']		??= false;
	}
	
}