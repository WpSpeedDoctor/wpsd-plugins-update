<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

function get_splide_templates(){
	
	$data = [
		'empty' => [
			'name' => __('Empty', 'plugin-domain'),
			'type' => 'empty',
		],
		'carousel' => [
			'name' => __('Carousel', 'plugin-domain'),
			'type' => 'carousel',
			'perPage' => 3,
			'gap' => '1rem',
			'focus' => 'center',
			'rewind' => true,
		],
		'fade' => [
			'name' => __('Fade', 'plugin-domain'),
			'type' => 'fade',
			'speed' => 800
		],
		'loop' => [
			'name' => __('Loop', 'plugin-domain'),
			'type' => 'loop',
			'perPage' => 1,
			'autoplay' => true,
			'interval' => 3000,
			'pauseOnHover' => true
		],
		'slide' => [
			'name' => __('Slide', 'plugin-domain'),
			'type' => 'slide',
			'perPage' => 1,
			'pagination' => true,
			'arrows' => true
		]
	];

	return $data;
}

/*

$attributes = [
		'perPage' => 1,
		'perMove' => 1,
		'focus' => 'center',
		'gap' => '1rem',
		'padding' => '0',
		'width' => '100%',
		'height' => 'auto',
		'fixedWidth' => 0,
		'fixedHeight' => 0,
		'autoWidth' => false,
		'autoHeight' => false,
		'direction' => 'ltr',
		'rtl' => false,
		'speed' => 400,
		'autoplay' => false,
		'interval' => 5000,
		'pauseOnHover' => false,
		'pauseOnFocus' => false,
		'arrows' => true,
		'pagination' => true,
		'drag' => true,
		'snap' => false,
		'loop' => false,
		'clones' => 0,
		'start' => 0,
		'keyboard' => true,
		'lazyLoad' => 'nearby',
		'rewind' => false,
		'rewindSpeed' => 600,
		'waitForTransition' => true,
		'easing' => 'ease',
		'trimSpace' => true,
		'breakpoints' => [],
		'classes' => [],
		'isNavigation' => false,
		'updateOnMove' => false,
		'cover' => false,
		'depth' => 0,
		'scale' => 1,
		'fade' => false,
		'releaseWheel' => false,
		'wheel' => false
	];
	
	*/