<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;


class Form_Component{

	private $slides;

	public function __construct($post=[]){

		$this->slides = $post['wpsd-slide']??[];

		// if(empty($post['wpsd-slide'])){
			
		// 	die( '<span style="white-space: pre;line-height: 2;">'.var_export( $_POST ,true ).'</span>' );
			
			
		// }
		switch( $_POST['wpsd-form-action']??'' ){

			case 'add-row':
				
				$this->slides[] =  $this->get_empty_slide_array();
				break;
			case 'remove-row':
				unset($this->slides[ $post['remove-row'] ]);
				break;

		} 

		if(!empty($_POST)){

		// 	die( '<span style="white-space: pre;line-height: 2;">'.var_export( $this->slides ,true ).'</span>' );
		// 	// die( '<span style="white-space: pre;line-height: 2;">'.var_export( $_POST['wpsd-form-action']??'' ,true ).'</span>' );
		}
		
	}

	static public function get_slides_markup($settings){

		$components = new Form_Component($settings);

		$slides_markup = $components->get_slides();

		$add_slide_button_markup = $components->get_the_add_button();

		return <<<HTML
		<div id="wpsd-slider-container">
			<div id="wpsd-slider-inner">
				{$slides_markup}
				{$add_slide_button_markup}
			</div>
		</div>
		HTML;
		

	}
	
	private function get_empty_slide_array(){

		return [ 
				 	'cta-link'=>'',
					'cta-makrup'=>'',
					'image-id'=>0
		];
	}

	public function get_slides(){

		if( empty($this->slides) ) return '';

		$output = '';
		
		foreach( $this->slides as $key => $slide ){
		
			$row_markup = $this->get_a_row($slide, $key);
	
			$output .= <<<HTML
			<div class="wpsd-metabox-slide">
				{$row_markup}
			</div>
			HTML;
		}

		return $output;
	}

	public function get_the_add_button(){

	$button_text = __('Add slide', 'plugin-domain');

	$ajax_url = admin_url('/admin-ajax.php?wpsd-slider-ajax');

	$output = <<<HTML
	<button class="button button-primary button-large wpsd-add-slide"
				hx-post='{$ajax_url}'
				hx-target="#wpsd-slider-inner"
				hx-swap="innerHTML">{$button_text}<input type="hidden" name="wpsd-form-action" value="add-row" />
		</button>
	HTML;

	return $output;
	}

	private function get_the_remove_button(){

	$button_text = __('Remove slide', 'plugin-domain');

	$output = <<<HTML
	<button class="button wpsd-remove-slide">{$button_text}</button>
	HTML;

	return $output;

	}

	public function get_a_row( $slide_values, $key ){
	
		$row_data = $this->get_row_data($slide_values, $key);

		return <<<HTML
			<p>Slide #{$row_data['slide_number']}</p>
			{$row_data['image_preview_markup']}
			<button type="button" class="button wpsd-upload-slide-image">
				{$row_data['upload_text']}
			</button>
			<label>
				{$row_data['image_link_label']}
				<input type="text" name="wpsd-slide[{$key}][image-link]" value="{$row_data['image_link']}" placeholder="{$row_data['input_link_placeholder']}">
			</label>
			<label>
				{$row_data['cta_link_label']}
				<input type="text" name="wpsd-slide[{$key}][cta-link]" value="{$row_data['cta_link']}" placeholder="{$row_data['input_link_placeholder']}">
			</label>
			<label>
			{$row_data['cta_markup_label']}
		</label>
		<textarea type="text" name="wpsd-slide[{$key}][cta-markup]" placeholder="{$row_data['cta_markup_placeholder']}">
		{$row_data['cta_markup']}
		</textarea>
			<input type="hidden" name="wpsd-slide[{$key}][image-id]" value="{$row_data['image_id']}">
			{$row_data['remove_button_markup']}
		HTML;
	}
	
	private function get_row_data( $slide_values, $key ){

		return [
			
			'cta_link'					=> $slide_values['cta-link']??'',

			'cta_markup' 				=> htmlentities( $slide_values['cta-markup']??'' ),
			
			'image_id'					=> $slide_values['image-id']??0,
			
			'image_link' 				=> $slide_values['image-link']??'',
			
			'image_preview_markup' 		=> $this->get_image_preview_markup($slide_values['image-id']??0),
			
			'remove_button_markup'		=> $this->get_the_remove_button($key),
			
			'slide_number' 				=> $key+1,
			
			'upload_text' 				=> __('Upload Image', 'plugin-domain'),
			
			'image_link_label' 			=> __('Image link', 'plugin-domain'),
			
			'input_link_placeholder' 	=> __('URL or anchor( e.g. #offer )', 'plugin-domain'),
			
			'cta_link_label' 			=> __('CTA link', 'plugin-domain'),
			
			'cta_markup_label'			=> __('CTA markup', 'plugin-domain'),

			'cta_markup_placeholder'	=> __('Text or HTML markup', 'plugin-domain'),
		
		];
	}
	
	private function get_image_preview_markup($image_id=0){

		if( empty($image_id)) return '';

		$image_src = wp_get_attachment_image_src( $image_id, 'full' )[0];

		if( empty($image_src) ) return '';

		return <<<HTML
		<img src='{$image_src}' class="wpsd-slide-preview">
		HTML;
		
	}

}