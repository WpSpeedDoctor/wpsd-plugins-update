jQuery(document).ready(function($) {
	// Delegate to dynamically handle multiple upload buttons
	$(document).on('click', '.wpsd-upload-slide-image', function(e) {
		e.preventDefault();
		
		let button = $(this);
		let slideContainer = button.closest('.wpsd-metabox-slide');
		let imageField = slideContainer.find('input[name*="[image-id]"]');

		// Create a new media uploader instance for each button click
		let mediaUploader = wp.media({
			title: 'Select or Upload an Image',
			button: {
				text: 'Use this image'
			},
			multiple: false
		});

		// Handle image selection
		mediaUploader.on('select', function() {
			let selection = mediaUploader.state().get('selection').first();

			if (!selection) {
				console.log('No image selected.');
				return;
			}

			let attachment = selection.toJSON();

			if (attachment.id) {
				imageField.val(attachment.id);
				
				// Remove existing preview
				slideContainer.find('img').remove();

				// Append new image preview
				button.before(`<img src="${attachment.url}" class="wpsd-slide-preview">`);
			} else {
				console.error('Attachment missing ID');
			}
		});

		// Open uploader
		mediaUploader.open();
	});
});




document.addEventListener('click', function(e){
    if(e.target.closest('.wpsd-remove-slide')){
        let slide = e.target.closest('.wpsd-metabox-slide');
        if(slide){
            slide.remove();
        }
    }
});


/**
 * populate template data into form elements
 */

document.addEventListener('DOMContentLoaded', function() {
	const form = document.querySelector('#settings');
	const templateSelect = form.querySelector('select[name="main[template]"]');

	function populateFormData(selectedTemplate) {
		const settings = formData[selectedTemplate];

		// Loop through all form inputs to reset, excluding main-size and mobile-size
		form.querySelectorAll('[name^="main["]').forEach(input => {
			if (input.name.includes('[main-size]') || input.name.includes('[mobile-size]')) {
				return;  // Skip resetting main-size and mobile-size
			}

			switch (input.type) {
				case 'checkbox':
					input.checked = false;
					break;
				case 'select-one':
					if (!settings || !(input.name in settings)) {
						return;  // Keep existing value if not part of settings
					}
					input.selectedIndex = 0;
					break;
				default:
					input.value = '';
					break;
			}
		});

		// Apply settings from formData
		if (!settings) return;

		for (const [key, value] of Object.entries(settings)) {
			let input = form.querySelector(`[name="main[${key}]"]`);

			if (input) {
				switch (input.type) {
					case 'checkbox':
						input.checked = !!value;
						break;
					case 'select-one':
						let option = input.querySelector(`option[value="${value}"]`);
						if (option) option.selected = true;
						break;
					default:
						input.value = value;
						break;
				}
			}
		}
	}

	// Re-populate only when template selection changes
	templateSelect.addEventListener('change', function() {
		populateFormData(this.value);
	});
});


/**
 * TABS
 */
