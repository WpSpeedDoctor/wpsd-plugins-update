# WordPress Slider Filters

## Filters Descriptions

### `wpsd-slider-mobile-image`
**File:** `includes/class.slider-render.php`  

Allows developers to modify the mobile image URL used in the slider.  
By default, this returns `false`, meaning there is no alternative image for the given input.

#### Parameters:
- **`$mobile_img`** (bool|string) - The initial mobile image URL. Defaults to `false`.
- **`$image_id`** (int) - The WordPress attachment ID of the image being processed.
- **`$slider_id`** (int) - The slider ID.

#### Returns:
An array containing:
- `0` (string) - Mobile image URL.
- `1` (int) - Mobile image width.

---

### `wpsd-slider-image`
**File:** `includes/class.slider-render.php`  

Provides slider image details for different devices.

#### Parameters:
- **`$data`** (array) - Existing image data.
- **`$image_id`** (int) - The WordPress attachment ID of the image being processed.
- **`$slider_id`** (int) - The slider ID.

#### Returns:
An array with the following keys:
- `main-url` (string) - Main image URL.
- `height` (int) - Image height.
- `width` (int) - Image width.
- `alt-markup` (string) - Alt text HTML markup.
- `mobile-url` (string) - Mobile image URL.
- `mobile-width` (int) - Mobile image width.

---

### `wpsd-slider-splide-args`
**File:** `includes/class.slider-render.php`  

Allows developers to modify the Splide.js arguments used in the slider.

#### Parameters:
- **`$args`** (array) - Splide.js arguments.
- **`$slider_id`** (int) - The slider ID.

#### Returns:
An array of modified Splide.js arguments.

Constant WPSD_SLIDER_SPLIDE_ENQUEUED will enqueue splide css, default is inlined with first slider on the page to avoid CLS