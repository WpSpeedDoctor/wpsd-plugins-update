<?php

namespace WPSD\slider;

defined( 'ABSPATH' ) || exit;

/**
 * @var string plugin's DIR with trailing slash
 */

defined('WPSD_SLIDER_DIR') || define( 'WPSD_SLIDER_DIR', __DIR__.'/' );

/**
 * @var string plugin's version
 */
define( 'WPSD_SLIDER_VER', '1.12');

if(!defined( 'REQUEST_FRONTEND')) {

	define( 'REQUEST_FRONTEND', 1 );
	define( 'REQUEST_AJAX', 2 );
	define( 'REQUEST_ADMIN', 3 );
	define( 'REQUEST_CRON', 4 );
	define( 'REQUEST_LOGIN', 5 );
	define( 'REQUEST_XMLRPC', 6 );
	define( 'REQUEST_EMPTY', 7 );
	define( 'REQUEST_REST', 8 );
	define( 'REQUEST_SITEMAP', 9 );
	define( 'REQUEST_DIRECT', 10 );
	define( 'REQUEST_404', 11 );
	define( 'REQUEST_FEED', 12 );
	define( 'REQUEST_CLI', 13 );
}

/**
 * @return int -
 *  - 1 frontend
 *  - 2 ajax
 *  - 3 admin
 *  - 4 cron
 *  - 5 login
 *  - 6 xmlrpc
 *  - 7 empty
 *  - 8 rest
 *  - 9 sitemap
 *  - 10 direct
 *  - 11 404
 *  - 12 feed
 *  - 13 cli
 */

function get_wp_request_type(){
	
	static $result;

	static $uri_path;

	$uri_path || $uri_path = strstr( $_SERVER['REQUEST_URI'] ?? '', '?', true ) ?: $_SERVER['REQUEST_URI'] ?? '';

	switch(true){

		case $result:
			break;

		case isset( $_GET['wc-ajax'] ) || wp_doing_ajax():
			$result = REQUEST_AJAX;
			break;

		case is_admin():
			$result = REQUEST_ADMIN;
			break;

		case wp_doing_cron():
			$result = REQUEST_CRON;
			break;

		case is_callable( 'login_header' ):
			$result = REQUEST_LOGIN;
			break;

		case defined( 'XMLRPC_REQUEST' ):
			$result = REQUEST_XMLRPC;
			break;

		case defined( 'WP_CLI' ):
			$result = REQUEST_CLI;
			break;

		case $uri_path === '':
			$result = REQUEST_EMPTY;
			break;

		case str_contains( $uri_path,'/wp-json/' ):
			$result = REQUEST_REST;
			break;

		case str_contains( $uri_path, 'sitemap' ) && str_ends_with( $uri_path, '.xml' ):
			$result = REQUEST_SITEMAP;
			break;

		case str_ends_with( $uri_path,'.php' ):
			$result = REQUEST_DIRECT;
			break;

		case str_contains( $uri_path,'.' ):
			$result = REQUEST_404;
			break;

		case str_ends_with( $uri_path, '/feed/' ):
			$result = REQUEST_FEED;
			break;

		default:
			$result = REQUEST_FRONTEND;
	}

	return $result;
}





