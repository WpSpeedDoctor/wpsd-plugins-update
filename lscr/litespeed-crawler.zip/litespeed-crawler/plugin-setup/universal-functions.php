<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

/**
 * fallback for PHP 7.x version
 */
if( !function_exists('str_contains') ){
	function str_contains( $haystack, $needle ){

		return strpos($haystack, $needle) !== false;
	}
}

function get_sql_query( $sql, $row = false ){

	global $wpdb;
   
	if ($row) {
   
		$result = $wpdb->get_row($sql, ARRAY_A );
   
	} else {
   
		$result = $wpdb->get_results($sql, ARRAY_A );
	}
		
	return $result;
}

function remove_domain_from_url( $url ){

	$parsed_url = parse_url($url);

	if ( empty ( $parsed_url['query'] ) ) return $parsed_url['path'];
	
	return $parsed_url['path'].'?'.$parsed_url['query'];

}

/**
 * Own nonce has to be generated as WP nonce is not available in mu-plugins
 */
function get_ajax_nonce(){

	static $stored_data = false;

	if( isset($stored_data['nonce']) ) return $stored_data['nonce'];
	
	$stored_data = get_option('lscr_nonce');
	
	$current_time = time();
	
	if ( $current_time < ($stored_data['timestamp']??0) ) {

		return $stored_data['nonce'];

	}

	$nonce = bin2hex(random_bytes(10));
	
	$stored_data = [

		'nonce' => $nonce,

		'timestamp' => $current_time + 21600 
	];

	update_option('lscr_nonce', $stored_data, false);
	
	return $stored_data['nonce'];
}


function get_ajax_url(){
	
	return admin_url('admin-ajax.php?litespeed-crawler');
}

function set_settings_constant(){

	/**
	 * @var array -
	 * - priority-keywords => ARRAY
	 * - excluded-keyword => ARRAY
	 * - custom-sitemap STRING
	 * - threads STRING int number
	 * - server-load-slowdown STRING int number
	 * - log STRING 1/0 TODO
	 */

	 defined('LSCR_SETTINGS') || define('LSCR_SETTINGS', get_option('ls_crawler_settings') );

}

function get_run_id(){

	static $run_id = false;

	if( $run_id !== false ) return $run_id;

	$run_id = get_option('ls_crawler_run_id');

	return (int) $run_id;
}