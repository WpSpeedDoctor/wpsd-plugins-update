<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

include_once LSCR_DIR.'plugin-setup/universal-functions.php';

require_once LSCR_DIR.'plugin-setup/setup.php';

function plugin_uninstall(){
	
	remove_plugin_db_tables();

	delete_option('ls_crawler_settings');

	delete_option('ls_crawler_run_id');

	delete_option('lscr_nonce');

}


function remove_plugin_db_tables(){

	global $wpdb;

	$plugins_tables = array_keys(get_plugins_table_sql_data());

	foreach( $plugins_tables as $table_name ){

		$wpdb->query( "DROP TABLE `{$table_name}`;" );
	}

}