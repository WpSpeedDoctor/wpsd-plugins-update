<?php

/*
* Plugin Name: Litespeed Crawler by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/litespeed-crawler/
* Description: Custom cache preload solution for Litespeed cache plugin with enhanced statistics reporting
* Version: 1.0.32
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: litespeed-crawler
* Domain Path: /languages/
* Last Update: 2024-04-23
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4
*/	

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

defined('LSCR_DIR') || define( 'LSCR_DIR', __DIR__.'/' );

const LSCR_VER = '1.0.32';

switch(true){

	case wp_doing_ajax():

		if( ($_POST['action']??'') === 'update-plugin' ) {
				
			require_once LSCR_DIR.'plugin-setup/update.php';
		}

		if ( ($_POST['action'] ?? '' ) === 'delete-plugin' ){
			
			require LSCR_DIR.'plugin-setup/uninstall.php';
		}

	break;

	case is_admin():

		require_once LSCR_DIR.'includes/admin-main.php';

		if( is_wp_plugin_page() ) {
		
			require_once LSCR_DIR.'plugin-setup/setup.php';

			register_deactivation_hook( __FILE__, 'ls_crawler\plugin_deactivation' );

			register_activation_hook( __FILE__, 'ls_crawler\plugin_activation' );

			register_uninstall_hook( __FILE__, 'ls_crawler\plugin_uninstall' );
		}

		require_once LSCR_DIR.'plugin-setup/update.php';

	break;

	case wp_doing_cron():

		require_once LSCR_DIR.'includes/scheduler.php';

		add_cron_tasks_main();

	break;

	// default:
	// require_once LSCR_DIR.'includes/scheduler.php';

	// add_cron_tasks_main();
	// break;
}

function get_plugin_main_file(){
	
	return __FILE__;
}

function is_wp_plugin_page(){
	
    global $pagenow;
    
    return $pagenow === 'plugins.php';
}


