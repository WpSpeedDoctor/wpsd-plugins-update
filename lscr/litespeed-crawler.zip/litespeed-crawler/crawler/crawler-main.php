<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

require_once LSCR_DIR.'crawler/curl.php';

require LSCR_DIR.'includes/sql.php';

// run_timeout_restart();

crawler_main();

function crawler_main(){

	switch(POST['action']){
		
		case 'crawler_start':
			
			$status = start_crawler();

			break;
		
		case 'crawler_continue':
			
			$status = start_full_loop();

			break;
		
		
		case 'progress':
			
			$status = get_the_progress();
			break;
		
		
		case 'crawler_stop_manual':
			
			$status = get_the_stop();
			break;
		
		case 'update_custom_sitemap':
			
			$status = init_update_custom_sitemap();
		
		break;
		

		default;
		
			$status = [
		
				'action'	=> 'stop',
			
				'message'	=> __('Stop','litespeed-crawler')
			];

		break;
	}

	
	if( ($status['action']??'') === 'continue' ) restart_crawler_loop($status['page']);
	
	echo $status['message']??'';

	die;

}

function get_the_stop(){
	
	update_option('ls_crawler_run_id', 0, 'no' );

	return [
	
		'action'	=> 'stop',
	
		'message'	=> __('Crawler has being stopped','litespeed-crawler')
	];
}

function init_update_custom_sitemap(){
	
	require_once LSCR_DIR.'crawler/custom-sitemap.php';

	$urls_count = update_custom_sitemap_main();

	return [
	
		'action'	=> 'stop',
	
		'message'	=> $urls_count
	];
}

function start_full_loop(){

	register_shutdown_function( __NAMESPACE__ . '\restart_crawler_from_shutdown' );

	set_php_timeout();

	$page = (int) sanitize_text_field( POST['page'] );

	$run_id = get_run_id();

	$run = true;

	while( $run ){
	
		if( has_crawler_been_stopped() ) $run=false;
		
		$urls = get_urls_to_crawl(['page'=>$page]);

		$response_data = crawl_urls($urls);

		add_response_data_into_db( $run_id, $response_data );

		if (count($urls) != LSCR_SETTINGS['threads']  ) $run=false;

		++$page;

		$GLOBALS['LSCR_PAGE'] = $page;
		
		if( $run && is_timeout() ){
			
			define('LSCR_LOOP_ENDED',true);

			restart_crawler_loop( $page );
		
			die;
		}

	}

	define('LSCR_LOOP_ENDED',true);

	end_crawling( $run_id );

	die;

}

function restart_crawler_from_shutdown(){

	if( defined('LSCR_LOOP_ENDED') || empty($GLOBALS['LSCR_PAGE']) ) return;

	error_log('LSCR: Attempting Restart of crawler from shutdown');

	restart_crawler_loop( $GLOBALS['LSCR_PAGE'] );
}

//had to use direct DB query because get_option was returning cached version and didn't reflect the change
function has_crawler_been_stopped(){

	global $wpdb;
	
	return empty(
	
		$wpdb->get_var(

			"SELECT option_value FROM `{$wpdb->prefix}options` WHERE `option_name` = 'ls_crawler_run_id'"
	
			)
	);
}


function is_timeout(){

	return ( microtime(true) - LSCR_TIME ) > (LSCR_TIMEOUT - 10) /* seconds */;
}

function end_crawling( $run_id ){

	if( $run_id == 0 ) $run_id = get_last_run_id();

	$end_datetime = date('Y-m-d H:i:s');

	$summary = json_encode( get_run_stats( $run_id ));

	update_run_summary_on_end( $run_id, $end_datetime, $summary );

	set_current_run_id( '0' );

}

function start_crawler(){
	
	if( get_run_id() ) return get_already_running_response();

	if( !empty(LSCR_SETTINGS['custom-sitemap']) ){

		$urls_count = call_ajax_custom_sitemap_update();
	
		if( $urls_count === 0 ) return respond_no_sitemap();
	}

	$default_args = ['per_page'=>LSCR_SETTINGS['threads'], 'page'=>0];

	$urls_to_crawl = get_urls_to_crawl( $default_args );

	$response_data = crawl_urls( $urls_to_crawl );

	if( !has_success_response($response_data) ){
		
		echo __( 'Start failed' ,'litespeed-crawler');

		die;
	}

	return respond_success_start( $response_data, $urls_count );
}

function respond_success_start( $response_data, $urls_count ){
	
	$run_id = get_new_run_id( $urls_count );

	set_current_run_id( $run_id );

	add_response_data_into_db( $run_id, $response_data );

	return get_has_started_response();
}

function get_has_started_response(){

	return [
	
		'action'	=> 'continue',

		'page'	=> '1',
	
		'message'	=> __('The crawler started successfully','litespeed-crawler')
	];

}

function get_already_running_response(){

	return [
	
		'action'	=> 'stop',
	
		'message'	=> __('Crawler is already running','litespeed-crawler')
	];

}

/**
* @param array $response_data
* @return array -
* - url_id
* - response
* - ttfb
* - total_time
* - cache_status
*/

function get_processed_response_data_for_db( $response_data ){
	
	$result = [];

	foreach( $response_data as $url_data ){

		$result[]=[
			'url'		=>  $url_data['url'],
			'response'		=>  $url_data['response_code'],
			'ttfb'			=>  convert_sec_float_to_ms_int( $url_data['ttfb'] ),
			'cache_status'	=>  get_cache_status( $url_data['response_header'] ),
		];
	}

	return $result;

}

function get_cache_status( $header ){

	$cache_strings = [
		
		'miss'		=> 'x-litespeed-cache: miss',
		'hit'		=> 'x-litespeed-cache: hit',
		'no-cache'	=> 'x-litespeed-cache-control: no-cache'

	];

	foreach( $cache_strings as $key => $string ){
		
		if( str_contains( $header, $string ) ) return $key;

	}

	return 'off';
}

function convert_sec_float_to_ms_int( $seconds_float ){

	return (int) round( $seconds_float * 1000);
}

function add_response_data_into_db($run_id, $response_data){
    global $wpdb;
    $response_data_for_db = get_processed_response_data_for_db($response_data);
    
    foreach ($response_data_for_db as $data){
		
        $wpdb->insert("{$wpdb->prefix}lscr_stats", [
            'run_id' => $run_id,
            'url' => $data['url'],
            'response' => $data['response'],
            'ttfb' => $data['ttfb'],
            'cache_status' => $data['cache_status']
        ]);
    }
}


function set_current_run_id( $run_id ){

	update_option('ls_crawler_run_id', $run_id, 'no' );
}

/**
 * @return bool if at least one response has code 200
 */

function has_success_response($response_data){

	return in_array( 200, wp_list_pluck($response_data,'response_code'));
}


/**
* @param string 
* @return array -
* - ['id'] =>  string
* - ['url'] => string
*/

function get_urls_to_crawl( $args ){

	global $wpdb;

	$per_page = $args['per_page']??LSCR_SETTINGS['threads'];

	$offset = (int) $args['page'] * (int) $per_page ;

	$sql_matching_rules_markup = get_sql_matching_rules_markup($args);

	$sql=
"SELECT url
FROM {$wpdb->prefix}lscr_url 
{$sql_matching_rules_markup}
LIMIT {$per_page}
OFFSET {$offset};";

	return $wpdb->get_results($sql, ARRAY_A );
	
}


function is_cralwer_already_running(){
	
	return true;
}

function send_message_already_running(){

	die( __('Crawler is already is running','litespeed-cache') );
}

function pause_based_on_server_load( $results ){

	if( have_all_results_cache_hit( $results ) ) return;

	$current_server_load = get_current_server_load();
	
	if ( $current_server_load === false || LSCR_SETTINGS['server-load-slowdown'] == 0 ) return;

	if ( $current_server_load > LSCR_SETTINGS['server-load-slowdown']  ){

		sleep( LSCR_SETTINGS['threads'] );

	} else {

		usleep(1000000);

	}
}

function have_all_results_cache_hit( $results ){

	foreach( $results as $result ){

        if( get_cache_status( $result['response_header'] ) != 'hit' ) return false;

    }

	return true;
}

function respond_no_sitemap(){

	echo __( 'Sitemap empty or not accessible' ,'litespeed-crawler');
	
	die;
}

function respond_not_urls_found(){

	echo __( 'No URLs found.' ,'litespeed-crawler');

	die;
}

function set_php_timeout(){
	
	ignore_user_abort( true );

	//70 years old people affirm that 70 is great but 69 is the best!
	ini_set('max_execution_time', 69 ); 

	//in case that hosting is blocking manually adjusted max_execution_time, max 60 seconds for higher probability to restart
	define('LSCR_TIMEOUT', min( 60, ini_get('max_execution_time') ) );
}

function get_the_progress(){

	$progress_data = get_progress_data();

	return [
	
		'action'	=> 'stop',
	
		'message'	=>  get_progress_output( $progress_data )
	];
}

function get_progress_output( $progress_data ){

	if ($progress_data === false ) return 'end';

	$progress_text = __( '%d of %d %s done' ,'litespeed-crawler');

	return sprintf( $progress_text, $progress_data['current_position'],$progress_data['end_position'],$progress_data['percentile_done']);

}

function get_progress_data(){

	$run_id = get_run_id();

	if( $run_id === 0 ) return false;

	$total = get_run_urls_count( $run_id );

	$current_count = get_count_stored_stats($run_id);

	if( $total === 0 || $current_count > $total ) return false;

	$percentile_done = round (($current_count/$total)*100 );

	return[
		
		'current_position'	=> $current_count,

		'end_position'		=> $total,

		'percentile_done'	=> "$percentile_done%"

	];
}
