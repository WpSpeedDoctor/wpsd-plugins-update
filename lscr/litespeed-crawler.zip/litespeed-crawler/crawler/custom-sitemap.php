<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

function update_custom_sitemap_main(){

	$urls_to_crawl_count = get_sitemap_count();
	
	if( !should_update_sitemap($urls_to_crawl_count) ){

		return json_encode( [
			
			'count'=> $urls_to_crawl_count,
			
			'message'=> 'Sitemap is already created'
		]);
	} 
	
	$update_data = get_sitemap_links();

	update_custom_sitemap($update_data);
	
	unset( $update_data['links'] );

	return json_encode( $update_data );
}

function should_update_sitemap($urls_to_crawl_count){
	
	return 			
			empty($urls_to_crawl_count) ||
			
			has_sitemap_expired() || 
			
			isset( $_POST['sitemap_update_forced'] );
}

function set_sitemap_alive_transient(){
	
	$sitemap_ttl = (int) LSCR_SETTINGS['sitemap_ttl']??2;

	if( $sitemap_ttl === 0 ){

		delete_transient('lscr_sitemap_alive');

	} else{

		set_transient('lscr_sitemap_alive', '1', $sitemap_ttl*60*60);
	}

}

/**
 * @return int count of rows in db table that stored urls to crawl
 */

function update_custom_sitemap($update_data){
	
	if( !is_array($update_data['links']) || count($update_data['links']) === 0 ) return; 

	global $wpdb;

	empty_crawler_url_table();

	$chunk_size = 20;

	$urls_to_db = array_unique( $update_data['links'] );

	foreach(array_chunk( $urls_to_db , $chunk_size) as $chunk){
		
		$values = [];

		foreach ($chunk as $url){

			$values[] = $wpdb->prepare('(%s)', add_trailing_slash_for_html($url) );
		}

		$values = implode(', ', array_unique($values));
	
		$query = "INSERT INTO `{$wpdb->prefix}lscr_url` (`url`) VALUES $values;";

		$wpdb->query($query);
	}
	
	set_sitemap_alive_transient();
	
}

function add_trailing_slash_for_html($url){

	$parsed = parse_url($url);

	switch(true){
		case !isset($parsed['path']):
			return $url.'/';

		case isset($parsed['query']):
			return $url;

		case str_contains( $parsed['path'], '.' ):
			return $url;
		default:
			return trailingslashit($url);
		
	}
	
}

function has_sitemap_expired(){

	if( (LSCR_SETTINGS['sitemap_ttl']??false ) === '0' ) return true; //no TTL in settings

	return empty( get_transient('lscr_sitemap_alive') );
}

function get_sitemap_count(){

	global $wpdb;
	
	return (int) $wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}lscr_url");
}


function empty_crawler_url_table(){
	
	global $wpdb;

	$wpdb->query("TRUNCATE TABLE `{$wpdb->prefix}lscr_url`");
}

function get_url_content($url){

	$url_arr = [['id'=>0,'url'=>$url]];

	$args=[
		'header'=> false,
		'content'=> true,
		'follow_redirect'=> true
	];
	
	$response = crawl_urls( $url_arr, $args );

	if( ($response[0]['response_code']??500) > 399 ){

		error_log( 'LSCR: Curl attempt to fetch sitemap failed '.var_export( $response[0]??'empty response',true ) );
		
		$args = [
			'timeout'     => 40,
			'redirection' => 5,
			'httpversion' => '2.0',
			'user-agent'  => get_user_agent(),
		];

		$response_wp_remote = wp_remote_get( home_url($url), $args);
		
		$response_body = wp_remote_retrieve_body($response_wp_remote);

		$status_code = (int) wp_remote_retrieve_response_code($response_wp_remote);

		if( !in_array( $status_code, [200,301,302])){

			error_log( "LSCR: wp_remote attempt response code: $status_code, response body length: ".strlen( $response_body??'' ) );
		}


		return $response_body;
			
	}

	return $response[0]['response_content']??'';
}


/**
* @return array ...
* - ['links']	=> array
* - ['count']	=> int
* - ['message']	=> string
*/

function get_sitemap_links(){
	
	$sitemap_subpages_links = get_sitemap_subpages_links();

	if( empty($sitemap_subpages_links) ) return ['links'=>false, 'count'=>0, 'message'=>__('Unable to fetch the main sitemap', 'litespeed-crawler') ];

	$result = [];

	$message = '';

	foreach( $sitemap_subpages_links as $url){

		$start = microtime(true);

		$sitemap_subpage_xml_content = get_url_content($url);
		
		$duration = (string) round( (microtime(true) - $start ),3);

		if( empty( $sitemap_subpage_xml_content ) ) {
			
			$message .= sprintf(__('Sitemap subpage %s content is empty.', 'litespeed-crawler'), $url ).'<br>';
			
			error_log( "Sitemap subpage $url content is empty. ".__FUNCTION__. '() at line '.__LINE__ );

			continue;
		}

		$subpage_sitemap_links = get_xml_links( $sitemap_subpage_xml_content );

		$subpage_sitemap_links_count = (string) count($subpage_sitemap_links);

		$message .= sprintf(__('In %s have been found %s URLs, fetched in %s seconds.', 'litespeed-crawler'), $url, $subpage_sitemap_links_count, $duration ).'<br>';

		if( empty($subpage_sitemap_links_count) ) continue;

		$result = array_merge( $result, $subpage_sitemap_links );

	}
	
	add_home_to_sitemap( $result );

	$result = array_unique( $result );

	return [ 
				'links' 	=> $result,
				'count'		=> count( $result ),
				'message'	=> $message
			];

}

function add_home_to_sitemap( &$result ){

	if( empty($result) ) return;

	$home_uri_path = parse_url(LSCR_SETTINGS['home-url'])['path']??'/';

	if( in_array( $home_uri_path, $result) ) return;

	array_unshift($result, $home_uri_path);
}

function get_sitemap_subpages_links(){
	
	$sitemap_links_cached = get_transient('lscr_xml_links');

	if( $sitemap_links_cached !== false ) return $sitemap_links_cached;

	$sitemap_links_xml = get_url_content( LSCR_SETTINGS['custom-sitemap'] );

	$sitemap_subpage_links = get_xml_links( $sitemap_links_xml, $exclude_keywords = false );

	if( empty($sitemap_subpage_links) ) return false;

	set_transient('lscr_xml_links', $sitemap_subpage_links, WEEK_IN_SECONDS );

	return $sitemap_subpage_links;
}	

function get_xml_links( $xml_data, $exclude_keywords = true ){

	$main_sitemap = simplexml_load_string( $xml_data );

	foreach ($main_sitemap as $url_obj){
		
		$url = add_trailing_slash_for_html( (string) $url_obj->loc );

		$uri = get_uri( $url );

		if( $exclude_keywords && has_excluded_keyword( $uri )  ) continue;

		$result[] = $uri;
	}

	return $result??[];
}

function get_uri( $url ){

	$parsed_url = parse_url($url);

	if ( !isset( $parsed_url['query'] ) || $parsed_url['query'] ==='' ) return $parsed_url['path'];
	
	return $parsed_url['path'].'?'.$parsed_url['query'];

}

function has_excluded_keyword( $url ){
	
	foreach( LSCR_SETTINGS['excluded-keywords'] as $keyword){

		if( preg_match("~{$keyword}~", $url) ) return true;

	}

	return false;
}
