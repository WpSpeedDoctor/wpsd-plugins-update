<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

function update_custom_sitemap_main(){

	$urls_to_crawl_count = get_sitemap_count();
	
	if( empty($urls_to_crawl_count) || has_sitemap_expired() || isset($_POST['sitemap_update_forced'])){
		
		$count_updated = update_custom_sitemap();

		if( $count_updated !== false ){
			
			set_sitemap_alive_transient();

			return $count_updated;
		}
		
	}

	return $urls_to_crawl_count;
}

function set_sitemap_alive_transient(){
	
	$default_sitemap_ttl = 120; // minutes

	set_transient('lscr_sitemap_alive', true, $default_sitemap_ttl*60);

}

/**
 * @return int count of rows in db table that stored urls to crawl
 */

function update_custom_sitemap(){
	
    global $wpdb;

    $custom_sitemap_url = LSCR_SETTINGS['custom-sitemap'];

    $all_sitemap_links = get_sitemap_links($custom_sitemap_url);
    
    if( empty( $all_sitemap_links ) ) return false;
    
    empty_crawler_url_table();

	$chunk_size = 20;

	foreach(array_chunk($all_sitemap_links, $chunk_size) as $chunk){
		
		$values = [];

        foreach ($chunk as $url){

			$values[] = $wpdb->prepare('(%s)', trailingslashit($url) );
        }

		$values = implode(', ', $values);

		$query = "INSERT INTO `{$wpdb->prefix}lscr_url` (`url`) VALUES $values;";

		$wpdb->query($query);
    }

	return count($all_sitemap_links);
	
}

function has_sitemap_expired( ){

	return empty( get_transient('lscr_sitemap_alive') );
}

function get_sitemap_count(){

	global $wpdb;
	
	return (int) $wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}lscr_url");
}


function empty_crawler_url_table(){
	
    global $wpdb;

    $wpdb->query("TRUNCATE TABLE `{$wpdb->prefix}lscr_url`");
}

function get_url_content($url){

	$url_arr = [['id'=>0,'url'=>$url]];

	$args=[
		'header'=> false,
		'content'=> true,
		'follow_redirect'=> true
	];
	
	$response = crawl_urls( $url_arr, $args );

	if( ($response[0]['response_code']??500) > 399 ){

		error_log( 'LSCR: Curl attempt to fetch sitemap failed '.var_export( $response[0]??'empty response',true ) );
		
		$args = [
			'timeout'     => 40,
			'redirection' => 5,
			'httpversion' => '2.0',
			'user-agent'  => get_user_agent(),
		];

		$response_wp_remote = wp_remote_get( home_url($url), $args);
		
		$response_body = wp_remote_retrieve_body($response_wp_remote);

		$status_code = (int) wp_remote_retrieve_response_code($response_wp_remote);

		if( !in_array( $status_code, [200,301,302])){

			error_log( "LSCR: wp_remote attempt response code: $status_code, response body length: ".strlen( $response_body??'' ) );
		}


		return $response_body;
			
	}

	return $response[0]['response_content']??'n/a';
}


function add_url_to_custom_sitemap($url,$table_name){

	global $wpdb;

	$wpdb->insert( $table_name, ['url' => $url],['%s'] );

}


function get_sitemap_links( $sitemap_url ){
	
	$main_sitemap_xml = get_url_content( $sitemap_url );

	if( empty($main_sitemap_xml) ) return false;

	$sitemap_subpages = get_xml_links( $main_sitemap_xml );

	$result = [];

	foreach($sitemap_subpages as $url){

		$sitemap_subpage_xml_content = get_url_content($url);

		if( empty($sitemap_subpage_xml_content) ) continue;

		$result = array_merge( $result??[], get_xml_links( $sitemap_subpage_xml_content  ) );

	}
	
	if( empty($result) ) return false;

	$result = array_merge( get_home_uri_path(), $result );

	return array_unique($result);

}

function get_home_uri_path(){

	return [ parse_url(LSCR_HOME_URL)['path']??'/' ];
}

function get_xml_links( $xml_data ){

	$main_sitemap = simplexml_load_string( $xml_data );

	foreach ($main_sitemap as $url_obj){
		
		$url = (string) $url_obj->loc;

		if( has_excluded_keyword( $url )  ) continue;

		$result[] = remove_domain_from_url($url);
	}

	return $result??[];
}

function has_excluded_keyword( $url ){
	
	foreach( LSCR_SETTINGS['excluded-keywords'] as $keyword){

        if( str_contains( $url, $keyword ) ) return true;

    }

	return false;
}