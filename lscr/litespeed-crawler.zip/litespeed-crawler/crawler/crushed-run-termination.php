<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;


function terminate_current_run(){

	require_once LSCR_DIR.'includes/sql.php';

	require_once LSCR_DIR.'crawler/curl.php';

	$run_id = get_run_id();

	$summary = json_encode( get_run_stats( $run_id ) );

	update_run_summary_on_end( $run_id, $end_datetime = '0', $summary );

	update_option('ls_crawler_run_id', '0', false);

}

function has_current_run_crushed(){

	$run_id = get_run_id();

	if( empty($run_id ) ) return false;

	$crawled_urls = get_crawled_urls_count( $run_id );

	sleep(10);
	//sleep 10 seconds to get another count, if the same, crawler has crushed and haven't shutdown properly,
	//assuming TTFB is not longer than 10 seconds.

	return $crawled_urls === get_crawled_urls_count( $run_id );
	
}

function get_crawled_urls_count($run_id) {

	global $wpdb;
	
	return intval(
	
		$wpdb->get_var(
	
			"SELECT COUNT(*) FROM `{$wpdb->prefix}lscr_stats` WHERE `run_id` = $run_id"
	
		)
	);
}
