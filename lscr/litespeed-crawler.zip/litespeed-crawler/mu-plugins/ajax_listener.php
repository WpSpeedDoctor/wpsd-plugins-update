<?php

namespace ls_crawler;

if( !isset($_GET['litespeed-crawler']) ) return;

define('POST', get_request_post() );

if( empty(POST['action']) || (POST['_wpnonce']??'') !== get_ajax_nonce() ) die_forbidden();

// error_log( basename(__FILE__).' at '.__LINE__.' '.var_export( POST, true ).PHP_EOL  );


/**
 * @var array -
 * - priority-keywords => ARRAY
 * - excluded-keyword => ARRAY
 * - custom-sitemap STRING
 * - threads STRING int number
 * - server-load-slowdown STRING int number
 * - log  STRING 1/0
 */

define('LSCR_SETTINGS', get_option('ls_crawler_settings') );

define( 'LSCR_TIME', microtime(true) );

/**
 * Run crawler
 */
require LSCR_DIR.'crawler/crawler-main.php';




function get_request_post(){

	if( !empty($_POST) ) return $_POST;

	return json_decode( file_get_contents('php://input'), true);

}

function die_forbidden(){

	http_response_code(403);

	die('Forbiden 403');
}