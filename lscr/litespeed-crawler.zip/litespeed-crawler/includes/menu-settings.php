<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

require_once LSCR_DIR.'crawler/curl.php';

?><h3><?=__('Settings','litespeed-crawler')?></h3><br><?php


$settings = get_settings_to_display();


$form_data = get_form_data($settings);

?>
<form method="POST" action="#" _lpchecked="1" autocomplete="off">
	<input type="hidden" name="tab" value="crawler-settings">
	<?php wp_nonce_field('ls-crawler-settings'); ?>
	<table class="crawler-settings">
		<?php foreach ($form_data as $field): ?>
		<tr>
			<td class="row-name d-block"><?=$field['text']?></td>
			<td class="pdl-15"><?=$field['input']?></td>
			<td class="pdl-15"><?=$field['description']?></td>
		</tr>
		<?php endforeach; ?>
	</table>
	<br>
	<?=get_save_button_markup()?>
</form>
<?php
display_sitemap_settings();

function display_sitemap_settings(){

	$ajax_url = get_ajax_url();
	
	$ajax_nonce = get_ajax_nonce();

	$section_subtitle = __('Sitemap','litespeed-crawler');

	$update_button_text = __('Update Sitemap','litespeed-crawler');

	$text_1 = __('Current sitemap count:','litespeed-crawler');

	$spinner_url = admin_url( '/images/spinner.gif' );
	require_once LSCR_DIR.'crawler/custom-sitemap.php';

	$urls_to_crawl_count = get_sitemap_count();

	echo <<<HTML
<hr style="margin-top:20px">
<h3>$section_subtitle</h3>
<div style="height: 24px;display: flex;align-items:end;margin-bottom:15px">
	{$text_1} <span id="result" style="margin-left:5px">{$urls_to_crawl_count}</span>
</div>
<button id="fetch_data" class="button button-primary">{$update_button_text}</button>
<script>
jQuery(document).ready(function($) {
    $('#fetch_data').on('click', function() {
        $('#result').html('<img src="$spinner_url">');
        var data = {
            action: 'update_custom_sitemap',
            sitemap_update_forced: 'true',
            _wpnonce: '{$ajax_nonce}'
        };
        $.ajax({
            url: '{$ajax_url}',
            type: 'POST',
            data: data,
            success: function(response) {
                $('#result').html(response);
            },
            error: function(xhr) {
                $('#result').html('Error: ' + xhr.status);
            }
        });
    });
});
</script>
HTML;

}

function get_save_button_markup(){

	if ( is_crawler_running() ){

		return __('You can\'t change the settings now because the crawler is running.', 'litespeed-crawler');
	}

	$save_setting_text = __('Save settings', 'litespeed-crawler');

	return
	<<<HTML
	<button class="button button-primary" type="submit" id="submit">{$save_setting_text}</button>
	HTML;
	
	
}


function get_form_data($settings) {

	// Set default values
	$settings['enabled'] ??= false;
	$settings['frequency'] ??= 'daily';
	$settings['priority-keywords'] ??= [];
	$settings['excluded-keywords'] ??= [];
	$settings['server-ip'] ??= $_SERVER['SERVER_ADDR'];
	$settings['custom-sitemap'] ??= '';
	$settings['threads'] ??= 1;
	$settings['server-load-slowdown'] ??= 3;

	$enabled		= checked($settings['enabled'], true, false); 
	$frequency		= get_frequency_options($settings['frequency']);
	$priority		= implode(PHP_EOL, $settings['priority-keywords']);
	$priority_rows	= max(2, count($settings['priority-keywords']));
	$excluded		= implode(PHP_EOL, $settings['excluded-keywords']);
	$excluded_rows	= max(2, count($settings['excluded-keywords']));
	$server_ip		= get_server_display_ip_markup($settings);

	$data = [
		'enabled' => [
			'text' => __('Crawler is enabled', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="checkbox" name="enabled" value="1" class="chkbox" {$enabled}>
HTML
			,
			'description' => '',
		],
		'frequency' => [
			'text' => __('Crawler frequency', 'litespeed-crawler'),
			'input' => <<<HTML
<select name="frequency" id="frequency">{$frequency}</select>
HTML
			,
			'description' => __('How often the crawler should run?', 'litespeed-crawler'),
		],
		'priority_keywords' => [
			'text' => __('Priority keywords:', 'litespeed-crawler'),
			'input' => <<<HTML
<textarea name="priority-keywords" rows="{$priority_rows}" cols="60">{$priority}</textarea>
HTML
			,
			'description' => __('URLs containing these keywords will be crawled first, e.g. /product/ or /2023/, one per line', 'litespeed-crawler'),
		],
		'excluded_keywords' => [
			'text' => __('Excluded keywords:', 'litespeed-crawler'),
			'input' => <<<HTML
<textarea name="excluded-keywords" rows="{$excluded_rows}" cols="60">{$excluded}</textarea>
HTML
			,
			'description' => __('For example /checkout/,/login/,/page/... One per line.', 'litespeed-crawler'),
		],
		'server_ip' => [
			'text' => __('Server IP:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="text" name="server-ip" autocomplete="off" value="{$server_ip}">
HTML
			,
			'description' => get_server_ip_description(),
		],
		'custom_sitemap' => [
			'text' => __('Custom sitemap URL:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="text" name="custom-sitemap" autocomplete="off" value="{$settings['custom-sitemap']}">
HTML
			,
			'description' => __('no domain, e.g. <i>/sitemap.xml</i> or <i>/sitemap_index.xml</i>. Leave empty for WP default <i>/wp-sitemap.xml<i>.', 'litespeed-crawler'),
		],
		'threads' => [
			'text' => __('Number of threads:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="number" name="threads" autocomplete="off" value="{$settings['threads']}">
HTML
			,
			'description' => __('Number of threads, simultaneously crawling the website. Recommended value is one per CPU core available.', 'litespeed-crawler'),
		],
		'server_load_slowdown' => [
			'text' => __('Slow down crawl when server load is over:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="number" name="server-load-slowdown" autocomplete="off" value="{$settings['server-load-slowdown']}">
HTML
			,
			'description' => __('When server load reaches this level, it will increase time between requests batches to 1 second times numbers threads. 0 is no delay between crawler\'s requests.', 'litespeed-crawler') . ' ' . get_current_server_load_markup(),
		],
	];
	

	return $data;
}

function get_server_display_ip_markup($settings){

	if( $settings['server-ip'] == $_SERVER['SERVER_ADDR'] ) return '';

	return $settings['server-ip'];
}

function get_server_ip_description(){

	$local_server_ip = $_SERVER['SERVER_ADDR'];

	$public_server_ip = get_domain_ip_from_cloudflare($_SERVER['HTTP_HOST']);
	
    return sprintf(__("Local IP is %s and public IP is %s. Leave empty to use local IP.", 'litespeed-crawler'), $local_server_ip, $public_server_ip);

}


function get_domain_ip_from_cloudflare($domain_name){
     
    $dns_server = ['1.1.1.1'];// Cloudflare WARP
	
    return dns_get_record($domain_name, DNS_A, $dns_server )[0]['ip'];
}

function get_frequency_options($current_frequency) {
	
	$options = [
		'hourly'		=> __('Hourly', 'litespeed-crawler'),
		'twicedaily'	=> __('Twicedaily', 'litespeed-crawler'),
		'daily'			=> __('Daily', 'litespeed-crawler'),
		'weekly'		=> __('Weekly', 'litespeed-crawler'),
	];

	$options_html = '';

	foreach ($options as $value => $label) {
		$selected = selected( $value, $current_frequency, false);
		$options_html .= 
		<<<HTML
		<option value="{$value}"{$selected}>{$label}</option>;
		HTML;
		
	}

	return $options_html;
}


function get_settings_to_display(){

	if( $_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST) ) return LSCR_SETTINGS;
	
	require LSCR_DIR.'/includes/save-settings.php';

	if( is_allowed_to_save() ) {
	
		$new_settings = get_new_settings();

		update_option( 'ls_crawler_settings', $new_settings, 'no' );

		display_saved_settings();

		require_once LSCR_DIR.'crawler/custom-sitemap.php';

		empty_crawler_url_table();

	} else {
		
		display_not_allowed_to_save();

	}

	return $new_settings??LSCR_SETTINGS;
}

function get_current_server_load_markup(){

	$current_load = get_current_server_load();

	// if( $current_load === false ) return __("N/A", 'litespeed-crawler');

	$current_load_string = ($current_load === false) ? __('N/A', 'litespeed-crawler') : (string) $current_load;

	return sprintf(__("Current server load: %s", 'litespeed-crawler'), $current_load_string);
}