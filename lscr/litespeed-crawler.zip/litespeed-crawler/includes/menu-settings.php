<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

require_once LSCR_DIR.'crawler/curl.php';

?><h3><?=__('Settings','litespeed-crawler')?></h3><br><?php


$settings = get_settings_to_display();


$form_data = get_form_data($settings);

?>
<form method="POST" action="#" _lpchecked="1" autocomplete="off">
	<input type="hidden" name="tab" value="crawler-settings">
	<?php wp_nonce_field('ls-crawler-settings'); ?>
	<table class="crawler-settings">
		<?php foreach ($form_data as $field): ?>
		<tr>
			<td class="row-name d-block"><?=$field['text']?></td>
			<td class="pdl-15"><?=$field['input']?></td>
			<td class="pdl-15"><?=$field['description']?></td>
		</tr>
		<?php endforeach; ?>
	</table>
	<br>
	<?php the_save_setting_button()?>
</form>
<?php

display_sitemap_settings( $settings );

function display_sitemap_settings( $settings ){

	$ajax_url = get_ajax_url();
	
	$ajax_nonce = get_ajax_nonce();

	$section_subtitle = __('Sitemap','litespeed-crawler');

	$current_count_text = __('Current sitemap contains','litespeed-crawler');

	$spinner_url = admin_url( '/images/spinner.gif' );

	require_once LSCR_DIR.'crawler/custom-sitemap.php';

	$urls_to_crawl_count = get_sitemap_count();

	$auto_update_markup = ($settings['sitemap-updated']??false) ? 'updateSitemap();' : '';

	echo <<<HTML
<hr style="margin-top:20px">
<h3>$section_subtitle</h3>
<div style="height: 24px;display: flex;align-items:end;margin-bottom:5px">
	{$current_count_text} <span id="linksCount" style="margin:0 5px">{$urls_to_crawl_count}</span>URLs
</div>
<div id="linksDetails" style="margin-bottom:15px"></div>
<script>
jQuery(document).ready(function($) {
	function updateSitemap() {
		$('#linksCount').html('<img src="$spinner_url">');
		$('#linksDetails').html('Updating...');
		var data = {
			action: 'update_custom_sitemap',
			sitemap_update_forced: 'true',
			_wpnonce: '{$ajax_nonce}'
		};
		$.ajax({
			url: '{$ajax_url}',
			type: 'POST',
			data: data,
			success: function(response) {
				var result = JSON.parse(response);
				$('#linksCount').html(result.count);
				$('#linksDetails').html(result.message);
			},
			error: function(xhr) {
				$('#linksCount').html('Error: ' + xhr.status);
				$('#linksDetails').html('');
			}
		});
	}

	$('#fetch_data').click(updateSitemap);

	{$auto_update_markup}
});
</script>
HTML;
	

	the_update_sitemap_button();

}

function the_save_setting_button(){

	if ( is_crawler_running() ){

		_e('You can\'t change the settings now because the crawler is running.', 'litespeed-crawler');
		
		return;
	}

	$save_setting_text = __('Save settings', 'litespeed-crawler');

	echo
	<<<HTML
	<button class="button button-primary" type="submit" id="submit">{$save_setting_text}</button>
	HTML;
	
}

function the_update_sitemap_button(){

	if ( is_crawler_running() ){

		_e('You can\'t update the sitemap now because the crawler is running.', 'litespeed-crawler');
		
		return;
	}

	$save_setting_text = __('Update sitemap', 'litespeed-crawler');

	echo
	<<<HTML
	<button id="fetch_data" class="button button-primary">{$save_setting_text}</button>
	HTML;
	
}


function get_form_data($settings) {

	// Set default values
	$settings['enabled'] ??= false;
	$settings['frequency'] ??= 'daily';
	$settings['priority-keywords'] ??= [];
	$settings['excluded-keywords'] ??= [];
	$settings['server-ip'] ??= $_SERVER['SERVER_ADDR'];
	$settings['custom-sitemap'] ??= '';
	$settings['sitemap_ttl'] ??= '2';
	$settings['threads'] ??= 1;
	$settings['server-load-slowdown'] ??= 3;

	$enabled		= checked($settings['enabled'], true, false); 
	$frequency		= get_frequency_options($settings['frequency']);
	$priority		= implode(PHP_EOL, $settings['priority-keywords']);
	$priority_rows	= max(2, count($settings['priority-keywords']));
	$excluded		= implode(PHP_EOL, $settings['excluded-keywords']);
	$excluded_rows	= max(2, count($settings['excluded-keywords']));
	$server_ip		= get_server_display_ip_markup($settings);
	$sitemap_ttl	= get_sitemap_ttl_options_markup($settings['sitemap_ttl']);

	$data = [
		'enabled' => [
			'text' => __('Crawler is enabled', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="checkbox" name="enabled" value="1" class="chkbox" {$enabled}>
HTML
			,
			'description' => '',
		],
		'frequency' => [
			'text' => __('Crawler frequency', 'litespeed-crawler'),
			'input' => <<<HTML
<select name="frequency" id="frequency">{$frequency}</select>
HTML
			,
			'description' => __('How often the crawler should run?', 'litespeed-crawler'),
		],
		'priority_keywords' => [
			'text' => __('Priority keywords:', 'litespeed-crawler'),
			'input' => <<<HTML
<textarea name="priority-keywords" rows="{$priority_rows}" cols="60">{$priority}</textarea>
HTML
			,
			'description' => __('URLs containing these keywords will be crawled first, e.g. /product/ or /2023/, one per line', 'litespeed-crawler'),
		],
		'excluded_keywords' => [
			'text' => __('Excluded keywords:', 'litespeed-crawler'),
			'input' => <<<HTML
<textarea name="excluded-keywords" rows="{$excluded_rows}" cols="60">{$excluded}</textarea>
HTML
			,
			'description' => __('For example /checkout/,^/my-account/.*,^/2024/, supports Regex. One per line.', 'litespeed-crawler'),
		],
		'server_ip' => [
			'text' => __('Server IP:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="text" name="server-ip" autocomplete="off" value="{$server_ip}">
HTML
			,
			'description' => get_server_ip_description(),
		],
		'custom_sitemap' => [
			'text' => __('Custom sitemap URL:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="text" name="custom-sitemap" autocomplete="off" value="{$settings['custom-sitemap']}">
HTML
			,
			'description' => __('no domain, e.g. <i>/sitemap.xml</i> or <i>/sitemap_index.xml</i>. Leave empty for WP default <i>/wp-sitemap.xml<i>.', 'litespeed-crawler'),
		],
		'sitemap_ttl' => [
			'text' => __('Sitemap TTL', 'litespeed-crawler'),
			'input' => <<<HTML
<select name="sitemap_ttl" id="sitemap_ttl">{$sitemap_ttl}</select>
HTML
			,
			'description' => __('Sets how often should be updated crawler\'s sitemap', 'litespeed-crawler'),
		],
		'threads' => [
			'text' => __('Number of threads:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="number" name="threads" autocomplete="off" value="{$settings['threads']}">
HTML
			,
			'description' => __('Number of threads, simultaneously crawling the website. Recommended value is one per CPU core available.', 'litespeed-crawler'),
		],
		'server_load_slowdown' => [
			'text' => __('Slow down crawl when server load is over:', 'litespeed-crawler'),
			'input' => <<<HTML
<input type="number" name="server-load-slowdown" autocomplete="off" value="{$settings['server-load-slowdown']}">
HTML
			,
			'description' => __('When server load reaches this level, it will increase time between requests batches to 1 second times numbers threads. 0 is no delay between crawler\'s requests.', 'litespeed-crawler') . ' ' . get_current_server_load_markup(),
		],
	];
	

	return $data;
}

function get_server_display_ip_markup($settings){

	if( $settings['server-ip'] == $_SERVER['SERVER_ADDR'] ) return '';

	return $settings['server-ip'];
}

function get_server_ip_description(){

	$local_server_ip = $_SERVER['SERVER_ADDR'];

	$public_server_ip = get_domain_ip_from_cloudflare($_SERVER['HTTP_HOST']);
	
    return sprintf(__("Local IP is %s and public IP is %s. Leave empty to use local IP.", 'litespeed-crawler'), $local_server_ip, $public_server_ip);

}


function get_domain_ip_from_cloudflare($domain_name){
     
    $dns_server = ['1.1.1.1'];// Cloudflare WARP
	
    return dns_get_record($domain_name, DNS_A, $dns_server )[0]['ip'];
}

function get_frequency_options($current_frequency) {
	
	$options = [
		'hourly'		=> __('Hourly', 'litespeed-crawler'),
		'twicedaily'	=> __('Twicedaily', 'litespeed-crawler'),
		'daily'			=> __('Daily', 'litespeed-crawler'),
		'weekly'		=> __('Weekly', 'litespeed-crawler'),
	];

	return get_options_markup( $options, $current_frequency );
}

function get_sitemap_ttl_options_markup($selected){

	$options = [
		'0'		=> __('None', 'litespeed-crawler'),
		'1'		=> __('1 hour', 'litespeed-crawler'),
		'2'		=> __('2 hours', 'litespeed-crawler'),
		'12'	=> __('12 hours', 'litespeed-crawler'),
		'24'	=> __('A day', 'litespeed-crawler'),
		'168'	=> __('Week', 'litespeed-crawler'),
		'336'	=> __('2 weeks', 'litespeed-crawler'),
		'720'	=> __('A month', 'litespeed-crawler'),
        '8766'	=> __('A year', 'litespeed-crawler'),
	];

	return get_options_markup( $options, $selected );
}

function get_options_markup( $options, $selected ){

	$options_html = '';

	foreach ($options as $value => $label) {
		$selected_markup = selected( $value, $selected, false);
		$options_html .= 
		<<<HTML
		<option value="{$value}"{$selected_markup}>{$label}</option>;
		HTML;
		
	}

	return $options_html;

}

function get_settings_to_display(){

	if( $_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST) ) return LSCR_SETTINGS;
	
	require LSCR_DIR.'/includes/save-settings.php';

	if( is_allowed_to_save() ) {
	
		$new_settings = get_new_settings();

		update_option( 'ls_crawler_settings', $new_settings, 'no' );

		display_saved_settings();

		require_once LSCR_DIR.'crawler/custom-sitemap.php';

		if( ($settings['sitemap-updated']??false) ){

			empty_crawler_url_table();
		}

	} else {
		
		display_not_allowed_to_save();

	}

	return $new_settings??LSCR_SETTINGS;
}

function get_current_server_load_markup(){

	$current_load = get_current_server_load();

	// if( $current_load === false ) return __("N/A", 'litespeed-crawler');

	$current_load_string = ($current_load === false) ? __('N/A', 'litespeed-crawler') : (string) $current_load;

	return sprintf(__("Current server load: %s", 'litespeed-crawler'), $current_load_string);
}