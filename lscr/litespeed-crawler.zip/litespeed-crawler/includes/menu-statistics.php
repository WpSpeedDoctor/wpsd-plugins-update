<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

require LSCR_DIR.'includes/sql.php';

require_once LSCR_DIR.'crawler/curl.php';

?><h3><?php echo __('Statistics','ls_crawler');?></h3><?php

display_stats();

function display_stats(){

	if( is_numeric($_GET['run']??'') ) {

		display_run_details();

	} else {

		display_overall_stats_main();
	}


}

function display_overall_stats_main(){

	?>
	<hr id="start-stats">
	<h4><?php echo __('Latest crawler statistics','ls_crawler');?></h4>
	<?php

	$last_stats = get_last_stats();

	if ( empty($last_stats) ) {

		?><p>The crawler hasn't run yet.</p><?php

	} else {

		display_overall_stats($last_stats);

	}
	

}

function display_overall_stats($last_stats) {

?>
<div class="stats-box">
	<table class="stats-table">
		<tbody>
			<tr>
				<td class="stat-name"><?=__('Statistics from','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Min time','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Max time','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Avg TTFB','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Avg no-hit TTFB','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Avg TTFB score','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Cache hit','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('No cache','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('301','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('302','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('403','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('404','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('50x','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Crawled','litespeed-crawler')?></td>
				<td class="stat-value"><?=__('Crawl duration','litespeed-crawler')?></td>
			</tr>
<?php
  
  foreach ($last_stats as $stats) {

	$start_date_time = explode('.', $stats['start'])[0] ?? '-';
	$data = json_decode($stats['data'] ?? '', true);
	$min_ttfb = $data['min_ttfb'] ?? '-';
	$avg_ttfb = $data['avg_ttfb'] ?? '-';
	$avg_no_hit_ttfb = isset($data['avg_no_hit_ttfb']) ? "{$data['avg_no_hit_ttfb']} ms" : '-';
	$avg_score = get_time_value_score_markup($avg_ttfb);
	$max_ttfb = $data['max_ttfb'] ?? '-';
	$no_cache = $data['no_cache'] ?? '0';
	$off = $data['off'] ?? '0';
	$response301 = get_non_200_response_value_markup($data['response_301'] ?? '0');
	$response302 = get_non_200_response_value_markup($data['response_302'] ?? '0');
	$response404 = get_non_200_response_value_markup($data['response_404'] ?? '0');
	$response403 = get_non_200_response_value_markup($data['response_403'] ?? '0');
	$response50x = get_non_200_response_value_markup($data['response_50x'] ?? '0');
	$cache_hit_percentage = get_overall_cache_hit_percentile($data);
	$no_cache_sum = $no_cache + $off;
	$run_id = $stats['run_id'] ?? '-';
	$crawled_percentile = get_crawled_percentile( $data, $stats );
	$time_transcurrent = get_transcurrent_time_markup($stats);
	$run_stats_url = admin_url("/options-general.php?page=litespeed_crawler&tab=stats&run=$run_id");

	echo <<<HTML
	<tr>
		<td class="stat-name">
			<a href="{$run_stats_url}">
				{$start_date_time}
			</a>
		</td>
		<td class="stat-value">
			{$min_ttfb} ms
		</td>
		<td class="stat-value">
			{$max_ttfb} ms
		</td>
		<td class="stat-value">
			{$avg_ttfb} ms
		</td>
		<td class="stat-value">
			{$avg_no_hit_ttfb}
		</td>
		<td class="stat-value">
			{$avg_score}
		</td>
		<td class="stat-value">
			{$cache_hit_percentage} %
		</td>
		<td class="stat-value">
			{$no_cache_sum}
		</td>
		<td class="stat-value">
			{$response301}
		</td>
		<td class="stat-value">
			{$response302}
		</td>
		<td class="stat-value">
			{$response403}
		</td>
		<td class="stat-value">
			{$response404}
		</td>
		<td class="stat-value">
			{$response50x}
		</td>
		<td class="stat-value">
			{$crawled_percentile}
		</td>
		<td class="stat-value">
			{$time_transcurrent}
		</td>
	</tr>
HTML;
}
  
	?>
			</tbody>
		</table>
	<?php
}

function get_transcurrent_time_markup($stats) {
	
	if (($stats['end'][0] ?? '0') == '0') return '-';

	$start_time = new \DateTime($stats['start']);
	
	$end_time = new \DateTime($stats['end']);
	
	$interval = $start_time->diff($end_time);

	switch(true) {
		
		case ($interval->h == 0 && $interval->i == 0):

			return $interval->format('%ss');
		
		case ($interval->h == 0):
			
			return $interval->format('%im %ss');
		
		default:
			
			return $interval->format('%hh %im %ss');
	}
}



function get_crawled_percentile( $data, $stats ){

	$crawled_total = intval($data['crawled_total']??0);
	
	$sitemap_total = intval($stats['count']??0);

	if( $crawled_total === 0 || $sitemap_total === 0 ) return '-';

	$percentile  = floor( ($crawled_total / $sitemap_total) * 100 );

	return "$percentile% ($crawled_total/$sitemap_total)";
}

function get_overall_cache_hit_percentile($data) {

	if ( empty($data['crawled_total']) ) return '-';

	$total_count = (int) $data['crawled_total'];

	$hit_count = (int) $data['hit'];

	if ( $hit_count === $total_count ) return 100;

	if( $hit_count === 0 ) return '0';

	return floor(($hit_count / $total_count) * 100);
}

function display_run_details(){

	display_stats_options_table();

	display_run_stats_by_args();
}

function display_run_stats_by_args(){

	$run_id = (int) sanitize_text_field($_GET['run']);

	$results= get_events_by( $run_id, $_POST );

	if( empty($results) ){

		?><h4><?=__('No results','litespeed-crawler')?></h4><?php
	} else {

		display_queried_results($results);
	}
}

function display_queried_results($results) {
	?>
	<table class="stats-table">
	  <thead>
		<tr>
		  <th class="stat-name">URL</th>
		  <th class="stat-value">Response</th>
		  <th class="stat-value">TTFB</th>
		  <th class="stat-value">Cache Status</th>
		</tr>
	  </thead>
	  <tbody>
	  <?php foreach ($results as $result) {?>
		<tr>
		  <td class="stat-name"><?=trailingslashit($result['url'])?></td>
		  <td class="stat-value"><?=$result['response']?></td>
		  <td class="stat-value"><?=$result['ttfb']?> ms</td>
		  <td class="stat-value"><?=$result['cache_status']?></td>
		</tr>
	  <?php }?>
	  </tbody>
	</table>
	<?php
}

function get_non_200_response_value_markup($value){

	if( $value != '0' ) return '<span class="value-very-bad">'.$value.'</span>';

	return '-';
}

// array (
// 	'sort-type' => 'slowest',
// 	'cache-type' => 'cache-hit',
// 	'response-type' => 'response-200',
//   )


function display_stats_options_table() {
  ?>
	<form method="post" action="<?=$_SERVER['REQUEST_URI']?>">
		<div class="stats-options">
			<?php
			the_select_component('Sort type', 'sort-type', [
				'slowest' => 'Slowest',
				'fastest' => 'Fastest'
			]);

			the_select_component('Cache status', 'cache-type', [
				'all' => 'Any',
				'cache-hit' => 'Cache Hit',
				'cache-miss' => 'Cache Miss',
				'no-cache' => 'No Cache',
				'cache-off' => 'Cache Off'
			]);

			the_select_component('Response code', 'response-type', [
				'all-responses' => 'All Responses',
				'response-200' => '200',
				'response-301' => '301',
				'response-302' => '302',
				'response-403' => '403',
				'response-404' => '404',
				'response-50x' => '50x'
			]);
		  ?>

			<input type="submit" value="Apply Filters">
		</div>
	</form>
	<br>
	<?php
}


function the_select_component($label, $id, $options) {
  ?>
	<label for="<?=$id?>"><?=$label?>:</label>
	<select name="<?=$id?>" id="<?=$id?>">
		<?php foreach ($options as $value => $text){?>
			<?php $selected = ( ($_POST[$id]??'') === $value) ? 'selected' : '';?>
			<option value="<?=$value?>" <?=$selected?>><?=$text?></option>
		<?php }?>
	</select>
	<?php
}

function get_value_score( $value ){

	if( $value > 3000 ) return 'very bad';

	if( $value > 1500 ) return 'bad';
	
	if( $value > 1200 ) return 'mediocre';

	if( $value > 1000 ) return 'OK';

	if( $value > 150 ) return 'good';

	if( $value > 80 ) return 'very good';

	return 'excellent';
}

function get_time_value_score_markup( $value ){

	if ( !is_numeric($value) ) return '';

	$value_score = get_value_score( $value ); 

	$value_class = 'value-'.str_replace(' ', '-', $value_score );

	$value_score_markup = '<span class="'.$value_class.'">'.$value_score.'</span>';

	return $value_score_markup;

}