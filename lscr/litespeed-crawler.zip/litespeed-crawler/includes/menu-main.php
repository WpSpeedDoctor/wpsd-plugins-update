<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

$active_tab = $_GET['tab']??'home';

if( !in_array($active_tab,['home','stats','settings']) ) wp_die('Page doesn\'t exist');

?><div class="ls-plugin-container"><?php

display_plugin_header();

display_tab_links($active_tab);

display_php_timeout_warning();


include __DIR__.'/'.get_tabs_arr()[$active_tab]['require'];


?></div><?php


/**
 * Functions only
 */

function display_plugin_header(){

?> 
<h2>
	<?=__('LiteSpeed crawler','litespeed-crawler');?>
</h2>
<h4>
	<i><?=__('Advanced crawler for LiteSpeed cache plugin','litespeed-crawler');?></i>
</h4>
<?php 
}


function display_tab_links( $active_tab ){
	
	?><nav class="ls-tabs"><?php
	
	foreach (get_tabs_arr() as $slug => $tab_arr){
		
		$active_tab_class = ($slug === $active_tab) ? ' nav-tab-active' : '';
		
		$tab_qs = $slug == 'home' ? '':'&tab='.$slug;
		
		?>
		<a href="?page=litespeed_crawler<?=$tab_qs?>" class="nav-tab<?=$active_tab_class?>">
			<?=$tab_arr['title']?>
		</a>
		<?php
	}
	
?></nav><br><br><?php
}

function get_tabs_arr(){

	return [
		
		'home'		=> [ 
				
			'title' 	=> __('Home','litespeed-crawler'),
			'require'	=> 'menu-home.php',
		],
		'stats'		=> [

			'title' 	=> __('Statistics','litespeed-crawler'),
			'require'	=> 'menu-statistics.php',
		],
		
		'settings'	=> [

			'title' 	=> __('Settings','litespeed-crawler'),
			'require'	=> 'menu-settings.php',
		]
	
	];

}

function the_form_value($value=false) {

	if ( !empty($value) or $value == '0' ) echo 'value="'.$value.'"';

}

function the_form_checked($value=false) {
	
	if ( $value == '1' )  echo 'checked';

}

function is_crawler_running(){
	
	return !empty( get_run_id() );
}

function display_php_timeout_warning() {
	
	$php_timeout = (int) ini_get('max_execution_time');
	
	if ( $php_timeout>29 ) return;
	
	$message = "$php_timeout ";

	$message = __('seconds of PHP timeout is a bit low.  Recommended value is at least 30 seconds.','litespeed-crawler');

echo 
<<<HTML
<br>
<div class="notice notice-warning is-dismissible">
	<p>{$message}</p>
</div>
<br>
HTML;

}

