<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

include_once LSCR_DIR.'plugin-setup/universal-functions.php';

require_once LSCR_DIR.'includes/scheduler.php';
		
add_cron_tasks_main();

add_action( 'admin_notices', 'ls_crawler\display_admin_error_message');

add_filter( 
	
	'plugin_action_links_' . plugin_basename( get_plugin_main_file() ),

	'ls_crawler\add_action_links_ls_crawler'

);

function get_error_transient_name(){
	
	return __NAMESPACE__.'_error_message';
}

function set_admin_notice_message($message){

	set_transient(get_error_transient_name(),$message,20);
}


function display_admin_error_message() {

	$transient_name = get_error_transient_name();

	$admin_notice_message = get_transient($transient_name);

	if( empty($admin_notice_message) ) return;

	?>
    <div class="notice notice-error">
        <p><?=esc_html($admin_notice_message)?></p>
    </div>
    <?php

	delete_transient($transient_name);
}


function add_action_links_ls_crawler ( $actions ) {

		return array_merge(
			$actions,
			['<a href="' . admin_url( 'options-general.php?page=litespeed_crawler' ) . '">'.__('Settings','litespeed-crawler').'</a>']
		);
}


function ls_crawler_admin_menu() {

	add_submenu_page('options-general.php',
	//add_menu_page( 
		'LiteSpeed Crawler', 
		'LiteSpeed Crawler', 
		'manage_options', 
		'litespeed_crawler', 
		'ls_crawler\litespeed_crawler_admin_page'
		);

	// if( is_plugin_active( 'litespeed-cache/litespeed-cache.php' ) ) { 
	// add_menu_page('LiteSpeed Cache', 'LiteSpeed Cache', 'manage_options', 'lscache-settings') ;

	// add_submenu_page('litespeed',
	//     'LiteSpeed Cache Crawler', 
	//     'LiteSpeed Cache Crawler', 
	//     'manage_options', 
	//     'page=litespeed_crawler',
	//     'litespeed_crawler_admin_page', 
	//     'dashicons-controls-repeat' 
	// );
	// }else {

	//   }

}
add_action('admin_menu', 'ls_crawler\ls_crawler_admin_menu');


function litespeed_crawler_admin_page(){
	
	set_settings_constant();

	require __DIR__.'/menu-main.php';
}

if( ($_GET['page']??'' ) === 'litespeed_crawler' ) {

	add_action('admin_print_styles', 'ls_crawler\enqueue_crawler_plugin_styles');

	function enqueue_crawler_plugin_styles(){
	
		wp_register_style( 'ls_crawler_admin_css', trailingslashit(plugin_dir_url( get_plugin_main_file() )).'style.css', false, LSCR_VER );
		wp_enqueue_style( 'ls_crawler_admin_css' );
	}
} 

