<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

function add_cron_tasks_main(){

	if( empty(get_option('ls_crawler_settings')['enabled']??false) ) return;
	
	add_cron_events();
	
	add_automatic_start_crawler();

}

function add_cron_events(){

	add_action( 'init', 'ls_crawler\schedule_custom_cron' );

	add_action( 'ls_crawler_run', 'ls_crawler\ls_crawler_event_task' );
	
	add_action( 'init', 'ls_crawler\schedule_daily_cron' );
	
	add_action( 'ls_crawler_daily', 'ls_crawler\ls_crawler_daily_task' );
}


function add_automatic_start_crawler(){

	//run after any update
	add_action( 'after_theme_update', 'ls_crawler\ls_crawler_event_task',999 );

	add_action( 'upgrader_process_complete', 'ls_crawler\ls_crawler_event_task',999 );

	//LiteSpeed purge
	add_action( 'litespeed_purged_all', 'ls_crawler\ls_crawler_event_task',999 );

}

function schedule_daily_cron(){

	if ( wp_next_scheduled( 'ls_crawler_daily' ) ) return;

	wp_schedule_event( time(), 'daily', 'ls_crawler_daily' );
   
}

function ls_crawler_daily_task(){
	
	require_once LSCR_DIR.'includes/cleanup-stats.php';

	remove_old_stats();

}

function schedule_custom_cron() {

	if ( ! wp_next_scheduled( 'ls_crawler_run' ) ) {

		wp_schedule_event( time(), get_option('ls_crawler_settings')['frequency'], 'ls_crawler_run' );
   
	}
}

function ls_crawler_event_task(){
		
	require_once LSCR_DIR.'plugin-setup/universal-functions.php';

	require_once LSCR_DIR.'crawler/crushed-run-termination.php';

	$has_current_run_crushed = has_current_run_crushed();

	if( get_run_id() && !$has_current_run_crushed ) return;

	if( $has_current_run_crushed ){
		
		terminate_current_run();
	} 

	require_once LSCR_DIR.'crawler/curl.php';
	
	start_crawler_loop();
	
}
