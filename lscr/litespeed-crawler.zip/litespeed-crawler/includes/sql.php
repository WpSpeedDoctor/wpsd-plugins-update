<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;
/*
sql.php at 184 -> array (
  'min_ttfb' => '45',
  'avg_ttfb' => '61',
  'max_ttfb' => '80',
  'response_301' => '0',
  'response_302' => '0',
  'response_404' => '0',
  'response_403' => '0',
  'response_50x' => '0',
  'hit' => '0',
  'miss' => '0',
  'no_cache' => '0',
  'off' => '22',
)

*/
function get_run_stats($run_id) {

    global $wpdb;
    
	return $wpdb->get_row($wpdb->prepare(

"SELECT 
MIN(CASE WHEN response = 200 THEN ttfb END) AS min_ttfb,
ROUND(AVG(CASE WHEN response = 200 THEN ttfb END), 0) AS avg_ttfb,
MAX(CASE WHEN response = 200 THEN ttfb END) AS max_ttfb,
COUNT(CASE WHEN response = 301 THEN 1 END) AS response_301,
COUNT(CASE WHEN response = 302 THEN 1 END) AS response_302,
COUNT(CASE WHEN response = 404 THEN 1 END) AS response_404,
COUNT(CASE WHEN response = 403 THEN 1 END) AS response_403,
COUNT(CASE WHEN response > 499 THEN 1 END) AS response_50x,
COUNT(CASE WHEN cache_status = 'hit' THEN 1 END) AS hit,
COUNT(CASE WHEN cache_status = 'miss' THEN 1 END) AS miss,
COUNT(CASE WHEN cache_status = 'no-cache' THEN 1 END) AS no_cache,
COUNT(CASE WHEN cache_status = 'off' THEN 1 END) AS off,
COUNT(*) AS crawled_total
FROM `{$wpdb->prefix}lscr_stats`
WHERE run_id = %d", 

	$run_id
   ), ARRAY_A);
}


function update_run_summary_on_end($run_id, $end_datetime, $summary) {

	global $wpdb;

	$server_load = get_current_server_load_sql_markup();

	$sql_update_summary = $wpdb->prepare(
		"UPDATE `{$wpdb->prefix}lscr_summary`
		SET `end` = %s,
			`end-load` = $server_load,
			`data` = %s
		WHERE `run_id` = %d",
		$end_datetime,
		$summary,
		$run_id
	);
	
	$wpdb->query($sql_update_summary);

}

function get_count_stored_stats($run_id) {

    global $wpdb;
    
	return intval(
        $wpdb->get_var(
            "SELECT COUNT(run_id) FROM `{$wpdb->prefix}lscr_stats` WHERE `run_id` = $run_id"
        )
    );
}


function get_run_urls_count($run_id) {

	global $wpdb;
	
	return (int) $wpdb->get_var(
		"SELECT `count` FROM `{$wpdb->prefix}lscr_summary` WHERE `run_id` = $run_id"
	);
}



function get_sql_matching_rules_markup($args){

	if( empty(LSCR_SETTINGS['priority-keywords']) ) return '';

	global $wpdb;

	$sql = 
'
WHERE 1=1
ORDER BY CASE
';


	$case_order = 0;

	foreach ( LSCR_SETTINGS['priority-keywords'] as $string ) {

		++$case_order;

		$escaped_string = $wpdb->esc_like( $string );
		
		$sql .= $wpdb->prepare( "WHEN `url` LIKE %s THEN %d\n", '%' . $escaped_string . '%', $case_order );
	}
	
	++$case_order;

	$sql .="WHEN 1=1 THEN {$case_order}\n";
	
	++$case_order;

	$sql .= "ELSE $case_order \nEND";

	return $sql;

}

function get_exclude_markup() {
  
	if ( empty( LSCR_SETTINGS['excluded-keywords'] ) ) return '';

    $prepared_query = 'AND ( ';
    
    foreach( LSCR_SETTINGS['excluded-keywords'] as $keyword){
    
        $prepared_query .="`url` NOT LIKE '%".esc_sql($keyword)."%' AND ";
            
    }
	
	$prepared_query = rtrim($prepared_query,' AND ').' ) ';
	
    return $prepared_query;
}

function get_priority_markup(){
	
	$prepared_query =' WHERE ( ';
	
	foreach( LSCR_SETTINGS['priority-keywords'] as $keyword){

	    $prepared_query .= "`url` LIKE '%".esc_sql($keyword)."%' OR ";
	    
	}
    
    return trim( $prepared_query, 'OR ').' OR `url` LIKE \'http%\' ) ';
    
}

function get_match_all_markup(){

	return "WHERE `url` LIKE 'http%'";

}

function get_last_stats(){

	$exclude_current_run_markup = get_exclude_current_run_markup();

	global $wpdb;

	$sql_last_stats = 
"SELECT * FROM `{$wpdb->prefix}lscr_summary` {$exclude_current_run_markup}
ORDER BY `{$wpdb->prefix}lscr_summary`.`run_id`
DESC
LIMIT 30";

	$last_stats = get_sql_query($sql_last_stats);
	
	return are_all_stats_complete($last_stats) === true ? $last_stats : get_last_stats();

}


function are_all_stats_complete( $last_stats ){

	$current_run = get_run_id();

	$stats_complete = true;

	foreach ( $last_stats as $run_stats){

		if( !empty($run_stats['data']) || $current_run == $run_stats['run_id']) continue;

		$end_datetime = '0'; //date('Y-m-d H:i:s');

		$run_summary = get_run_stats( $run_stats['run_id'] );
		
		//return true to avoid infinite recursion
		if( empty($run_summary) ) return true;

		$summary = json_encode( $run_summary );

		update_run_summary_on_end( $run_stats['run_id'], $end_datetime, $summary );

		$stats_complete = false;
	}

	return $stats_complete;

}

function get_exclude_current_run_markup(){

	$run_id = get_run_id();

	if( empty( $run_id ) ) return '';

	return "WHERE `run_id` != $run_id";
}


function get_events_by( $run_id, $args ){
	
	global $wpdb;

	$order_markup = get_run_events_sql_args_markup( $args, $wpdb->prefix );

$sql="SELECT *  FROM `{$wpdb->prefix}lscr_stats`
WHERE `run_id` = {$run_id}
{$order_markup}
LIMIT 200;";

	return get_sql_query($sql);

}

function get_run_events_sql_args_markup( $args, $prefix){

	$sort_type = ($args['sort-type']??'slowest') == 'fastest' ? 'ASC': 'DESC';

	$cache_type = get_cache_type_markup($args['cache-type']??'any');

	$response_type = get_response_type_markup( $args['response-type']??'all-responses' );

	$sql = "{$cache_type}
{$response_type}
ORDER BY `{$prefix}lscr_stats`.`ttfb` {$sort_type}";

	return $sql;
}

function get_new_run_id( $urls_count ){
	
	global $wpdb;
	
	$server_load = get_current_server_load_sql_markup();

	$start_datetime = date('Y-m-d H:i:s');

	$sql_new_run_id = 
"INSERT INTO `{$wpdb->prefix}lscr_summary`
(
	`run_id`,
	`start`,
	`end`,
	`start-load`,
	`end-load`,
	`count`,
	`data`
) VALUES (
	NULL,
	'{$start_datetime}',
	NULL,
	'{$server_load}',
	NULL,
	'{$urls_count}',
	NULL
);";
		
	get_sql_query($sql_new_run_id);

	return $wpdb->insert_id;
	
}


function get_last_run_id() {

	global $wpdb;
	
	return $wpdb->get_var(
	
		"SELECT run_id FROM `{$wpdb->prefix}lscr_summary` ORDER BY run_id DESC LIMIT 1"
	
	);
}



function get_cache_type_markup( $cache_type ){

	$cache_types = [

		'cache-hit' => 'hit',
		'cache-miss' => 'miss',
		'no-cache' => 'no-cache',
		'cache-off' => 'off'
		
	];

	return empty($cache_types[$cache_type]) ? '' : " AND `cache_status` = '{$cache_types[$cache_type]}'";
}

function get_response_type_markup( $response_type ){

	$response_types = [

		'response-200'	=> '200',
		'response-301'	=> '301',
		'response-302'	=> '302',
		'response-403'	=> '403',
		'response-404'	=> '404',
		'response-50x'	=> '5%'
		
	];

	return empty($response_types[$response_type]) ? '' : " AND `response` LIKE '{$response_types[$response_type]}'";
}
