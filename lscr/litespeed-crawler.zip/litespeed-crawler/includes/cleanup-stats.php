<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

function remove_old_stats() {

    global $wpdb;
    
	$old_run_ids = get_old_run_ids();
    
    foreach (array_chunk($old_run_ids, 50) as $run_ids_batch) {
        
		$in_clause = implode(',', array_map('intval', $run_ids_batch));
        
        $wpdb->query("DELETE FROM {$wpdb->prefix}lscr_summary WHERE run_id IN ($in_clause)");

        $wpdb->query("DELETE FROM {$wpdb->prefix}lscr_stats WHERE run_id IN ($in_clause)");
    }
}

function get_old_run_ids() {

    global $wpdb;
    
	return $wpdb->get_col(
    
		"SELECT run_id FROM {$wpdb->prefix}lscr_summary WHERE start < DATE_SUB(NOW(), INTERVAL 30 DAY)"
    
	);
}
