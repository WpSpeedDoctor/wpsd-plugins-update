<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;


function plugin_activation(){

	mu_plugin_activation();

	create_default_settings();

	create_plugin_tables();

	update_db_tables();

	delete_legacy_db_data();

	add_cron_tasks_main();
}

function update_db_tables(){
    
	global $wpdb;
    
	$table_name = $wpdb->prefix . 'lscr_summary';

    $column = $wpdb->get_results("SHOW COLUMNS FROM `$table_name` LIKE 'count'");
    
    if ( !empty($column) ) return;

    $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `count` MEDIUMINT UNSIGNED NOT NULL DEFAULT 0");
}


function delete_legacy_db_data(){

	global $wpdb;

	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}litespeed_crawler_stats" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}litespeed_crawler_summary" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}litespeed_crawler_url" );

	delete_option('ls_crawler_url_count');
}

function create_default_settings(){

	if( empty(get_option('ls_crawler_settings')) ){

		add_option('ls_crawler_settings', get_default_crawler_settings(),'', 'no');
	}
		
	if( get_run_id() === false ){

		add_option('ls_crawler_run_id', 0 ,'', 'no'); //0 when crawler is not running
	}

	get_ajax_nonce();

}

function get_default_crawler_settings(){

	return [
		
		'priority-keywords'		=> [],

		'excluded-keyword'		=> ['wp-admin','login'],

		'custom-sitemap'		=> '/wp-sitemap.xml',

		'threads'				=> '1',

		'server-load-slowdown'	=> '3',

		'enabled' 				=> '0',

		'server-ip'				=> $_SERVER['SERVER_ADDR'],
		
		'frequency'				> 'daily'

	];
}

function create_plugin_tables(){

	$existing_tables = get_existing_tables_names();

	foreach ( get_plugins_table_sql_data() as $table_name => $sql_to_create_table) {

		if ( has_table( $table_name, $existing_tables ) ) continue;

		get_sql_query( $sql_to_create_table );

	}

}

function get_plugins_table_sql_data(){

	global $wpdb;

	return [

"{$wpdb->prefix}lscr_url" =>

"CREATE TABLE `{$wpdb->prefix}lscr_url`
	(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
	PRIMARY KEY (`id`),
	UNIQUE KEY `url` (`url`(191))
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;",


"{$wpdb->prefix}lscr_stats" => 
		
"CREATE TABLE `{$wpdb->prefix}lscr_stats` 
(`meta_id` INT NOT NULL AUTO_INCREMENT,
`run_id` INT NOT NULL,
`url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
`response` SMALLINT(1) UNSIGNED NOT NULL,
`ttfb` SMALLINT(1) UNSIGNED NOT NULL,
`cache_status` VARCHAR(8) NULL,
PRIMARY KEY (`meta_id`)) 
ENGINE = InnoDB
CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci", 


"{$wpdb->prefix}lscr_summary" => 
		
"CREATE TABLE `{$wpdb->prefix}lscr_summary` (
	`run_id` INT NOT NULL AUTO_INCREMENT,
	`start` DATETIME(1) NULL,
	`end` DATETIME(1) NULL,
	`start-load` FLOAT NULL,
	`end-load` FLOAT NULL,
	`count` MEDIUMINT UNSIGNED NOT NULL DEFAULT 0,
	`data` VARCHAR(255) NULL,
	PRIMARY KEY (`run_id`)
	)
ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci"
];

}

function get_existing_tables_names(){

	$sql_result = get_sql_query('SHOW FULL TABLES');

	return 	wp_list_pluck( $sql_result, 'Tables_in_'.DB_NAME );

}

function has_table( $table_name, $existing_tables ){

	return in_array($table_name, $existing_tables);
}

function create_plugin_table( $sql ){

	get_sql_query($sql);

}	

/**
 * End of setup
 */

function plugin_deactivation(){
	
	mu_plugin_deactivation();

	unschedule_cleanup_cron();
}

function unschedule_cleanup_cron(){
	
	$timestamp = wp_next_scheduled( 'ls_crawler_run' );

	wp_unschedule_event( $timestamp, 'ls_crawler_run' );
	
	$timestamp = wp_next_scheduled( 'ls_crawler_daily' );

	wp_unschedule_event( $timestamp, 'ls_crawler_daily' );

}

function mu_plugin_activation(){

	require LSCR_DIR.'plugin-setup/setup-must-use-plugins.php';
	
	activate_local_mu_plugins();
}

function mu_plugin_deactivation(){

	require LSCR_DIR.'plugin-setup/setup-must-use-plugins.php';

	if ( file_exists( LSCR_MU_LOADER_WP_FILEPATH ) ) unlink( LSCR_MU_LOADER_WP_FILEPATH );

}

