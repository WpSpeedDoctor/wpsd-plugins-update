<?php

namespace ls_crawler;

if( !isset($_GET['litespeed-crawler']) ) return;

define('POST', get_request_post() );

if( empty(POST['action']) || (POST['_wpnonce']??'') !== get_ajax_nonce() ) die_forbidden();

set_settings_constant();

/**
 * Run crawler
 */
require LSCR_DIR.'crawler/crawler-main.php';




function get_request_post(){

	if( !empty($_POST) ) return $_POST;

	return json_decode( file_get_contents('php://input'), true);

}

function die_forbidden(){

	http_response_code(403);

	die('Forbiden 403');
}