<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;



function get_new_settings(){

	$new_settings['priority-keywords'] = get_textarea_settings('priority-keywords');

	$new_settings['excluded-keywords'] = get_textarea_settings('excluded-keywords');
	
	$new_settings['custom-sitemap'] = get_sitemap_uri();

	$new_settings['sitemap_ttl'] = get_settings_numeric_value( ($_POST['sitemap_ttl']??2), 0, 8766, 2 );

	$new_settings['threads'] = get_settings_numeric_value( ($_POST['threads']??1), 1, 24, 1 );
	
	$new_settings['server-load-slowdown'] = get_settings_numeric_value( ($_POST['server-load-slowdown']??3), 0, 45, 3 );
	
	$new_settings['enabled'] = get_enabled_status();

	$new_settings['discover'] = isset($_POST['discover']) ? '1' : '0';

	$new_settings['frequency'] = in_array($_POST['frequency']??'', ['hourly','twicedaily','daily','weekly']) ? $_POST['frequency'] : 'daily';
	
	$new_settings['server-ip'] = empty($_POST['server-ip']) ? $_SERVER['SERVER_ADDR'] : filter_var($_POST['server-ip'], FILTER_VALIDATE_IP);

	$new_settings['sitemap-updated'] = is_sitemap_updated( $new_settings );

	reschedule_cron_tasks($new_settings);

	return $new_settings;
	
}


function is_sitemap_updated( $new_settings ){

	$new_settings_related_to_sitemap = [
	
		'excluded-keywords',
		'custom-sitemap'

	]; 

	foreach( $new_settings_related_to_sitemap as $key ){

        if( $new_settings[$key]!== LSCR_SETTINGS[$key] ) return true;

    }

	return false;
}

function reschedule_cron_tasks($new_settings){

	require_once LSCR_DIR.'plugin-setup/setup.php';

	unschedule_cleanup_cron();

}

function get_sitemap_uri(){

	$sitemap_uri = empty($_POST['custom-sitemap']) ? '/wp-sitemap.xml' : trim($_POST['custom-sitemap']);

	if (filter_var(  home_url().$sitemap_uri, FILTER_VALIDATE_URL) === FALSE) return '/wp-sitemap.xml';

	$sitemap_uri = str_replace('..', '', $sitemap_uri);

	$sitemap_uri = urldecode($sitemap_uri);

	$sitemap_uri = preg_replace('/[^-a-zA-Z0-9_\/.]/', '', $sitemap_uri);

	return $sitemap_uri;
}

function is_allowed_to_save(){

	return ($_POST['tab']??'') === 'crawler-settings' &&
	
	wp_verify_nonce( ($_POST['_wpnonce']??''), 'ls-crawler-settings') &&

	current_user_can('manage_options');
}

function get_textarea_settings($post_key){

	if( empty($_POST[$post_key])) return [];

	$input_without_double_spaces = remove_empty_spaces($_POST[$post_key]);

	$input_array = explode( PHP_EOL , sanitize_textarea_field( $input_without_double_spaces ));

	return array_unique( $input_array );
}


function get_settings_numeric_value( $value, $min, $max, $default ){

	if( !is_numeric( $value ) ) return (string) $default;

	if( $value < $min ) return (string) $min;

	return ($value > $max) ? (string) $max : (string) $value;

}

function remove_empty_spaces($string){

	return trim(str_replace([' ',"\n\n"],'', $string));
}

function get_enabled_status(){
	
	$current_crawler_status = get_option('ls_crawler_settings')['enabled'];
	
	if( $current_crawler_status === ($_POST['enabled']??'') ) return $current_crawler_status;

	wp_clear_scheduled_hook('ls_crawler_event');

	return empty($_POST['enabled']) ? '0':'1';

}

function display_saved_settings() {
	?>
	<br>
	<div class="notice notice-success is-dismissible">
		<p><?=__( 'Settings saved', 'litespeed-crawler' ); ?></p>
	</div>
	<?php
}

function display_not_allowed_to_save() {
	?>
	<br>
	<div class="notice notice-error is-dismissible">
		<p><?=__( 'Not authorized to save these settings', 'litespeed-crawler' ); ?></p>
	</div>
	<?php
}