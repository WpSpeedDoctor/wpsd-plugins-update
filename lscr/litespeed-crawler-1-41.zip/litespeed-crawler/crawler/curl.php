<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

set_settings_constant();

function get_server_host_and_ip(){

	static $resolve_ip;

	if( $resolve_ip ){

		return $resolve_ip;
	}

	$server_ip = empty(LSCR_SETTINGS['server-ip']) ? $_SERVER['SERVER_ADDR'] : LSCR_SETTINGS['server-ip'];

	$parsed_home_url = get_parsed_home_url();

	$port = $parsed_home_url['scheme'] === 'https' ? '443':'80';
	
	// IPv6 must be array and IPv4 must be as string
	// curl_setopt($ch, CURLOPT_RESOLVE, ['domain.com:443:2a01:390:dc4:1469:81:89:56:101']);

	$ip_markup = str_contains($server_ip, ':') ? "[{$server_ip}]" : $server_ip;

	$resolve_ip = ["{$parsed_home_url['host']}:$port:$ip_markup"];

	return $resolve_ip;

}

function get_parsed_home_url(){

	static $parsed_home_url;

	if( $parsed_home_url ){

		return $parsed_home_url;
	}

	$parsed_home_url = parse_url( LSCR_SETTINGS['home-url'] );
	
	return $parsed_home_url; 

}

/**
 * @param array $urls -
 * - id
 * - url
 * 
 * @param array $args -
 * - content
 * - header
 * 
 * @return array -
 * - start_datetime
 * - url_id
 * - response_code
 * - curl_error
 * - ttfb
 * - total_time
 * - response_header
 * - response_content
 */

function crawl_urls( $urls, $args=['content'=>0,'header'=>1] ){

	if( empty($urls) ) return [];

	$link_discover = $args['link-discover'] ?? false;

	if( $link_discover ){
		
		require_once LSCR_DIR.'crawler/custom-sitemap.php';

		unset( $args['link-discover'] );
	}

	$multi_handle = curl_multi_init();

	$curl_handles = [];
	
	foreach( $urls as $url_data ) {
		
		$url_to_crawl = LSCR_SETTINGS['home-url'].$url_data['url'];

		$handle = curl_init( $url_to_crawl );
		
		$curl_handles[] = $handle;

		curl_setopt_array( $handle, get_curl_request_settings( $url_to_crawl, $args ) );

		curl_multi_add_handle($multi_handle, $handle);
	}
	
	do {

		$status = curl_multi_exec($multi_handle, $running);
	
	} while( $status === CURLM_CALL_MULTI_PERFORM || $running );
	
	foreach( $curl_handles as $index => $handle ) {

		// url that request been made to: curl_getinfo($handle, CURLINFO_EFFECTIVE_URL);
		
		$results[$index]['url'] = $urls[$index]['url'];

		$results[$index]['response_code'] = curl_getinfo( $handle, CURLINFO_HTTP_CODE );

		$results[$index]['curl_error'] = curl_errno($handle);
		
		$results[$index]['ttfb'] = get_response_ttfb($handle);

		$header_and_body = get_header_and_body( $handle, $args );
		
		$results[$index]['response_header'] = $header_and_body['header'];
		
		$results[$index]['response_content'] = $header_and_body['body'];

		curl_multi_remove_handle($multi_handle, $handle);

		if( LSCR_SETTINGS['discover'] && $link_discover ){
			discover_links($header_and_body['body']);
		}
	}
	
	curl_multi_close($multi_handle);
	
	pause_based_on_server_load( $results, $urls );

	return $results??[];
 
}

function get_response_ttfb($handle){

	return curl_getinfo($handle, CURLINFO_STARTTRANSFER_TIME) - curl_getinfo($handle, CURLINFO_PRETRANSFER_TIME);
}

function get_header_and_body( $handle, $args ){

	$header_size = empty( $args['header'] ) ? 0 : curl_getinfo( $handle, CURLINFO_HEADER_SIZE );

	$response = curl_multi_getcontent( $handle );

	$content = get_unzipped_content($response);
	
	$body_size = strlen($content) - $header_size;

	return [

		'header' => empty( $args['header'] ) ? false : trim( substr( $content, 0, $header_size) ),
        
		'body'  => empty( $args['content']) ? false : trim( substr( $content, $header_size, $body_size ) )

	];

}

function get_unzipped_content($response){
	
	// `\x1f\x8b` are first two characters of gzipped content
	if( (substr($response, 0, 2) !== "\x1f\x8b") ) return $response;

	return @gzdecode( $response );
}

/**
 * @param array $args -
 * - 'url' => string *required
 * - 'timeout' => int
 * - 'follow_redirect' bool
 */

function get_curl_request_settings( $url, $args ){
	
	return [

		CURLOPT_SSL_VERIFYHOST => 0,
		
		CURLOPT_SSL_VERIFYPEER => 0,

		CURLOPT_RETURNTRANSFER => 1,

		CURLOPT_RESOLVE => get_server_host_and_ip(),
		
		CURLOPT_ENCODING=>'gzip, deflate',

		CURLOPT_HEADER=> $args['header']??1,
		
		CURLOPT_FAILONERROR => 1, // will return page content as false when 4xx response is generated.
	
		CURLOPT_URL =>  $url,

		CURLOPT_HTTPHEADER =>  get_curl_http_header(),

		CURLOPT_TIMEOUT_MS => $args['timeout'] ?? 20000,

		CURLOPT_FOLLOWLOCATION => $args['follow_redirect']??0
	];
}

function get_user_agent(){

	return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 LSCR";
}

function get_curl_http_header(){

	static $result;

	if( $result ){

		return $result;
	}

	$user_agent = get_user_agent();

	$parsed_home_url = get_parsed_home_url();

	$result = [
		"Host: {$parsed_home_url['host']}",
		"User-Agent: $user_agent",
		'Referer: '.LSCR_SETTINGS['home-url'].'/',
		'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
		'Accept-Language: en-US,en;q=0.5',
		'Accept-Encoding: gzip, deflate',
		'Cache-Control: no-cache',
		'Pragma: no-cache',
		'Connection: keep-alive',
		'Upgrade-Insecure-Requests: 1'
	];

	return $result;
}

/**
 * @param array $args
 * @param string $args['url'] 
 * @param array $args['timeout'] 
 * @param array $args['post_data'] 
 * @return array 
 * ['response' => string,
 * 'http_status' => int,
 * 'error_code' => int]
 */

 function get_post_request($args) {

	$ch = curl_init();
	
	curl_setopt_array($ch, get_post_curl_options($args));
	
	$response = curl_exec($ch);
	
	$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	
	$error_code = curl_errno($ch);
	
	return [
		'response' => get_unzipped_content($response),
		'http_status' => $http_status,
		'error_code' => $error_code
	];
}

function get_post_curl_options($args) {
	return [
		CURLOPT_URL => $args['url'],
		CURLOPT_POST => 1,
		CURLOPT_HEADER => 0,
		CURLOPT_POSTFIELDS => $args['body'],
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_TIMEOUT => ($args['timeout'] ?? 10), 
		CURLOPT_HTTPHEADER => get_curl_http_header(),		
		CURLOPT_SSL_VERIFYHOST => 0,
		CURLOPT_SSL_VERIFYPEER => 0
	];
}


function start_crawler_loop(){

	$args =[
		'url'			=> get_ajax_url(),
		
		'timeout'		=>'20',
	
		'body'	=>[
	
			'action'			=> 'crawler_start',
	
			'_wpnonce'          => get_ajax_nonce()
		]
	];
	
	$response = get_post_request($args);
	
	if( $response['http_status'] == 200 ) return;

	// update_option('ls_crawler_run_id', 0, 'no' );
	unset( $response['response'] );
	
	error_log( basename(__FILE__).' at '.__LINE__.' '.var_export( array_merge( $args, $response) , true ).PHP_EOL  );

}

function restart_crawler_loop( $page_db ){

	$args =[
		'url'			=> get_ajax_url(),
		
		'timeout'		=>'1',
	
		'body'	=>[
	
			'action'			=> 'crawler_continue',
	
			'page'				=> $page_db,
	
			'_wpnonce'          => get_ajax_nonce()
		]
	];
	
	$response =  get_post_request($args);
	
	if( $response['http_status'] != 403 && $response['http_status'] != 404 ) return;

	update_option('ls_crawler_run_id', 0, 'no' );
	
	error_log( 'LS Crawler restart failed. '.basename(__FILE__).' at '.__LINE__.' '.var_export( $response , true ).PHP_EOL  );

}


/**
 * @return integer count of found urls in the custom sitemap
 */

function call_ajax_custom_sitemap_update(){

	$args =[
		'url'			=> get_ajax_url(),
		
		'timeout'		=>'20',
	
		'body'	=>[
	
			'action'			=> 'update_custom_sitemap',
	
			'_wpnonce'          => get_ajax_nonce()
		]
	];
	
	$response = get_post_request( $args );

	$response_data = json_decode($response['response']??'',true);
	
	$links_count = (int) $response_data['count']??0;

	if( $links_count === 0 ) {

		update_option('ls_crawler_run_id', 0, 'no' );
		
		error_log( 'No urls been found in custom sitemap in '. basename(__FILE__).' at line '.__LINE__."\n".var_export( $response , true ).PHP_EOL  );
	}

	return $links_count;
}

function get_current_server_load() {
	
	if (!is_callable('sys_getloadavg') ) return false;
	
	$server_load  = sys_getloadavg()[0]??false;
	
	return is_numeric($server_load) ? round( $server_load,2) : false;

}

function get_current_server_load_sql_markup(){

	$server_load_value = get_current_server_load();

	return ($server_load_value === false) ? 'NULL' : "'$server_load_value'";
}