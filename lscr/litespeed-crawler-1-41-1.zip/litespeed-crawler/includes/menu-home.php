<?php

namespace ls_crawler;

defined( 'ABSPATH' ) || exit;

if(!is_callable('curl_version')){

	show_curl_warning();
	
	return;
}

?><h3><?=__('Home','litespeed-crawler')?></h3>

<?php

the_start_stop_button();

if( isset($_GET['runid']) ){

	define( 'POST',['action'=>'summary']);

	require LSCR_DIR.'crawler/crawler-main.php';

}

function the_start_stop_button(){

	if ( is_crawler_running() ){

		main_running_crawler();
	
	} else {

		the_start_button();

	}
}


function main_running_crawler(){

	if ( has_stopping_crawler_initialised() ) {
		
		the_stop_process();

	} else {

		the_running_crawler_progress();

		the_stop_button();

	}

}


function the_start_button(){

	?>
	<h4><?=__('Crawler status:','litespeed-crawler')?> <?=__('Inactive','litespeed-crawler')?></h4>
	<div id="button-wrap" class="tab-box">
			<button class="button button-primary" type="submit" id="start-crawler">Run crawler now</button>
	</div>
	<script>
		const buttonWrap = document.getElementById("button-wrap");
		const button = document.getElementById("start-crawler");
		button.addEventListener("click", function() {
			
			buttonWrap.innerHTML = '<span class="stat-name">Starting crawler</span><img src="/wp-includes/images/spinner.gif" alt="Loading spinner"><br>';

			const options = {
				method: 'POST',
				body: JSON.stringify(
                    { 
                        action: 'crawler_start',
                        _wpnonce: '<?=get_ajax_nonce()?>'
                    }
                ),
				headers: {
				'Content-Type': 'application/json'
				}
			};

		fetch("<?=get_ajax_url()?>", options)
			.then(response => {
				if(response.ok) {
					return response.text();
				}
				throw new Error(`${response.status}`);
			})
			.then(data => {
				alert(data);
				location.reload();
			})
			.catch(error => {
				alert(`${error}\nCrawler couldn't be started.`);
			});
		});
	</script>
	<?php

}

function the_stop_button(){

	?>
	<div id="button-wrap" class="tab-box">
			<button class="button button-primary" type="submit" id="stop-crawler">Stop crawler now</button>
	</div>
	<script>
		const buttonWrap = document.getElementById("button-wrap");
		const button = document.getElementById("stop-crawler");
		button.addEventListener("click", function() {
			
			buttonWrap.innerHTML = '<span class="stat-name">Stopping crawler</span><img src="/wp-includes/images/spinner.gif" alt="Loading spinner"><br>';

			const options = {
				method: 'POST',
				body: JSON.stringify(
                    { 
                        action: 'crawler_stop_manual',
                        _wpnonce: '<?=get_ajax_nonce()?>'
                    }
                ),
				headers: {
				'Content-Type': 'application/json'
				}
			};

		fetch("<?=get_ajax_url()?>", options)
			.then(response => {
				if(response.ok) {
					return response.text();
				}
				throw new Error(`${response.status}`);
			})
			.then(data => {
				alert(data);
				location.reload();
			})
			.catch(error => {
				alert(`${error}\nCrawler couldn't be stopped.`);
			});
		});
	</script>
	<?php

}


function the_running_crawler_progress(){
	$text = 'Finished!';
	?>
	<h4><?=__('Crawler status:','litespeed-crawler')?> <?=__('Running','litespeed-crawler')?></h4>
	<span id="crawler-progress">Started</span><br>
	<br>
	<script>
		const intervalId = setInterval(() => {
			fetch('<?=get_ajax_url()?>', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ action: 'progress', _wpnonce: '<?=get_ajax_nonce()?>'}),
			})
			.then(response => response.text())
			.then(data => {
				document.getElementById("crawler-progress").innerText = data;
				if(data.includes('end')) {
					clearInterval(intervalId);
					document.getElementById("crawler-progress").innerText = <?=json_encode($text)?>;
					location.reload();
				}
			})
			.catch(error => {
				console.error(error);
			});
		}, 2000);
	</script>
	<?php
}



function the_stop_process(){

}


function has_stopping_crawler_initialised(){

    return false;
}