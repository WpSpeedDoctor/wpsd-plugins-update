<?php
namespace ls_crawler;

define( 'LSCR_MU_LOADER_NAME', __NAMESPACE__.'_mu_loader.php' );

define( 'LSCR_MU_FOLDER', LSCR_DIR.'mu-plugins/' );

define( 'LSCR_MU_LOADER_FILEPATH', LSCR_DIR.'mu-plugins/'.LSCR_MU_LOADER_NAME );

define( 'LSCR_MU_LOADER_WP_FILEPATH', WP_CONTENT_DIR.'/mu-plugins/'.LSCR_MU_LOADER_NAME );

define( 'LSCR_WP_MU_PLUGINS_FOLDER', WP_CONTENT_DIR.'/mu-plugins/' );


function activate_local_mu_plugins(){

	if ( file_exists( LSCR_MU_LOADER_WP_FILEPATH ) ) return;

	if( create_mu_plugin_wp_folder() === false ) return show_no_write_mu_plugins();

	create_automatic_loader_for_local_mu_plugins();

}

function create_automatic_loader_for_local_mu_plugins( ){

	$php_loader_file_for_wp_mu_folder = generate_loader_for_local_mu_plugins();
	
	file_put_contents( LSCR_MU_LOADER_WP_FILEPATH, $php_loader_file_for_wp_mu_folder );
	
}

function generate_loader_for_local_mu_plugins(){

	$text_domain = 'litespeed-crawler';

	$plugin_basedir = basename(LSCR_DIR);

	$mu_plugin_name = __( "Litespeed Crawler", $text_domain );

	$mu_plugin_description = __( "Enhanced data collection of PHP errors, easy to log and display data", $text_domain );
	
	$mu_plugin_author = "WP Speed Doctor";

	$mu_plugin_url = "https://wpspeeddoctor.com/";
	

	return 

"<?php

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/
Description: {$mu_plugin_description}
Version: ".LSCR_VER."
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

if( !( isset( \$_GET['litespeed-crawler']) && wp_doing_ajax() ) )  return;

define( 'LSCR_DIR', WP_PLUGIN_DIR.'/{$plugin_basedir}/');

@include_once LSCR_DIR.'plugin-setup/universal-functions.php';

@include_once LSCR_DIR.'mu-plugins/ajax_listener.php';
";

}



function has_local_mu_plugin_loader(){

	return file_exists( LSCR_MU_LOADER_FILEPATH );
}

/**
 * @return bool true if WP mu-plugins folder exists or been successfully created
 */

function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR  ) ) return true;
	
	return mkdir(  WPMU_PLUGIN_DIR , 0755 );

}

function show_no_write_mu_plugins(){

	set_admin_notice_message( __('Folder mu-plugins, could not be created','litespeed-crawler') );
}