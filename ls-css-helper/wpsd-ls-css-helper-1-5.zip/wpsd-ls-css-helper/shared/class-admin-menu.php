<?php

namespace WPSD\shared;

defined( 'ABSPATH' ) || exit;

class Admin_Menu{

	public const FILTER_CONTENT			= 'wpsd-main-page-content';

	public const FILTER_SUBMENUS		= 'wpsd-plugins-submenus';

	public const KEY_SUBMENU_TITLE		= 0;

	public const KEY_SUBMENU_SLUG		= 1;

	public const KEY_SUBMENU_CALLABLE	= 2;

	private static string $relase_date = '';

	private static string $main_menu_title = '';

	static function add_shared_wpsd_menu(){

		global $menu;

		if( in_array('wpsd', array_column($menu,2)) ){
			return;
		}

		add_menu_page(
			self::$main_menu_title,
			self::$main_menu_title,
			'manage_options',
			'wpsd',
			[self::class,'wpsd_main_page'],
			'dashicons-code-standards',
			30
		);

		/**
		 * @param array $submenus -
		 * - 0 submenu title
		 * - 1 submenu slug
		 * - 2 submenu callable
		 *
		 * @return array -
		 * - 0 submenu title
		 * - 1 submenu slug
		 * - 2 submenu callable
		 */

		$plugins_submenus = apply_filters( self::FILTER_SUBMENUS, [] );

		if( empty($plugins_submenus) ) return;

		foreach( $plugins_submenus as $submenu ){
			
			add_submenu_page(
				'wpsd',
				$submenu[self::KEY_SUBMENU_TITLE],
				$submenu[self::KEY_SUBMENU_TITLE],
				'administrator',
				$submenu[1],
				$submenu[2]
			);
		}
	}

	static function wpsd_main_page(){

		/**
		 * Delivers plugin with latest release to display conent in main page
		 * 
		 * @var string $latest_release is date in format YYYY-MM-DD
		 * 
		 */

		$page_content = apply_filters(self::FILTER_CONTENT, self::$relase_date );

		//no scripts allowed
		if( str_contains($page_content,'script') ){
			wp_die('Illegal content');
		}

		//no other domains allowed
		foreach( explode('http',$page_content) as $key => $piece ){

			if($key===0) continue;

			if( !str_starts_with($piece,'s://wpspeeddoctor.com/') ){
			wp_die('Illegal content');
			}
		}

		echo <<<HTML
		<div class="wrap">
		{$page_content}
		</div>
		HTML;	
		return;
	

	}
	/**
	 * 
	 * @param string $release_date
	 */

	static function set_release_date($release_date){
		
		
	}

	/**
	 * @param string $translated_title
	 */

	static function set_data($translated_title,$release_date){
	
		if(self::$relase_date < $release_date){

			self::$relase_date = $release_date;
		}

		if(self::$main_menu_title === ''){

			self::$main_menu_title = $translated_title;
		}
	}


	static function set_title($translated_title){

		if(self::$main_menu_title === ''){

			self::$main_menu_title = $translated_title;
		}
	}


}



