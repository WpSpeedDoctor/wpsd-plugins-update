<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	// register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	// register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}

function plugin_activation_main(){

}


function plugin_deactivation_main(){

}


/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(Consts::DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ){

	$page_link = admin_url( 'admin.php?page='.Consts::SLUG );

	$menu_text = __('Menu','ls-css-helper');

	$menu_link =
	<<<HTML
	<a href="{$page_link}">{$menu_text}</a>
	HTML;
		
		
	$actions[] = $menu_link;

	return $actions;

}