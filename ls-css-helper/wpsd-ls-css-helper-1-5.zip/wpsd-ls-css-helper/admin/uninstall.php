<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){
	

	delete_option(Consts::OPTION_ASYNC);

	delete_option(Consts::OPTION_VARY);

	delete_option(Consts::OPTION_MODE);
}

