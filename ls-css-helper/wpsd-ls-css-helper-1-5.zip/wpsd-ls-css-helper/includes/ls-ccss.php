<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

if( get_option(Consts::OPTION_VARY) ){

	add_filter( 'litespeed_vary', __NAMESPACE__.'\set_ls_vary' );
}

if( get_option(Consts::OPTION_ASYNC) && !isset($_GET['LSCWP_CTRL'])){

	add_filter('litespeed_buffer_after', __NAMESPACE__ . '\load_async_css');
}

function set_ls_vary($vary){

	$body_classes = get_body_class();

	$body_classes = remove_numeric_id_class( $body_classes );

	$body_classes = array_unique($body_classes);

	$body_classes = apply_filters( 'wpsd-ls-ccss-vary', $body_classes );

	sort($body_classes);

	$body_classes_flat = implode('',$body_classes); 

	if( !in_array($body_classes_flat, $vary) ){

		$vary[] = $body_classes_flat;
	}

	return $vary;
}

//removes classes that has after last `-` numbers till end.
//examples: page-id-123, category-123, avia-chrome-136
function remove_numeric_id_class( $body_classes ){

	foreach( $body_classes as $key => $class ){

		$pos = get_position_of_last_separator( $class );
		
		if( $pos===false ) continue;

		$last = substr($class, ++$pos);

		if( is_numeric($last) ){

			unset($body_classes[$key]);
		}
	}

	return $body_classes;
}

function get_position_of_last_separator( $class ){

	$pos = strrpos($class,'-');

	if( $pos ){
		return $pos;
	}

	$pos = strrpos($class,'_');

	if( $pos ){
		return $pos;
	}

	return false;
}

//MARK: CCSS

function load_async_css($html){

	if(
		empty($html)
		|| !str_contains($html,'<style id="litespeed-ccss">')
	 
	){

		return $html;
	}

	$dom = wpsd_get_html_dom($html);

	if(empty($dom)) return $html;

	$links_data = wpsd_extract_stylesheet_links($dom);

	if(empty($links_data)) return $html;

	$html = wpsd_get_dom_html($dom);

	$html = wpsd_add_delayed_css_script($html, $links_data);

	return $html;

}



function wpsd_get_html_dom($html){

	if(empty($html) || !is_string($html)) return false;

	if( class_exists('Dom\\HTMLDocument') ){

		return \Dom\HTMLDocument::createFromString($html, LIBXML_NOERROR | LIBXML_COMPACT, 'UTF-8');

	}

	$dom = new \DOMDocument('1.0', 'UTF-8');

	libxml_use_internal_errors(true);

	$loaded = $dom->loadHTML(
		'<?xml encoding="UTF-8">' . $html,
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
	);

	libxml_clear_errors();

	return empty($loaded) ? false : $dom;

}

function wpsd_extract_stylesheet_links($dom){

	if(empty($dom)) return false;

	$links_data = [];

	$links = $dom->getElementsByTagName('link');

	$links_to_remove = [];

	foreach($links as $link){

		if(false === wpsd_is_delayed_stylesheet_link($link)) continue;

		$links_data[] = wpsd_get_link_attributes($link);

		$links_to_remove[] = $link;

	}

	if(empty($links_to_remove)) return false;

	foreach($links_to_remove as $link){

		$link->parentNode->removeChild($link);

	}

	return $links_data;

}

function wpsd_is_delayed_stylesheet_link($link){

	if(empty($link)) return false;

	$rel = strtolower($link->getAttribute('rel') ?: '');

	switch($rel){
		case 'stylesheet':
		case 'preload':
			break;
		default:
			return false;
	}

	$href = $link->getAttribute('href');

	$href_path = parse_url($href, PHP_URL_PATH) ?: '';

	return str_ends_with($href_path,'.css');

}

function wpsd_get_link_attributes($link){

	if(empty($link)) return false;

	$attributes = [];

	foreach($link->attributes as $attribute){

		$attributes[$attribute->name] = $attribute->value;

	}

	return $attributes;

}

function wpsd_get_dom_html($dom){

	if(empty($dom)) return false;

	return $dom->saveHtml();

}

function wpsd_add_delayed_css_script($html, $links_data){

	if(empty($html)) return $html;

	if(empty($links_data)) return $html;

	$links_data_json = wp_json_encode($links_data);

	$script = <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function(){

	var links_data = {$links_data_json};

	links_data.forEach(function(attributes){

		var link = document.createElement('link');

		Object.keys(attributes).forEach(function(attribute_name){

			link.setAttribute(attribute_name, attributes[attribute_name]);

		});

		document.head.appendChild(link);

	});

});
</script>
HTML;

	if(false !== stripos($html, '</body>')){

		return str_ireplace('</body>', $script . '</body>', $html);

	}

	return $html . $script;

}
