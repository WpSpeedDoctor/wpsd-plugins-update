<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

validate_input();

$mode = LS_CSS_HELPER_CSS_MODE;

if( !($mode === 'ccss' || $mode === 'ucss' )  ){

	http_response_code(401);

	die;
}

$ls_option_key = "litespeed.conf.optm-{$mode}_whitelist";

$ls_whitelist = json_decode( get_option( $ls_option_key ), true);

$new_list = is_array( $ls_whitelist ) ? $ls_whitelist : [];

$new_selectors = json_decode($_POST['selectors'],true); 

$new_selectors_sanitized = get_sanitized_input( $new_selectors );

$new_selectors_sanitized = remove_numeric_suffix( $new_selectors_sanitized );

foreach( $new_selectors_sanitized as $selector ){

	if( in_array($selector, $new_list) ){

		continue;
	}

	$new_list[] = $selector;
}

if( $ls_whitelist !== $new_list ){

	update_option( $ls_option_key, json_encode($new_list) );
}

echo json_encode(true);

die;

function get_sanitized_input($array){

	$result = [];

	foreach($array as $value){

		$result[] = sanitize_text_field($value);
	}

	return $result;
}

function validate_input(){

	switch( true ){

		case empty($_POST['selectors']):
		case ($_COOKIE[Consts::SLUG]??'') != get_transient_nonce():

			http_response_code(403);
			
			die('Forbidden');

			break;

	}
}

//removes classes that has after last `-` numbers till end.
//examples: page-id-123, category-123, avia-chrome-136
function remove_numeric_suffix( $selectors ){

	foreach( $selectors as $key => $class ){

		$pos = strrpos($class,'-');

		if( $pos === false ){
			$pos = strrpos($class,'_');
		}


		if( $pos === false ){
			continue;
		}

		$last = substr($class, ++$pos);

		if( is_numeric($last) ){

			unset($selectors[$key]);
		}
	}

	return $selectors;
}