<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

add_action( 'plugins_loaded', __NAMESPACE__.'\ajax_cookie_set' );

function ajax_cookie_set(){

	$cookie = sanitize_text_field( wp_unslash( $_GET['ls-css-helper-cookie']??'' ) );

	$cookie_value = get_transient_nonce();

	if( $cookie !== $cookie_value ){

		return false;
	}

	setcookie( Consts::SLUG, $cookie_value, time() + DAY_IN_SECONDS, '/', COOKIE_DOMAIN, is_ssl(), false );

	$_COOKIE[Consts::SLUG] = $cookie_value;

	$home_url = home_url('/');

	echo <<<HTML
	Cookie been set, continue to <a href="{$home_url}">{$home_url}</a>
	HTML;
	die;
}
