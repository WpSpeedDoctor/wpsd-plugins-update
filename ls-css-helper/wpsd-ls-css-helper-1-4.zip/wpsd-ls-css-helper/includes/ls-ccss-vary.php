<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

add_filter( 'litespeed_vary', __NAMESPACE__.'\set_ls_vary' );

function set_ls_vary($vary){

	$body_classes = get_body_class();

	remove_numeric_id_class( $body_classes );

	sort($body_classes);

	$body_classes_flat = implode('',$body_classes); 

	if( !in_array($body_classes_flat, $vary) ){

		$vary[] = $body_classes_flat;
	}

	return $vary;
}

//remove classes that has after last `-` numbers till end.
//examples: page-id-123, category-123, avia-chrome-136
function remove_numeric_id_class( &$body_classes ){

	foreach( $body_classes as $key => $class ){

		$pos = get_position_of_last_separator( $class );
		
		$last = substr($class, ++$pos);

		if( is_numeric($last) ){

			unset($body_classes[$key]);
		}
	}
}

function get_position_of_last_separator( $class ){

	$pos = strrpos($class,'-');

	if( $pos ){
		return $pos;
	}

	$pos = strrpos($class,'_');

	if( $pos ){
		return $pos;
	}

	return false;
}