<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

function home_menu_main(){

	home_form();

	the_cookie_set_button();

}

function the_cookie_set_button(){

	$text = __('Activate front-end class search. After this logout and perform website browsing.','ls-css-helper');

	$transient_nonce = get_transient_nonce();

	echo <<<HTML
<label class="toggle-switch">
  <input type="checkbox" id="ls-helper-toggle">
  <span class="slider"></span>
  <p>{$text}</p>
</label>

<style>
.toggle-switch {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
  font-family: sans-serif;
  font-size: 14px;
  gap: 0.5em;
  position: relative;
}

/* hide the checkbox */
.toggle-switch input[type="checkbox"] {
  opacity: 0;
  width: 0;
  height: 0;
  position: absolute;
}

/* slider */
.toggle-switch .slider {
  position: relative;
  width: 40px;
  height: 20px;
  background-color: #ccc;
  border-radius: 34px;
  transition: background-color 0.3s;
  flex-shrink: 0;
}

/* circle */
.toggle-switch .slider::before {
  content: "";
  position: absolute;
  height: 16px;
  width: 16px;
  left: 2px;
  bottom: 2px;
  background-color: white;
  border-radius: 50%;
  transition: transform 0.3s;
}

/* checked state */
.toggle-switch input[type="checkbox"]:checked + .slider {
  background-color: #4caf50;
}
.toggle-switch input[type="checkbox"]:checked + .slider::before {
  transform: translateX(20px);
}
</style>

<script>
  // Utility to get cookie value by name
  function getCookie(name) {
	const matches = document.cookie.match('(?:^|; )' + name.replace(/([.$?*|{}()[\]\\/+^])/g, '\\$1') + '=([^;]*)');
	return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  // Utility to set cookie
  function setCookie(name, value, options = {}) {
	options = {
	  path: '/',
	  // add other defaults if needed
	  ...options
	};

	let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

	for (let optionKey in options) {
	  updatedCookie += "; " + optionKey;
	  const optionValue = options[optionKey];
	  if (optionValue !== true) {
		updatedCookie += "=" + optionValue;
	  }
	}
	document.cookie = updatedCookie;
  }

  // Utility to delete cookie
  function deleteCookie(name) {
	setCookie(name, "", {
	  'max-age': -1,
	  path: '/'
	});
  }

  const toggle = document.getElementById('ls-helper-toggle');
  const cookieName = 'ls-css-helper';

  // On page load, set toggle state by cookie presence
  document.addEventListener('DOMContentLoaded', () => {
	toggle.checked = !!getCookie(cookieName);
  });

  toggle.addEventListener('change', () => {
	if (toggle.checked) {
	  setCookie(cookieName, '{$transient_nonce}', { 'max-age': 3600 * 24 * 1 }); // 1 day
	} else {
	  deleteCookie(cookieName);
	}
  });
</script>
HTML;
}

function home_form(){
	
	$d = get_settings_form_data();
	
	echo <<<HTML
<h3>{$d->title}</h3>
<form id="ls-css-helper-menu-form" method="post">
	<input type="hidden" name="wp-nonce" value="{$d->nonce}">
	<label for="cssmode-select">Mode:</label>
	<select id="cssmode-select" name="cssmode">
		{$d->options_markup}
	</select>
	<div style="display: flex;flex-direction: column;gap: 1em;width: fit-content;margin-top:1em;">
		<button name="settings-action" value="ls-css-helper-settings" type="submit" class="button button-primary">{$d->button_texts->save}</button>
	</div>
</form>
HTML;
}

function get_settings_form_data(){
		
	$selected = get_plugin_setting();

	$select_texts = [
		'off' => __('Off','ls-css-helper'),
		'ccss' => __('CCSS','ls-css-helper'),
		'ucss' => __('UCSS','ls-css-helper'),
	];

	$options_markup = '';
	foreach( $select_texts as $value => $text ){
		$selected_attr = ($value === $selected) ? ' selected' : '';
		$options_markup .= <<<HTML
	<option value="{$value}"{$selected_attr}>{$text}</option>
	HTML;
	}

	$button_texts = (object)[
		'save'  =>  __('Save settings','ls-css-helper')
	];

	$nonce = esc_attr( \wp_create_nonce('ls-css-helper-nonce') );

	$title = __('Helper with Litespeed CCSS and UCSS','ls-css-helper');

	return (object) [
		'select'			=> $select_texts,
		'options_markup'	=> $options_markup,
		'button_texts'		=> $button_texts,
		'nonce'				=> $nonce,
		'title'			=> $title
	];
}

function get_plugin_setting(){
	
	$key = 'ls-css-helper';

	if( is_settings_action('ls-css-helper-settings') && has_right_to_save() ){

	
		switch($_POST['cssmode']){

			case 'ccss':
			case 'ucss':
				$css_mode = $_POST['cssmode'];
				break;
			default:
				$css_mode = 'off';

		}

		update_option( $key, $css_mode, 'off' );
	
	} else{
		
		$css_mode = LS_CSS_HELPER_CSS_MODE;

	}

	return $css_mode;
}

function has_right_to_save(){

	return current_user_can( 'manage_options' ) && wp_verify_nonce($_POST['wp-nonce']??'', 'ls-css-helper-nonce');

}

function is_settings_action($action){

	switch(true){

		case $_SERVER['REQUEST_METHOD'] !== 'POST':
		case !isset($_POST['settings-action']):
		case $_POST['settings-action'] !== $action:
			return false;
		default:
			return true;
	}
}