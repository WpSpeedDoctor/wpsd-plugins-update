<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

// AJAX sender: send all selectors in key 'selectors' prefixed (# for ids, . for classes) plus nonce
function print_send_ajax() {

    $nonce = wp_create_nonce('ls-css-helper-nonce');

echo <<<JS
(function() {
    const sentSelectors = new Set();

    window.ls_ccss_helper_send_selector = function(type, value) {
        const prefix = type === 'classes' ? '.' : (type === 'ids' ? '#' : '');
        const selector = prefix + value;
        if (sentSelectors.has(selector)) return; // Already sent in this session
        sentSelectors.add(selector);

        const ajaxUrlVar = typeof ajaxUrl !== 'undefined' ? ajaxUrl : '';
        const data = new FormData();
        data.append('action', 'ls-ccss-helper');
        data.append('selectors', JSON.stringify([selector]));
        data.append('nonce', '{$nonce}');

        fetch(ajaxUrlVar, {
            method: 'POST',
            body: data,
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .catch(() => {
            // On failure, remove to allow retry
            sentSelectors.delete(selector);
        });
    };
})();
JS;
}