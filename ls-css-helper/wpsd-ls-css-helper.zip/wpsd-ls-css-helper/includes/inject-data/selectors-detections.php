<?php

namespace WPSD\ls_css_helper;


defined( 'ABSPATH' ) || exit;

// Selectors detection, triggers AJAX on every new selector found without persistent storage
function print_selectors_detection() {
    echo <<<JS
(function() {
    const alreadyUsedClasses = new Set( (typeof usedClasses !== 'undefined') ? usedClasses : [] );
    const alreadyUsedIds = new Set( (typeof usedIds !== 'undefined') ? usedIds : [] );

    const sentSelectors = new Set();

    function sendAndStoreSelectors(selectorsArr) {
        if (!selectorsArr || selectorsArr.length === 0) return;
        const newSelectors = selectorsArr.filter(s => !alreadyUsedClasses.has(s.substring(1)) && !alreadyUsedIds.has(s.substring(1)) && !sentSelectors.has(s));
        if (newSelectors.length === 0) return;

        newSelectors.forEach(s => sentSelectors.add(s));

        const data = new FormData();
        data.append('action', 'ls-ccss-helper');
        data.append('selectors', JSON.stringify(newSelectors));

        fetch(ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' })
        .catch(() => {
            newSelectors.forEach(s => sentSelectors.delete(s));
        });
    }

    function processSelectors() {
        console.log( 'Scan for new selectors triggered' );
        const classSet = new Set();
        const idSet = new Set();
        document.querySelectorAll('*').forEach(el => {
            if (el.classList) el.classList.forEach(cls => classSet.add(cls));
            if (el.id) idSet.add(el.id);
        });

        const classSelectors = Array.from(classSet)
            .filter(c => !alreadyUsedClasses.has(c))
            .map(c => '.' + c);
        const idSelectors = Array.from(idSet)
            .filter(i => !alreadyUsedIds.has(i))
            .map(i => '#' + i);

        const allSelectors = classSelectors.concat(idSelectors);

        sendAndStoreSelectors(allSelectors);
    }

    let lastRun = 0, scheduled = false;
    function throttled() {
        const now = Date.now();
        if (now - lastRun > 500) {
            lastRun = now;
            processSelectors();
            scheduled = false;
        } else if (!scheduled) {
            scheduled = true;
            setTimeout(() => {
                lastRun = Date.now(); processSelectors(); scheduled = false;
            }, 500 - (now - lastRun));
        }
    }

    if ( typeof cssMode !== 'undefined' && cssMode === 'ucss') {

        window.addEventListener('scroll', throttled);
        window.addEventListener('click', throttled);
    
    } else {

        window.addEventListener('DOMContentLoaded', processSelectors);
    }


    window.ls_ccss_helper_new_selectors_detected = processSelectors;
})();
JS;
}