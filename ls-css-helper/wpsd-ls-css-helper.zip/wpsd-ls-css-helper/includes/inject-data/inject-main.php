<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

switch(LS_CSS_HELPER_CSS_MODE){

	case 'ccss':
	case 'ucss':
		
		require LS_CSS_HELPER_DIR.'includes/inject-data/send-ajax.php';
		require LS_CSS_HELPER_DIR.'includes/inject-data/selectors-detections.php';
		require LS_CSS_HELPER_DIR.'includes/inject-data/dom-reduction.php';

		add_action('wp_head', __NAMESPACE__.'\print_css_helper_javascript',0);
		
		add_filter('litespeed_buffer_before', __NAMESPACE__.'\add_static_classes_hook');

		break;

}

function print_css_helper_javascript(){

	echo <<<HTML
		<script data-no-optimize="1" data-cfasync="false"> 
		HTML;
	
	print_constants();

	if (LS_CSS_HELPER_CSS_MODE === 'ccss'){
		print_dom_reduction();
	}
	print_selectors_detection();
	print_send_ajax();
	echo <<<HTML
		</script>
		HTML;
}

// Constants, now including bodyHash for storage and AJAX params
function print_constants(){
	$ccss_mode = LS_CSS_HELPER_CSS_MODE;
	$ajax_url = admin_url( 'admin-ajax.php?ls-css-helper' );
	echo <<<JS
const usedClasses = ['placeholder'];
const usedIds = ['placeholder'];
const cssMode = '{$ccss_mode}';
const ajaxUrl = '{$ajax_url}';
const lsWhitelist = ['placeholder'];

JS;
}

function add_static_classes_hook( $html ) {

	require_once LS_CSS_HELPER_DIR.'/includes/static-data.php';

	return add_static_classes($html);
}
