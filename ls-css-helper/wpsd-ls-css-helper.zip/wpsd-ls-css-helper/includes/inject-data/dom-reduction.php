<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

function print_dom_reduction() {
	echo <<<JS
window.addEventListener('load', function() {
	requestAnimationFrame(function() {
		const vpTop = window.scrollY || 0;
		const vpBottom = vpTop + window.innerHeight + 100;
		document.querySelectorAll('body *').forEach(function(el) {
			const rect = el.getBoundingClientRect();
			if (
				(rect.bottom + window.scrollY) < vpTop ||
				(rect.top + window.scrollY) > vpBottom ||
				(rect.bottom === 0 && rect.top === 0)
			) {
				el.remove();
			}
		});
			console.log('DOM reduced after window onload');
	});
});
JS;
}