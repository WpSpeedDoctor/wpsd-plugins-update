<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

validate_input();

$mode = LS_CSS_HELPER_CSS_MODE;

if( !($mode === 'ccss' || $mode === 'ucss' )  ){

	http_response_code(401);

	die;
}

$ls_option_key = "litespeed.conf.optm-{$mode}_whitelist";

$ls_whitelist = json_decode( get_option( $ls_option_key ), true);

$new_list = is_array( $ls_whitelist ) ? $ls_whitelist : [];

$new_selectors = json_decode($_POST['selectors'],true); 

$new_selectors_sanitized = get_sanitized_input( $new_selectors );

foreach( $new_selectors_sanitized as $selector ){

	if( in_array($selector, $new_list) ){

		continue;
	}

	$new_list[] = $selector;
}

if( $ls_whitelist !== $new_list ){

	update_option( $ls_option_key, json_encode($new_list) );
}

echo json_encode(true);

die;

function get_sanitized_input($array){

	$result = [];

	foreach($array as $value){

		$result[] = sanitize_text_field($value);
	}

	return $result;
}

function validate_input(){

	switch( true ){

		case empty($_POST['selectors']):
		case ($_COOKIE['ls-css-helper']??'') !== get_transient_nonce():

			http_response_code(403);
			
			is_callable('debl') && debl( $_POST , 'Wrong input '.basename(__FILE__).' at '.__LINE__ );

			die('Forbidden');

			break;

	}
}