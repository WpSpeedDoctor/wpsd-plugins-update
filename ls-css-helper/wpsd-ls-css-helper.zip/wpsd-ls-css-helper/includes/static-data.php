<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

/**
 * Main function to add static classes and ids into HTML, replacing placeholders
 * @param string $html
 * @return string
 */
function add_static_classes( $html){

    libxml_use_internal_errors(true);
    $dom = new \DOMDocument();
    $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    $classes = extract_classes($dom);
    $ids = extract_ids($dom);

    $ls_whitelist = json_decode( get_option('litespeed.conf.optm-' .LS_CSS_HELPER_CSS_MODE . '_whitelist'), true );

	if( !empty($ls_whitelist) && is_array($ls_whitelist) ){

		foreach($ls_whitelist as $selector){

			if($selector[0] === '#' ){

				$ids[]= ltrim( $selector, '#' );

			} else {

				$classes[] = ltrim( $selector, '.' );
			}
		}
	}

    // Format JS arrays
    $js_classes = "usedClasses = " . format_js_array($classes);
    $js_ids = "usedIds = " . format_js_array($ids);

    // Replace placeholders in HTML string
    $modified_html = str_replace("usedClasses = ['placeholder']", $js_classes, $html);
    $modified_html = str_replace("usedIds = ['placeholder']", $js_ids, $modified_html);

    return $modified_html;
}

/**
 * Extract classes from HTML elements
 * @param \DOMDocument $dom
 * @return array
 */
function extract_classes(\DOMDocument $dom): array {
    $classes = [];
    foreach ($dom->getElementsByTagName('*') as $element) {
        if ($element->hasAttribute('class')) {
            foreach (preg_split('/\s+/', $element->getAttribute('class')) as $class) {
                $class = trim($class);
                if ($class && !in_array($class, $classes, true)) {
                    $classes[] = $class;
                }
            }
        }
    }
    return $classes;
}

/**
 * Extract IDs from HTML elements
 * @param \DOMDocument $dom
 * @return array
 */
function extract_ids(\DOMDocument $dom): array {
    $ids = [];
    foreach ($dom->getElementsByTagName('*') as $element) {
        if ($element->hasAttribute('id')) {
            $id = trim($element->getAttribute('id'));
            if ($id && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
    }
    return $ids;
}

/**
 * Format array values as single-quoted, comma separated string for JS
 * @param array $arr
 * @return string
 */
function format_js_array(array $arr): string {
    return '[' . implode(', ', array_map(function($v) {
        return "'" . addslashes($v) . "'";
    }, $arr)) . ']';
}
