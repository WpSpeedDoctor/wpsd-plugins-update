<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){
	

	delete_option('ls-css-helper');
}

