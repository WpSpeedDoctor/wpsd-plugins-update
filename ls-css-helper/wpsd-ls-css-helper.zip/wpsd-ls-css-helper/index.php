<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Litespeed CCSS & UCSS generation helper
* Plugin URI: https://wpspeeddoctor.com/
* Description: Helps build accurate CCSS and UCSS
* Version: 1.0
* Updated: 2025-05-23
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: ls-css-helper
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	


require __DIR__.'/constants.php';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(WPSD_REQUEST_TYPE){

		case REQUEST_AJAX:
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'delete-plugin' ){

				require LS_CSS_HELPER_DIR.'admin/uninstall.php';
			}
			
			if( $post_action === 'update-plugin' ) {
				
				require_once LS_CSS_HELPER_DIR.'admin/update.php';
			}

			if( isset( $_GET['ls-css-helper'] ) && $post_action === 'ls-ccss-helper' ){

				include_once LS_CSS_HELPER_DIR.'includes/ajax-controller.php';
			}

			break;

		case REQUEST_ADMIN:
			
			run_back_end();

		break;
			
		case REQUEST_404:
		case REQUEST_FRONTEND:

			run_front_end();
			
			break;

	}
	
}

function run_front_end(){

	$is_user_logged_in = isset( $_COOKIE[LOGGED_IN_COOKIE] );

	switch(true){
		
		case isset($_GET['LSCWP_CTRL']):
		case $is_user_logged_in:
		case !isset( $_COOKIE['ls-css-helper'] ):
		case $_COOKIE['ls-css-helper'] !== get_transient_nonce():
			break;
	
		default:
		
			require LS_CSS_HELPER_DIR.'includes/inject-data/inject-main.php';
			break;
	}
	
	if( !$is_user_logged_in && get_option('litespeed.conf.optm-css_async') ){

		require LS_CSS_HELPER_DIR.'includes/ls-ccss-vary.php';
	}
}

function run_back_end(){
	
	global $pagenow;
	
	$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

	if( $page_now === 'plugins.php' ){
		
		require_once LS_CSS_HELPER_DIR.'admin/setup.php';

		plugin_setup_main(__FILE__);

	}
	

	add_action('admin_menu', __NAMESPACE__.'\admin_menu');

	if( $pagenow === 'options-general.php' && ($_GET['page']??'') == 'ls_css_helper' ){

		require LS_CSS_HELPER_DIR.'includes/menu-home.php';
	}

	require_once LS_CSS_HELPER_DIR.'admin/update.php';

	
	add_action('plugins_loaded', __NAMESPACE__.'\load_language_domain');
}

function load_language_domain(){

	load_plugin_textdomain('ls-css-helper', false, basename(LS_CSS_HELPER_DIR) . '/languages/');
}

function admin_menu(){

	add_submenu_page(
		'options-general.php',
		__( "LS CSS Helper", 'ls-css-helper' ), 
		__( "LS CSS Helper", 'ls-css-helper' ), 
		'administrator', 
		'ls_css_helper', 
		__NAMESPACE__.'\home_menu_main'
	);
}