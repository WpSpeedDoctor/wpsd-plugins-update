<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Litespeed CSS helper
* Plugin URI: https://wpspeeddoctor.com/plugins/litespeed-ccss-and-ucss-helper/
* Description: Helps build accurate CCSS and UCSS, creates vary for CCSS, when CCSS in place loads CSS when DOM ready
* Version: 1.5.1
* Updated: 2025-06-12
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: ls-css-helper
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

require_once __DIR__.'/constants.php';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */
run_update();

function main(){

	switch(WPSD_REQUEST_TYPE){

		case REQUEST_AJAX:
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'delete-plugin' ){

				require Consts::DIR.'admin/uninstall.php';
			}
			
			if( $post_action === 'update-plugin' ) {
				
				run_update();
			}

			if( isset( $_GET[Consts::SLUG] ) && $post_action === Consts::SLUG ){
				
				include_once Consts::DIR.'includes/ajax-controller.php';
			}

			break;

		case REQUEST_ADMIN:
			
			require Consts::DIR.'includes/admin-main.php';

			run_back_end(__FILE__);

			break;
			
		case REQUEST_FRONTEND:
			
			// !is_user_logged_in
			if(!isset( $_COOKIE[LOGGED_IN_COOKIE] ) && LS_CSS_HELPER_CSS_MODE !== 'off'){

				require Consts::DIR.'includes/front-end-main.php';

				run_front_end();
			}
			
			break;

		case REQUEST_CRON:
		case REQUEST_CLI:

			run_update();
			break;
	}
	
}

function run_update(){
	require_once Consts::DIR.'admin/update.php';
}

function get_plugin_slug(){

	return basename( dirname( __FILE__ ) ).DIRECTORY_SEPARATOR.basename( __FILE__ );
}

/**
 * Available filter for CCSS vary, use if you want to unify some or remove.
 * 
 *add_filter('wpsd-ls-ccss-vary', function($vary){
 *
 *	//remove vary strings here
 *
 *	return $vary;
 *});
 */

 