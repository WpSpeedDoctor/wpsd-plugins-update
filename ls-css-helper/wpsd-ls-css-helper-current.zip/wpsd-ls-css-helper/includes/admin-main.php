<?php

namespace WPSD\ls_css_helper;

use \WPSD\shared\Admin_Menu as Admin_Menu;

function run_back_end($file){
	
	global $pagenow;
	
	$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

	if( $page_now === 'plugins.php' ){
		
		require_once Consts::DIR.'admin/setup.php';

		plugin_setup_main($file);

	}

	if( $page_now === 'update-core.php' || $page_now === 'plugin-install.php' ){
		run_update();
	}
	
	

	/**
	 * This plugin menu
	 */
	if( ($_GET['page']??'') == Consts::SLUG ){

		require Consts::DIR.'includes/menu-home.php';
	}
	
	add_action('init', __NAMESPACE__.'\load_language_domain');

	add_action('init', __NAMESPACE__.'\wpsd_shared_menu');
}

function wpsd_shared_menu(){

	if(!class_exists('WPSD\shared\Admin_Menu')){

		require Consts::DIR.'shared/class-admin-menu.php';
		
	}

	/**
	 * Shared menu setup
	 */
	add_action('admin_menu', [Admin_Menu::class, 'add_shared_wpsd_menu']);

	//add this plugin to submenu
	add_filter( Admin_menu::FILTER_SUBMENUS, __NAMESPACE__.'\add_wpsd_submenu' );

	//set main page content
	add_filter( Admin_menu::FILTER_CONTENT, __NAMESPACE__.'\wpsd_main_page_content' );
//TODO: fix doit it wrong __() too early
	Admin_Menu::set_data(__( 'WPSD Plugins', 'ls-css-helper' ), Consts::RELEASED_DATE);

}

function load_language_domain(){

	load_plugin_textdomain('ls-css-helper', false, basename(Consts::DIR) . '/languages/');
}

function add_wpsd_submenu($submenus){

	$submenus[] = [
		__( "Litespeed CSS helper", 'ls-css-helper' ), 
		Consts::SLUG, 
		__NAMESPACE__.'\home_menu_main'
	];

	return $submenus;
}

/**
 * When release date is the same as current date, return this plugin html
 * 
 * @param string $release_date
 * 
 * @return string
 */

function wpsd_main_page_content($release_date){

	if($release_date !== Consts::RELEASED_DATE){
		return $release_date;
	}

	return file_get_contents(Consts::DIR.'includes/wpsd-main-content.html');
}