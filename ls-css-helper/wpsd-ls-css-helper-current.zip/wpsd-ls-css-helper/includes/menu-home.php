<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

function home_menu_main(){

	home_form();

	the_cookie_set_button();

}

function the_cookie_set_button(){

	if(!defined( 'LSCWP_V' ) || !(get_option(Consts::OPTION_SETTINGS) === 'ccss' || get_option(Consts::OPTION_SETTINGS) === 'ucss')){
		return;
	}

	$nonce= get_transient_nonce();

	$ajax_url = add_query_arg(
		[
			'ls-css-helper-cookie' => $nonce,
		],
		home_url( '/' )
	);
	
	$ajax_url_esc = esc_url($ajax_url);
	$text = __('Activate front-end selectors search by pasting this link into incognito window.','ls-css-helper');

	$text_incognito_window = __('Open in Incognito window:','ls-css-helper');
	echo <<<HTML
	<br>
	<h3>{$text}</h3>
	<span style="color:red;font-size:20px;font-wigth:bold">{$text_incognito_window}</span>
	<a href="{$ajax_url}">{$ajax_url_esc}</a>
	HTML;
}

function home_form(){
	
	$d = get_settings_form_data();

	if(!defined( 'LSCWP_V' )){
		
		echo <<<HTML
		<h3>{$d->title}</h3>
		<div class="notice notice-error">{$d->ls_not_active}</div>
		HTML;
		return;
	}

	if( get_option(Consts::OPTION_SETTINGS) === 'ccss' ){
		$ccss_html = <<<HTML
		<tr>
			<th scope="row">{$d->vary_text}</th>
			<td>
				<label>
					<input type="checkbox" name="ccss_vary" value="1"{$d->vary_checked}>
					{$d->enabled_text}
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row">{$d->async_text}</th>
			<td>
				<label>
					<input type="checkbox" name="ccss_async" value="1"{$d->async_checked}>
					{$d->enabled_text}
				</label>
			</td>
		</tr>
		HTML;
	} else {
		$ccss_html = '';
	}

	echo <<<HTML
<h3>{$d->title}</h3>
<form id="ls-css-helper-menu-form" method="post">
	<input type="hidden" name="wp-nonce" value="{$d->nonce}">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row">
					<label for="cssmode-select">{$d->mode_text}</label>
				</th>
				<td>
					<select id="cssmode-select" name="cssmode">
						{$d->options_markup}
					</select>
				</td>
			</tr>
			{$ccss_html}
		</tbody>
	</table>
	<div style="display: flex;flex-direction: column;gap: 1em;width: fit-content;margin-top:1em;">
		<button name="settings-action" value="ls-css-helper-settings" type="submit" class="button button-primary">{$d->button_texts->save}</button>
	</div>
</form>
HTML;
}

function get_settings_form_data(){
		
	$selected = get_plugin_setting();

	$vary_checked = get_option(Consts::OPTION_VARY) ? ' checked' : '';

	$async_checked = get_option(Consts::OPTION_ASYNC) ? ' checked' : '';

	$select_texts = [
		'off' => __('Off','ls-css-helper'),
		'ccss' => __('CCSS','ls-css-helper'),
		'ucss' => __('UCSS','ls-css-helper'),
	];

	$options_markup = '';
	foreach( $select_texts as $value => $text ){
		$selected_attr = ($value === $selected) ? ' selected' : '';
		$options_markup .= <<<HTML
	<option value="{$value}"{$selected_attr}>{$text}</option>
	HTML;
	}

	$button_texts = (object)[
		'save'  =>  __('Save settings','ls-css-helper')
	];

	$nonce = esc_attr( \wp_create_nonce('ls-css-helper-nonce') );

	$title = __('Helper with Litespeed CCSS and UCSS','ls-css-helper');

	$ls_not_active = __('Litespeed plugin is not active.','ls-css-helper');

	$mode_text = __('Mode','ls-css-helper');

	$vary_text = __('Apply CCSS vary','ls-css-helper');

	$async_text = __('Load CSS late','ls-css-helper');

	$enabled_text = __('Enabled','ls-css-helper');
	
	return (object) [
		'select'			=> $select_texts,
		'options_markup'	=> $options_markup,
		'button_texts'		=> $button_texts,
		'nonce'				=> $nonce,
		'title'				=> $title,
		'ls_not_active'		=> $ls_not_active,
		'mode_text'			=> $mode_text,
		'vary_text'			=> $vary_text,
		'async_text'		=> $async_text,
		'enabled_text'		=> $enabled_text,
		'vary_checked'		=> $vary_checked,
		'async_checked'		=> $async_checked

	];
}

function get_plugin_setting(){
	
	if( is_settings_action('ls-css-helper-settings') && has_right_to_save() ){

	
		switch($_POST['cssmode']){

			case 'ccss':
			case 'ucss':
				$css_mode = $_POST['cssmode'];
				break;
			default:
				$css_mode = 'off';

		}

		update_option( Consts::OPTION_SETTINGS, $css_mode, 'off' );

		update_option( Consts::OPTION_VARY, isset($_POST['ccss_vary']) ? '1' : '0', 'off' );

		update_option( Consts::OPTION_ASYNC, isset($_POST['ccss_async']) ? '1' : '0', 'off' );
	
	} else{
		
		$css_mode = LS_CSS_HELPER_CSS_MODE;

	}

	return $css_mode;
}

function has_right_to_save(){

	return current_user_can( 'manage_options' ) && wp_verify_nonce($_POST['wp-nonce']??'', 'ls-css-helper-nonce');

}

function is_settings_action($action){

	switch(true){

		case $_SERVER['REQUEST_METHOD'] !== 'POST':
		case !isset($_POST['settings-action']):
		case $_POST['settings-action'] !== $action:
			return false;
		default:
			return true;
	}
}
