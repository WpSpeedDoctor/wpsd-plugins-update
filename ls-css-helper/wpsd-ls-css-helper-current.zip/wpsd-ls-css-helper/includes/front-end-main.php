<?php

namespace WPSD\ls_css_helper;


function run_front_end(){

	switch(true){
		case !defined( 'LSCWP_V' ):
		case !isset( $_COOKIE[Consts::SLUG] ):
		case $_COOKIE[Consts::SLUG] != get_transient_nonce():
			break;
	
		default:
			require Consts::DIR.'includes/inject-data/inject-main.php';
			break;
	}

	if( isset( $_GET['ls-css-helper-cookie'] ) ){

		include_once Consts::DIR.'includes/cookie-set.php';
	}

	if( get_option('litespeed.conf.optm-css_async') && !isset( $_COOKIE[Consts::SLUG] ) ){

		require Consts::DIR.'includes/ls-ccss.php';
	}

}
