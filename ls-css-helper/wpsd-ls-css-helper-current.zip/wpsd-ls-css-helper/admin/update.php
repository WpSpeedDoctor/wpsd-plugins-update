<?php

namespace WPSD\ls_css_helper;

defined( 'ABSPATH' ) || exit;

function get_remote_json_data( $url, $transient_name=false ){
	
	switch(true){

		case $transient_name === false:
		case !($cached_update_data = get_transient( $transient_name )):
			break;
		default:
			return $cached_update_data;
	}
	
	global $wp_version;

	$args = [
		'headers' => [
			'User-Agent' => "WordPress/{$wp_version};"
			],
		'sslverify' => true, 
	];

	
	$response = wp_remote_get( $url, $args );

	if ( is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200 ) {
		
		return false;
	}

	$response_body = wp_remote_retrieve_body( $response );

	$result = json_decode( $response_body , true );

	if( json_last_error() !== JSON_ERROR_NONE ){

		$result = $response_body;
	}

	if( !$transient_name ) return $result;

	if( empty($result) ){

		delete_transient( $transient_name );

	} else {

		set_transient( $transient_name, $result, HOUR_IN_SECONDS );
	}

	return $result;

}
/**
 * @return array -
 * - version
 * - download_link
 * - requires
 * - tested
 * - requires_php
 * - last_updated
 * - sections
 */

function get_auto_update_data(){

	return get_remote_json_data( 'https://raw.githubusercontent.com/WpSpeedDoctor/wpsd-plugins-update/refs/heads/main/ls-css-helper/update.json', 'ls-css-helper' );

}

function enable_plugin_auto_update($transient) {

	if (empty($transient->checked)) {
		return $transient;
	}
	
	$plugin_slug = 'wpsd-ls-css-helper/wpsd-ls-css-helper.php';

	if (!isset($transient->checked) || !isset($transient->checked[$plugin_slug])) {
		return $transient;
	}

	$current_version = $transient->checked[$plugin_slug];

	$update_data = get_auto_update_data();

	if( !empty($update_data['version']) && version_compare($current_version, $update_data['version'], '<')) {

		$obj = new \stdClass();
		$obj->id = 0;
		$obj->slug = $plugin_slug;
		$obj->plugin = $plugin_slug;
		$obj->new_version = $update_data['version'];
		$obj->package = $update_data['download_link'];
		$obj->requires = $update_data['requires'];
		$obj->tested = $update_data['tested'];
		$obj->requires_php = $update_data['requires_php'];
		$obj->last_updated = $update_data['last_updated'];;

		$transient->response[$plugin_slug] = $obj;
	}

	return $transient;
}

add_filter('pre_set_site_transient_update_plugins', __NAMESPACE__.'\\enable_plugin_auto_update');


function custom_plugin_api_handler($false, $action, $args) {
	
	$plugin_slug = 'wpsd-ls-css-helper/wpsd-ls-css-helper.php';

	if ($action !== 'plugin_information' || isset($args->slug) && $args->slug !== $plugin_slug) return $false;
	
	$update_data = get_auto_update_data();

	if (empty($update_data['version'])) return $false;

	$changelog_text = get_remote_json_data( 'https://raw.githubusercontent.com/WpSpeedDoctor/wpsd-plugins-update/refs/heads/main/ls-css-helper/changelog.log' );

	if ( empty($changelog_text) ){

		$changelog_text = __("The changelog couldn't be fetched.",'ls-css-helper');
		
	} else {

		$changelog_text = str_replace( "\r\n",'\n',  $changelog_text );

		$changelog_text = str_replace( "\n",'<br>', esc_html( $changelog_text ) );
	}

	
	$response = new \stdClass();
	$response->slug = $plugin_slug;
	
	$response->version = 		$update_data['version']; 
	$response->download_link =	$update_data['download_url']??$update_data['download_link'];
	
	
	$response->requires =		$update_data['requires'];// Minimum WordPress version
	$response->tested =			$update_data['tested']; // Tested up to WordPress version
	$response->requires_php =	$update_data['requires_php']; // Minimum PHP version
	
	$response->name = esc_html__('Litespeed CCSS & UCSS generation helper','ls-css-helper');

	$response->sections = [
				// 'description' => 'The latest version of the plugin.', // Main description
				
				'changelog' => $changelog_text, 
				
				// Add other sections as needed
			];

	// $response->banners = array(
		//     'low' => 'URL to a 772x250px banner image', // Optional: Banner image
		//     'high' => 'URL to a 1544x500px banner image' // Optional: High-resolution banner image
		// );

	return $response; // Return the custom response

}

add_filter('plugins_api', __NAMESPACE__.'\\custom_plugin_api_handler', 10, 3);

