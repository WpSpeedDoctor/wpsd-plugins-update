<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced PHP Debug by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data
* Version: 1.36
* Updated: 2026-02-15
* Network: true
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
* Requires PHP extension: sqlite3
*/	

require_once __DIR__.'/constants.php';

/**
 * Main branching
 */
switch( WPSD_REQUEST_TYPE ){

	case REQUEST_AJAX:
		
		isset($_POST['action']) && require Consts::DIR.'admin/request-ajax.php';
		break;

	case REQUEST_ADMIN:
		
		$file = __FILE__;//necessary for register_activation_hook
		require Consts::DIR.'admin/request-back-end.php';
		unset($file);
		break;
	
	case REQUEST_CRON:
			
		require_once Consts::DIR.'includes/cron/cron.php';
		break;
	
	case REQUEST_LOGIN:

		require Consts::DIR.'includes/login/display-cookies.php';
		add_action('wp_login', __NAMESPACE__ . '\\set_admin_bar_cookie', 99, 2);
		add_action('wp_logout', __NAMESPACE__ . '\\delete_admin_bar_cookie');
		break;

}

/**
 * Displaying menu in admin bar for admin only
 */
switch(WPSD_REQUEST_TYPE){
	case REQUEST_FRONTEND:
	case REQUEST_ADMIN:
	case REQUEST_404:

		if(isset($_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR])){
			// On Multisite cookie constant is not available before INIT hook
			require Consts::DIR.'includes/admin-bar/wp-admin-bar.php';
		}
		
		break;
}


//TODO: Add custom url check to set admin bar cookie after login
// if( isset($_GET['act']) ){

// 	require Consts::DIR.'playground.php';

// }