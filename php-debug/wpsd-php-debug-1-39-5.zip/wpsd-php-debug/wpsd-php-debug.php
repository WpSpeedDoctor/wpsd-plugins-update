<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: WPSD Debug
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data, support functionality for advanced debugging
* Version: 1.39.5
* Updated: 2026-09-29
* Network: true
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 8.0.0
* Requires PHP extension: sqlite3
*/	

require_once __DIR__.'/constants.php';

/**
 * Main branching
 */
switch( WPSD_REQUEST_TYPE ){

	case REQUEST_AJAX:
		
		isset($_POST['action']) && require_once Consts::DIR.'admin/request-ajax.php';

		isset($_GET[Consts::AJAX_QS_FETCH]) && require Consts::DIR.'fetch.php';
		break;

	case REQUEST_ADMIN:
		
		$file = __FILE__;//necessary for register_activation_hook
		require Consts::DIR.'admin/request-back-end.php';
		unset($file);
		break;
	
	case REQUEST_CRON:
			
		require_once Consts::DIR.'includes/cron/cron.php';
		break;
}

/**
 * Run login and logout hooks on requests that hooks can be triggered.
 */

switch(WPSD_REQUEST_TYPE){

	case REQUEST_ADMIN:
	case REQUEST_FRONTEND:
	case REQUEST_AJAX:
	case REQUEST_LOGIN:
	case REQUEST_REST:
		add_action('wp_login', __NAMESPACE__ . '\\set_admin_bar_cookie', 99, 2);
		add_action('wp_logout', __NAMESPACE__ . '\\delete_admin_bar_cookie');
		defined('USER_SWITCHING_VERSION') && add_action( 'switch_back_user', __NAMESPACE__ . '\\set_admin_bar_cookie');
		break;

}

function delete_admin_bar_cookie(){

	require_once Consts::DIR.'includes/login/display-cookies.php';
	
	delete_plugin_cookies();
	
}

function set_admin_bar_cookie($user_login, $user=null){

	if(defined('USER_SWITCHING_VERSION') && is_null($user) && is_numeric($user_login) && $user = get_userdata($user_login)){
		$user = get_userdata($user_login);
		if(!$user){
			return;
		}
	}

	require_once Consts::DIR.'includes/login/display-cookies.php';
	
	set_cookies_after_login($user);
}


/**
 * Displaying menu in admin bar for admin only
 */
switch(WPSD_REQUEST_TYPE){
	case REQUEST_FRONTEND:
	case REQUEST_ADMIN:
	case REQUEST_404:

		if(isset($_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR])){
			add_action('init', __NAMESPACE__ . '\\hook_admin_bar');
		}
		break;
}

function hook_admin_bar(){
	
		require Consts::DIR.'includes/admin-bar/wp-admin-bar.php';
}

/**
 * Dark mode
 */

is_dark_mode() && require Consts::DIR.'includes/dark-mode/wpsd-admin-darkmode.php';

function is_dark_mode(){

	switch(WPSD_REQUEST_TYPE){

		//when login page is custom is ususally categorized as a front-end request type
		case REQUEST_FRONTEND:

			return is_callable('login_header') || //wp-login.php been loaded
				is_callable('crb_get_settings') && //WP Cerber is active
				str_contains(WPSD_URI_PATH, crb_get_settings( 'loginpath' )); // is WP Cerber login page

		case REQUEST_ADMIN:
			
			return isset($_COOKIE[Consts::COOKIE_DARK_MODE]) && 
				$_COOKIE[Consts::COOKIE_DARK_MODE] === Consts::get_nonce();

		case REQUEST_LOGIN:
				return true;

		default:
				return false;			
	}
}
