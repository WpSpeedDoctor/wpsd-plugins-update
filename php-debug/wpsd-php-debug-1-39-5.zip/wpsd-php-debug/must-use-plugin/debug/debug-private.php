<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

// require_once Consts::DIR.'must-use-plugin/errors/error-handler-private.php';

function debl( $value='%marker%', $id=false ){
	
	$value_string = get_value_as_string_wpsd( $value, $esc_html = false );
	
	$id_string = $id === false ? '' : $id.' -> ';

	require_error_handler_private();

	errors_storage( [
		
		0 => 99999,

		1 => "{$id_string}{$value_string}\n",

	],false);

	if(defined('WPSD_DEBL_SHUTDOWN')) return;

	define( 'WPSD_DEBL_SHUTDOWN', true );

}

function add_deb_to_log_wpsd(){

	require_once Consts::DIR.'must-use-plugin/errors/error-handler-private.php';
	
	record_php_errors();
}

function debu( $display_value1='%marker%', $display_value2=false){

	write_debug_file('a:0:{}');

	deb( $display_value1, $display_value2);

}

function deb( $value='%marker%', $id=false ){

	$id_string = $id === false ? '' : $id.' -> ';

	cache_deb_values( $id_string.get_value_as_string_wpsd( $value ));

	if( defined('WPSD_DEB_SHUTDOWN') ) return;

	define('WPSD_DEB_SHUTDOWN', true);
}

function cache_deb_values( $differentiator = false ){

	static $vary_value = [ ];

	if($differentiator === false) return $vary_value;

	$vary_value[] = $differentiator;

}

function get_cache_stopwatch_start( $reset=false ){

	static $stw_timestamp = false;

	if( $stw_timestamp === false ){

		$stw_timestamp = microtime(true);
		
		return false;
	}

	$result = $stw_timestamp;

	if( $reset ){

		$stw_timestamp = microtime(true);
		
	}

	return $result;

}

function store_deb_values_wpsd(){

	$deb_values = get_stored_values_wpsd();
	
	$deb_values[] = [ 

		//timestamp of expiration magic number 15 is 15 seconds TTL
		't' => time() + 15,

		// values
		'v' => implode('<br>',cache_deb_values(false))
	];

	write_debug_file( serialize($deb_values) );
}

function write_debug_file( $value ){

	file_put_contents( get_debug_data_filepath_wpsd(), gzencode( $value, 1) );
}

function read_debug_file(){

	return gzdecode( file_get_contents(get_debug_data_filepath_wpsd()) );
}
/**
 * @return array
 */

function get_stored_values_wpsd(){

	$debug_data_filepath = get_debug_data_filepath_wpsd();
	
	if( !file_exists($debug_data_filepath) ) return [];

	$deb_values = read_debug_file();	
	
	if( empty( $deb_values ) ) return [];
	
	$current_timestamp = time();
	
	$deb_values_array = unserialize( $deb_values );
	
	
	// remove expired records
	foreach( $deb_values_array as $key => $record ){
		
		if( $record['t'] < $current_timestamp ) unset($deb_values_array[$key]);
	}

	// clean up on all expired records
	if( empty( $deb_values_array ) ) {

		write_debug_file('a:0:{}');
	} 

	return $deb_values_array;
}

function get_debug_data_filepath_wpsd(){

	static $value;

	$value || $value = Consts::DB_DIR.'debug-data.'.get_server_last_ip_number();

	return $value;

}


function get_value_as_string_wpsd($value, $esc_html = true ){

	switch( true ){
		
		case is_numeric($value):

			return ( string ) $value;

		case $value === '%marker%':
	
			return get_marker_text_wpsd();

		case is_string($value):
			
			return $esc_html ? htmlentities($value, ENT_QUOTES, 'UTF-8') : $value;
		
		case is_bool($value):

			$bool_text = $value ? 'true' : 'false';
			
			if(!$esc_html ){

				return $bool_text;
			}

			$color = $value ? 'green':'red';
			
			return	<<<HTML
					Bool: <span style="color:{$color}">{$bool_text}</span> 
					HTML;
			
		case $value === null:

			if(!$esc_html ){

				return 'Null';
			}

			return	<<<HTML
					<span style="color:blue">Null</span>
					HTML;

		case is_resource($value):
			
			ob_start();

			var_dump( $value );

			$iterable_value = trim(ob_get_clean());
			
			break;

		default:
			
			$iterable_value = var_export($value,true);

			break;
	}

	if( !$esc_html ) return $iterable_value;
	
	$result = '';

	foreach ( explode("\n", $iterable_value ) as $line ) {

		$result .= htmlentities( $line, ENT_QUOTES, 'UTF-8')."\n";
	}

	return $result === '' 
		? htmlentities( $iterable_value, ENT_QUOTES, 'UTF-8') 
		: $result;
}

function get_var_dump( $value ){

	ob_start();
	
	var_dump( $value );

	$output = ob_get_clean();
	
	return $output;
	
}

function get_marker_text_wpsd(){

	$marker = get_marker_location_wpsd();
	
	$filepath = get_filepath_slice_wpsd( $marker['file'] );

	$filename = basename(dirname($filepath)).DIRECTORY_SEPARATOR.basename( $filepath );

	return
<<<HTML
{$marker['function']}() at line {$marker['line']} in {$filename}
HTML;

	
}

function display_debug_data() {
	
	$stored_values = get_stored_values_wpsd();

	$cached_values = cache_deb_values(false);

	if( !empty( $cached_values) ) {

		$stored_values[]['v'] = implode('<br>', $cached_values);
	}

	if( empty( $stored_values ) ) return;

	$values_to_display = implode('<br>', array_reverse( array_column( $stored_values,'v') ) );

	if( ($_COOKIE[Consts::COOKIE_DISPLAY_VALUES]??'')!== Consts::get_nonce() ) return;

?><style>.wpsd-debug-window{ position: fixed;bottom:90px;right:10px;z-index: 999999;background-color: #ddd;
;border: 1px solid grey;padding:0px 5px 0 5px;line-height:30px;color: black;font-size: 20px;padding-right: 35px;max-height: 800px;
overflow-y: scroll;white-space: break-spaces;max-width: 97%;max-height: 80%;}
.wpsd-debug-close {position: absolute;top: -1px;right: 10px;font-size: 30px;font-weight: bold;text-decoration: none;color: #555;}
.wpsd-debug-window:target,.wpsd-debug-window-hidden {display: none;}
</style>
<div id="debug-popup" class="wpsd-debug-window wpsd-debug-window-hidden">
<?php echo $values_to_display; ?><a class="wpsd-debug-close" href="#debug-popup">×</a>
</div>
<script data-cfasync="false" defer >
	document.addEventListener("DOMContentLoaded", function() {
	const cookieName = '<?php echo Consts::COOKIE_DISPLAY_VALUES ?>';

	if (document.cookie.split(';').some((item) => item.trim().startsWith(`${cookieName}=`))){
		const debugPopup = document.getElementById('debug-popup');
		debugPopup.classList.remove('wpsd-debug-window-hidden');
	}
});
</script>
	<?php
	
}

/**
 * Displays a variable in a formatted manner within an HTML block.
 * 
 * @param mixed $value The variable to be displayed.
 * @param string|false $identifier Optional identifier to display with the value.
 * @param bool $float If true, adjust the CSS for floating the debug window.
 * @param bool $esc_html If true, escape HTML special characters in the output.
 */

function vd( $value= '', $identifier=false, $float=false, $esc_html=false ) {
	
	$css = get_debug_window_css_wpsd($float);

	$id = bin2hex(random_bytes(2));

	$identifier_line = $identifier ?: get_marker_text_wpsd();

	$value_markup = get_value_as_string_wpsd( $value, $esc_html );

	echo <<<HTML
<div id="vd-{$id}" style="{$css}">
	<div style="text-align:center">{$identifier_line}</div>
	<div class="debug-data" style="white-space: pre-wrap">{$value_markup}</div>
</div>
HTML;
	
}

function the_debug_window_header_wpsd($value2){
//https://stackoverflow.com/questions/2110732/how-to-get-name-of-calling-function-method-in-php
	if (! defined( 'ABSPATH' ) ) return;
		
	global $template;

	$marker_location = get_marker_location_wpsd();

	$caller_details = 'Template: '.get_filepath_slice_wpsd($template??'') ?:'';

	$caller_details .= '  Called from: '.$marker_location['function']??'';

	$caller_details .= '  Line: '.$marker_location['line']??'';

	$caller_details .= '  File: '.get_filepath_slice_wpsd($marker_location['file']??'');

	$text_to_display = $value2?: $caller_details;

	?>
	<div class="debug-header" style="position: absolute;background: rgb(51, 51, 51);width:100%;line-height: 0;text-align:center;">
		<h4>
			<?=$text_to_display?>
		</h4>
	</div>
	<?php
}

function get_marker_location_wpsd( ){

	$trace = array_reverse(debug_backtrace());

	//debug functions
	$fnc_names = [
		'deb',
		'debl',
		'debu',
		'vd',
		__NAMESPACE__ . '\\deb',
		__NAMESPACE__ . '\\debl',
		__NAMESPACE__ . '\\debu',
		__NAMESPACE__ . '\\vd',
		__NAMESPACE__ . '\\get_value_as_string_wpsd',
		__NAMESPACE__ . '\\get_marker_text_wpsd',
		 __FUNCTION__
	];

	foreach( $trace as $key => $value ) {

		if ( in_array( $value['function'], $fnc_names  ) ) break;
		
		$caller_key = $key+1;
		
	}
	
	$caller_key ??= count( $trace )-1;

	return [
		
		'function'	=> get_function_name_wpsd( $trace, $caller_key ),
		
		'file'		=> $trace[$caller_key]['file']??'',
		
		'line'		=> $trace[$caller_key]['line']??''

	];
}

function get_function_name_wpsd( $trace, $caller_key ){

	if( empty( $trace[$caller_key-1]['function'] ) ) return '';

	return str_replace('\\\\','\\',$trace[$caller_key-1]['function']);
}

/**
 * stw() stopwatch
 */
function stw($reset=false){

	$now = microtime(true);

	$start = get_cache_stopwatch_start($reset);

	if( $start === false ) return;

	dtm( $start , $now );
	
}

function get_filepath_slice_wpsd( $filepath ){

	foreach (['themes','plugins','wp-content','public_html','www'] as $separator ){

		$filepath_slices = explode( $separator, $filepath );

		if ( isset($filepath_slices[1]) ) return $filepath_slices[1];

	}

	return $filepath;
}


function get_debug_window_css_wpsd( $float = false ) {

	$css = 'padding: 0 10px 10px 10px;border: 1px solid red;font-weight: bold;/*white-space: pre-wrap*/;overflow: scroll;max-height: 400px;color: #ddd;font-family: monospace;font-size: 18px;line-height: 30px;background-color: #333;';

	if( $float ){

		$css .='position: fixed;bottom: 40px;right: 0px;z-index: 10;max-width:80%';
	} 

	return $css;

}

/**
 * Time debugging functions
 */

function the_tm($start,$end) {

	$time_elapsed = tm($start,$end);
	
	echo 
<<<HTML
Time elapsed: {$time_elapsed}
HTML;

}	

function dtm( $start, $end, $identifier='' ) {

	$identifier_text = $identifier === '' ? 'Time elapsed' : $identifier;

	deb( tm($start,$end), $identifier_text );

}

function tm( $start_time_measure, $end_time_measure, $microseconds_output = false  ) {

	switch(true){

		case !( is_numeric($start_time_measure) && is_numeric($end_time_measure) ):
			return $microseconds_output ? 0 : '-';

		case is_float($start_time_measure):
			require_once Consts::DIR.'must-use-plugin/debug/func.tm-microtime.php';
			return tm_microtime( $start_time_measure, $end_time_measure, $microseconds_output );
		
		//fallthough, never false
		case null === $difference = $end_time_measure - $start_time_measure:

		case $microseconds_output:
			return intval( $difference/ 1e3 );

		case ($difference) >= 1e9:
			return round( $difference / 1e9, 3 ).' s';

		case ($difference) >= 1e6:
			return round( $difference / 1e6, 0 ).' ms';

		case ($difference) >= 1e3:
			return round( $difference / 1e3, 0 ).' µs';

		default:
			return ($difference).' ns';
	}

}

function wpsd_used_php(){

	require_once Consts::DIR.'includes/admin-bar/included-files.php';

	deb( implode(PHP_EOL, get_plugins_memory_usage() ) );
}
