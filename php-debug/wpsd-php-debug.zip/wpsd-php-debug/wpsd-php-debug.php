<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced PHP Debug by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data
* Version: 1.1.0
* Updated: 2024-07-30
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-php-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.0
* Requires PHP: 7.0.0
*/	

/**
 * Constants
 */

define( 'WPSD_PHP_DEBUG_DIR', __DIR__.'/' );

const WPSD_PHP_DEBUG_VER = '1.1.0';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){

		case wp_doing_ajax():
				
			if( ($_POST['action']??'') === 'delete-plugin' ) {

				require_once WPSD_PHP_DEBUG_DIR.'admin/uninstall.php';
			}
			
			if( ($_POST['action']??'') === 'update-plugin' ) {
				
				require_once WPSD_PHP_DEBUG_DIR.'admin/update.php';
			}


		break;

		case is_admin():
			
			run_back_end();

			require_once WPSD_PHP_DEBUG_DIR.'admin/update.php';

			require_once WPSD_PHP_DEBUG_DIR.'includes/cleanup-cron.php';

		break;
		
		case wp_doing_cron():
				
			require_once WPSD_PHP_DEBUG_DIR.'includes/cleanup-cron.php';
			
		break;


		/*
		case str_contains( $_SERVER['REQUEST_URI']??'', '/wp-json/' ):

			//your code for REST API comes here

		break;
		*/
		
		
		default:
			
			// your code for font-end comes here
			
			// automatically set cookies to display debug values for localhost and staging
			if( ($_SERVER['SERVER_ADDR']??'') === '127.0.0.1' || defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE === 'staging' ){
		
				add_action('wp_login', __NAMESPACE__ . '\\set_display_value_cookies');
			}
			
		
		break;

	}
	
}

function run_back_end(){
	
	global $pagenow;
	
	if ( $pagenow === 'plugins.php' ) {
		
		require_once WPSD_PHP_DEBUG_DIR.'admin/setup.php';

		plugin_setup_main(__FILE__);

	}	

	add_action('admin_menu', __NAMESPACE__.'\admin_menu');

	if ( $pagenow === 'tools.php' && ($_GET['page']??'') == 'wpsd-php-debug-page' ) {

		require WPSD_PHP_DEBUG_DIR.'includes/menu/wp-admin-menu.php';
	}

}

function set_display_value_cookies() {

	$dir_string = substr( get_option('wpsd-php-debug-dir'), 6, 20);

	setcookie(
		'wpsd-debug-display-values',
		$dir_string,
		0
	);

}

function admin_menu() {

	add_submenu_page(
		'tools.php',
	//add_menu_page( 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		'administrator', 
		'wpsd-php-debug-page', 
		__NAMESPACE__.'\admin_menu_main',
		4
	);
}

function require_universal_function(){

	require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

}
