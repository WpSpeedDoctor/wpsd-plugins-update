<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced PHP Debug by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data
* Version: 1.0.22
* Updated: 2024-05-07
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-php-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.0
* Requires PHP: 7.0.0
*/	

/**
 * TODO
 * Move is_ini_set_allowed() into mu-plugin constructor and set constant if not allowed
 */


/**
 * Constants
 */

define( 'WPSD_PHP_DEBUG_DIR', __DIR__.'/' );

const WPSD_PHP_DEBUG_VER = '1.0.22';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){

		case wp_doing_ajax()://must be first case because is_admin() === true when URI is /wp-admin/admin-ajax.php
				
			if( ($_POST['action']??'') === 'delete-plugin' ) {

				require WPSD_PHP_DEBUG_DIR.'admin/uninstall.php';
			}
			
			if( ($_POST['action']??'') === 'update-plugin' ) {
				
				require_once WPSD_PHP_DEBUG_DIR.'admin/update.php';
			}


		break;

		case is_admin():
			
			run_back_end();

			require_once WPSD_PHP_DEBUG_DIR.'admin/update.php';

			// require_once WPSD_PHP_DEBUG_DIR.'includes/cleanup-cron.php';
			
		break;
			
		// case wp_doing_cron():
				
			// require_once WPSD_PHP_DEBUG_DIR.'includes/cleanup-cron.php';
			
			//your code for cron comes here
		// break;

		// case str_contains( $_SERVER['REQUEST_URI']??'', '/wp-json/' ):		
		// 	//your code for REST API comes here
		// break;

		// default:
			
		// 	//your code for font-end comes here		
			
		// break;
	}
		
		
}

function run_back_end(){
	
	global $pagenow;
	
	//require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';
	
	//execute on the wp plugins page
	if ( $pagenow === 'plugins.php' ) {
		
		require_once WPSD_PHP_DEBUG_DIR.'admin/setup.php';

		plugin_setup_main(__FILE__);

	}
	

	add_action('admin_menu', __NAMESPACE__.'\admin_menu');

	if ( $pagenow === 'tools.php' && ($_GET['page']??'') == 'wpsd-php-debug-page' ) {

		require WPSD_PHP_DEBUG_DIR.'includes/menu/wp-admin-menu.php';
	}

}


function admin_menu() {

	add_submenu_page(
		'tools.php',
	//add_menu_page( 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		'administrator', 
		'wpsd-php-debug-page', 
		__NAMESPACE__.'\admin_menu_main',
		4
	);
}


