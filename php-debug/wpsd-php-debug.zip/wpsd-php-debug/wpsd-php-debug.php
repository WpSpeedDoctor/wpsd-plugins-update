<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced PHP Debug by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data
* Version: 1.29.1
* Updated: 2025-05-10
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
* Requires PHP extension: sqlite3
*/	


require_once __DIR__.'/constants.php';

/**
 * Runtime code
 */

// if( isset($_GET['act']) ){

// 	require WPSD_DEBUG_DIR.'playground.php';

// }

main();

/**
 * functions only beyond this point
 */

function main(){

	plugin_cookies_main();

	switch( WPSD_REQUEST_TYPE ){

		case REQUEST_AJAX:
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'delete-plugin' ) {

				require_once WPSD_DEBUG_DIR.'admin/uninstall.php';
			}
			
			if( $post_action === 'update-plugin' ) {
				
				require_once WPSD_DEBUG_DIR.'admin/update.php';
			}
			
			if( $post_action === 'htmx-php-debug-search' && !function_exists( __NAMESPACE__.'\set_php_error_reporting') ) {

				require_once WPSD_DEBUG_DIR.'/must-use-plugin/ajax/ajax-handler.php';

			}

			break;

		case REQUEST_ADMIN:
			
			run_back_end();

			require_once WPSD_DEBUG_DIR.'admin/update.php';

			require_once WPSD_DEBUG_DIR.'includes/cleanup-cron.php';

			break;
		
		case REQUEST_CRON:
				
			require_once WPSD_DEBUG_DIR.'includes/cleanup-cron.php';
			
			break;

	}
	
}

function plugin_cookies_main(){
	
	require_once WPSD_DEBUG_DIR.'includes/universal-functions.php';

	//set displaying menu in admin bar
	$cookies = get_debug_cookies();

	$is_user_logged_in = defined('LOGGED_IN_COOKIE') && isset( $_COOKIE[LOGGED_IN_COOKIE] );

	switch(true){

		case WPSD_REQUEST_TYPE !== REQUEST_FRONTEND && WPSD_REQUEST_TYPE !== REQUEST_ADMIN:
		case isset($_COOKIE[$cookies->admin_check]):
		case !$is_user_logged_in:
			break;

		default:
			
			require_once WPSD_DEBUG_DIR.'includes/display-cookies.php';

			add_action('plugins_loaded', __NAMESPACE__.'\\set_display_cookies' );

			break;
	}

	//display admin bar
	switch(true){

		case !isset($_COOKIE[$cookies->display_admin_bar]):
		case $_COOKIE[$cookies->display_admin_bar] !== $cookies->nonce:
		case !$is_user_logged_in:
		case WPSD_REQUEST_TYPE !== REQUEST_FRONTEND && WPSD_REQUEST_TYPE !== REQUEST_ADMIN:
			break;

        default:

			require_once WPSD_DEBUG_DIR.'includes/wp-admin-bar.php';

			add_action('admin_bar_menu', __NAMESPACE__ . '\\add_php_time_menu', 1000);

			break;
	}

	//delete cookies after logout
	if( isset($_COOKIE[$cookies->admin_check]) && !$is_user_logged_in ){

		require_once WPSD_DEBUG_DIR.'includes/display-cookies.php';

		delete_plugin_cookies();

	}
}

function run_back_end(){
	
	global $pagenow;

	$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;
	
	if ( $page_now === 'plugins.php' ) {
		
		require_once WPSD_DEBUG_DIR.'admin/setup.php';

		plugin_setup_main(__FILE__);

	}	

	add_action('admin_menu', __NAMESPACE__.'\admin_menu');

	if ( $page_now === 'tools.php' && ($_GET['page']??'') == 'wpsd-php-debug-page' ) {

		require WPSD_DEBUG_DIR.'includes/menu/wp-admin-menu.php';
	}

}

function admin_menu() {

	add_submenu_page(
		'tools.php',
	//add_menu_page( 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		__( "Advanced PHP Debug", 'wpsd-php-debug' ), 
		'administrator', 
		'wpsd-php-debug-page', 
		__NAMESPACE__.'\admin_menu_main',
		4
	);
}