<?php

namespace wpsd_php_debug;

defined( 'ABSPATH'  ) || exit;

function get_error_messages($page, $per_page){
// __DIR__.'/test.log'
	$file = fopen( WPSD_LOG_FILE, 'r');

	fseek($file, 0, SEEK_END);

	[$timestamp, $position_in_file] = get_start_position($file,$page,$per_page);
	
	if(!$timestamp) return [];
	
	$line = '';
	
	$result[$timestamp]='';

	while ($position_in_file > 0) {
		
		$position_in_file--;
	
		fseek($file, $position_in_file);
	
		$char = fgetc($file);
	
		if ( is_line_completed( $char, $line ) ) {
			
			$trimmed_line = trim($line);

			if( is_timestamp_line( $trimmed_line ) ) {
				
				trim_completed_value( $result, ($timestamp??0) );

				$timestamp = strrev( substr($trimmed_line,2));
				
				if( count( $result) == $per_page ) return $result;

				$result[$timestamp] ='';
				
			} else {
				
				if( !empty($timestamp)){

					$result[$timestamp] .= strrev($line)."\n";
				}

			}
	
			$line = '';
	
		} else {
	
			$line .= $char;
	
		}
	
	}
	
	$result[$timestamp] .= strrev($line)."\n";
	
	fclose($file);

	return $result;

}


function get_start_position( &$file, $page, $per_page ){

	$position_in_file = ftell($file);

	// if( $page === 0 ) return [ 0, $position_in_file];

	$skip_timestamps = ($per_page*$page)+1;

	$line = '';

	while ($position_in_file > 0) {
		
		$position_in_file--;
	
		fseek($file, $position_in_file);

		$char = fgetc($file);

		if ($char == "\n") {
			
			$trimmed_line = trim( $line );

			if( is_timestamp_line( $trimmed_line ) ) {
				
				--$skip_timestamps;
				
				if( $skip_timestamps === 0 ) {
					
					return	[
						
						strrev( substr($trimmed_line,2)),
						
						$position_in_file
					];
				}
			}

			$line = '';

		} else {

			$line .= $char;
		
		}
	}

	return [ false, false ];
}


function is_timestamp_line( $trimmed_line ){

	return isset($trimmed_line['1']) && $trimmed_line[1] ==='&' && $trimmed_line['0'] === '%';
}

function trim_completed_value( &$result, $timestamp ){

	
	if( !isset($result[$timestamp]) ) return;

	$result[$timestamp] = trim($result[$timestamp]);
}

function is_line_completed( $char, $line ){
	
	return $char == "\n" && $line !== '';
}
