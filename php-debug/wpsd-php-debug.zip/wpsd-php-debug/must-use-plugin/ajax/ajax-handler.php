<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

if( empty($_POST['nonce']) || $_POST['nonce'] !== get_nonce() ){

	http_response_code( 401 );

	die('Unauthorized Access');
}

$input = get_input_from_post();

switch(true){

	case $input['source-error-log']:
		
		require __DIR__.'/source-error-log.php';

		display_source_error_log($input);

		break;
	
	case $input['download']:

		download_error_log_with_metadata($input);
		break;

	case $input['delete']:

		delete_log_file( $input );
		break;

	default:
		
		display_data_main($input);
		break;

}

die;

function display_data_main( $input ){

	$recorded_fragments = record_fragments( $input );

	require __DIR__.'/sqlite-errors.php';
	
	$microtime_int = intval( microtime(true) );
	$start_time_measure = microtime(true)-$microtime_int;

	$data = get_input_match_data( $input );

	$end_time_measure = microtime(true)-$microtime_int;

	$time = tm( $start_time_measure, $end_time_measure );
	
	if( empty($data['error']) ) {
		
		display_no_results();

	} else {
		
		display_pagination_main( $input, $data['total'] );
	
		display_data( $data, $input );

	}
	
	
	$text = sprintf(
		esc_html__('SQLite query took %s.', 'wpsd-php-debug'),
		$time
	);

	if($recorded_fragments){

		$text .= sprintf(
			esc_html__(' Recorded fragments %d.', 'wpsd-php-debug'),
			$recorded_fragments
		);
	}
	
	echo <<<HTML
	<div class="wpsd-recorded">$text</div>
	HTML;
}

function record_fragments( $input ){
	
	$ip_from_db_filename = get_ip_from_db_filename( $input['db-filename'] );

	//limit of files count for quick record fragments without prompt
	$limit_files = 2048;

	//MB
	$limit_size = 3 * 1024 * 1024; 

	$fragments_stats = get_extensions_size( $ip_from_db_filename, $limit_files );

	if( $fragments_stats->count === 0 ) {
		return false;
	}

	$is_over_count_limit = $fragments_stats->count === $limit_files;

	$is_over_size_limit = $fragments_stats->size > $limit_size;

	if( $input['record-fragments'] || $is_over_count_limit === false && $is_over_size_limit === false ){

		require WPSD_DEBUG_DIR.'includes/class.fragments-recorder.php';

		$record = new sqlite_recorder($ip_from_db_filename);

		$record->record_fragments_files();

	} else {

		display_fragments_notice( $input );

	}

	return $record->fragments_recorded??false;
}

function display_fragments_notice($input){

	if( !empty( $input['record-fragments']) ) return;

	$log_dir_string = get_log_dir_string();

	$fragments_dir_path = WP_CONTENT_DIR."{$log_dir_string}fragments/";
	
	if( !file_exists( $fragments_dir_path ) || !is_dir( $fragments_dir_path) ) return;

	$file_extension = '.'.get_ip_from_db_filename( $input['db-filename'] );
	
	$directory = dir( $fragments_dir_path );

	$fragments_count = 0;

	while( ($file = $directory->read()) !== false ){

		if( $file === '.' || $file === '..' || !str_ends_with($file, $file_extension) ) continue;

		$fragments_count++;

	}

	$directory->close();

	if( $fragments_count === 0 ) return;

	$text = sprintf(
		__( '⚠ %d unrecorded errors found.', 'wpsd-php-debug' ),
		$fragments_count
	);

	
	echo <<<HTML
	<div class="notice notice-warning is-dismissible iterable-key">{$text}</div>
	HTML;
}


/**
* @param string $ext
* @param int $max
* @return object -
* - size => int
* - count => int
*/

function get_extensions_size( $ext, $max ){

	$fragments_dir_path = WP_CONTENT_DIR.get_log_dir_string().'fragments/';

	if( !is_dir( $fragments_dir_path ) ) return false;
	
	$directory = opendir( $fragments_dir_path );
	
	if( !$directory ) return false;
	
	$total_size = $file_count = 0;

	while( ( $file = readdir( $directory ) ) !== false ){

		if( is_dir( $fragments_dir_path.$file ) ) continue;

		if( pathinfo( $file, PATHINFO_EXTENSION ) != $ext ) continue;

		$total_size += filesize( $fragments_dir_path.$file );

		$file_count++;

		if( $file_count === $max ) break;
	}

	closedir( $directory );

	return (object)[
		'size' => $total_size,
		'count' => $file_count
	];
}


function get_ip_from_db_filename($db_filename){

	preg_match('/ip(\d+)/', $db_filename, $matches);

	return $matches[1] ?? 'null';
}


function get_export_metadata_markup($value){

	if( empty($value['metadata'])) return '';

	$conversion = [
		'e' => esc_html__('Error code:', 'wpsd-php-debug'),
		's' => esc_html__('$_SERVER:', 'wpsd-php-debug'),
		'u' => esc_html__('User name:', 'wpsd-php-debug'),
		'c' => esc_html__('Cookies:', 'wpsd-php-debug'),
		'p' => esc_html__('$_POST:', 'wpsd-php-debug'),
		't' => esc_html__('Timestamp:', 'wpsd-php-debug')
	];

	$output = '';

	foreach( $value['metadata'] as $key => $value){
			
		if( $key==='e' ) $value = " $value - ".get_php_error_code_text($value);

		if( $key==='t' ) $value = date('d-M-Y H:i:s', intval($value)) . ' UTC -> '.$value; 

		$output .= "\n".($conversion[$key]??$key);
		
		$output .= get_export_value($value);

	}

	return $output;
}

function get_export_value($value_to_display){

	if( is_echo_safe( $value_to_display ) ) return " $value_to_display\n";

	$output = "\n";

	foreach( $value_to_display as $key => $value){

		$value_safe = is_echo_safe( $value )  ? $value : var_export( $value, true );

		$output .= "     $key => $value_safe\n";
	}

	return $output;
}

function is_echo_safe($value){

	return  is_string( $value ) || is_numeric( $value );
}

function get_error_type_filename_suffix($input){

	if( $input['error-type']===0 ) return 'all-error';

	$error_type_text = get_php_error_code_text($input['error-type']);

	$pieces  = explode(' ',ltrim($error_type_text,'E_'));

	return str_replace('_','-',strtolower($pieces[0]??''));

}

//MARK:Download
function download_error_log_with_metadata($input) {

	$error_type_suffix = get_error_type_filename_suffix($input);

	$hour = date('H-i-s');
	
	$filename = "{$input['selected-day']}-at-{$hour}-{$error_type_suffix}.log";

	$data = get_input_match_data( $input );
	
	$error_type_strings = get_error_type_strings();

	$output_string = '';

	foreach( $data as $event_data){

		if( $output_string !== '' ) $output_string .= "\n\n";

		$output_string .= "{$event_data['daytime']}\n";

		// $output .= get_export_metadata_markup($value);
		
		$error_name = $error_type_strings[$event_data['code']]??'Unknown error';

		$output_string .= "Error {$event_data['code']} - {$error_name}\n";
		
		$output_string .= "{$event_data['error']}\n";
		$output_string .= "{$event_data['meta']}\n";

		// $error_display = replace_eol_for_html( $event_data['error'] );
		
		// $meta_display = replace_eol_for_html( $event_data['meta'] );
		// $event_data['daytime']

	}

	$output = json_encode(json_encode($output_string));

	echo <<<HTML
	<script data-cfasync="false" defer>
	(function() {
		const filename = '{$filename}';
		const content = {$output};
	
		function downloadEmbeddedContent(filename, content) {
			const decodedContent = JSON.parse(content);
	
			const blob = new Blob([decodedContent], { type: 'text/plain' });
			const url = window.URL.createObjectURL(blob);
	
			const downloadLink = document.createElement('a');
			downloadLink.href = url;
			downloadLink.download = filename;
	
			document.body.appendChild(downloadLink);
			downloadLink.click();
			document.body.removeChild(downloadLink);
			window.URL.revokeObjectURL(url);
		}
	
		downloadEmbeddedContent(filename, content);
	})();
	</script>
	HTML;
	
	die;
}

function get_total_db_data( $query_vars,$input ){

	$total_query = get_total_query($query_vars);

	return get_sqlite_query( $total_query , $input['db-filename'] )[0]['total']??0;

}

function get_error_log_db_data( $input, $query_vars ){
	
	$error_log_query = get_error_log_query($query_vars);

	$error_log_data = get_sqlite_query( $error_log_query , $input['db-filename'] );

die( '<span style="white-space: pre;line-height: 2;">'.var_export( $error_log_data ,true ).'</span>' );


	if( empty($error_log_data) ) return [];

	$result = [];

	foreach( $error_log_data as $event_data ){
	
		$result[] = [
			'daytime' => $event_data['daytime'],
			'code' => (int) $event_data['code'],
			'message' => $event_data['error'],
			'meta_id' => (int) $event_data['meta_id']
		];
	}
	
	return $result;
}

function get_db_metadata($input, $error_log_data ){
	
	$meta_ids = array_unique(array_column($error_log_data,'meta_id'));

	$result = [];

	$metadata_query = get_metadata_query($meta_ids);

	$metadata_raw = get_sqlite_query( $metadata_query, $input['db-filename'] );
	
	foreach( $metadata_raw as $meta_event ){

		$result[ (int) $meta_event['meta_id'] ] = $meta_event['meta'];
	}

	return $result;
}

function get_metadata_query($meta_ids) {
	$ids = implode(',',$meta_ids);

	return <<<SQL
SELECT *
FROM "error_meta"
WHERE meta_id IN ({$ids})
SQL;
}

function get_combined_query($input) {
	$where_clause_error_log = get_where_clause($input, 'log');
	$where_clause_error_meta = get_where_clause($input, 'meta');
	$order = strtolower($input['order']) === 'asc' ? 'ASC' : 'DESC';
	$limit = $input['per-page'];
	$offset = $input['current-page'] * $limit;

	$total_query = <<<SQL
SELECT COUNT(*) 
FROM (
	SELECT el.event_id
	FROM "error_log" el
	{$where_clause_error_log}
	UNION ALL
	SELECT el.event_id
	FROM "error_log" el
	JOIN "error_meta" em ON el.meta_id = em.meta_id
	{$where_clause_error_meta}
)
SQL;

	$union_meta = '';
	if (!empty($where_clause_error_meta)) {
		$union_meta = <<<SQL
	UNION ALL
	SELECT el.event_id, el.meta_id, el.daytime, el.code, NULL AS error, em.meta
	FROM "error_log" el
	JOIN "error_meta" em ON el.meta_id = em.meta_id
	{$where_clause_error_meta}
SQL;
	}

	return <<<SQL
SELECT event_id, meta_id, daytime, code, error, meta, ({$total_query}) AS total
FROM (
	SELECT el.event_id, el.meta_id, el.daytime, el.code, el.error, NULL AS meta
	FROM "error_log" el
	{$where_clause_error_log}
	{$union_meta}
)
ORDER BY daytime $order
LIMIT $limit OFFSET $offset
SQL;
}




function get_where_clause($input, $type = 'log') {
	$conditions = [];
	if ($type === 'log' && !empty($input['selected-day']) && $input['selected-day'] !== 'all') {
		$conditions[] = "el.daytime LIKE '{$input['selected-day']}%'";
	}
	if (!empty($input['search-keyword']) && !$input['search-regex']) {
		$column = $type === 'log' ? 'el.error' : 'em.meta';
		$conditions[] = "{$column} LIKE '%" . sanitize_sqlite_like($input['search-keyword']) . "%' ESCAPE '\'";
	}
	if (!empty($input['exclude-keyword']) && !$input['exclude-regex']) {
		$column = $type === 'log' ? 'el.error' : 'em.meta';
		$conditions[] = "{$column} NOT LIKE '%" . sanitize_sqlite_like($input['exclude-keyword']) . "%' ESCAPE '\'";
	}
	return empty($conditions) ? '' : 'WHERE ' . implode(' AND ', $conditions);
}







function get_error_log_query($query_vars){
	return <<<SQL
SELECT el.meta_id, el.daytime, el.code, el.error
FROM "error_log" el
{$query_vars['where_clause']}
ORDER BY el.daytime {$query_vars['order']}
{$query_vars['limit']}
SQL;
}

function get_total_query($query_vars){
	return <<<SQL
SELECT COUNT(*) AS total
FROM "error_log" el
{$query_vars['where_clause']};

SQL;
}

function filter_data_with_regex( $data, $input ){

	if( !$input['search-regex'] && !$input['exclude-regex'] ) return $data;

	$filtered_data = [];

	foreach($data['error'] as $row){

		$searched_data = $row['message'].$data['meta'][$row['meta_id']];
		
		$keep = true;

		if ($input['search-keyword'] !=='' && $input['search-regex']){

			$search_pattern = '~' . $input['search-keyword'] . '~';
			
			if (!preg_match($search_pattern, $searched_data)){
			
				$keep = false;
			
			}
		}

		if ($input['exclude-keyword'] !=='' && $input['exclude-regex']){

			$exclude_pattern = '~' . $input['exclude-keyword'] . '~';
			
			if (preg_match($exclude_pattern, $searched_data)){
			
				$keep = false;
			
			}
		}

		if ($keep){
			
			$filtered_data[] = $row;
		
		}
	}

	$total_filtered = count($filtered_data);

	if( $total_filtered === 0 ) return [];

	$per_page = isset($input['per-page']) ? (int) $input['per-page'] : 10;

	$current_page = isset($input['current-page']) ? (int) $input['current-page'] : 0;

	$offset = $current_page * $per_page;

	$paged_data = array_slice($filtered_data, $offset, $per_page);

	$result['total'] = $total_filtered;

	foreach( $paged_data as $key =>$row ){

		$result['error'][] = $row;

		if( isset($paged_data['meta'][(int)$row['meta_id']]) ) continue;
		
		$result['meta'][(int)$row['meta_id']] = $data['meta'][(int)$row['meta_id']]??'qwe';

	}

	return $result;
}

function get_sqlite_query( $query, $db_filename=false ){

	$db_filepath = $db_filename ? dirname(get_db_filepath())."/{$db_filename}" : get_db_filepath();

	if ( !file_exists($db_filepath) ) return false;

	$db = new \SQLite3($db_filepath);

	if (!$db) return false;

	$result = $db->query($query);

	if (!$result) {

		// error_log( is_string($query) ? "WPSD PHP Debug error in query\n".$query : 'Query is not a string');

		return false;
	} 
	
	$data = [];

	while ($row = $result->fetchArray(SQLITE3_ASSOC)){
		$data[] = $row;
	}

	$db->close();

	return $data;
}


/**
 * @return array -
 * - order
 * - limit
 * - where_clause
 */
function get_sqlite_query_vars($input) {

	$search_keyword = sanitize_sqlite_like($input['search-keyword']);

	$exclude_keyword = sanitize_sqlite_like($input['exclude-keyword']);

	$offset = $input['current-page'] * $input['per-page'];

	$conditions = [];

	if (!empty($input['selected-day']) && $input['selected-day'] !== 'all') {
		$conditions[] = "el.daytime LIKE '{$input['selected-day']}%'";
	} 

	if (intval($input['error-type']) !== 0) {
		$conditions[] = "el.code = {$input['error-type']}";
	}

	if ($search_keyword !== '' && !$input['search-regex']) {
		$conditions[] = "el.error LIKE '%$search_keyword%' ESCAPE '\'";
	}

	if ($exclude_keyword !== '' && !$input['exclude-regex']) {
		$conditions[] = "el.error NOT LIKE '%$exclude_keyword%' ESCAPE '\'";
	}

	$limit = ($input['search-regex'] || $input['exclude-regex']) ? '' : "LIMIT {$input['per-page']} OFFSET $offset";

	$where_clause = empty($conditions) ? '' : 'WHERE ' . implode(' AND ', $conditions);

	$order = strtolower($input['order']) === 'asc' ? 'ASC' : 'DESC';

	return [
		'where_clause' => $where_clause,
		'order' => $order,
		'limit' => $limit,
	];
}


function sanitize_sqlite_like($keyword){

	$keyword = str_replace(['\\', '%', '_',"'"], ['\\\\', '\%', '\_',"''"], $keyword);

	return $keyword;
}

function display_data( $data, $input ){
	
	$error_type_strings = get_error_type_strings();
	
	foreach( array_keys( $data['error'] ) as $error_key ){

		$output = get_event_markup( $data, $error_key, $error_type_strings, $input );

		echo $output;
	}
	
}

function get_event_markup( $data, $error_key, $error_type_strings, $input ){
	
	$code = $data['error'][$error_key]['code']??0;

	$message = $data['error'][$error_key]['message']??'';

	$daytime = $data['error'][$error_key]['daytime']??'';

	$meta_id = $data['error'][$error_key]['meta_id']??'';

	$checked = $input['display_meta'];

	switch($code){

		case 99999:
			
			$checked = '';

			$error_display = '';

			$error_message = replace_eol_for_html( htmlentities($message) );
			
			break;
			
		default:

			$error_message = replace_eol_for_html( strip_tags($message) );

			$error_name = $error_type_strings[$code]??'Unknown error';

			$error_display = "Error {$code} - {$error_name}<br><br>";
		
		break;
	}
		
	$meta_display = replace_eol_for_html( htmlentities($data['meta'][$meta_id]) );

	return <<<HTML
<div class="wpsd-container">
	{$error_display}
	{$error_message}
	<input type="checkbox" id="wpsd-toggle{$error_key}" class="wpsd-toggle" {$checked}>
	<label for="wpsd-toggle{$error_key}" class="wpsd-toggle-label">
		meta ID: {$meta_id} <span class="wpsd-arrow">↓</span>
	</label>
	<div id="metadata1" class="wpsd-metadata">
		{$daytime}<br><br>$meta_display
	</div>
</div>
<hr>
HTML;

}

function replace_eol_for_html( $string ){

	return str_replace( "\n",'<br>', $string );
}

function display_pagination_main( $input, $total ){

	$pages = (int)ceil($total/$input['per-page']);

	if( $total <= $input['per-page'] ){

		?><img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18"><?php
		
		return;
	}
	

	the_container_start();

	the_goto_start( $input );

	the_goto_previous( $input );

	the_three_pages_around_current_page($input, $pages, $total);

	the_goto_next( $input, $pages );

	the_goto_end( $input, $pages );

	the_container_end();
}

function the_goto_next($input, $pages){

	$is_clickable = $input['current-page'] < ($pages - 1);

	$class = $is_clickable ? ' active' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] + 1), $is_clickable);

	echo 
	<<<HTML
	<span id="next" class="pagination-button{$class}"
		{$button_hx_markup}
	>></span>
	HTML;

}

function the_three_pages_around_current_page($input, $pages){

	$pages_to_display = $pages === 2 ? 1 : 2;

	for($i = -1; $i < $pages_to_display; ++$i){

		$display_value = get_display_value($input, $i, $pages);
		
		$is_clickable = is_page_clickable($input, $display_value, $pages);

		$class = $is_clickable ? ' active' : ' passive';

		if($display_value === 0) continue;

		$button_hx_markup = $is_clickable ? get_button_hx_markup($input, ($display_value - 1) ) : '';

		echo 
		<<<HTML
		<span class="pagination-page-number{$class}"{$button_hx_markup}>{$display_value}</span>
		HTML;

	}

	$text = esc_html__('of', 'wpsd-php-debug');

	echo sprintf(
		'%s<span class="pagination-of-number">%d</span>',
		$text,
		$pages
	);
	
}


function get_display_value($input, $i, $pages) {

	switch($input['current-page']) {

		case 0:

			$offset = 1;
			break;

		case $pages - 1:
			
			$offset = -1;
			break;
		
		default:
			
			$offset = 0;
			break;
	}

	return $i + $input['current-page'] + $offset + 1;
}


function is_page_clickable($input,$display_value,$pages){

	return $display_value !== $input['current-page']+1;
}

function the_goto_start($input){

	$is_clickable = $input['current-page'] >= 1;

	$class = $is_clickable ? ' active' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, 0, $is_clickable);

	echo 
	<<<HTML
	<span id="start" class="pagination-button{$class}"
		{$button_hx_markup}
	><<</span>
	HTML;
}

function the_goto_end($input, $pages){

	$is_clickable = $input['current-page'] !== ($pages - 1);

	$class = $is_clickable ? ' active' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, $pages - 1, $is_clickable);

	echo 
	<<<HTML
	<span id="end" class="pagination-button{$class}"
		{$button_hx_markup}
	>>></span>
	HTML;

}


function the_goto_previous($input){

	$is_clickable = $input['current-page'] !== 0;

	$class = $is_clickable ? ' active' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] - 1), $is_clickable);

	echo 
	<<<HTML
	<span id="previous" class="pagination-button{$class}" 
		{$button_hx_markup}
	><</span>
	HTML;

}

function get_button_hx_markup($input, $link_to_page, $is_clickable = true){

	if(!$is_clickable) return '';

	$ajax_url = admin_url('/admin-ajax.php?php-debug-search&pagination');

	$nonce = get_wpsd_transient('wpsd-php-debug-nonce');

	$display_meta = $input['display_meta']??0;

	return <<<HTML
	hx-post="{$ajax_url}"
	hx-indicator="#htmx-spinner"
	hx-vals='{
		"selected-day": "{$input['selected-day']}",
		"db-filename": "{$input['db-filename']}",
		"error-type": "{$input['error-type']}",
		"order": "{$input['order']}",
		"search-keyword": "{$input['search-keyword']}",
		"search-regex": "{$input['search-regex']}",
		"exclude-keyword": "{$input['exclude-keyword']}",
		"exclude-regex": "{$input['exclude-regex']}",
		"per-page": "{$input['per-page']}",
		"current-page": "{$link_to_page}",
		"display_meta": "{$display_meta}",
		"nonce": "{$nonce}"
	}' 
	hx-target="#display-data"
HTML;
}



function the_container_start(){
	
	?><div id="pagination"><?php

}

function the_container_end(){
	
	?><img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18"></div><?php

}



function die_wrong_data(){

	http_response_code(422);

	die('Incorrect data');

}


/**
 * Retrieves and sanitizes input data from the $_POST array.
 *
 * @return array -
 * - error-type			=> int - The type of error to filter.
 * - order				=> string - The order of the results (asc/desc).
 * - per-page			=> int - The number of results per page.
 * - selected-day		=> string - The selected day for filtering results.
 * - current-page		=> int - The current page number.
 * - download			=> bool - Whether to download the results.
 * - search-keyword		=> string - The keyword to search for.
 * - search-regex		=> bool - Whether to use regex in search.
 * - exclude-keyword	=> string - The keyword to exclude from the search.
 * - exclude-regex		=> bool - Whether to use regex in exclusion.
 * - delete				=> bool - Whether to delete the selected entries.
 * - db-filename		=> string - The name of the log file to process.
 * - display_meta		=> string - Meta display option ('checked' if selected).
 * - source-error-log	=> bool - Whether to source from the error log.
 * - nonce				=> string - The nonce for security.
 * - timestamp			=> bool|string - The timestamp for filtering. DEPRECATED
 */

//MARK:INPUT
function get_input_from_post(){

	return [
		'error-type'		=> is_numeric($_POST['error-type']??false) ? absint($_POST['error-type']) : 0,

		'order'				=> ($_POST['order']??'desc') === 'desc' ? 'desc' : 'asc',

		'per-page'			=> min(absint($_POST['per-page']??10), 200),

		'selected-day'		=> sanitize_date($_POST['selected-day']??''),

		'current-page'		=> intval($_POST['current-page']??0),

		'download'		=> ($_POST['download']??'') === 'true',

		'search-keyword'	=> $_POST['search-keyword']??'',

		'search-regex'		=> !empty($_POST['search-regex']),
		
		'exclude-keyword'	=> $_POST['exclude-keyword']??'',

		'exclude-regex'		=> !empty($_POST['exclude-regex']),

		'delete'			=> !empty($_POST['delete']),

		'db-filename'		=> ( preg_match('/^[a-z0-9_\-\.]+$/', $_POST['db-filename']??'') ? $_POST['db-filename']??'' : '' ),

		'display_meta' 		=> empty($_POST['display_meta']) ? '' : ' checked',

		'source-error-log'	=> isset($_POST['source-error-log']),

		'record-fragments'	=> !empty($_POST['record-fragments'])
	];
}

function sanitize_date($date){
	
	if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return $date;

	return date('Y-m-d');
	
}

function delete_log_file( $input ){

	$query_vars = get_sqlite_delete_query_vars($input);

	$query_delete_error_log = <<<SQL
DELETE FROM error_log
{$query_vars['where_clause']};
SQL;

	$query_delete_orphaned_metadata = <<<SQL
DELETE FROM error_meta
WHERE meta_id NOT IN (
SELECT DISTINCT meta_id 
FROM error_log
);
SQL;

	$db_filename = empty($input['db-filename']) ? false : $input['db-filename'];

	get_sqlite_query($query_delete_error_log, $db_filename);
	
	get_sqlite_query($query_delete_orphaned_metadata, $db_filename);

	get_sqlite_query( 'VACUUM', $db_filename );

	$message  = esc_html__('Deleted from the log file','wpsd-php-debug');

	the_simple_message($message);
}

function get_sqlite_delete_query_vars($input){

	if(empty($input) || !is_array($input)) return false;

	$error_type = (int) $input['error-type'];

	$selected_day = $input['selected-day'];

	$search_keyword = sanitize_sqlite_like($input['search-keyword']);

	$exclude_keyword = sanitize_sqlite_like($input['exclude-keyword']);

	$conditions = [];

	if (!empty($selected_day)) $conditions[] = "daytime LIKE '$selected_day%'";

	if ($error_type !== 0) $conditions[] = "code = $error_type";

	if (!empty($search_keyword) && !$input['search-regex'] ){
		$conditions[] = "(error LIKE '%$search_keyword%' ESCAPE '\')";
	}

	if (!empty($exclude_keyword) && !$input['exclude-regex'] ){
		$conditions[] = "(error NOT LIKE '%$exclude_keyword%' ESCAPE '\')";
	}

	$where_clause = '';

	if (!empty($conditions)) $where_clause = 'WHERE ' . implode(' AND ', $conditions);

	return [
		'where_clause' => $where_clause
	];
}

function display_no_results(){
	
	$message = esc_html__('No results','wpsd-php-debug');
		
	the_simple_message($message);
	
}

function the_simple_message($message){

	echo <<<HTML
	<div class="form-elements-wrap">
		<span>{$message}</span>
		<img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18">
	</div>
	HTML;

}

function display_record_fragments( $input ){


}