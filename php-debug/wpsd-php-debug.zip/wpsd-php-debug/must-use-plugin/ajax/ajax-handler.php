<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

define( 'WPSD_LOG_DIR', WP_CONTENT_DIR. get_option('wpsd-php-debug-dir') );

$input = get_input_from_post();

require __DIR__.'/display-metadata.php';

if( $input['download'] ) {

	download_error_log_with_metadata($input);

} else {

	display_data_main($input);
}


die;

function get_export_metadata_markup($value){

	if( empty($value['metadata'])) return '';

	$conversion = [
		'e'	=> 'Error code:',

		's'	=> '$_SERVER:',

		'u'	=> 'User name:',

		'c'	=> 'Cookies:',

		'p'	=> '$_POST:',

		't'	=> 'Timestamp:'

	];

	$output = '';

	foreach( $value['metadata'] as $key => $value){
			
		if( $key==='e' ) $value = " $value - ".get_php_error_code_text($value);

		if( $key==='t' ) $value = date('d-M-Y H:i:s', intval($value)) . ' UTC -> '.$value; 

		$output .= "\n".($conversion[$key]??$key);
		
		$output .= get_export_value($value);

	}

	return $output;
}

function get_export_value($value_to_display){

	if( is_echo_safe( $value_to_display ) ) return " $value_to_display\n";

	$output = "\n";

	foreach( $value_to_display as $key => $value){

		$value_safe = is_echo_safe( $value )  ? $value : var_export( $value, true );

		$output .= "     $key => $value_safe\n";
	}

	return $output;
}

function is_echo_safe($value){

	return  is_string( $value ) || is_numeric( $value );
}

function serialize_output($output) {
    return json_encode(json_encode($output), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
}


function get_error_type_filename_suffix($input){

	if( $input['error-type']===0 ) return 'all-error';

	$error_type_text = get_php_error_code_text($input['error-type']);

	$pieces  = explode(' ',ltrim($error_type_text,'E_'));

	return str_replace('_','-',strtolower($pieces[0]??''));

}

function download_error_log_with_metadata($input) {

	$error_type_suffix = get_error_type_filename_suffix($input); 

	$filename = str_replace( 'error',$error_type_suffix, $input['log-file']);

	$data = get_input_match_data( $input );
	
	$output = '';

	foreach( $data as $value){
	
		if( $output !== '' ) $output .= "\n\n";

		$output .= trim($value['log'])."\n";

		$output .= get_export_metadata_markup($value);

	}
	$output = serialize_output($output);
		?>
  <script data-cfasync="false">
   
(function() {
    const filename = '<?=$filename?>';
    const content = <?=$output?>;

    function downloadEmbeddedContent(filename, content) {
        const decodedContent = JSON.parse(content);

        const blob = new Blob([decodedContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);

        const downloadLink = document.createElement('a');
        downloadLink.href = url;
        downloadLink.download = filename;

        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        window.URL.revokeObjectURL(url);
    }

    downloadEmbeddedContent(filename, content);
})();
</script>
</div>
	<?php
	die;
}


function display_data_main( $input ){
	
	$data = get_input_match_data( $input );


	if( empty($data) ) {
		
		echo '<p>'.esc_html__('No results','wpsd-php-debug').'</p>';

		return;
	}

	$total = count($data);

	$pages = (int)ceil($total/$input['per-page']);

	display_pagination_main( $input, $total, $pages );

	$offset = $input['current-page']*$input['per-page'];

	$data_slice = array_slice($data, $offset, $input['per-page']);

	display_slice( $data_slice, $input);
	
}

function get_error_log_filepath( $input ){

	if( str_contains( $input['log-file'], 'current') ) return ini_get('error_log');

	return WPSD_LOG_DIR."/{$input['log-file']}";
}

function load_metadata_to_array( $error_log_filepath ){

	$metadata_filepath = get_metadata_log_filepath( $error_log_filepath );

	if( !(file_exists($metadata_filepath) && is_readable($metadata_filepath)) ) return [];

	$meta_stream = fopen( $metadata_filepath, "r");

	$key = 0;

	$result = [];

	while( !feof($meta_stream) ) {
	
		$line = fgets($meta_stream);
		
		if( empty($line) ) continue;

		if( is_numeric($line[0]) ){

			$key = intval($line);
			
		} else {

			$result[$key] = json_decode($line, true);
		}

	}

	return $result;
}

function get_input_match_data( $input ){

	$error_log_filepath = get_error_log_filepath( $input );
	
	$metadata = load_metadata_to_array( $error_log_filepath );

	$error_stream = fopen( $error_log_filepath, "r");

	[ $result, $current_error, $position ]= [ [],'',null ];

	while( !feof($error_stream) ) {
	
		$line = fgets($error_stream);
		
		if( ($line[0]??'') === '[' || $line===false) {

			if( $current_error !=='' ){

				// echo "<br>position: $position<br>";
				// echo isset( $metadata[$position] ) ? 'true' : 'false';
				// echo '<br>';

				// $metadata_key = in_array( $position, array_keys() ) || in_array( $position-2, array_keys() )

				// echo "<br>position: $position - $offset_position <br>";

				$error_metadata = isset($metadata[$position]) ? $metadata[$position] : ''; //['s'=>['no'=>'data']]

				$error=['log'=>$current_error,'metadata'=>$error_metadata];
				
				if( is_input_matched_data( $error, $input ) ) $result[]= $error;
				
				$position = ftell($error_stream);
			}
			$current_error = $line;
			
			// echo ftell($error_stream);
			// echo " yes<br>";

		} else {
			// echo "no<br>";
		// 	$result[] = [
		// 		'log' => $current_error,
        //         'metadata' => [$metadata[$position]??'']
		// 	];

		// 	echo "position: $position <br";
			
			// echo $current_error;
			
			$current_error .= $line;

			$position = ftell($error_stream);
		}


//$result[]=['log'=>$line,'metadata'=>''];
		// if( empty($line) ) continue;

		// if( is_numeric($line[0]) ){

		// 	$end = intval($line)-1;
			
		// } else {

		// 	$error['log'] = get_piece_of_file($error_stream, $start, $end );
			
		// 	$error['metadata'] =  json_decode($line, true);	

		// 	if( is_input_matched_data( $error, $input ) ) $result[]= $error;

		// 	$start = ++$end;
		// }

	}

	// vd($result??'no results');
	
	// add_latest_user_error_log_without_metadata( $result, $error_stream, $error_log_filepath, $end, $input );

	fclose($error_stream);

	if( $input['order'] === 'desc') rsort($result);

	return $result;
}

/**
 * error_log() doesn't have stored metadata. If last record was error_log() then it wouldn't be taken into account.
 * this function will add it to the result if it matches input criteria
*/

function add_latest_user_error_log_without_metadata( &$result, $error_stream, $error_log_filepath, $end, $input ){

	$error_filesize = filesize($error_log_filepath);
	
	if( $end === $error_filesize ) return;
		
	$error = [ 'log' => get_piece_of_file( $error_stream, $end, $error_filesize ), 'metadata' => ''];

	if( is_input_matched_data( $error, $input ) ) $result[]= $error;
		
}

function is_input_matched_data( $error, $input ){

	if( !is_match_by_type( $error, $input ) ) return false;

	if( $input['exclude-keyword'] === '' ) return contains_any_array_value( $error, $input['search-keyword'] );

	return
	
		contains_any_array_value( $error, $input['search-keyword'] ) &&
		
		!contains_any_array_value( $error, $input['exclude-keyword'] );
	
}

function is_search_match_active($input){
	
	return  $input['search-keyword'] !=='' || $input['exclude-keyword'] !=='';
}

function contains_any_array_value( $data, $keyword ){
	
	if( $keyword ==='' ) return true;

	if( is_array( $data ) || is_object( $data ) ) {

		foreach( $data as $value ){
			
			if( contains_any_array_value( $value, $keyword ) ) return true;

		}

	} else {
		
		if( has_match_by_input( $data, $keyword ) ) return true;
	
	}

    return false;
}


function has_match_by_input( $data, $keyword ){

	if( $keyword === '' ) return false;

	if( is_preg_search($keyword) ) return str_contains_preg(  $data,  $keyword );

	return str_contains( mb_strtolower( $data ), mb_strtolower( $keyword ) );
}



function is_preg_search( $keyword ){

	return str_contains( $keyword, '|' );
}

function str_contains_preg($haystack, $needle) {

    return (bool)preg_match( "/{$needle}/" ,$haystack);
}

function is_match_by_type( $error, $input ){

	if( $input['error-type'] === 0 ) return true;

	return ($error['metadata']['e']??false) === $input['error-type'];
}

function display_slice( $data_slice ){
	
	
	foreach($data_slice as $event_data ){
		
		$display_value = str_replace( "\n",'<br>', esc_html($event_data['log'] ));

		echo 
		<<<HTML
		<p>$display_value</p>		
		HTML;
		
		display_queried_metadata( $event_data['metadata']??'' );
		

		echo 
		<<<HTML
		<hr>
		HTML;
	}

}

function the_load_metadata_button($timestamp,$input,$key){
	
	$html_id = "load-button-id-$key";

	$ajax_url = admin_url('/admin-ajax.php?php-debug-search');

	?><br><br>
<button id="<?=$html_id?>" class="btn btn-primary"

	hx-post="<?php echo $ajax_url; ?>"
	hx-swap="outerHTML"
	hx-vals='{"action":"php-debug-search-metadata","timestamp":"<?=$timestamp?>","log-file":"<?=$input['log-file']?>","nonce":"<?=$input['nonce']?>"}' 
	hx-target="#<?=$html_id?>"

>Load metadata</button>
	<?php
}

function display_pagination_main( $input, $total, $pages){

	if( $total <= $input['per-page'] ) return;

	the_container_start();

	the_goto_start( $input );

	the_goto_previous( $input );

	the_three_pages_around_current_page($input, $pages, $total);

	the_goto_next( $input, $pages );

	the_goto_end( $input, $pages );

	the_container_end();
}

function the_goto_next($input, $pages){

	$is_clickable = $input['current-page'] < ($pages - 1);

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] + 1), $is_clickable);

	echo <<<HTML
<span id="next" class="pagination-button{$class}"
	{$button_hx_markup}
>></span>
HTML;
}

function the_three_pages_around_current_page($input, $pages){

	$pages_to_display = $pages === 2 ? 1 : 2;

	for($i = -1; $i < $pages_to_display; ++$i){

		$display_value = get_display_value($input, $i, $pages);
		
		$is_clickable = is_page_clickable($input, $display_value, $pages);

		$class = $is_clickable ? '' : ' passive';

		if($display_value === 0) continue;

		$button_hx_markup = $is_clickable ? get_button_hx_markup($input, $display_value - 1) : '';

		echo <<<HTML
<span class="pagination-page-number{$class}"{$button_hx_markup}>{$display_value}</span>
HTML;
	}

	if($is_clickable){

		$text = esc_html__('of', 'wpsd-php-debug');
		
		echo <<<HTML
		$text<span class="pagination-of-number">$pages</span>
		HTML;
	}
}


function get_display_value($input, $i, $pages) {

    switch(true) {
        case ($input['current-page'] === 0):
            $offset = 1;
		break;

        case ($input['current-page'] === $pages - 1):
            $offset = -1;
		break;
		
		default:
			$offset = 0;
		break;
    }

    return $i + $input['current-page'] + $offset + 1;
}


function is_page_clickable($input,$display_value,$pages){

	return $display_value !== $input['current-page']+1;
}

function the_goto_start($input){

	$is_clickable = $input['current-page'] >= 1;

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, 0, $is_clickable);

	echo <<<HTML
<span id="start" class="pagination-button{$class}"
	{$button_hx_markup}
><<</span>
HTML;
}

function the_goto_end($input, $pages){

	$is_clickable = $input['current-page'] !== ($pages - 1);

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, $pages - 1, $is_clickable);

	echo <<<HTML
<span id="end" class="pagination-button{$class}"
	{$button_hx_markup}
>>></span>
HTML;
}


function the_goto_previous($input){

	$is_clickable = $input['current-page'] !== 0;

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] - 1), $is_clickable);

	echo <<<HTML
<span id="previous" class="pagination-button{$class}" 
	{$button_hx_markup}
><</span>
HTML;
}

function get_button_hx_markup($input, $link_to_page, $is_clickable = true){

	if(!$is_clickable) return '';

	$ajax_url = admin_url('/admin-ajax.php?php-debug-search');

	return <<<HTML
	hx-post="{$ajax_url}"
	hx-vals='{
		"error-type": "{$input['error-type']}",
		"order": "{$input['order']}",
		"per-page": {$input['per-page']},
		"current-page": {$link_to_page},
		"log-file": "{$input['log-file']}",
		"nonce": "{$input['nonce']}"
	}' 
	hx-target="#display-data"
HTML;
}



function the_container_start(){
	echo 
<<<HTML
<div id="pagination">
HTML;

}

function the_container_end(){
	echo 
<<<HTML
</div>
HTML;

}

function get_piece_of_file($handle, $start, $end ){

	if( ($end - $start) < 1 ) return '';

	fseek($handle, $start );
	
	return fread( $handle, $end - $start );

}


function die_wrong_data(){

	http_response_code(422);

	die('Incorrect data');

}


/**
* @return array -
* - type =>  'fatal'/'warning'/'all'
* - order => asc/desc
* - per-page => number
* - log-file => string
*/

function get_input_from_post(){

	return [
		'error-type' => is_numeric($_POST['error-type']??false) ? absint($_POST['error-type']) : 0,

		'order' => ($_POST['order']??'desc') === 'desc' ? 'desc' : 'asc',

		'per-page' => min(absint($_POST['per-page']??10), 200),

		'log-file' => !empty($_POST['log-file']) && !str_contains($_POST['log-file'], '..') ? sanitize_text_field($_POST['log-file']) : die_wrong_data(),

		'current-page' => intval($_POST['current-page']??0),

		'timestamp' => is_numeric($_POST['timestamp']??'') ? $_POST['timestamp'] : false,

		'download' => ($_POST['download']??'') === 'true',

		'search-keyword' => $_POST['search-keyword']??'',

		'exclude-keyword' => $_POST['exclude-keyword']??'',

		'nonce' => get_transient('wpsd-php-debug-nonce')
	];
}



die('END');