<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

define( 'WPSD_LOG_DIR', WP_CONTENT_DIR. get_option('wpsd-php-debug-dir') );

$input = get_input_from_post();

switch(true){

	case $input['download']:

		download_error_log_with_metadata($input);
		break;

	case $input['delete']:

		delete_log_file( $input );
        break;

	default:

		display_data_main($input);
		break;

}

die;

function display_data_main( $input ){

	$data = get_input_match_data( $input );
	
	if( empty($data) ) {
		
		echo '<p>'.esc_html__('No results','wpsd-php-debug').'</p>';

		return;
	}

	$total = $data[0]['total'];

	$pages = (int)ceil($total/$input['per-page']);

	display_pagination_main( $input, $total, $pages );

	display_data( $data );
	
}

function get_export_metadata_markup($value){

	if( empty($value['metadata'])) return '';

	$conversion = [
		'e' => esc_html__('Error code:', 'wpsd-php-debug'),
		's' => esc_html__('$_SERVER:', 'wpsd-php-debug'),
		'u' => esc_html__('User name:', 'wpsd-php-debug'),
		'c' => esc_html__('Cookies:', 'wpsd-php-debug'),
		'p' => esc_html__('$_POST:', 'wpsd-php-debug'),
		't' => esc_html__('Timestamp:', 'wpsd-php-debug')
	];

	$output = '';

	foreach( $value['metadata'] as $key => $value){
			
		if( $key==='e' ) $value = " $value - ".get_php_error_code_text($value);

		if( $key==='t' ) $value = date('d-M-Y H:i:s', intval($value)) . ' UTC -> '.$value; 

		$output .= "\n".($conversion[$key]??$key);
		
		$output .= get_export_value($value);

	}

	return $output;
}

function get_export_value($value_to_display){

	if( is_echo_safe( $value_to_display ) ) return " $value_to_display\n";

	$output = "\n";

	foreach( $value_to_display as $key => $value){

		$value_safe = is_echo_safe( $value )  ? $value : var_export( $value, true );

		$output .= "     $key => $value_safe\n";
	}

	return $output;
}

function is_echo_safe($value){

	return  is_string( $value ) || is_numeric( $value );
}

// function serialize_output($output) {
//     return json_encode(json_encode($output));
// }


function get_error_type_filename_suffix($input){

	if( $input['error-type']===0 ) return 'all-error';

	$error_type_text = get_php_error_code_text($input['error-type']);

	$pieces  = explode(' ',ltrim($error_type_text,'E_'));

	return str_replace('_','-',strtolower($pieces[0]??''));

}

//MARK:Download
function download_error_log_with_metadata($input) {

	$error_type_suffix = get_error_type_filename_suffix($input);

	$hour = date('H-i-s');
	
	$filename = "{$input['selected-day']}-at-{$hour}-{$error_type_suffix}.log";

	$data = get_input_match_data( $input );
	
	$error_type_strings = get_error_type_strings();

	$output_string = '';

	foreach( $data as $event_data){

		if( $output_string !== '' ) $output_string .= "\n\n";

		$output_string .= "{$event_data['daytime']}\n";

		// $output .= get_export_metadata_markup($value);
		
		$error_name = $error_type_strings[$event_data['code']]??'Unknown error';

		$output_string .= "Error {$event_data['code']} - {$error_name}\n";
		
		$output_string .= "{$event_data['error']}\n";
		$output_string .= "{$event_data['meta']}\n";

		// $error_display = replace_eol_for_html( $event_data['error'] );
		
		// $meta_display = replace_eol_for_html( $event_data['meta'] );
		// $event_data['daytime']

	}

	$output = json_encode(json_encode($output_string));

	echo <<<HTML
	<script data-cfasync="false">
	(function() {
		const filename = '{$filename}';
		const content = {$output};
	
		function downloadEmbeddedContent(filename, content) {
			const decodedContent = JSON.parse(content);
	
			const blob = new Blob([decodedContent], { type: 'text/plain' });
			const url = window.URL.createObjectURL(blob);
	
			const downloadLink = document.createElement('a');
			downloadLink.href = url;
			downloadLink.download = filename;
	
			document.body.appendChild(downloadLink);
			downloadLink.click();
			document.body.removeChild(downloadLink);
			window.URL.revokeObjectURL(url);
		}
	
		downloadEmbeddedContent(filename, content);
	})();
	</script>
	HTML;
	
	die;
}

function get_input_match_data( $input ){

	$input_match_data_query = get_retrieve_sqlite_query( $input );

	// vd($input_match_data_query);die;

	$data = get_sqlite_query( $input_match_data_query );
	
	return filter_data_with_regex( $data, $input );
}

function filter_data_with_regex( $data, $input ){

	if( !$input['search-regex'] && !$input['exclude-regex'] ) return $data;

	$filtered_data = [];

	foreach ($data as $row){

		$keep = true;

		if ($input['search-keyword'] !=='' && $input['search-regex']){

			$search_pattern = '~' . $input['search-keyword'] . '~';
			
			if (!preg_match($search_pattern, $row['error']) && !preg_match($search_pattern, $row['meta'])){
			
				$keep = false;
			
			}
		}

		if ($input['exclude-keyword'] !=='' && $input['exclude-regex']){

			$exclude_pattern = '~' . $input['exclude-keyword'] . '~';
			
			if (preg_match($exclude_pattern, $row['error']) || preg_match($exclude_pattern, $row['meta'])){
			
				$keep = false;
			
			}
		}

		if ($keep){
			
			$filtered_data[] = $row;
		
		}
	}

	$total_filtered = count($filtered_data);

	$per_page = isset($input['per-page']) ? (int) $input['per-page'] : 10;

	$current_page = isset($input['current-page']) ? (int) $input['current-page'] : 0;

	$offset = $current_page * $per_page;

	$paged_data = array_slice($filtered_data, $offset, $per_page);

	if (!empty($paged_data)){

		$paged_data[0]['total'] = $total_filtered;
	
	}

	return $paged_data;
}




function get_sqlite_query( $query ){

	$db_filepath = get_db_filepath();

	if (!file_exists($db_filepath) ) return false;

	$db = new \SQLite3($db_filepath);

	if (!$db) return false;

	$result = $db->query($query);

	if (!$result) return false;

	$data = [];

	while ($row = $result->fetchArray(SQLITE3_ASSOC)){
		$data[] = $row;
	}

	$db->close();

	return $data;
}

function get_retrieve_sqlite_query($input){

	$query_vars = get_sqlite_query_vars($input);

	if($query_vars === false) return false;

	$query = <<<SQL
WITH total_count AS (
    SELECT COUNT(*) AS total
    FROM error_log el
    JOIN error_meta em ON el.meta_id = em.meta_id
    {$query_vars['where_clause']}
)
SELECT el.daytime, el.code, el.error, em.meta, tc.total
FROM error_log el
JOIN error_meta em ON el.meta_id = em.meta_id
JOIN total_count tc
{$query_vars['where_clause']}
ORDER BY el.daytime {$query_vars['order']}
{$query_vars['limit']}
SQL;

	return $query;
}

/**
 * @return array -
 * - order
 * - limit
 * - where_clause
 */

function get_sqlite_query_vars($input){

	$search_keyword = sanitize_sqlite_like($input['search-keyword']);

	$exclude_keyword = sanitize_sqlite_like($input['exclude-keyword']);

	$offset = $input['current-page'] * $input['per-page'];

	$conditions = [];

	if (!empty($input['selected-day']) && $input['selected-day'] !== 'all') {

		$conditions[] = "el.daytime LIKE '{$input['selected-day']}%'";
	} 

	if ( intval($input['error-type']) !== 0) {
	
		$conditions[] = "el.code = {$input['error-type']}";
	}

	if ( $search_keyword !=='' && !$input['search-regex'] ){
		$conditions[] = "(el.error LIKE '%$search_keyword%' ESCAPE '\' OR em.meta LIKE '%$search_keyword%' ESCAPE '\')";
	}

	if ( $exclude_keyword !=='' && !$input['exclude-regex'] ){
		$conditions[] = "(el.error NOT LIKE '%$exclude_keyword%' ESCAPE '\' AND em.meta NOT LIKE '%$exclude_keyword%' ESCAPE '\')";
	}

	$limit = ($input['search-regex'] || $input['exclude-regex']) ? '' : "LIMIT {$input['per-page']} OFFSET $offset";

	$where_clause = empty($conditions) ? '': 'WHERE ' . implode(' AND ', $conditions);

	$order = strtolower($input['order']) === 'asc' ? 'ASC' : 'DESC';

	return [
		'order' => $order,
		'limit' => $limit,
		'where_clause' => $where_clause
	];
}

function sanitize_sqlite_like($keyword){

	$keyword = str_replace(['\\', '%', '_'], ['\\\\', '\%', '\_'], $keyword);

	return $keyword;
}

function display_data( $data_slice ){
	
	$error_type_strings = get_error_type_strings();
	
	foreach($data_slice as $key => $event_data ){

		$output = get_event_markup( $event_data, $key, $error_type_strings );

		echo $output;
	}

}

function get_event_markup( $event_data, $key, $error_type_strings ){

	
	switch($event_data['code']??0){

		case 99999:
			
			$checked = '';

			$error_display = '';

			break;
			
		default:

			$error_name = $error_type_strings[$event_data['code']]??'Unknown error';

			$error_display = "Error {$event_data['code']} - {$error_name}<br><br>";
		
			$checked = 'checked';

		break;
	}

	$error_display = replace_eol_for_html( $event_data['error'] );
		
	$meta_display = replace_eol_for_html( $event_data['meta'] );
	
	

	return <<<HTML
<div class="wpsd-container">
{$error_display}
	<input type="checkbox" id="wpsd-toggle{$key}" class="wpsd-toggle" {$checked}>
	<label for="wpsd-toggle{$key}" class="wpsd-toggle-label">
		<span class="wpsd-arrow">▼</span>
	</label>
	<div id="metadata1" class="wpsd-metadata">
		<p>{$event_data['daytime']}<br><br>$meta_display</p>
	</div>
</div>
<hr>
HTML;

	// return $output;
}

function replace_eol_for_html( $string ){

	return str_replace( "\n",'<br>', $string );
}

function display_pagination_main( $input, $total, $pages){

	if( $total <= $input['per-page'] ) return;

	the_container_start();

	the_goto_start( $input );

	the_goto_previous( $input );

	the_three_pages_around_current_page($input, $pages, $total);

	the_goto_next( $input, $pages );

	the_goto_end( $input, $pages );

	the_container_end();
}

function the_goto_next($input, $pages){

	$is_clickable = $input['current-page'] < ($pages - 1);

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] + 1), $is_clickable);

	echo 
	<<<HTML
	<span id="next" class="pagination-button{$class}"
		{$button_hx_markup}
	>></span>
	HTML;

}

function the_three_pages_around_current_page($input, $pages){

	$pages_to_display = $pages === 2 ? 1 : 2;

	for($i = -1; $i < $pages_to_display; ++$i){

		$display_value = get_display_value($input, $i, $pages);
		
		$is_clickable = is_page_clickable($input, $display_value, $pages);

		$class = $is_clickable ? '' : ' passive';

		if($display_value === 0) continue;

		$button_hx_markup = $is_clickable ? get_button_hx_markup($input, ($display_value - 1) ) : '';

		echo 
		<<<HTML
		<span class="pagination-page-number{$class}"{$button_hx_markup}>{$display_value}</span>
		HTML;

	}

	if($is_clickable){

		$text = esc_html__('of', 'wpsd-php-debug');
		
		echo 
		<<<HTML
		$text<span class="pagination-of-number">$pages</span>
		HTML;
	}
}


function get_display_value($input, $i, $pages) {

    switch($input['current-page']) {

        case 0:

            $offset = 1;
			break;

        case $pages - 1:
            
			$offset = -1;
			break;
		
		default:
			
			$offset = 0;
			break;
    }

    return $i + $input['current-page'] + $offset + 1;
}


function is_page_clickable($input,$display_value,$pages){

	return $display_value !== $input['current-page']+1;
}

function the_goto_start($input){

	$is_clickable = $input['current-page'] >= 1;

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, 0, $is_clickable);

	echo 
	<<<HTML
	<span id="start" class="pagination-button{$class}"
		{$button_hx_markup}
	><<</span>
	HTML;
}

function the_goto_end($input, $pages){

	$is_clickable = $input['current-page'] !== ($pages - 1);

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, $pages - 1, $is_clickable);

	echo 
	<<<HTML
	<span id="end" class="pagination-button{$class}"
		{$button_hx_markup}
	>>></span>
	HTML;

}


function the_goto_previous($input){

	$is_clickable = $input['current-page'] !== 0;

	$class = $is_clickable ? '' : ' passive';

	$button_hx_markup = get_button_hx_markup($input, max(0, $input["current-page"] - 1), $is_clickable);

	echo 
	<<<HTML
	<span id="previous" class="pagination-button{$class}" 
		{$button_hx_markup}
	><</span>
	HTML;

}
//qwe
function get_button_hx_markup($input, $link_to_page, $is_clickable = true){

	if(!$is_clickable) return '';

	$ajax_url = admin_url('/admin-ajax.php?php-debug-search&pagination');

	return <<<HTML
	hx-post="{$ajax_url}"
	hx-vals='{
		"error-type": "{$input['error-type']}",
		"order": "{$input['order']}",
		"search-keyword": "{$input['search-keyword']}",
		"search-regex": "{$input['search-regex']}",
		"exclude-keyword": "{$input['exclude-keyword']}",
		"exclude-regex": "{$input['exclude-regex']}",
		"per-page": "{$input['per-page']}",
		"current-page": "{$link_to_page}",
		"nonce": "{$input['nonce']}"
	}' 
	hx-target="#display-data"
HTML;
}



function the_container_start(){
	
	?><div id="pagination"><?php

}

function the_container_end(){
	
	?></div><?php

}



function die_wrong_data(){

	http_response_code(422);

	die('Incorrect data');

}


/**
 * Retrieves and validates input data from the POST request.
 *
 * @return array - 
 * - 'error-type' => int - The type of error to filter.
 * - 'order' => string - The order of the results (asc/desc).
 * - 'per-page' => int - The number of results per page.
 * - '' => string - The name of the log file to process.
 * - 'current-page' => int - The current page number.
 * - 'timestamp' => bool|string - The timestamp for filtering. DEPRECATED
 * - 'download' => bool - Whether to download the results.
 * - 'earch-keyword' => string - The keyword to search for.
 * - 'exclude-keyword' => string - The keyword to exclude from the search.
 * - 'nonce' => string - The nonce for security.
 *
 */

function get_input_from_post(){

	return [
		'error-type' => is_numeric($_POST['error-type']??false) ? absint($_POST['error-type']) : 0,

		'order' => ($_POST['order']??'desc') === 'desc' ? 'desc' : 'asc',

		'per-page' => min(absint($_POST['per-page']??10), 200),

		'selected-day' => sanitize_date($_POST['selected-day']??''),

		'current-page' => intval($_POST['current-page']??0),

		'download' => ($_POST['download']??'') === 'true',

		'search-keyword' => $_POST['search-keyword']??'',

		'search-regex' => !empty($_POST['search-regex']),
		
		'exclude-keyword' => $_POST['exclude-keyword']??'',

		'exclude-regex' => !empty($_POST['exclude-regex']),

		'delete'		=> !empty($_POST['delete']),

		'nonce' => get_transient('wpsd-php-debug-nonce')
	];
}

function sanitize_date($date){
    
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return $date;

    return date('Y-m-d');
	
}

function delete_log_file( $input ){

	$query_vars = get_sqlite_delete_query_vars($input);

	$query_delete_error_log = <<<SQL
DELETE FROM error_log
{$query_vars['where_clause']};
SQL;

	$query_delete_orphaned_metadata = <<<SQL
	DELETE FROM error_meta
WHERE meta_id NOT IN (
	SELECT DISTINCT meta_id 
	FROM error_log
);
SQL;

	get_sqlite_query($query_delete_error_log);
	
	get_sqlite_query($query_delete_orphaned_metadata);

	get_sqlite_query('VACUUM');

	esc_html_e('Deleted from log file');

	return;
	
}

function get_sqlite_delete_query_vars($input){

	if(empty($input) || !is_array($input)) return false;

	$error_type = (int) $input['error-type'];

	$selected_day = $input['selected-day'];

	$search_keyword = sanitize_sqlite_like($input['search-keyword']);

	$exclude_keyword = sanitize_sqlite_like($input['exclude-keyword']);

	$conditions = [];

	if (!empty($selected_day)) $conditions[] = "daytime LIKE '$selected_day%'";

	if ($error_type !== 0) $conditions[] = "code = $error_type";

	if (!empty($search_keyword) && !$input['search-regex'] ){
		$conditions[] = "(error LIKE '%$search_keyword%' ESCAPE '\')";
	}

	if (!empty($exclude_keyword) && !$input['exclude-regex'] ){
		$conditions[] = "(error NOT LIKE '%$exclude_keyword%' ESCAPE '\')";
	}

	$where_clause = '';

	if (!empty($conditions)) $where_clause = 'WHERE ' . implode(' AND ', $conditions);

	return [
		'where_clause' => $where_clause
	];
}
