<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

function display_queried_metadata( $data ){

    if( $data === '' ) return;
    
	?>
	<table class="metadata-table">
		<?php
		
		foreach( $data as $key => $value ){
							
			$value_to_display = get_value_display_markup($value);

			display_metadata_value($key,$value_to_display);
			
		}
	
	?></table>
	<?php

}

function display_metadata_value($key,$value_to_display){
	
	if( $key==='e' ) $value_to_display = $value_to_display . ' - '.get_php_error_code_text($value_to_display);

    if( $key==='t' ) $value_to_display = date('d-M-Y H:i:s',intval($value_to_display)) . ' UTC -> '.$value_to_display; 

	$conversion = [
		'e'	=> esc_html__( 'Error code', 'wpsd-php-debug' ),

		's'	=> esc_html__( '$_SERVER', 'wpsd-php-debug' ),

		'u'	=> esc_html__( 'User name', 'wpsd-php-debug' ),

		'c'	=> esc_html__( 'Cookies', 'wpsd-php-debug' ),

		'p'	=> esc_html__( '$_POST', 'wpsd-php-debug' ),
        
        't' => esc_html__('Timestamp' , 'wpsd-php-debug' )

	];

	?>
	<tr class="metadata-row">
		<td class="metadata-key"><?=$conversion[$key]??$key?></td>
		<td class="metadata-value"><?=$value_to_display?></td>
	</tr>
<?php
}

function get_value_display_markup($value){

	$value_to_display = get_value_unserialized_or_json_decode($value);

	return ( is_array($value_to_display) || is_object($value_to_display) ) ? get_iterable_as_display_markup($value_to_display) : $value_to_display;

}

function get_iterable_as_display_markup($data){

	if( is_array($data) && empty($data) ) return '[ ]';

	if( is_object($data) && empty($data) ) return '[ ]';

	$result_loop = get_iterable_as_display_markup_loop($data);

	if($result_loop === '') return htmlentities( var_export($data,true) ); 

    $result = <<<HTML
    <table class="iterable-table">
        <tbody>
            {$result_loop}
    </tbody>
    </table>
    HTML;

    return trim($result);
}

function get_iterable_as_display_markup_loop($data){

	$result = '';

    foreach( $data as $key=> $value ){

        $key_display = htmlentities($key);

        $value_display =  get_value_display( $value );

        $result .= <<<HTML
        <tr>
            <td class="iterable-key words-unbreakable">     $key_display</td>
            <td class="iterable-arrow words-unbreakable">=></td>
            <td class="iterable-value">$value_display</td>
        </tr>
        HTML;
    }

	return $result;
	//if not iteration been made, var_export the data
	// return $result === '' ? htmlentities( var_export($data,true) ) : $result; 

}

function get_value_display( $value ){
	
	if( is_bool($value) ) return $value ? 'bool:true':'bool:false';

	if( $value === null ) return 'NULL';

	if( is_numeric($value) || is_string($value) ) return htmlentities($value);

    return get_iterable_as_display_markup( $value );
}

// function get_value_string($value_array){
	
// 	if ( !is_array($value_array) ) return $value_array;

// 	$result = '';

// 	foreach( $value_array as $key => $value ){

// 		$value_to_display = get_value_unserialized_or_json_decode($value);

// 		$key_markup = is_int($key) ? $key : '"'.$key.'"';

// 		$result .= "$key => ".get_value_based_on_type($value_to_display).PHP_EOL;
// 	}

// 	return $result;
// }

function get_value_based_on_type($value_to_display){

	if ( is_string($value_to_display) || is_numeric($value_to_display) ) return $value_to_display;
	
	if( is_bool($value_to_display) ) return $value_to_display ? 'bool:true' : 'bool:false';

	return var_export($value_to_display,true);
}

function get_value_unserialized_or_json_decode($value){

	if( !is_string($value) ) return $value;

	$result = get_unserialized_value($value);

	if ($result !== null ) return $result;

	$result = get_json_decode_value($value);

	if ($result !== null ) return $result;

	return $value;
}

function get_unserialized_value($value){

	if ( ($value[1]??'') !==':') return null;

	$unserialized_value = @unserialize($value);

	return is_invalid_unserialization( $value, $unserialized_value) ? null: $unserialized_value;
}

function is_invalid_unserialization( $value, $unserialized_value){

	if( $unserialized_value === $value ) return true;

	return $value !=="b:0;" && $unserialized_value === false;
}



function get_json_decode_value($value){
	
	$value_without_spaces = trim($value);
	
	if ( $value_without_spaces ==='' || !isset($value_without_spaces[0]) ) return '';

	$json_starting_characters=['"','{','['];

	if ( !in_array($value_without_spaces[0],$json_starting_characters) ) return null;
	
	return json_decode($value_without_spaces,true);
}

function get_php_error_code_text($code){

    switch( $code ) {
        case 1:
            return 'E_FATAL_ERROR - Fatal run-time errors';
        case 2:
            return 'E_WARNING - Run-time warnings (non-fatal errors)';
        case 4:
            return 'E_PARSE - Compile-time parse errors';
        case 8:
            return 'E_NOTICE - Run-time notices';
        case 16:
            return "E_CORE_ERROR - Fatal errors that occur during PHP's initial startup";
        case 32:
            return "E_CORE_WARNING - Warnings (non-fatal errors) that occur during PHP's initial startup";
        case 64:
            return 'E_COMPILE_ERROR - Fatal compile-time errors';
        case 128:
            return 'E_COMPILE_WARNING - Compile-time warnings (non-fatal errors)';
        case 256:
            return 'E_USER_ERROR - User-generated error message';
        case 512:
            return 'E_USER_WARNING - User-generated warning message';
        case 1024:
            return 'E_USER_NOTICE - User-generated notice message';
        case 2048:
            return 'E_STRICT';
        case 4096:
            return 'E_RECOVERABLE_ERROR - Catchable fatal error';
        case 8192:
            return 'E_DEPRECATED';
        case 16384:
            return 'E_USER_DEPRECATED';
        default:
            return 'Other';
    }
}
