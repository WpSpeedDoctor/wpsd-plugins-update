<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$php_execution_time = ini_get('max_execution_time');

$timeout = min( $php_execution_time - 5, 58 ); //58 seconds timeout

define('TIMEOUT_TIMESTAMP', intval(WP_START_TIMESTAMP) + $timeout);

function display_source_error_log($input){
	
	if(  get_wpsd_option( 'wpsd-ini-status') === '1' ){

		$input['log-filepath'] = WP_CONTENT_DIR.get_log_dir_string().$input['db-filename'];

	} else {
		
		$input['log-filepath'] =  ini_get('error_log');
	}

    if( !is_file( $input['log-filepath'] ) ){

        echo __('Error log file not found', 'wpsd-php-debug');

        return;
    }

    $errors = $input['order'] === 'desc'
        ? get_errors_desc($input)
        : get_errors_asc($input);

    foreach ($errors as $error){
        echo htmlentities( $error ). "\n<hr>\n";
    }

	if( count($errors) == $input['per-page'] ){

		display_load_more($input);
	}
}
/*
error-type => int - The type of error to filter.
order => string - The order of the results (asc/desc).
per-page => int - The number of results per page.
selected-day => string - The selected day for filtering results.
current-page => int - The current page number.
download => bool - Whether to download the results.
search-keyword => string - The keyword to search for.
search-regex => bool - Whether to use regex in search.
exclude-keyword => string - The keyword to exclude from the search.
exclude-regex => bool - Whether to use regex in exclusion.
delete => bool - Whether to delete the selected entries.
db-filename => string - The name of the log file to process.
display_meta => string - Meta display option ('checked' if selected).
source-error-log => bool - Whether to source from the error log.
nonce => string - The nonce for security.
*/
function display_load_more($input){

	$texts = get_load_more_texts();

	$load_more_input = $_POST;

	$load_more_input['current-page'] = intval($input['current-page']??0) + 1;
	// $load_more_input['action'] = 'htmx-php-debug-search';

	$htmx_values = json_encode($load_more_input);

	echo <<<HTML
	<button id="load-more"
		hx-post="{$texts['ajax_url']}"
		hx-trigger="click"
		hx-indicator="#htmx-spinner"
		hx-headers='{"Content-Type": "application/json"}'
		hx-swap="outerHTML"
		hx-target="#load-more"
		hx-vals='{$htmx_values}'>
		{$texts['button_text']}
	</button>
HTML;

}

function get_load_more_texts(){

	return [
		'ajax_url' => admin_url('/admin-ajax.php?php-debug-search'),
		'button_text' => __('Load More', 'wpsd-php-debug'),
	];

}

function get_errors_desc($input){
    
	$errors = [];

    $handle = fopen($input['log-filepath'], 'r');
    
    if (!$handle){
        return $errors;
    }

    $pattern = get_date_pattern();
    $error_message = '';
    $results_counter = 0;

    fseek($handle, 0, SEEK_END);
    $position = ftell($handle);

    while (!has_timeout() && $position > 0 && $results_counter < ($input['current-page'] + 1) * $input['per-page']){
        $position--;
        fseek($handle, $position);
        $char = fgetc($handle);

        $error_message = $char . $error_message;

        if ($char !== '[') continue;

        if (!preg_match($pattern, $error_message)) continue;

        $error_message = rtrim($error_message);

        if (is_searched($input, $error_message) && !is_excluded($input, $error_message)){
            $errors[] = $error_message;
            $results_counter++;
        }

        $error_message = '';
    }

    if (has_timeout()){
        $errors[] = esc_html__('Search timed out', 'wpsd-php-debug');
    }

    fclose($handle);

    $start = $input['current-page'] * $input['per-page'];
    return array_slice($errors, $start, $input['per-page']);
}

function get_errors_asc($input){

	if( !file_exists($input['log-filepath']) || !is_readable($input['log-filepath']) ) return [];

    $errors = [];
    $handle = fopen($input['log-filepath'], 'r');
    
    if (!$handle){
        return $errors;
    }

    $pattern = get_date_pattern();
    $error_message = '';
    $results_counter = 0;

    while (($line = fgets($handle)) !== false && $results_counter < ($input['current-page'] + 1) * $input['per-page'] && !has_timeout()){
        $line = rtrim($line);

        if (preg_match($pattern, $line)){
            if (!empty($error_message)){
                if (is_searched($input, $error_message) && !is_excluded($input, $error_message)){
                    $errors[] = $error_message;
                    $results_counter++;
                }
            }
            $error_message = $line;
        } else {
            $error_message .= "\n" . $line;
        }
    }

    if (!empty($error_message) && $results_counter < ($input['current-page'] + 1) * $input['per-page'] && !has_timeout()){
        if (is_searched($input, $error_message) && !is_excluded($input, $error_message)){
            $errors[] = $error_message;
        }
    }

    if (has_timeout()){
        $errors[] = "Search timeout";
    }

    fclose($handle);

    $start = $input['current-page'] * $input['per-page'];
    return array_slice($errors, $start, $input['per-page']);
}

function is_searched($input, $message){
    if (empty($input['search-keyword'])){
        return true;
    }

    $search_pattern = $input['search-regex'] 
        ? '~' . $input['search-keyword'] . '~i'
        : '~' . preg_quote($input['search-keyword'], '~') . '~i';

    return preg_match($search_pattern, $message);
}

function is_excluded($input, $message){
    if (empty($input['exclude-keyword'])){
        return false;
    }

    $exclude_pattern = $input['exclude-regex'] 
        ? '~' . $input['exclude-keyword'] . '~i'
        : '~' . preg_quote($input['exclude-keyword'], '~') . '~i';

    return preg_match($exclude_pattern, $message);
}

function get_date_pattern(){
    $timezone = ini_get('date.timezone');
    return '~^\[\d{2}-\w{3}-\d{4} \d{2}:\d{2}:\d{2} (UTC|' . preg_quote($timezone, '~') . ')\]~';
}

function has_timeout(){
    return time() > TIMEOUT_TIMESTAMP;
}






// $input =array (
// 	'order' => 'desc',
// 	'per-page' => 10,
// 	'current-page' => 0,
// 	'search-keyword' => '',
// 	'search-regex' => false,
// 	'exclude-keyword' => '',
// 	'exclude-regex' => false,
// 	'db-filename' => '2024-11-11-ip1-error.log',
// );

// function display_source_error_log($input){


	
// }