<?php

namespace wpsd_php_debug;

defined( 'ABSPATH'  ) || exit;


function get_error_meta( $timestamp ){

	$file = fopen( WPSD_LOG_META_FILE, 'r' );

	fseek( $file, 0, SEEK_END );

	$position_in_file = ftell( $file );
	
	$line = '';
	
	while ( $position_in_file > 0 ) {
	
		$position_in_file--;
	
		fseek( $file, $position_in_file );
	
		$char = fgetc( $file );
	
		if ( $char == "\n" ) {
			
			$line_revered = strrev($line);

			if( is_searched_timestamp( $timestamp, $line_revered ) ) return json_decode( substr($line_revered,13),true );
	
			$line = '';
	
		} else {
	
			$line .= $char;
	
		}
	}
	
	fclose( $file );

	$line_revered = strrev($line);

	return is_searched_timestamp( $timestamp, $line_revered ) ? json_decode( substr($line_revered,13),true ) : false;
}

function is_searched_timestamp( $timestamp, $line ){

	return $timestamp === substr( $line, 0, 12);
}