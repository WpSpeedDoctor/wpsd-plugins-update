<?php

defined( 'ABSPATH' ) || exit;

// Decide if errors and debug data should be displayed
if( isset($_COOKIE[ \wpsd_php_debug\get_debug_cookies()->display_values ]) && \wpsd_php_debug\is_screen_output_allowed() ){

	add_action ( (WPSD_REQUEST_TYPE === REQUEST_ADMIN) ? 'admin_footer' : 'shutdown' , 'display_debug_data_wpsd' , 1000 );
	
}

function wpsd_private(){

	require_once __DIR__ . '/func.debug-private.php';
	
}

function display_debug_data_wpsd() {
	
	wpsd_private();
	
	\wpsd_php_debug\display_debug_data();
}


if( !function_exists('debl') ){
	
	 /**
	 * Logs debug values into SQLite database.
	 *
	 * @param mixed $value - The value to store. Defaults to '%marker%' show place where from function has been called from.
	 * @param false|string $id - Optional ID to prefix the debug output.
	 *
	 * @return void
	 */

	
	function debl( $value = '%marker%', $id = false ) {
		
		wpsd_private();
		
		\wpsd_php_debug\debl( $value, $id );
	}
}


if( !function_exists('debu') ){

	/**
	 * Records value and removes all previous recorded values
	 */

	 function debu( $display_value1 = '%marker%', $display_value2 = false ) {
		
		wpsd_private();
		
		\wpsd_php_debug\debu( $display_value1, $display_value2 );
	}
}

if( !function_exists('deb') ){
	
	/**
	 * Records debug values and registers shutdown storage if not already done.
	 *
	 * @param mixed $value - The value to debug. Defaults to '%marker%'.
	 * @param false|string $id - Optional ID to prefix the debug output.
	 *
	 * @return void
	 */

	function deb( $value = '%marker%', $id = false ) {
		
		wpsd_private();
		
		\wpsd_php_debug\deb( $value, $id );
	}
}



if( !function_exists('vd') ){

	/**
	 * vd() function displays var_dump in formatted manner. HTML is converted to plain text.
	 * @param
	 * 
	 * $value: mixed
	 * This is variable to be displayed.
	 * 
	 * $value2: string 
	 * This is name/identifyer.
	 */

	function vd( $value= '', $identifier=false, $float=false ) {
		
		wpsd_private();

		wpsd_php_debug\vd( $value, $identifier, $float );
    }
}



if( !function_exists('stw') ){
	
	/**
	 * stw() stopwatch
	 */
	
	 function stw( $reset=false ) {
		
		wpsd_private();
		
		\wpsd_php_debug\stw( $reset );
	}
}




if( !function_exists('the_tm') ){
	 
	/**
	 * Time debugging functions
	*/

	function the_tm( $start, $end ) {
		
		wpsd_private();
		
		\wpsd_php_debug\the_tm( $start, $end );
	}
}

if( !function_exists('tm') ){
	
	/**
	 * Calculates the time difference between two timestamps.
	 *
	 * @param float $start_time_measure - The start timestamp.
	 * @param float $end_time_measure - The end timestamp.
	 * @param bool $microseconds_output - Whether to return the result in microseconds.
	 *
	 * @return string|float - default string with time scale
	 * 
	 */

	function tm( $start_time_measure, $end_time_measure, $microseconds_output = false ) {
		
		wpsd_private();
		
		return \wpsd_php_debug\tm( $start_time_measure, $end_time_measure, $microseconds_output );
	}
}


if( !function_exists('wpsd_dd') ){

	/**
	 * WPSD Display Debug sets errors and values displaying cookies. 
	 */

	function wpsd_dd() {
		
		wpsd_private();
		
		\wpsd_php_debug\wpsd_dd();
	}
}

function the_wpsd_used_php(){

	require_once WPSD_DEBUG_DIR.'includes/required-files.php';

	deb( implode(PHP_EOL, wpsd_php_debug\get_plugins_memory_usage() ) );
}