<?php

defined( 'ABSPATH' ) || exit;

if( isset($_COOKIE['wpsd-debug-display-values']) && wpsd_php_debug\is_allowed_display_of_error() === true ){

	add_action ( is_admin() ? 'admin_footer' : 'shutdown' , 'display_debug_data_wpsd' , 1000 );
}

function debl( $value='%marker%', $id=false ){
	
	global $wpsd_debug_errors;

	$value_string = get_value_as_string_wpsd( $value );
	
	$id_string = $id === false ? '' : $id.' -> ';

	$wpsd_debug_errors[] = [
		
		0 => 99999,

		1 => "{$id_string}{$value_string}\n",

	];

	if(defined('WPSD_DEBUG_SHUTDOWN')) return;

	register_shutdown_function( 'add_deb_to_log_wpsd');
}

function add_deb_to_log_wpsd(){

	if(defined('WPSD_DEBUG_SHUTDOWN')) return;
	
	defined( 'WPSD_PHP_DEBUG_DIR' ) || define( 'WPSD_PHP_DEBUG_DIR', WP_CONTENT_DIR.'/plugins/wpsd-php-debug/' );

	require_once WPSD_PHP_DEBUG_DIR.'must-use-plugin/errors/functions-error-handler.php';
	
	wpsd_php_debug\record_php_errors( );
}

function debu( $display_value1='%marker%', $display_value2=false){

	update_option('wpsd-debug-values', '', 'no');

	deb( $display_value1, $display_value2);

}

function deb( $value='%marker%', $id=false ){

	global $wpsd_deb_values;

	if(!isset($wpsd_deb_values)) $wpsd_deb_values = '';

	$id_string = $id === false ? '' : $id.' -> ';

	$wpsd_deb_values .= $id_string.get_value_as_string_wpsd( $value ).'<br>';

	static $is_recording_registered = false;

	if( $is_recording_registered ) return;

	$is_recording_registered = true;

	register_shutdown_function('wpsd_record_deb_values');
}

function wpsd_record_deb_values(){

	global $wpsd_deb_values;

	$deb_values = get_stored_values_wpsd();
	
	$deb_values[] = [ 
		
		't' => intval( microtime(true) ) + 15, //15 = 15 seconds TTL
		'v' => $wpsd_deb_values // values
	];
	
	update_option('wpsd-debug-values', $deb_values, 'no');

}

function get_stored_values_wpsd( $should_purge_empty=false ){
	
	$deb_values = get_option('wpsd-debug-values');
	
	if( !is_array($deb_values) ) return [];

	$current_timestamp = (int) microtime(true);

	foreach($deb_values as $key => $record){

		if( $record['t'] < $current_timestamp ) unset($deb_values[$key]);
	}

	if( empty($deb_values) && $should_purge_empty ) {

		update_option('wpsd-debug-values','','no');
	}

	return empty($deb_values) ? [] : $deb_values;
}

function get_value_as_string_wpsd($value){

	switch( true ){
		
		case is_numeric($value):

			return ( string ) $value;

		case $value === '%marker%':
	
			return get_marker_text_wpsd();

		case is_string($value):
			
			return  htmlentities($value, ENT_QUOTES, 'UTF-8');
		
		case is_bool($value):

			$color = $value ? 'green':'red';

			$bool_text = $value ? 'true' : 'false';
			
			return	<<<HTML
					Bool: <span style="color:{$color}">{$bool_text}</span> 
					HTML;
			
		case $value === null:

			return	<<<HTML
					<span style="color:blue">Null</span>
					HTML;

		case is_resource($value):
			
			ob_start();

			var_dump( $value );

			$iterable_value = trim(ob_get_clean());
			
			break;

		default:
			
			$iterable_value = var_export($value,true);

			break;
	}

	$result = '';

	foreach ( explode("\n", $iterable_value ) as $line ) {

		$result .= htmlentities( $line, ENT_QUOTES, 'UTF-8');
	}

	return $result === '' 
		? htmlentities( $iterable_value, ENT_QUOTES, 'UTF-8') 
		: $result;
}

function get_var_dump( $value ){

	ob_start();
	
	var_dump( $value );

	$output = ob_get_clean();
	
	return $output;
	
}

function get_marker_text_wpsd(){

	$marker = get_marker_location_wpsd();
	
	$file = get_filepath_slice_wpsd( $marker['file'] );
		
	return
<<<HTML
fnc: <span style="color:blue">{$marker['function']}()</span> at line <span style="color:yellow">{$marker['line']}</span> in $file
HTML;
	
	
}

function display_debug_data_wpsd() {
	
	global $wpsd_deb_values;
	
	$stored_values = get_stored_values_wpsd( $should_purge_empty=false );

	$values_to_display = '';

	if( !empty( $stored_values ) ) $values_to_display = implode('', array_column( $stored_values,'v') );
	
	if( !empty( $wpsd_deb_values ) ) $values_to_display .= $wpsd_deb_values;

	if( $values_to_display === '' ) return;

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	if( $_COOKIE['wpsd-debug-display-values'] !== $dir_string ) return;

?><style>.wpsd-debug-window{ position: fixed;bottom:90px;right:10px;z-index: 999999;background-color: #ddd;
;border: 1px solid grey;padding:0px 5px 0 5px;line-height:30px;color: black;font-size: 20px;padding-right: 35px;max-height: 800px;
overflow-y: scroll;white-space: break-spaces;max-width: 97%;max-height: 80%;}
.wpsd-debug-close {position: absolute;top: -1px;right: 10px;font-size: 30px;font-weight: bold;text-decoration: none;color: #555;}
.wpsd-debug-window:target,.wpsd-debug-window-hidden {display: none;}
</style>
<div id="debug-popup" class="wpsd-debug-window wpsd-debug-window-hidden"><?php echo $values_to_display; ?><a class="wpsd-debug-close" href="#debug-popup">×</a></div>
<script data-cfasync="false" defer >
	document.addEventListener("DOMContentLoaded", function() {
	const cookieName = 'wpsd-debug-display-values';

	if (document.cookie.split(';').some((item) => item.trim().startsWith(`${cookieName}=`))){
		const debugPopup = document.getElementById('debug-popup');
		debugPopup.classList.remove('wpsd-debug-window-hidden');
	}
});
</script>
	<?php
	
}



/**
 * vd() function displays var_dump in formatted manner. HTML is converted to plain text.
 * @param
 * 
 * $value: mixed
 * This is variable to be displayed.
 * 
 * $value2: string 
 * This is name/identifyer.
 */

function vd( $value, $value2='', $float=false ) {
	
	$css = get_debug_window_css_wpsd($float);

	$id = bin2hex(random_bytes(6));

	$value_markup = get_value_as_string_wpsd( $value );

	echo <<<HTML
<div id="{$id}" style="{$css}">
	<div class="debug-data" style="white-space: pre-wrap"><br>
{$value_markup}
	</div>
</div>
HTML;
	
}


//Float window
function fvd( $value1, $value2='' ) {

	vd($value1, $value2, true );
}


function the_debug_window_header_wpsd($value2){
//https://stackoverflow.com/questions/2110732/how-to-get-name-of-calling-function-method-in-php
	if (! defined( 'ABSPATH' ) ) return;
		
	global $template;

	$marker_location = get_marker_location_wpsd();

	$caller_details = 'Template: '.get_filepath_slice_wpsd($template??'') ?:'';

	$caller_details .= '  Called from: '.$marker_location['function']??'';

	$caller_details .= '  Line: '.$marker_location['line']??'';

	$caller_details .= '  File: '.get_filepath_slice_wpsd($marker_location['file']??'');

	$text_to_display = $value2?: $caller_details;

	?>
	<div class="debug-header" style="position: absolute;background: rgb(51, 51, 51);width:100%;line-height: 0;text-align:center;">
		<h4>
			<?=$text_to_display?>
		</h4>
	</div>
	<?php
}

function get_marker_location_wpsd( ){

	$trace = array_reverse(debug_backtrace());

	$fnc_names = ['deb', 'debu', 'vd','fvd','get_marker_text_wpsd',  __FUNCTION__ ];

	foreach( $trace as $key=>$value ) {

		if ( in_array( $value['function'], $fnc_names  ) ) break;
		
		$caller_key = $key+1;
	
	}

	return [
		
		'function'	=> get_function_name_wpsd( $trace, $caller_key ),
		
		'file'		=> $trace[$caller_key]['file']??'',
		
		'line'		=> $trace[$caller_key]['line']??''

	];
}

function get_function_name_wpsd( $trace, $caller_key ){

	if( empty( $trace[$caller_key-1]['function'] ) ) return '';

	$parts = explode('\\', $trace[$caller_key-1]['function'] );

	return end( $parts );
}

/**
 * stw() stopwatch
 */
function stw(){

	$now = microtime(true);

	if( !isset($GLOBALS['wpsd-stopwatch'] ) ){
		
		$GLOBALS['wpsd-stopwatch'] = $now;

		return;
	}
	
	dtm( $GLOBALS['wpsd-stopwatch'], $now );
	
}

function get_filepath_slice_wpsd( $filepath ){

	foreach (['themes','plugins','wp-content','public_html','www'] as $separator ){

		$filepath_slices = explode( $separator, $filepath );

		if ( isset($filepath_slices[1]) ) return $filepath_slices[1];

	}

	return $filepath;
}


function get_debug_window_css_wpsd( $float = false ) {

	$css = 'padding: 0 10px 10px 10px;border: 1px solid red;font-weight: bold;/*white-space: pre-wrap*/;overflow: scroll;max-height: 400px;color: #ddd;font-family: monospace;font-size: 18px;line-height: 30px;background-color: #333;';

	if ($float) $css .='position: fixed;bottom: 40px;right: 0px;z-index: 10;max-width:80%';

	return $css;


}

/**
 * Time debugging functions
 */

function the_tm($start,$end) {

	$time_elapsed = tm($start,$end);
	
	echo 
<<<HTML
Time elapsed: {$time_elapsed}
HTML;

}	

function dtm( $start, $end ) {

	deb( tm($start,$end), 'Time elapsed' );
}

function tm( $start_time_measure=false, $end_time_measure=false ) {

	$difference = bcsub($end_time_measure, $start_time_measure, 14);

	switch (true) {

		case $difference >= 1: // More than or equal to 1 second
			$elapsed_time = (string) round($difference,3);
			$time_unit = 's';
			break;

		case $difference * 1e3 >= 1: // More than or equal to 1 millisecond
			$elapsed_time =  (string) intval($difference * 1e3);
			$time_unit = 'ms';
			break;

		case $difference * 1e6 >= 1: // More than or equal to 1 microsecond
			$elapsed_time = (string) intval( $difference * 1e6 );
			$time_unit = 'μs';
			break;

		default: // Nanoseconds
			$elapsed_time =  (string) intval( $difference * 1e9 );
			$time_unit = 'ns';
			break;
	}

	return "$elapsed_time $time_unit";
}

/**
 * WPSD Display Debug sets errors and values displaying cookies. 
 */
function wpsd_dd(){

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	setcookie(
		'wpsd-debug-display-values',
		$dir_string,
		0
	);

	setcookie(
		'wpsd-debug-display-errors',
		$dir_string,
		0
	);


}