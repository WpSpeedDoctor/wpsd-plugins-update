<?php

defined( 'ABSPATH' ) || exit;

if( isset($_COOKIE['wpsd-debug-display-values']) && wpsd_php_debug\is_allowed_display_of_error() === true ){

	add_action ( is_admin() ? 'admin_footer' : 'shutdown' , 'display_debug_data_wpsd' , 1000 );
}

function create_transient_constant_wpsd( bool $unique=false ){

	if ( defined( 'DEBUG_TRANSIENT_ID' ) ) return;

	define('DEBUG_TRANSIENT_ID', 'wpsd-debug'.( $unique ? '-'.bin2hex(random_bytes(10)) : '' ) );
}

function debu( $display_value1='%marker%', $display_value2=false){

	create_transient_constant_wpsd(true);

	deb( $display_value1, $display_value2);

}

function deb( $value='%marker%', $id=false ){

	create_transient_constant_wpsd();

	$value_string = get_value_as_string_wpsd( $value );
	
	$id_string = $id === false ? '' : $id.' -> ';

	$transient_output = get_transient ( DEBUG_TRANSIENT_ID ).$id_string.$value_string.'<br>';
	
	set_transient( DEBUG_TRANSIENT_ID, $transient_output, 15); //set transient life to 15 seconds	
}

function get_value_as_string_wpsd($value){

	switch( true ){
		
		case is_numeric($value):

			return ( string ) $value;

		case $value === '%marker%':
	
			return get_marker_text_wpsd();

		case is_string($value):
			
			return  htmlentities($value, ENT_QUOTES, 'UTF-8');
		
		case is_bool($value):

			$color = $value ? 'green':'red';

			$bool_text = $value ? 'true' : 'false';
			
			return	<<<HTML
					Bool: <span style="color:{$color}">{$bool_text}</span> 
					HTML;
			
		case $value === null:

			return	<<<HTML
					<span style="color:blue">Null</span>
					HTML;

		case is_resource($value):
			
			ob_start();

			var_dump( $value );

			$iterable_value = trim(ob_get_clean());
			
			break;

		default:
			
			$iterable_value = var_export($value,true);

			break;
	}

	$result = '';

	foreach ( explode("\n", $iterable_value ) as $line ) {

		$result .= htmlentities( $line, ENT_QUOTES, 'UTF-8');
	}

	return $result === '' 
		? htmlentities( $iterable_value, ENT_QUOTES, 'UTF-8') 
		: $result;
}

function get_var_dump( $value ){

	ob_start();
	
	var_dump( $value );

	$output = ob_get_clean();
	
	return $output;
	
}

function get_marker_text_wpsd(){

	$marker = get_marker_location_wpsd();
	
	$file = get_filepath_slice_wpsd( $marker['file'] );
		
	return
<<<HTML
fnc: <span style="color:blue">{$marker['function']}()</span> at line <span style="color:yellow">{$marker['line']}</span> in $file
HTML;
	
	
}

function display_debug_data_wpsd() {
	
	$transient_name = defined('DEBUG_TRANSIENT_ID') ? DEBUG_TRANSIENT_ID : 'wpsd-debug';

	$transient_output = get_transient( $transient_name );
	
	if ( !is_string($transient_output) ) return;

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	if( $_COOKIE['wpsd-debug-display-values'] !== $dir_string ) return;

?><style>.debug_window{ position: fixed;bottom:90px;right:10px;z-index: 999999;background-color: #ddd;
;border: 1px solid grey;padding:0px 5px 0 5px;line-height:30px;color: black;font-size: 20px;padding-right: 35px;max-height: 800px;
overflow-y: scroll;white-space: break-spaces;max-width: 97%;max-height: 80%;}
.close {position: absolute;top: -1px;right: 10px;font-size: 30px;font-weight: bold;text-decoration: none;color: #555;}
.debug_window:target,.debug_window_hidden {display: none;}
</style>
<div id="debug-popup" class="debug_window debug_window_hidden"><?php echo $transient_output; ?><a class="close" href="#debug-popup">×</a></div>
<script>
	document.addEventListener("DOMContentLoaded", function() {
	const cookieName = 'wpsd-debug-display-values';

	if (document.cookie.split(';').some((item) => item.trim().startsWith(`${cookieName}=`))){
		const debugPopup = document.getElementById('debug-popup');
		debugPopup.classList.remove('debug_window_hidden');
	}
});
</script>
	<?php
	
}



/**
 * vd() function displays var_dump in formatted manner. HTML is converted to plain text.
 * @param
 * 
 * $value: mixed
 * This is variable to be displayed.
 * 
 * $value2: string 
 * This is name/identifyer.
 */

function vd( $value, $value2='', $float=false ) {
	
	$css = get_debug_window_css_wpsd($float);

	$id = bin2hex(random_bytes(6));

	$value_markup = get_value_as_string_wpsd( $value );

	echo <<<HTML
<div id="{$id}" style="{$css}">
	<div class="debug-data" style="white-space: pre-wrap"><br>
{$value_markup}
	</div>
</div>
HTML;
	
}


//Float window
function fvd( $value1, $value2='' ) {

	vd($value1, $value2, true );
}


function the_debug_window_header_wpsd($value2){
//https://stackoverflow.com/questions/2110732/how-to-get-name-of-calling-function-method-in-php
	if (! defined( 'ABSPATH' ) ) return;
		
	global $template;

	$marker_location = get_marker_location_wpsd();

	$caller_details = 'Template: '.get_filepath_slice_wpsd($template??'') ?:'';

	$caller_details .= '  Called from: '.$marker_location['function']??'';

	$caller_details .= '  Line: '.$marker_location['line']??'';

	$caller_details .= '  File: '.get_filepath_slice_wpsd($marker_location['file']??'');

	$text_to_display = $value2?: $caller_details;

	?>
	<div class="debug-header" style="position: absolute;background: rgb(51, 51, 51);width:100%;line-height: 0;text-align:center;">
		<h4>
			<?=$text_to_display?>
		</h4>
	</div>
	<?php
}

function get_marker_location_wpsd( ){

	$trace = array_reverse(debug_backtrace());

	$fnc_names = ['deb', 'debu', 'vd','fvd','get_marker_text_wpsd',  __FUNCTION__ ];

	foreach( $trace as $key=>$value ) {

		if ( in_array( $value['function'], $fnc_names  ) ) break;
		
		$caller_key = $key+1;
	
	}

	return [
		
		'function'	=> get_function_name_wpsd( $trace, $caller_key ),
		
		'file'		=> $trace[$caller_key]['file']??'',
		
		'line'		=> $trace[$caller_key]['line']??''

	];
}

function get_function_name_wpsd( $trace, $caller_key ){

	if( empty( $trace[$caller_key-1]['function'] ) ) return '';

	$parts = explode('\\', $trace[$caller_key-1]['function'] );

	return end( $parts );
}

/**
 * stw() stopwatch
 */
function stw(){

	$now = microtime(true);

	if( !isset($GLOBALS['wpsd-stopwatch'] ) ){
		
		$GLOBALS['wpsd-stopwatch'] = $now;

		return;
	}
	
	dtm( $GLOBALS['wpsd-stopwatch'], $now );
	
}

function get_filepath_slice_wpsd( $filepath ){

	foreach (['themes','plugins','wp-content','public_html','www'] as $separator ){

		$filepath_slices = explode( $separator, $filepath );

		if ( isset($filepath_slices[1]) ) return $filepath_slices[1];

	}

	return $filepath;
}


function get_debug_window_css_wpsd( $float = false ) {

	$css = 'padding: 0 10px 10px 10px;border: 1px solid red;font-weight: bold;/*white-space: pre-wrap*/;overflow: scroll;max-height: 400px;color: #ddd;font-family: monospace;font-size: 18px;line-height: 30px;background-color: #333;';

	if ($float) $css .='position: fixed;bottom: 40px;right: 0px;z-index: 10;max-width:80%';

	return $css;


}

/**
 * Time debugging functions
 */

function the_tm($start,$end) {

	$time_elapsed = tm($start,$end);
	
	echo 
<<<HTML
Time elapsed: {$time_elapsed}
HTML;

}	

function dtm( $start, $end ) {

	deb( tm($start,$end), 'Time elapsed' );
}

function tm( $start_time_measure=false, $end_time_measure=false ) {

	$difference = bcsub($end_time_measure, $start_time_measure, 14);

	switch (true) {

		case $difference >= 1: // More than or equal to 1 second
			$elapsed_time = (string) round($difference,3);
			$time_unit = 's';
			break;

		case $difference * 1e3 >= 1: // More than or equal to 1 millisecond
			$elapsed_time =  (string) intval($difference * 1e3);
			$time_unit = 'ms';
			break;

		case $difference * 1e6 >= 1: // More than or equal to 1 microsecond
			$elapsed_time = (string) intval( $difference * 1e6 );
			$time_unit = 'μs';
			break;

		default: // Nanoseconds
			$elapsed_time =  (string) intval( $difference * 1e9 );
			$time_unit = 'ns';
			break;
	}

	return "$elapsed_time $time_unit";
}

/**
 * WPSD Display Debug sets errors and values displaying cookies. 
 */
function wpsd_dd(){

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	setcookie(
		'wpsd-debug-display-values',
		$dir_string,
		0
	);

	setcookie(
		'wpsd-debug-display-errors',
		$dir_string,
		0
	);


}