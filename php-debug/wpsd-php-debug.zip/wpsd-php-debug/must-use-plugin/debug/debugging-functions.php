<?php

defined( 'ABSPATH' ) || exit;

function is_displayed_on_this_ip_wpsd(){

	return true;

	// $debug_ips = ['127.0.0.1'];

	// return in_array( ($_SERVER['REMOTE_ADDR']??''),$debug_ips );

}

function create_transient_constant_wpsd( bool $unique=false ){

	if ( defined( 'DEBUG_TRANSIENT_ID' ) ) return;

	define('DEBUG_TRANSIENT_ID', 'mu-plugin-debug'.( $unique ? '-'.uniqid() : '' ) );
}

function get_no_display_uri_identifier_wpsd(){

	return array(	
					'.xml',
					'wp-json',
					'ajax'
		);
}


function debu( $display_value1='%marker%', $display_value2=false){

	create_transient_constant_wpsd(true);

	deb( $display_value1, $display_value2);

}

function deb( $value='%marker%', $id=false ){

	create_transient_constant_wpsd();

	$value_string = get_value_as_string_wpsd( $value );
	
	$id_string = $id === false ? '' : $id.' -> ';

	$transient_output = get_transient ( DEBUG_TRANSIENT_ID ).$id_string.$value_string.'<br>';
	
	set_transient ( DEBUG_TRANSIENT_ID, $transient_output, 15); //set transient life to 15 seconds	
}

function get_value_as_string_wpsd( $value ){

	if ( $value ==='%marker%' ) return get_marker_text_wpsd();

	if ( is_bool($value) ) return $value ? 'Bool: true' : 'Bool: false';

	if ( !(is_string($value) || is_numeric($value)) ) $value = var_export($value,true);

	$result = '';

	foreach( explode("\n", $value) as $line  ){
		
		$result .= htmlentities($line, ENT_QUOTES, 'UTF-8').'<br>';
	}

	return $result === '' ? htmlentities($value, ENT_QUOTES, 'UTF-8') : $result;
}

function get_marker_text_wpsd(){

	extract(get_marker_location_wpsd());
	
	$file = get_filepath_slice_wpsd($file);
	
	return " $line   $function()    $file ";
}

function is_uri_no_display_wpsd(){

	foreach ( get_no_display_uri_identifier_wpsd() as $string ) {

		if ( strpos( $_SERVER['REQUEST_URI']??'' , $string ) !== false ) return true;
	}

	return false;
}

function display_debug_data_wpsd() {
	
	if ( is_uri_no_display_wpsd() || !is_displayed_on_this_ip_wpsd() ) return;

	defined('DEBUG_TRANSIENT_ID') || define( 'DEBUG_TRANSIENT_ID','mu-plugin-debug');

	$transient_output = get_transient ( DEBUG_TRANSIENT_ID );
	
	if ( !is_string($transient_output) ) return;

	?><style>.debug_window{ position: fixed;bottom:90px;right:10px;z-index: 9999;background-color: #ddd;
	 ;border: 1px solid grey;padding:0px 5px 0 5px;line-height:30px;color: black;font-size: 20px;padding-right: 35px;max-height: 800px;overflow-y: scroll;white-space: break-spaces;max-width: 97%;max-height: 80%;}
	.close {position: absolute;top: -1px;right: 10px;font-size: 30px;font-weight: bold;text-decoration: none;color: #555;}.debug_window:target {display: none;}
	</style>
	<div id="popup1" class="debug_window"><?=$transient_output?><a class="close" href="#popup1">×</a></div>
	<?php
	
}

add_action ( is_admin() ? 'admin_footer' : 'shutdown' , 'display_debug_data_wpsd' , 1000 );


/**
 * vd() function displays var_dump in formated manner. HTML is converted to plain text.
 * @param
 * 
 * $value: mixed
 * This is variable to be displayed.
 * 
 * $value2: string 
 * This is name/identifyer.
 */

function vd( $value, $value2='', $float=false ) {
	
	$css = get_debug_window_css_wpsd($float);

?><div id="<?php echo uniqid(); ?>" style="<?=$css?>"><?php

	// the_debug_window_header_wpsd($value2);

	// $output = var_export($value,true);

	?>
<div class="debug-data" style="white-space: pre-wrap"><br>
<?=get_value_as_string_wpsd( $value )?>
</div>
</div>
	<?php
	
}


//Float window
function fvd( $value1, $value2='' ) {

	vd($value1, $value2, true );
}


function the_debug_window_header_wpsd($value2){
//https://stackoverflow.com/questions/2110732/how-to-get-name-of-calling-function-method-in-php
	if (! defined( 'ABSPATH' ) ) return;
		
	global $template;

	$marker_location = get_marker_location_wpsd();

	$caller_details = 'Template: '.get_filepath_slice_wpsd($template??'') ?:'';

	$caller_details .= '  Called from: '.$marker_location['function']??'';

	$caller_details .= '  Line: '.$marker_location['line']??'';

	$caller_details .= '  File: '.get_filepath_slice_wpsd($marker_location['file']??'');

	$text_to_display = $value2?: $caller_details;

	?>
	<div class="debug-header" style="position: absolute;background: rgb(51, 51, 51);width:100%;line-height: 0;text-align:center;">
		<h4>
			<?=$text_to_display?>
		</h4>
	</div>
	<?php
}

function get_marker_location_wpsd( ){

	$trace = array_reverse(debug_backtrace());

	$fnc_names = ['deb', 'debu', 'vd','fvd','get_marker_text_wpsd',  __FUNCTION__];

	foreach( $trace as $key=>$value ) {

		if ( in_array( $value['function'], $fnc_names  ) ) break;
		
		// echo $value['function'].'<br>';
		
		$caller_key = $key+1;
	
	}

	return [
		
		'function'	=> $trace[$caller_key-1]['function']??'',
		
		'file'		=> $trace[$caller_key]['file']??'',
		
		'line'		=> $trace[$caller_key]['line']??''


	];
}

//TODO timemarker
// function get_passed_time_from_last_marker(){

// 	$timestamp = get_transient( DEBUG_TRANSIENT_ID.'-time' );

// 	set_transient( DEBUG_TRANSIENT_ID.'-time', (string) microtime(true), 15 );

// 	return tm( $timestamp, microtime(true) );
// }

function get_filepath_slice_wpsd( $filepath ){

	foreach (['themes','plugins','wp-content','public_html','www'] as $separator ){

		$filepath_slices = explode( $separator, $filepath );

		if ( isset($filepath_slices[1]) ) return $filepath_slices[1];

	}

	return $filepath;
}


function get_debug_window_css_wpsd( $float = false ) {

	$css = 'padding: 0 10px 10px 10px;border: 1px solid red;font-weight: bold;/*white-space: pre-wrap*/;overflow: scroll;max-height: 400px;color: #ddd;font-family: monospace;font-size: 18px;line-height: 30px;background-color: #333;';

	if ($float) $css .='position: fixed;bottom: 40px;right: 0px;z-index: 10;max-width:80%';

	return $css;


}



function the_tm($start,$end) {

	echo '<br>Time elapsed: '.tm($start,$end).PHP_EOL;
}

function dtm($start=false, $end=false) {

	deb( tm($start,$end), 'Time elapsed' );
}

function tm( $start_time_measure=false, $end_time_measure=false ) {

	if( is_string( $start_time_measure ) ) {

		//new version using microtime():string return
		return tm_string( $start_time_measure, $end_time_measure );
		
	} else {
		
		//older version using microtime(true):float return
		return tm_float( $start_time_measure, $end_time_measure );

	}
}

function tm_float( $start_time_measure, $end_time_measure ) {

	$end_time_measure = $end_time_measure ?: microtime(true);

	$start_time_measure = $start_time_measure ?: $_SERVER['REQUEST_TIME_FLOAT'];

	$elapsed_microtime = $end_time_measure - $start_time_measure; 

	foreach ( get_time_scale_conversions_wpsd() as $time_unit => $scale_condition ){

		$elapsed_time = round( $elapsed_microtime,$scale_condition['rounding'])*$scale_condition['multiplier'];
	
		if ( is_scope_large_enough_wpsd($elapsed_time) ) break;
	
	}

	return "$elapsed_time $time_unit";
}

//todo remove string version
function tm_string( $start_time_measure=false, $end_time_measure=false ) {

	$start_microtime = explode( ' ', $start_time_measure ?: $_SERVER['REQUEST_TIME_FLOAT']);

	$end_microtime = explode( ' ', $end_time_measure ?: microtime());

	$integer_difference = intval( $end_microtime[1] ) - intval( $start_microtime[1] );

	$end_time_with_sec_difference = intval( $end_microtime[0] * 100000000) + ( $integer_difference * 100000000);

	$decimal_difference = $end_time_with_sec_difference - intval($start_microtime[0] * 100000000);

	$conversion_scales = [  
		
		'ns' => ['limit'=>100,'divider'=> 0.1 ],
		'μs' => ['limit'=>100000,'divider'=>100 ],
		'ms' => ['limit'=>100000000,'divider'=>100000 ],
		's'  => ['limit'=>1000000000,'divider'=>100000000 ],
					
	];

	foreach ( $conversion_scales as $time_unit => $scale_condition ){
		
		$decimal_difference_result = $decimal_difference / $scale_condition['divider'];
		
		if( $scale_condition['limit'] > $decimal_difference ) break;
	}

	//leave 2 decimals rounding for single digit integer
	$rounding = $decimal_difference_result < 10 ? 2 : 0;

	return  round($decimal_difference_result, $rounding ).' '.$time_unit;
}

function is_scope_large_enough_wpsd($elapsed_time){

	return round($elapsed_time,0) >= 1;
}

function get_time_scale_conversions_wpsd(){

	return array(   's'  => array('multiplier'=>1, 'rounding' => 3 ),
					'ms' => array('multiplier'=>100, 'rounding' => 4 ),
					'μs' => array('multiplier'=>1000000, 'rounding' => 8 ),
					
	);
}
