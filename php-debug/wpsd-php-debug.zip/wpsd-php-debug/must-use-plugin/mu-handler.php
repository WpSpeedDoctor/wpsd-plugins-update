<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

require_once WP_PLUGIN_DIR.'/wpsd-php-debug/constants.php';

require_once WP_PLUGIN_DIR.'/wpsd-php-debug/includes/universal-functions.php';

if( get_wpsd_option( 'wpsd-debug-ver' ) !== WPSD_DEBUG_VER ){

    require WPSD_DEBUG_DIR.'admin/setup.php';

    update_previous_version_settings();
}

require __DIR__.'/errors/error-handler.php';

require __DIR__.'/debug/debugging-functions.php';

if( isset($_GET['php-debug-search']) && ($_POST['action']??'') === 'htmx-php-debug-search' ){

    require __DIR__.'/ajax/ajax-handler.php';
}

//TODO:add headers
/*
send_origin_headers();
send_nosniff_header();
wc_nocache_headers();
header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
header( 'X-Robots-Tag: noindex' );

*/