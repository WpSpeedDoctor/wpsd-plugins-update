<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

require __DIR__.'/errors/error-handler.php';

require __DIR__.'/debug/debugging-functions.php';

if( isset($_GET['php-debug-search']) && ($_POST['action']??'') === 'htmx-php-debug-search' ){

    require __DIR__.'/ajax/ajax-handler.php';
}
