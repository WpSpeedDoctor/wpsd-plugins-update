<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


function record_php_errors_in_custom_format(){

	$error_log_filepath = ini_get('error_log');

	if( !file_exists( $error_log_filepath ) ) return;

	$timestamp = filesize( $error_log_filepath );
	
	$php_error_metadata = get_php_error_metadata($timestamp);

	log_php_error( $error_log_filepath, $php_error_metadata );

}

function get_line_with_error(){

	if( !is_php_error_file_valid_filepath() ) return '';

	$php_error_line = get_file_line( WP_PHP_DEBUG_LAST_ERROR['file'], (int) WP_PHP_DEBUG_LAST_ERROR['line'] );

	$last_error = WP_PHP_DEBUG_LAST_ERROR;

	[$message,$stack_trace ]= explode( 'Stack trace:', $last_error['message']);



	return
<<<TEXT

Line with error:


$php_error_line

Type: {$last_error['type']}

Message: {$message}

File: {$last_error['file']}

Line: {$last_error['line']}

Stack trace: $stack_trace



TEXT;

}

function is_php_error_file_valid_filepath(){

	return 
	
		file_exists( WP_PHP_DEBUG_LAST_ERROR['file']??'' ) &&
			
		is_readable( WP_PHP_DEBUG_LAST_ERROR['file']??'' ) &&
		
		is_numeric( WP_PHP_DEBUG_LAST_ERROR['line']??false );
}

function get_file_line( $filename, $line_number ) {

	$handle = fopen( $filename, 'r' );
	
	if (!$handle ) return 'N/A';

	$current_line = 1;

	while (( $line = fgets( $handle ) ) !== false ) {

		if ( $current_line == $line_number ) {
		
			fclose( $handle );
		
			return $line;
		}
		
		$current_line++;
	}

	fclose( $handle );
	
	return 'N/A';
}




function get_sanitized_uri(){

	$uri = $_SERVER['REQUEST_URI']??$_SERVER['PHP_SELF']??'N/A';

	if( !str_contains( $uri,'pass' ) ) return $uri;

	return preg_replace_callback('/(pass(?:word)?=)[^&]*/i', function ($matches) {
        return $matches[1] . '***removed***';
    }, $uri);
}

/**
 * $name: string
 *
 **/

function log_php_error( $error_log_filepath, $php_error_metadata ){

	file_put_contents(	get_metadata_log_filepath( $error_log_filepath ) , $php_error_metadata, FILE_APPEND );

}

function get_php_error_metadata( $timestamp ){
	
	$config = json_decode( get_option( 'wpsd-php-debug-settings'), true );
	
	//e= error type code
	$result['e'] = WP_PHP_DEBUG_LAST_ERROR['type']??'15';
	
	//s = server
	$result['s'] =  get_server_superglobal( $config );
	
	//u = username
	$result['u'] = get_logged_in_user_from_cookies();

	//p = post
	$result['p'] = get_sanitized_post_superglobal($config);
	
	//c = cookies
	$result['c'] = get_sanitized_cookies_superglobal( $config );

	//timestamp as in PHP error log
	$result['t'] = (float) $_SERVER['REQUEST_TIME_FLOAT'];

	remove_empty_keys( $result );
	
	/**
	 * $timestamp is marker to determine where event log starts and ends for purposes of displaying in admin area
	 */
	return "$timestamp\n".json_encode($result).PHP_EOL;
			
}

function remove_empty_keys( &$result ){

	foreach(array_keys( $result) as $key){
		
		if( empty( $result[$key] ) ) unset( $result[$key] );

	}
}

function get_logged_in_user_from_cookies( ){

	foreach( $_COOKIE as $key => $value ) {

		if( strpos( $key,'wordpress_logged_in_' ) === 0 ) {
			
			return get_cookie_username($value);
			
		}
	}
		
	return '';
}


//call if Fatal PHP error doesn't show the message
function display_fatal_error_data( ){

	if( !is_fatal_error() ||
		
		!is_error_displayed()
	
	) return;
	
	?>
	<style type="text/css">
	@media (prefers-color-scheme: dark ) {
		html {
			background: #222!important;
		}
		body#error-page {
			background: #333;
		}
		body#error-page {
			background: #333;
			color: #ccc;
			font-size: 20px;
		}
	}
	</style>
	<div style="white-space: break-spaces">
	<?php

	echo get_line_with_error().'<br>';

	?></div><?php
	

}


function is_fatal_error(  ){
	
	$php_error_type = (int )( WP_PHP_DEBUG_LAST_ERROR['type'] ?? 0 );

	$excluded_types_to_display = [1,4,16,64];
		
	return in_array( $php_error_type, $excluded_types_to_display );
}


function get_sanitized_post_superglobal( $config ){

	if ( empty( $_POST ) || !$config['post'] ) return [];

	foreach( array_keys( $_POST ) as $key ){

		$result[$key] = str_contains( $key, 'pass' ) ? '***removed***' : sanitize_text_field( $_POST[$key] );

	}

	return $result??[]; 
}

function get_server_superglobal( $config ){

	if( !$config['server'] ) return [];

	foreach( $config['server_keys'] as $key ){

		if( !isset( $_SERVER[$key] ) ) continue;

		switch($key){

			case 'REQUEST_URI':
			
				$result[$key] = get_sanitized_uri();

			break;

			default:

				$result[$key] = $_SERVER[$key];
			break;
		}

	}

	return $result??[]; 
}

function get_sanitized_cookies_superglobal( $config ){
	
	if( empty( $_COOKIE ) || !$config['cookies'] ) return [];

	foreach( $_COOKIE as $key => $cookie_value ){

		if( is_cookie_key_excluded_string( $key ) ) continue;
		
		//multiple cookies with the same name is passed as an array, therefore value has to be iterated.
		foreach( (array) $cookie_value as $multi_key => $multi_value ){

			$stored_value = is_full_value_stored( $key,$config ) ? $multi_value : get_truncated_value( $multi_value );
			
			$result_key = $multi_key === 0 ? $key : "{$key}_{$multi_key}";
			
            $result[$result_key] = $stored_value;

		}

	}

	return $result??[]; 
}

function get_truncated_value( $cookie_value ){

	if( strlen( $cookie_value ) < 6 ) return $cookie_value; 

	return substr( $cookie_value, 0, 5 )."...";
}

function is_full_value_stored( $key, $config ){

	return !empty( $config['cookies_keys_full_value'] ) && in_array( $key, $config['cookies_keys_full_value'] );
}

function is_cookie_key_excluded_string( $key ){
	
	return arr_contains( $key,['wordpress_logged_in','nonce'] );

}
function get_cookie_username( $cookie_value ){

	return get_str_before( $cookie_value, '|' );

}

function get_str_before( $string, $before_char ){

	return str_contains( $string, $before_char ) ? substr( $string, 0, strpos( $string, $before_char ) ) : $string;
}

