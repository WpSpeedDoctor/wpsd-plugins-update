<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

// 0=> error code
// 1=> error string

function record_php_errors(){

	global $wpsd_debug_errors;

	if( empty($wpsd_debug_errors) ) return;

	$db_status = create_sqlite_db();

	if(!$db_status) return;
	
	$db = new \SQLite3( get_db_filepath() );

	$db->exec('PRAGMA journal_mode = WAL;');

	$db->busyTimeout(5000);

	if (!$db) return;

	$timestamp = get_timestamp();

	$daytime = date('Y-m-d H:i:s', (int) $timestamp );

	$meta_id = store_event_meta( $db, $daytime, $timestamp );

	$db->exec('BEGIN TRANSACTION');

	$stmt = $db->prepare('INSERT INTO error_log (meta_id, daytime, code, error) VALUES (:meta_id, :daytime, :code, :error)');

	foreach( $wpsd_debug_errors as $error_event ){

		$error_code = $error_event[0];

		$error_string = $error_event[1];

		$stmt->bindValue(':meta_id', $meta_id, SQLITE3_INTEGER);

		$stmt->bindValue(':daytime', $daytime, SQLITE3_TEXT);

		$stmt->bindValue(':code', $error_code, SQLITE3_INTEGER);

		$stmt->bindValue(':error', $error_string, SQLITE3_TEXT);

		$stmt->execute();
	}

	$db->exec('END TRANSACTION');

	$db->close();
	
}



function store_event_meta( $db, $daytime, $timestamp ){

	$meta = get_php_error_metadata( $timestamp );

	$query = <<<SQL
INSERT INTO error_meta ( meta )
VALUES ( :meta);
SQL;

	$stmt = $db->prepare($query);

	if (!$stmt) return false;

	$stmt->bindValue(':meta', $meta, SQLITE3_TEXT);

	$result = $stmt->execute();

	if (!$result) return false;

	$meta_id = $db->lastInsertRowID();

	return $meta_id;

}


function get_store_events_sql($data) {

	$daytime = date('Y-m-d H:i:s', microtime(true));

	$values = array_map(function($entry) use ($daytime) {
		if (!isset($entry['code'], $entry['error'], $entry['meta'])) return false;

		$code = (int) $entry['code'];
		$error = SQLite3::escapeString($entry['error']);
		$meta = SQLite3::escapeString($entry['meta']);

		return "('$daytime', $code, '$error', '$meta')";
	}, $data);

	$values = array_filter($values);

	if (empty($values)) return false;

	$values_string = implode(',', $values);

	$query = <<<SQL
	INSERT INTO error_log (daytime, code, error, meta)
	VALUES $values_string;
	SQL;

	return $query;
}


function the_line_with_error( $last_error ){

	if( !is_php_error_file_valid_filepath( $last_error ) ) return '';

	$php_error_line = get_file_line( $last_error['file'], (int) $last_error['line'] );

	[$message,$stack_trace ]= explode( 'Stack trace:', $last_error['message']);

	echo
<<<HTML

Line with error:


$php_error_line

Type: {$last_error['type']}

Message: {$message}

File: {$last_error['file']}

Line: {$last_error['line']}

Stack trace: $stack_trace



HTML;

}

function is_php_error_file_valid_filepath( $last_error ){

	return 
	
		file_exists( $last_error['file']??'' ) &&
			
		is_readable( $last_error['file']??'' ) &&
		
		is_numeric( $last_error['line']??false );
}

function get_file_line( $filename, $line_number ) {

	$handle = fopen( $filename, 'r' );
	
	if (!$handle ) return 'N/A';

	$current_line = 1;

	while (( $line = fgets( $handle ) ) !== false ) {

		if ( $current_line == $line_number ) {
		
			fclose( $handle );
		
			return $line;
		}
		
		$current_line++;
	}

	fclose( $handle );
	
	return 'N/A';
}




function get_sanitized_uri(){

	$uri = $_SERVER['REQUEST_URI']??$_SERVER['PHP_SELF']??'N/A';

	if( empty($_SERVER['QUERY_STRING']) || !str_contains( $_SERVER['QUERY_STRING'],'pass' ) ) return $uri;

	return preg_replace_callback('/(pass(?:word)?=)[^&]*/i', function ($matches) {
        return $matches[1] . '***removed***';
    }, $uri);
}


function get_php_error_metadata( $timestamp ){
	
	$settings = get_debug_settings();
	
	$result = get_logged_in_user_from_cookies();

	$result .= get_server_superglobal( $settings );
	
	$result .= get_sanitized_post_superglobal($settings);

	$result .= get_sanitized_cookies_superglobal( $settings );

	return "{$result}\nTimestamp: {$timestamp}";
			
}

function get_timestamp(){
	
	if( !isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ) return defined('WP_START_TIMESTAMP') ? WP_START_TIMESTAMP : microtime(true); 
	
	//sometimes server float time is 9999999999 or 0

	$server_timestamp = (float) $_SERVER['REQUEST_TIME_FLOAT'];

	if( $server_timestamp != 0 && $server_timestamp < 3000000000 ) return $server_timestamp;
	
}


function get_logged_in_user_from_cookies( ){

	foreach( $_COOKIE??[] as $key => $value ) {

		if( str_starts_with( $key,'wordpress_logged_in_' ) ) {
			
			return 'Username: '.get_cookie_username($value).PHP_EOL;
			
		}
	}
		
	return '';
}


//call if Fatal PHP error doesn't show the message
function display_fatal_error_data( ){

	$last_error = error_get_last();

	if( !is_fatal_error($last_error) || !is_error_displayed() ) return;
	
	?>
	<style type="text/css">
	@media (prefers-color-scheme: dark ) {
		html {
			background: #222!important;
		}
		body#error-page {
			background: #333;
		}
		body#error-page {
			background: #333;
			color: #ccc;
			font-size: 20px;
		}
	}
	</style>
	<div style="white-space: break-spaces">
	<?php

	the_line_with_error( $last_error ).'<br>';

	?></div><?php
	

}


function is_fatal_error( $last_error ){
	
	switch( intval( $last_error['type']??0 ) ){

		case 1:
		case 4:
		case 16:
		case 64:
            
			return true;
        	break;

		default:
            return false;
        break;
	}
	
}


function get_sanitized_post_superglobal( $settings ){

	if ( empty( $_POST ) || !$settings['post'] ) return '';

	$result = '';

	foreach( array_keys( $_POST ) as $key ){

		switch(true){

			case str_contains($key, 'pass' ):
			case str_contains($key, 'nonce' ):
				$value = '***';
				break;
			default:
			    $value = sanitize_text_field( $_POST[$key] );
				break;
		}

		$result .= "$key => {$value}\n";
	}

	return $result === '' ? '' : "\nPOST:\n$result"; 
}

function get_server_superglobal( $settings ){

	if( !$settings['server'] ) return '';

	$result = '';

	foreach( $settings['server_keys'] as $key ){

		if( !isset( $_SERVER[$key] ) ) continue;

		$result .= $key === 'REQUEST_URI' ? 'REQUEST_URI => '.get_sanitized_uri()."\n" : "$key => {$_SERVER[$key]}\n";
			
	}

	return $result === '' ? '' : "\nSERVER:\n$result"; 
}

function get_sanitized_cookies_superglobal( $settings ){
	
	if( empty( $_COOKIE ) || !$settings['cookies'] ) return '';

	$result = '';

	foreach( $_COOKIE as $key => $cookie_value ){

		if( is_cookie_key_excluded_string( $key ) ) continue;
		
		//multiple cookies with the same name is passed as an array, therefore value has to be iterated.
		foreach( (array) $cookie_value as $multi_key => $multi_value ){

			$stored_value = is_full_value_stored( $key,$settings ) ? $multi_value : get_truncated_value( $multi_value );
			
			$result_key = $multi_key === 0 ? $key : "{$key}_{$multi_key}";
			
            $result .= "$result_key => $stored_value\n";

		}

	}

	return $result === '' ? '' : "\nCookies:\n$result"; 
}

function get_truncated_value( $cookie_value ){

	if( strlen( $cookie_value ) < 6 ) return $cookie_value; 

	return substr( $cookie_value, 0, 5 )."...";
}

function is_full_value_stored( $key, $settings ){

	return !empty( $settings['cookies_keys_full_value'] ) && in_array( $key, $settings['cookies_keys_full_value'] );
}

function is_cookie_key_excluded_string( $key ){

	switch( true ){

		case str_contains( $key, 'wordpress_logged_in'):
		case str_contains( $key, 'nonce'):
			return true;
			break;
	
		default:
			return false;

	}
}

function get_cookie_username( $cookie_value ){

	return get_str_before( $cookie_value, '|' );

}

function get_str_before( $string, $before_char ){

	return str_contains( $string, $before_char ) ? substr( $string, 0, strpos( $string, $before_char ) ) : $string;
}

