<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

set_php_error_reporting();

set_error_handler( __NAMESPACE__.'\error_handler');

register_shutdown_function( __NAMESPACE__.'\store_php_fatal_error');

define('QM_DISABLE_ERROR_HANDLER',true);


//some plugins change error reporting, this will re-assign the error_reporting
// add_action('plugins_loaded', __NAMESPACE__.'\\error_handling_main', PHP_INT_MAX );

// add_action('init', __NAMESPACE__.'\error_handling_main', PHP_INT_MAX );

// add_action('wp', __NAMESPACE__.'\error_handling_main', PHP_INT_MAX );



function store_php_fatal_error(){
	
	global $EZSQL_ERROR;
	
	if( !empty($EZSQL_ERROR) ) {
		
		foreach( $EZSQL_ERROR as $sql_errors ){
			// 32768 is arbitrary code for database error.
			error_handler( 32768 , "{$sql_errors['error_str']}\n\n{$sql_errors['query']}" , '', '' );
			
		}
	}

	if( !isset(error_get_last()['type']) ) return;

	switch( error_get_last()['type'] ){

		case E_ERROR:
		case E_PARSE:
		case E_CORE_ERROR:
		case E_COMPILE_ERROR:
		case E_USER_ERROR:

			$last_error = error_get_last();

			error_handler( $last_error['type'], $last_error['message'], $last_error['file'], $last_error['line'] );
			break;
	}
	
}

function error_handler( $error_code, $error_string, $error_file, $error_line ){
	
	$settings = get_debug_settings();
	
	if( in_array( (int) $error_code , $settings['excluded_errors']??[] ) ) return;
	
	global $wpsd_debug_errors;

	// 0=> error code
	// 1=> (string) error data and stack 
	$stored_message = $error_string;

	if( !empty($error_file) && !str_contains($error_string, $error_file ) ) $stored_message .= "\n\n{$error_file}:{$error_line}";

	if( !str_contains($error_string,'Stack trace:') && $error_code !== 32768 ) $stored_message .= "\n\n".get_stack(new \Exception);
	
	$wpsd_debug_errors[] = [
		
		0 => $error_code,

		1 => remove_abspath( $stored_message ),

	];

	if(defined('WPSD_DEBUG_SHUTDOWN') ) return false;
	
	define('WPSD_DEBUG_SHUTDOWN', true );

	register_shutdown_function( __NAMESPACE__.'\debug_shutdown_main' );

	return false;

}

function get_stack($exception){
	
	$stack = remove_abspath( $exception->getTraceAsString() );

	$start = strpos($stack, "\n") + 1;

	return substr($stack, $start, strrpos($stack, "\n") - $start);

}

function remove_abspath( $string ){

	if( PHP_OS !== 'WINNT' ) return str_replace( ABSPATH, '/', $string);

	$string = str_replace('\\','/', $string );

	$abspath = str_replace('\\','/', ABSPATH );
	
	return str_replace( $abspath, '/', $string);
}

function debug_shutdown_main(){

	require_once __DIR__.'/functions-error-handler.php';

	record_php_errors();

    display_fatal_error_data();
}

function set_php_error_reporting(){

	ini_set('log_errors', '1' );

	ini_set('ignore_repeated_errors', '1' );
	
	ini_set('ignore_repeated_source', '1' );
	
	error_reporting( get_wpsd_option( 'wpsd-php-debug-error-reporting') );

	activate_display_errors();
	
	//some hostings don't allow to change `error_log` PHP settings
	if( get_wpsd_option( 'wpsd-php-ini-set-allowed') ){

			ini_set( 'error_log', get_error_log_filename() );
		
	}

}

function activate_display_errors(){

	$display_error = is_error_displayed();

	ini_set('display_errors', $display_error );

	ini_set('display_startup_errors', $display_error );
}

/**
 * @return bool True if cookie 'php-debug' is set or is localhost
 */
function is_error_displayed(){
	
	return isset($_COOKIE['wpsd-debug-display-errors']) &&
	
			is_screen_output_allowed() &&
			
			$_COOKIE['wpsd-debug-display-errors'] == substr( get_log_dir_string(),6,20);

}

function is_screen_output_allowed(){
	
	switch(true){

		case str_contains($_SERVER['REQUEST_URI'], 'ajax'):
		case str_contains($_SERVER['REQUEST_URI'], 'cron'):
		case str_contains($_SERVER['REQUEST_URI'], '/wp-json/'):
			return false;
        default:
		    return true;

	}
	
}