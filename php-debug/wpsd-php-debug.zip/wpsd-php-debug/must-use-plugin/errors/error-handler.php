<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

require_once WP_PLUGIN_DIR.'/wpsd-php-debug/includes/universal-functions.php';

set_error_handler( __NAMESPACE__.'\error_handler');

register_shutdown_function( __NAMESPACE__.'\store_php_fatal_error');

set_php_error_reporting();

//some plugins change error reporting, this will re-assign the error_reporting
// add_action('plugins_loaded', __NAMESPACE__.'\\set_php_error_reporting_code', PHP_INT_MAX );

// add_action('init', __NAMESPACE__.'\set_php_error_reporting_code', PHP_INT_MAX );

// add_action('wp', __NAMESPACE__.'\set_php_error_reporting_code', PHP_INT_MAX );

function store_php_fatal_error(){
	
	global $EZSQL_ERROR;
	
	if( !empty($EZSQL_ERROR) ) {
		
		foreach( $EZSQL_ERROR as $sql_errors ){
			
			error_handler( 32768 , "{$sql_errors['error_str']}\n\n{$sql_errors['query']}" , '', '' );
			
		}
	}

	if( !isset(error_get_last()['type']) ) return;

	switch( error_get_last()['type'] ){

		case E_ERROR:
		case E_PARSE:
		case E_CORE_ERROR:
		case E_COMPILE_ERROR:
		case E_USER_ERROR:

			$last_error = error_get_last();

			error_handler( $last_error['type'], $last_error['message'], $last_error['file'], $last_error['line'] );
			break;
	}
	
}

function error_handler( $error_code, $error_string, $error_file, $error_line ){
	
	$settings = get_debug_settings();
	
	if( in_array( (int) $error_code , $settings['excluded_errors'] ) ) return;
	
	global $wpsd_debug_errors;

	// 0=> error code
	// 1=> (string) error data and stack 
	$stored_message =$error_string;

	if( !empty($error_file) && !str_contains($error_string, $error_file ) ) $stored_message .= "\n\n{$error_file}:{$error_line}";

	if( !str_contains($error_string,'Stack trace:') && $error_code !== 32768 ) $stored_message .= "\n\n".get_stack(new \Exception);

	$wpsd_debug_errors[] = [
		
		0 => $error_code,

		1 => remove_abspath( $stored_message ),

	];

	if(defined('WPSD_DEBUG_SHUTDOWN') ) return false;
	
	define('WPSD_DEBUG_SHUTDOWN', true );

	register_shutdown_function( __NAMESPACE__.'\debug_shutdown_main' );

	return false;


	//continue here
	// if ( empty( error_get_last() ) ) return;
	
	

	// if( empty(WP_PHP_DEBUG_LAST_ERROR['type']) || in_array( (int) $error_code , $settings['excluded_errors']??[] ) ) return;

    // require_once __DIR__.'/functions-error-handler.php';

    // record_php_errors_in_custom_format();

	//  return false;
}

function get_stack($exception){
	
	$stack = remove_abspath( $exception->getTraceAsString() );

	$start = strpos($stack, "\n") + 1;

	return substr($stack, $start, strrpos($stack, "\n") - $start);

}

function remove_abspath( $string ){

	if( PHP_OS !== 'WINNT' ) return str_replace( ABSPATH, '/', $string);

	$string = str_replace('\\','/', $string );

	$abspath = str_replace('\\','/', ABSPATH );
	
	return str_replace( $abspath, '/', $string);
}

function get_debug_settings(){
		
	static $settings = false;

	if( $settings !== false ) return $settings;

	return $settings = json_decode( get_option( 'wpsd-php-debug-settings' ), true );

}

//MARK: shutdwn_main
function debug_shutdown_main(){

	require_once __DIR__.'/functions-error-handler.php';

	record_php_errors();

    display_fatal_error_data();
}

function set_php_error_reporting(){

	ini_set('log_errors', '1' );

	ini_set('ignore_repeated_errors', '1' );
	
	ini_set('ignore_repeated_source', '1' );
	
	activate_display_errors();
	
	switch( get_option( 'wpsd-php-ini-set-allowed') ){

		case '1':
			//some hosting doesn't allow to change filepath to error log.
			ini_set( 'error_log', get_error_log_filename() );
			break;
		case false:

			require_once ABSPATH.'/wp-content/plugins/wpsd-php-debug/admin/setup.php';
			
			create_default_plugin_settings();

			break;
		
	}
	
	set_php_error_reporting_code();

}

function set_php_error_reporting_code(){

	error_reporting( get_option( 'wpsd-php-debug-error-reporting') );
}

function activate_display_errors(){

	$display_error = is_error_displayed();

	ini_set('display_errors', $display_error );

	ini_set('display_startup_errors', $display_error );
}

function get_error_log_filename(){

		$dir = WP_CONTENT_DIR;

		$folder_name = get_option('wpsd-php-debug-dir');
		
		$filename_base = get_server_last_ip_number();

		$date = date("Y-m-d");

		return "{$dir}{$folder_name}{$date}-ip{$filename_base}-error.log";
}



/**
 * @return bool True if cookie 'php-debug' is set or is localhost
 */
function is_error_displayed(){
	
	return isset($_COOKIE['wpsd-debug-display-errors']) &&
	
			is_allowed_display_of_error() &&
			
			$_COOKIE['wpsd-debug-display-errors'] == substr( get_option('wpsd-php-debug-dir'),6,20);

}

function is_allowed_display_of_error(){
	
	return !arr_contains( $_SERVER['REQUEST_URI']??' ', ['ajax','cron','wp-json',' '] );
}