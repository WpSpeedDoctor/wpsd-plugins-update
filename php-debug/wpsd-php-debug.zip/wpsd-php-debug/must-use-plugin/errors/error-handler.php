<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

require_once WP_PLUGIN_DIR.'/wpsd-php-debug/includes/universal-functions.php';


register_shutdown_function( __NAMESPACE__.'\store_error_data_main' );

register_shutdown_function( __NAMESPACE__.'\display_fatal_error_data_main' );

set_php_error_reporting();


function store_error_data_main(){
	
	if ( empty( error_get_last() )
	
	// || (error_get_last()['type']??'' ) == '8192' //exclude deprecated errors
	
	) return;

	define( 'WP_PHP_DEBUG_LAST_ERROR', error_get_last() );
	
    require_once __DIR__.'/functions-error-handler.php';

    record_php_errors_in_custom_format();

}

function display_fatal_error_data_main(){

    if(	!defined('WP_PHP_DEBUG_LAST_ERROR') ) return;

    require_once __DIR__.'/functions-error-handler.php';

    display_fatal_error_data();
}

function set_php_error_reporting(){
	
	//recording all errors should be declared in error_reporting because metadata will be generated anyway
	//and it will mess up the assigning metadata to errors.
	
	error_reporting(E_ALL); 
	// error_reporting(E_ALL ^ E_WARNING); //no warning recorded
	// error_reporting(E_ALL); // error_reporting(E_ALL & ~E_DEPRECATED);
	
	ini_set("log_errors", 'On' );

	ini_set('ignore_repeated_errors', '1' );
	
	ini_set('ignore_repeated_source', '1' );
	
	activate_display_errors();
	
	if( !is_ini_set_allowed() ) return;

	ini_set('error_log', get_error_log_filename() );
	
}

function activate_display_errors(){

	$display_error = is_error_displayed();

	ini_set('display_errors', $display_error );

	ini_set('display_startup_errors', $display_error );
}


/**
 * Returns the path and filename of the error log file for the current host and IP address.
 *
 * @param string $type The type of log file to return, "fatal" or "none-fatal", default is for default PHP error log. 
 * @return string The path and filename of the log file.
 */

 function get_error_log_filename( $type='error' ){

		$dir = WP_CONTENT_DIR;

		$folder_name = get_option('wpsd-php-debug-dir');
		
		$filename_base = get_log_filename_base();

		$date = date("Y-m-d");

		return "{$dir}{$folder_name}{$date}-ip{$filename_base}-{$type}.log";
}


/**
 * Returns string of log file based on server IP address
 * 
 * @return string last part of IP address
 */

function get_log_filename_base(){

	if( empty($_SERVER['SERVER_ADDR']) ) return 'null';

	$separator = str_contains( $_SERVER['SERVER_ADDR'] ,'.') ? '.' : ':';

	$start_last_chars = strrpos( $_SERVER['SERVER_ADDR'], $separator ) + 1;

	return substr( $_SERVER['SERVER_ADDR'], $start_last_chars );
 
}

/**
 * @return bool True if cookie 'php-debug' is set or is localhost
 */
function is_error_displayed(){
		
	return isset($_COOKIE['php-debug']) && is_allowed_display_of_error();

}

function is_allowed_display_of_error(){

	return !arr_contains( $_SERVER['REQUEST_URI']??'', ['ajax','cron','wp-json'] );
}