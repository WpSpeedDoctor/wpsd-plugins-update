<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

defined( 'WPSD_DEBUG_DIR') || define( 'WPSD_DEBUG_DIR', __DIR__.'/' );

defined('WPSD_DEBUG_VER') || define('WPSD_DEBUG_VER','1.1.20');

