<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

// if( !class_exists('SQLite3') ) return;

function record_event_meta( $db, $meta ) {

	$query = <<<SQL
INSERT INTO error_meta (meta)
VALUES (:meta);
SQL;

	$stmt = $db->prepare($query);

	if (!$stmt){

		// error_log("PHP Debug couldn't prepare SQLite statement for metadata table.");
		
		return false;
	}

	$stmt->bindValue(':meta', $meta, SQLITE3_TEXT);
		
	$result = $stmt->execute();
	
	if( !$result ){

		// error_log("PHP Debug couldn't write metadata into SQLite database");
		
		return false;
	}

	$meta_id = $db->lastInsertRowID();
		
	return $meta_id;
}

function get_debug_settings(){

	static $settings;

	if( !$settings ){

		$settings = get_wpsd_option( 'wpsd-debug-settings' );
	}
	
	return $settings; 

}

/**
 * The file path to the SQLite database or an empty string if SQLite3 is not available or the file does not exist.
 * @return string 
*/

function get_db_filepath() {

	static $db_filepath;
	
	switch(true) {

		case $db_filepath:
			break;

		case !class_exists('SQLite3'):
		case !($db_filepath_string = get_db_filepath_string()):

			$db_filepath = '';
			break;

		default:
				$db_filepath = $db_filepath_string;
			break;
	}
	
	return $db_filepath;
}

function get_db_filepath_string(){

	static $filepath;
	
	if( !$filepath ){
		
		$ip = get_server_last_ip_number();
		
		$multisite_string = is_multisite() ? '-site'.get_current_blog_id() : '';
		
		$filepath = get_db_dir()."error-log-ip{$ip}{$multisite_string}.sqlite";
		
	}

	return $filepath;
}

/**
 * @return string '/database/wpsd-debug/'
 */
function get_log_dir_string(){

	return '/database/wpsd-debug/';
	
}

/**
 * @return string WP_CONTENT_DIR.'/database/wpsd-debug/'
 */

 function get_db_dir(){

	return WP_CONTENT_DIR.get_log_dir_string();
}

// function get_plugin_strings(){

// 	static $strings;

// 	if( !$strings ){

// 		$strings = (object) [

// 			'db_dir'		=> 'database',

// 			'plugin_db_dir'	=> 'wpsd-debug',

// 			'fragments_dir'	=> 

// 		];

// 	}

// 	return $strings;
// }


function update_wpsd_option( $name, $value, $autoload = 'off' ){

	return is_multisite() ? update_site_option( $name, $value ) : update_option( $name, $value, $autoload);
}

function get_wpsd_option($name){

	return is_multisite() ? get_site_option( $name ) : get_option( $name );
}

function get_wpsd_transient($name){

	return is_multisite() ? get_site_transient( $name ) : get_transient( $name );
}

function set_wpsd_transient( $name, $value, $timeout = 30 * MINUTE_IN_SECONDS ){ //default 30 minutes

	return is_multisite() ? set_site_transient( $name, $value, $timeout ) : set_transient( $name, $value, $timeout);
}


function get_db_prefix(){

	static $prefix;

	if( $prefix ) return $prefix;

	global $wpdb;

	$prefix = is_multisite() ? $wpdb->base_prefix : $wpdb->prefix;

	return $prefix;
}


function get_error_log_filename(){

	static $this_server_error_log;

	if( !$this_server_error_log ) {
	
		$ip = get_server_last_ip_number();
		
		$date = date("Y-m-d");
		
		$multisite_string = is_multisite() ? '-site'.get_current_blog_id() : '';
		
		$this_server_error_log = get_db_dir()."{$date}-ip{$ip}{$multisite_string}-error.log";
	}

	return $this_server_error_log;

}

/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_wpsd_transient('wpsd-debug-nonce');

	if( !$nonce ){
		
		$nonce = bin2hex(random_bytes(10));
		
		set_wpsd_transient('wpsd-debug-nonce',$nonce, HOUR_IN_SECONDS ); 
	}

	return $nonce;
}

/**
 * @return bool 
 * - true when file exists or is successfully created
 * - false if could not be created.
 */

function create_sqlite_db($db_filepath=false){

	if( !class_exists('SQLite3') ) {

		error_log('Could not create SQLite database, SQLite3 extension is not installed');

		return false;
	}

	if( !$db_filepath ){

		$db_filepath = get_db_filepath_string();
	}
	
	if( file_exists($db_filepath) ) return true;

	try{

		$db = new \SQLite3($db_filepath);

		$db->enableExceptions( true );
		
	} catch ( \Exception $e ){

		error_log('PHP DEBUG: Unable to create SQLite database, probably writing to the filesystem');
	
		return false;
	}

	$query = <<<SQL
CREATE TABLE error_log (
event_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta_id INTEGER NOT NULL,
daytime TEXT NOT NULL,
code INTEGER NOT NULL,
error TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_log`');

		return false;
	}

	$query = <<<SQL
CREATE TABLE error_meta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_meta`');

		return false;
	}

	$db->close();

	return true;

}


/**
 * Returns last digit of IPv4 or IPv6 or `null`
 * 
 * @return string last part of IP address
 */

function get_server_last_ip_number() {

    static $server_number;
    
    switch(true) {

        case $server_number:
            break;
            
        case empty($_SERVER['SERVER_ADDR']):
        
			$server_number = 'null';
        
			break;
            
        default:

            $ip_separator_position = strrpos($_SERVER['SERVER_ADDR'], '.') ?: strrpos($_SERVER['SERVER_ADDR'], ':');
        
			$server_number = substr($_SERVER['SERVER_ADDR'], $ip_separator_position + 1);
        
			break;
    }
    
    return $server_number;
}

function get_error_type_strings(){
	
	return [
		0 =>		esc_html__('All','wpsd-php-debug'),
		32768 =>	esc_html__('Database error','wpsd-php-debug'),
		1 =>		esc_html__(	'E_FATAL_ERROR','wpsd-php-debug'),
		2 =>		esc_html__(	'E_WARNING','wpsd-php-debug'),
		4 =>		esc_html__(	'E_PARSE','wpsd-php-debug'),
		8 =>		esc_html__(	'E_NOTICE','wpsd-php-debug'),
		16 =>		esc_html__(	'E_CORE_ERROR','wpsd-php-debug'),
		32 =>		esc_html__(	'E_CORE_WARNING','wpsd-php-debug'),
		64 =>		esc_html__(	'E_COMPILE_ERROR','wpsd-php-debug'),
		128 =>		esc_html__(	'E_COMPILE_WARNING','wpsd-php-debug'),
		256 =>		esc_html__(	'E_USER_ERROR','wpsd-php-debug'),
		512 =>		esc_html__(	'E_USER_WARNING','wpsd-php-debug'),
		1024 =>		esc_html__(	'E_USER_NOTICE','wpsd-php-debug'),
		4096 =>		esc_html__(	'E_RECOVERABLE_ERROR','wpsd-php-debug'),
		8192 =>		esc_html__(	'E_DEPRECATED','wpsd-php-debug'),
		16384 =>	esc_html__('E_USER_DEPRECATED','wpsd-php-debug'),
		99999 =>	esc_html__('debl() logged value','wpsd-php-debug')
	
	];
}

/**
 * Retrieves debug cookies used for displaying errors and values.
 *
 * @return object -
 * - admin_check => '1' / null
 * - display_errors => string
 * - display_values => string
 * - display_admin_bar => string
 * - nonce => string
 */
 
function get_debug_cookies(){

	static $cookies;

	if( !$cookies ){

		$cookie_nonce = hash('fnv164',substr( NONCE_SALT, 6, 6).date('d-m'));
	
		$cookies = (object) [
			'admin_check' => 'wpsd-debug-admin-check',
			'display_errors'	=> 'wpsd-debug-error',
			'display_values'	=> 'wpsd-debug-values',
			'display_admin_bar'	=> 'wpsd-debug-admin-bar',
			'nonce' => $cookie_nonce
		];
		
	}
	
	return $cookies;
	
	// $cookies = get_debug_cookies();

	// $cookies->nonce
	// $cookies->admin_check
	// $cookies->display_errors
	// $cookies->display_values
	// $cookies->display_admin_bar
}

function get_json_vals( $htmx_values ){

	return json_encode($htmx_values, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
}