<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


if( !function_exists('str_contains') ){

/**
 * A fallback for PHP version 7.x. 
 * This fallback is not 100% compatible with PHP 8.x function "str_contains",
 * it's just compatible with my usage of "str_pos" to get the same result
 * should be used with namespace to avoid conflict with another plugins
**/
    function str_contains(string $haystack, string $needle ): bool {
 
        return strpos($haystack, $needle) !==false;
    }
}
 


/**
 * Array contains
 * @param string $haystack
 * @param array|object $needle
 * @return bool true if in any value of $haystack contains the $needle 
 */
	
function arr_contains( $haystack, $needle ){
		
	foreach ( $needle as $value) {
	
		if ( str_contains( $haystack, $value) ) return true;
		
	}
	
	return false;
}

/**
 * The file path to the SQLite database or an empty string if SQLite3 is not available or the file does not exist.
 * @return string 
*/

function get_db_filepath(){

	static $db_filepath = false;

	if( $db_filepath !== false ) return $db_filepath;

	$db_filepath_string = get_db_filepath_string();
	
	if ( !class_exists('SQLite3') || !file_exists( $db_filepath_string ) ) {
		
		$db_filepath = '';

	} else {
		
        $db_filepath = $db_filepath_string;
	}

	return $db_filepath;
}

function get_db_filepath_string(){

	static $filepath = false;
	
    if( $filepath !== false ) return $filepath;

	return $filepath = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir').'error-log-ip'.get_server_last_ip_number().'.sqlite';
}

function get_error_log_filename(){

	static $this_server_error_log = false;

	if( $this_server_error_log !== false ) return $this_server_error_log;

	$dir = WP_CONTENT_DIR;

	$folder_name = get_option('wpsd-php-debug-dir');
	
	$filename_base = get_server_last_ip_number();

	$date = date("Y-m-d");

	$this_server_error_log = "{$dir}{$folder_name}{$date}-ip{$filename_base}-error.log";

	return $this_server_error_log;

}

/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_transient('wpsd-php-debug-nonce');

	if($nonce) return $nonce;

	$nonce = bin2hex(random_bytes(10));

	set_transient('wpsd-php-debug-nonce',$nonce, HOUR_IN_SECONDS ); 

	return $nonce;
}

/**
 * @return bool 
 * - true when file exists or is successfully created
 * - false if could not be created.
 */

function create_sqlite_db(){

	if( !class_exists('SQLite3') ) {

		error_log('Could not create SQLite database, SQLite3 extension is not installed');

		return false;
	}

	$db_filepath = get_db_filepath_string();
	
	if( file_exists($db_filepath) ) return true;

	$db = new \SQLite3($db_filepath);

	if (!$db) {

		error_log('PHP DEBUG: Unable to create SQLite database, probably writing to the filesystem');

		return false;
	}
	

	$query = <<<SQL
CREATE TABLE error_log (
event_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta_id INTEGER NOT NULL,
daytime TEXT NOT NULL,
code INTEGER NOT NULL,
error TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_log`');

		return false;
	}

	$query = <<<SQL
CREATE TABLE error_meta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_meta`');

		return false;
	}

	$db->close();

	return true;

}


/**
 * Returns string of log file based on server IP address
 * 
 * @return string last part of IP address
 */

function get_server_last_ip_number(){

	static $server_number = false;

	if( $server_number !== false ) return $server_number;

	if( empty($_SERVER['SERVER_ADDR']) ) return $server_number = 'null';

	$pos = strrpos($_SERVER['SERVER_ADDR'], '.');

    if ($pos === false) $pos = strrpos($_SERVER['SERVER_ADDR'], ':');
    
	return $server_number = substr($_SERVER['SERVER_ADDR'], $pos + 1);

}

function get_error_type_strings(){
	
	return [
		0 =>		esc_html__('All','wpsd-php-debug'),
		32768 =>	esc_html__('Database error','wpsd-php-debug'),
		1 =>		esc_html__(	'E_FATAL_ERROR','wpsd-php-debug'),
		2 =>		esc_html__(	'E_WARNING','wpsd-php-debug'),
		4 =>		esc_html__(	'E_PARSE','wpsd-php-debug'),
		8 =>		esc_html__(	'E_NOTICE','wpsd-php-debug'),
		16 =>		esc_html__(	'E_CORE_ERROR','wpsd-php-debug'),
		32 =>		esc_html__(	'E_CORE_WARNING','wpsd-php-debug'),
		64 =>		esc_html__(	'E_COMPILE_ERROR','wpsd-php-debug'),
		128 =>		esc_html__(	'E_COMPILE_WARNING','wpsd-php-debug'),
		256 =>		esc_html__(	'E_USER_ERROR','wpsd-php-debug'),
		512 =>		esc_html__(	'E_USER_WARNING','wpsd-php-debug'),
		1024 =>		esc_html__(	'E_USER_NOTICE','wpsd-php-debug'),
		2048 =>		esc_html__(	'E_STRICT','wpsd-php-debug'),
		4096 =>		esc_html__(	'E_RECOVERABLE_ERROR','wpsd-php-debug'),
		8192 =>		esc_html__(	'E_DEPRECATED','wpsd-php-debug'),
		16384 =>	esc_html__('E_USER_DEPRECATED','wpsd-php-debug'),
		99999 =>	esc_html__('debl() logged value','wpsd-php-debug')
	
	];
}