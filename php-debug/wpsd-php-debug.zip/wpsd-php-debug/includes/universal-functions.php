<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

// if( !class_exists('SQLite3') ) return;

if( !function_exists('str_contains') ){

/**
 * A fallback for PHP version 7.x. 
 * This fallback is not 100% compatible with PHP 8.x function "str_contains",
 * it's just compatible with my usage of "str_pos" to get the same result
 * should be used with namespace to avoid conflict with another plugins
**/
	function str_contains(string $haystack, string $needle ): bool {

		return strpos($haystack, $needle) !==false;
	}
}

function is_file_write_available($filepath, $max_retries = 100 ){

	if( !file_exists($filepath) || !is_writable($filepath) ) return false;

	$retries = 0;

	while($retries < $max_retries){
		$handle = fopen($filepath, 'c');

		if($handle && flock($handle, LOCK_EX | LOCK_NB)){
			flock($handle, LOCK_UN);
			fclose($handle);
			return true;
		}

		if($handle){
			fclose($handle);
		}

		usleep(1000); //1ms delay

		$retries++;
	
	}

	return false;
}

function record_event_meta( $db, $meta ) {

	$query = <<<SQL
INSERT INTO error_meta (meta)
VALUES (:meta);
SQL;

	$stmt = $db->prepare($query);

	if (!$stmt){

		// error_log("PHP Debug couldn't prepare SQLite statement for metadata table.");
		
		return false;
	}

	$stmt->bindValue(':meta', $meta, SQLITE3_TEXT);
		
	$result = $stmt->execute();
	
	if( !$result ){

		// error_log("PHP Debug couldn't write metadata into SQLite database");
		
		return false;
	}

	$meta_id = $db->lastInsertRowID();
		
	return $meta_id;
}

function get_debug_settings(){

	static $settings = null;

	if( $settings !== null ) return $settings;
	
	return $settings = get_wpsd_option( 'wpsd-php-debug-settings' );

}

/**
 * The file path to the SQLite database or an empty string if SQLite3 is not available or the file does not exist.
 * @return string 
*/

function get_db_filepath(){

	static $db_filepath = false;

	if( $db_filepath !== false ) return $db_filepath;

	$db_filepath_string = get_db_filepath_string();
	
	if ( !class_exists('SQLite3') || !file_exists( $db_filepath_string ) ) {
		
		$db_filepath = '';

	} else {
		
		$db_filepath = $db_filepath_string;
	}

	return $db_filepath;
}

function get_db_filepath_string(){

	static $filepath = false;
	
	if( $filepath !== false ) return $filepath;

	$ip = get_server_last_ip_number();

	$multisite_string = is_multisite() ? '-site'.get_current_blog_id() : '';

	$log_dir_string = get_log_dir_string();

	return $filepath = WP_CONTENT_DIR."{$log_dir_string}error-log-ip{$ip}{$multisite_string}.sqlite";
}

function get_log_dir_string(){

	static $debug_dir = false;

	if( $debug_dir !== false ) return $debug_dir;

	$debug_dir = get_wpsd_option( 'wpsd-php-debug-dir' );

	return $debug_dir;
	
}

function update_wpsd_option( $name, $value, $autoload = 'off' ){

	return is_multisite() ? update_site_option( $name, $value ) : update_option( $name, $value, $autoload);
}

function get_wpsd_option($name){

	return is_multisite() ? get_site_option( $name ) : get_option( $name );
}

function get_wpsd_transient($name){

	return is_multisite() ? get_site_transient( $name ) : get_transient( $name );
}

function set_wpsd_transient( $name, $value, $timeout = 30 * MINUTE_IN_SECONDS ){ //default 30 minutes

	return is_multisite() ? set_site_transient( $name, $value, $timeout ) : set_transient( $name, $value, $timeout);
}


function get_db_prefix(){

	$prefix = false;

	if( $prefix !== false ) return $prefix;

	global $wpdb;

	$prefix = is_multisite() ? $wpdb->base_prefix : $wpdb->prefix;

	return $prefix;
}


function get_error_log_filename(){

	static $this_server_error_log = false;

	if( $this_server_error_log !== false ) return $this_server_error_log;

	$dir = WP_CONTENT_DIR;

	$folder_name = get_log_dir_string();
	
	$ip = get_server_last_ip_number();

	$date = date("Y-m-d");

	$multisite_string = is_multisite() ? '-site'.get_current_blog_id() : '';

	$this_server_error_log = "{$dir}{$folder_name}{$date}-ip{$ip}{$multisite_string}-error.log";

	return $this_server_error_log;

}

/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_wpsd_transient('wpsd-php-debug-nonce');

	if($nonce) return $nonce;

	$nonce = bin2hex(random_bytes(10));

	set_wpsd_transient('wpsd-php-debug-nonce',$nonce, HOUR_IN_SECONDS ); 

	return $nonce;
}

/**
 * @return bool 
 * - true when file exists or is successfully created
 * - false if could not be created.
 */

function create_sqlite_db($db_filepath=false){

	if( !class_exists('SQLite3') ) {

		error_log('Could not create SQLite database, SQLite3 extension is not installed');

		return false;
	}

	if( !$db_filepath ){

		$db_filepath = get_db_filepath_string();
	}
	
	if( file_exists($db_filepath) ) return true;

	try{

		$db = new \SQLite3($db_filepath);
	} catch ( \Exception $e ){

		error_log('PHP DEBUG: Unable to create SQLite database, probably writing to the filesystem');
	
		return false;
	}

	$query = <<<SQL
CREATE TABLE error_log (
event_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta_id INTEGER NOT NULL,
daytime TEXT NOT NULL,
code INTEGER NOT NULL,
error TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_log`');

		return false;
	}

	$query = <<<SQL
CREATE TABLE error_meta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
meta TEXT NOT NULL
);
SQL;

	if (!$db->exec($query)) {

		$db->close();

		// error_log( 'PHP DEBUG: Unable to create SQLite table `error_meta`');

		return false;
	}

	$db->close();

	return true;

}


/**
 * Returns string of log file based on server IP address
 * 
 * @return string last part of IP address
 */

function get_server_last_ip_number(){

	static $server_number = false;

	if( $server_number !== false ) return $server_number;

	if( empty($_SERVER['SERVER_ADDR']) ) return $server_number = 'null';

	$pos = strrpos($_SERVER['SERVER_ADDR'], '.') ?:  strrpos($_SERVER['SERVER_ADDR'], ':') ;

	return $server_number = substr($_SERVER['SERVER_ADDR'], $pos + 1);

}

function get_error_type_strings(){
	
	return [
		0 =>		esc_html__('All','wpsd-php-debug'),
		32768 =>	esc_html__('Database error','wpsd-php-debug'),
		1 =>		esc_html__(	'E_FATAL_ERROR','wpsd-php-debug'),
		2 =>		esc_html__(	'E_WARNING','wpsd-php-debug'),
		4 =>		esc_html__(	'E_PARSE','wpsd-php-debug'),
		8 =>		esc_html__(	'E_NOTICE','wpsd-php-debug'),
		16 =>		esc_html__(	'E_CORE_ERROR','wpsd-php-debug'),
		32 =>		esc_html__(	'E_CORE_WARNING','wpsd-php-debug'),
		64 =>		esc_html__(	'E_COMPILE_ERROR','wpsd-php-debug'),
		128 =>		esc_html__(	'E_COMPILE_WARNING','wpsd-php-debug'),
		256 =>		esc_html__(	'E_USER_ERROR','wpsd-php-debug'),
		512 =>		esc_html__(	'E_USER_WARNING','wpsd-php-debug'),
		1024 =>		esc_html__(	'E_USER_NOTICE','wpsd-php-debug'),
		2048 =>		esc_html__(	'E_STRICT','wpsd-php-debug'),
		4096 =>		esc_html__(	'E_RECOVERABLE_ERROR','wpsd-php-debug'),
		8192 =>		esc_html__(	'E_DEPRECATED','wpsd-php-debug'),
		16384 =>	esc_html__('E_USER_DEPRECATED','wpsd-php-debug'),
		99999 =>	esc_html__('debl() logged value','wpsd-php-debug')
	
	];
}