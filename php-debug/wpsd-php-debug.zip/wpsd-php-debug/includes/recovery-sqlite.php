<?php

namespace wpsd_php_debug;

die;

/**
 * TODO: Add data recovery to corrupted database files
 */

$broken_db_filepath = str_replace( '.sqlite','-broken.sqlite', $db_filepath);
	
$new_db_filepath = str_replace( '.sqlite','-recovered.sqlite', $db_filepath);

rename($db_filepath, $broken_db_filepath);

create_sqlite_db();

rename($db_filepath, $new_db_filepath);

create_sqlite_db();

copy_data_to_new_db($broken_db_filepath, $new_db_filepath);

unlink($broken_db_filepath);


function copy_data_to_new_db($old_db_filepath, $new_db_filepath){

	//allows more time to copy data between databases
	ini_set( 'max_execution_time','600' );

	$old_db = new \SQLite3($old_db_filepath);

	$new_db = new \SQLite3($new_db_filepath);

	$new_db->exec('PRAGMA synchronous = OFF;');
	$new_db->exec('PRAGMA journal_mode = WAL;');
	$new_db->exec('PRAGMA cache_size = 1000000;');
	$new_db->exec('PRAGMA foreign_keys = OFF;');

	copy_table_data($old_db, $new_db, 'error_log');

	copy_table_data($old_db, $new_db, 'error_meta');

	$old_db->close();

	$new_db->close();
	
}


function copy_table_data($old_db, $new_db, $table){

	$offset = 0;

	$limit = 1000;

	while(true){

		$result = $old_db->query("
			SELECT * 
			FROM $table 
			LIMIT $limit 
			OFFSET $offset
		");

		$rows_copied = 0;

		while($row = $result->fetchArray(SQLITE3_ASSOC)){

			$columns = array_keys($row);

			$values = array_map([$new_db, 'escapeString'], array_values($row));

			$columns_str = implode(', ', $columns);

			$values_str = "'" . implode("', '", $values) . "'";

			$new_db->exec("INSERT INTO $table ($columns_str) VALUES ($values_str)");

			$rows_copied++;
		}

		if($rows_copied < $limit) break;

		$offset += $limit;
	}
}
