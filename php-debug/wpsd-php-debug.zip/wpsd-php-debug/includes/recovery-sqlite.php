<?php

namespace wpsd_php_debug;

function recover_broken_sqlite_db($db_filepath){

	$broken_db_filepath = str_replace( '.sqlite','-broken.sqlite', $db_filepath);

	$new_db_filepath = str_replace( '.sqlite','-recovered-'.time().'.sqlite', $db_filepath);

	rename($db_filepath, $broken_db_filepath);
	
	$is_success = create_sqlite_db($new_db_filepath);

	if( ! $is_success ){
		return;
	}

	copy_data_to_new_db($broken_db_filepath, $new_db_filepath);
	
	unlink($broken_db_filepath);

}

function copy_data_to_new_db($old_db_filepath, $new_db_filepath){

	//allows more time to copy data between databases
	ini_set( 'max_execution_time','600' );

	$cache_size = get_sqlite_cache_size();
	
	$old_db = new \SQLite3($old_db_filepath);

	$new_db = new \SQLite3($new_db_filepath);

	$new_db->exec('PRAGMA journal_mode = OFF');

	$new_db->exec('PRAGMA synchronous = OFF');

	$new_db->exec('PRAGMA locking_mode = EXCLUSIVE');

	$new_db->exec('PRAGMA temp_store = MEMORY');

	$new_db->exec("PRAGMA cache_size = {$cache_size}");
	
	copy_table_data($old_db, $new_db, 'error_log');

	copy_table_data($old_db, $new_db, 'error_meta');

	$old_db->close();

	$new_db->close();
	
}


function copy_table_data($old_db, $new_db, $table){

	$offset = 0;

	$limit = 1000;

	while(true){

		$result = $old_db->query("
			SELECT * 
			FROM $table 
			LIMIT $limit 
			OFFSET $offset
		");

		$rows_copied = 0;

		while($row = $result->fetchArray(SQLITE3_ASSOC)){

			$columns = array_keys($row);

			$values = array_map([$new_db, 'escapeString'], array_values($row));

			$columns_str = implode(', ', $columns);

			$values_str = "'" . implode("', '", $values) . "'";

			$new_db->exec("INSERT INTO $table ($columns_str) VALUES ($values_str)");

			$rows_copied++;
		}

		if($rows_copied < $limit) break;

		$offset += $limit;
	}
}

function get_sqlite_cache_size(){

	$memory_limit = ini_get('memory_limit');

	if($memory_limit === false || $memory_limit == '-1') {

		return '-131072'; //128MB, negative number is for KB
	}

	$memory_bytes = wp_convert_hr_to_bytes($memory_limit);

	$half_memory = (int)($memory_bytes / 2);

	$half_memory_kb = (int)($half_memory / 1024);

	$cache_size = -1 * $half_memory_kb;// negative number is for KB

	return $cache_size;
}

