<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

function set_display_value_cookies(){

	// require_once WPSD_DEBUG_DIR.'includes/universal-functions.php';

	$cookies = get_debug_cookies();

	if( !isset($_COOKIE[$cookies->display_values]) ){
		
		setcookie(
			$cookies->display_values,
			$cookies->nonce,
			0,
			'/'
		);
		
        $_COOKIE[$cookies->display_values] = $cookies->nonce;
	}

	if( !isset($_COOKIE[$cookies->display_admin_bar]) ){
		
		setcookie(
			$cookies->display_admin_bar,
			$cookies->nonce,
			0,
			'/'
		);

		$_COOKIE[$cookies->display_admin_bar] = $cookies->nonce;
	}

}

function set_display_cookies(){

	$cookies = get_debug_cookies();

	// set check cookie so displaying assessment is not performed anymore
	setcookie(
		$cookies->admin_check,
		'1',
		0,
		'/'
	);

	if( !current_user_can( 'administrator' ) ) return;
	
	//cookie to display admin bar
	setcookie(
		$cookies->display_admin_bar,
		$cookies->nonce,
		0,
		'/'
	);

	$_COOKIE[$cookies->display_admin_bar] = $cookies->nonce;
	
	// automatically set cookies to display debug values for localhost and staging
	if( is_local_or_staging() ){

		set_display_value_cookies($cookies);
	}
	
}

function delete_plugin_cookies(){
	
	$cookies = get_debug_cookies();

	setcookie( $cookies->admin_check, '', time()-3600, '/');
	setcookie( $cookies->display_admin_bar, '', time()-3600, '/');
	setcookie( $cookies->display_errors, '', time()-3600, '/');
	setcookie( $cookies->display_values, '', time()-3600, '/');

	unset(

		$_COOKIE[$cookies->admin_check],
		$_COOKIE[$cookies->display_admin_bar],
		$_COOKIE[$cookies->display_errors],
		$_COOKIE[$cookies->display_values]

	);

}

function is_local_or_staging(){
	
	return ($_SERVER['SERVER_ADDR']??'') === '127.0.0.1' || defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE ==='staging';
}