<?php

namespace wpsd_php_debug;

global $pagenow;

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cleanup_cron' );

add_action( 'cleanup_main_cron', __NAMESPACE__.'\cleanup_main' );


function setup_cleanup_cron() {

	if ( wp_next_scheduled( 'cleanup_main_cron' ) ) return;
	
	/**
	 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
	 *  
	 * time() will schedule and execute immediately after plugin activation
	 */
	
	$time = strtotime('+7 days 1:00 AM');

	// $time = time(); 

	wp_schedule_event( $time, 'weekly', 'cleanup_main_cron' );
	
}


function cleanup_main(){
	
	remove_old_logs();
	
}

function remove_old_logs(){

	$log_dirname = get_option('wpsd-php-debug-dir');

	if( empty($log_dirname) ) return;

	remove_old_files( WP_CONTENT_DIR.$log_dirname, $extension = false, $keep_days = 7 );

}

function remove_old_files( $path, $extension = false, $keep_days = 30 ){
 
    $max_age_in_seconds = $keep_days * 24 * 60 * 60;
 
    $time = time();
 
    $files = new \DirectoryIterator($path);
 
    foreach ($files as $file) {
 
        if ( $file->isDot() || !$file->isFile() ) continue;
 
        if ( $extension && strtolower($file->getExtension()) != strtolower($extension) ) continue;
 
        $file_path = $file->getRealPath();
 
        $file_age = $time - $file->getMTime();
 
        if ($file_age <= ($max_age_in_seconds)) continue;
 
        unlink($file_path);
 
    }
 
}