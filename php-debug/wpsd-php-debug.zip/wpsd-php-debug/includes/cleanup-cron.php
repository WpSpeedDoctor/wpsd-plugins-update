<?php

namespace wpsd_php_debug;

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cleanup_cron' );

add_action( 'cleanup_main_cron', __NAMESPACE__.'\cleanup_main' );


function setup_cleanup_cron() {
	
	if ( wp_next_scheduled( 'cleanup_main_cron' ) ) return;
	
	/**
	 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
	 *  
	 * time() will schedule and execute immediately after plugin activation
	 */
	
	$time = strtotime('tomorrow 1:00 AM');

	// $time = time(); 

	wp_schedule_event( $time, 'daily', 'cleanup_main_cron' );
	
}


function cleanup_main(){
	
	//put your clean up code here
	
	
}

