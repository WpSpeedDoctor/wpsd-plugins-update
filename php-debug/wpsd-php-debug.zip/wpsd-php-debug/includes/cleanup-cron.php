<?php

namespace wpsd_php_debug;

global $pagenow;

require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cleanup_cron' );

add_action( 'cleanup_main_cron', __NAMESPACE__.'\cleanup_main' );

add_action( 'wpsd_debug_reporting_cron', __NAMESPACE__.'\wpsd_debug_reporting_cron' );


function setup_cleanup_cron() {

	if ( !wp_next_scheduled( 'cleanup_main_cron' ) ){
		
		/**
		 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
		 *  
		 * time() will schedule and execute immediately after plugin activation
		 */
		
		$time = strtotime('+1 days 1:00 AM');

		// $time = time(); 

		wp_schedule_event( $time, 'daily', 'cleanup_main_cron' );

	}

	$settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

	if ( !empty($settings['report_email']) && !wp_next_scheduled( 'wpsd_debug_reporting_cron' )){
		
		wp_schedule_event( time(), 'hourly', 'wpsd_debug_reporting_cron' );

	}
	
}

function wpsd_debug_reporting_cron(){

	$settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

	if( empty($settings['report_email']) ) return;

	$message = get_report_email_body();

	if( empty( $message ) ) return; 
	
	$email = $settings['report_email'];

	$subject = esc_html__('[ALERT] PHP Fatal errors detected on your website', 'wpsd-php-debug' );

	$message .= '<p style="width: 100%; border-collapse: collapse; font-family: Arial, sans-serif;">';

	$message .= sprintf(
		__("Sent from website %s, server IP: %s by plugin %s", 'wpsd-php-debug' ),
		get_home_url(),
		$_SERVER['SERVER_ADDR'],
		esc_html__( 'Advanced PHP Debug by WP Speed Doctor.', 'wpsd-php-debug' )
	);

	$message .= '</p>';

	$domain = parse_url(get_home_url() )['host'];

	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		"From: noreply@{$domain}",
		"Reply-To: noreply@{$domain}"
	);

	wp_mail(
		$email,
		$subject,
		$message,
		$headers
	);

}

function get_report_email_body(){
	
	$errors = get_codes_count();

	// $errors[1] is count of fatal errors or null
	if( empty($errors[1]) ) return false;

	$message =  sprintf(
		__('Between %s and %s occurred', 'wpsd-php-debug' ),
		date('Y-m-d H:i:s', strtotime('-1 hour')),
		date('Y-m-d H:i:s'),
	);

	$message .= '<span style="color:red">';

	$message .=  sprintf(
		_n(
			' %d PHP Fatal error.',
			' %d PHP Fatal errors.',
			$errors[1],
			'wpsd-php-debug'
		),
		$errors[1]
	);

	$message = '</span><p style="font-family: Arial, sans-serif;">'.$message.'</p>';
	
	if( count($errors) === 1 ) return $message;

	$types = get_error_type_strings();

	$errors_breakdown_markup = '';

	foreach( $errors as $error_code => $count){

		$errors_breakdown_markup.= '<tr><td style="padding: 10px; border: 1px solid #ddd;">'.$types[$error_code].
		'</td><td style="padding: 10px; border: 1px solid #ddd;">'."{$count}</td></tr>\n";
	}

	$header_text = esc_html__('Here is the breakdown of all recorded during this period:', 'wpsd-php-debug' );

	$header_text_markup = '<p style="border-collapse: collapse; font-family: Arial, sans-serif;">'.$header_text.'</p>';
	
	$errors_breakdown_markup =<<<HTML
	{$header_text_markup}
	<table style="border-collapse: collapse; font-family: Arial, sans-serif;">
		<thead>
			<tr>
				<th style="background-color: #4CAF50; color: white; padding: 10px; border: 1px solid #ddd;text-align: center;">Error Type</th>
				<th style="background-color: #4CAF50; color: white; padding: 10px; border: 1px solid #ddd;text-align: center;">Count</th>
			</tr>
		</thead>
		<tbody>
			{$errors_breakdown_markup}
		</tbody>
	</table>
	<br>
	HTML;
	
	return $message.$errors_breakdown_markup;
	
}

function get_codes_count(){

	$db_filepath = get_db_filepath();

	if ( $db_filepath === '' ) return [];

	$db = new \SQLite3($db_filepath);

	if (!$db) return [];

	$cutoff_time = date('Y-m-d H:i:s', strtotime('-1 hour'));

	$query = <<<SQL
SELECT code, COUNT(*) as count 
FROM error_log 
WHERE daytime >= :cutoff_time
GROUP BY code
SQL;

	$stmt = $db->prepare($query);

	$stmt->bindValue(':cutoff_time', $cutoff_time, SQLITE3_TEXT);

	$result = $stmt->execute();

	if (!$result) return [];

	$codes_count = [];

	while ($row = $result->fetchArray(SQLITE3_ASSOC)){
		$codes_count[$row['code']] = $row['count'];
	}

	$db->close();

	return $codes_count;
}



function cleanup_main(){
	
	$keep_days = 7;

	remove_old_logs( $keep_days );
	
	remove_old_sqlite_records( $keep_days );

	require_once WPSD_PHP_DEBUG_DIR.'admin/uninstall.php';

	delete_matched_files( ['meta.log'] );

	delete_option('wpsd-debug-values');
}

function remove_old_sqlite_records($keep_days){

	$db_filepath = get_db_filepath();

	if ( empty($db_filepath) ) return;

	$db = new \SQLite3($db_filepath);

	if (!$db) return;

	$cutoff_date = date('Y-m-d H:i:s', strtotime("-$keep_days days"));

	$delete_log_query = <<<SQL
DELETE FROM error_log 
WHERE daytime < :cutoff_date
SQL;

	$delete_orphaned_meta_query = <<<SQL
DELETE FROM error_meta
WHERE meta_id NOT IN (
	SELECT DISTINCT meta_id 
	FROM error_log
)
SQL;

	$db->exec('BEGIN TRANSACTION');

	$stmt_log = $db->prepare($delete_log_query);
	$stmt_log->bindValue(':cutoff_date', $cutoff_date, SQLITE3_TEXT);
	$stmt_log->execute();

	$db->exec($delete_orphaned_meta_query);

	$db->exec('COMMIT');

	$db->exec('VACUUM');

	$db->close();

}




function remove_old_logs( $keep_days ){

	$log_dirname = get_option('wpsd-php-debug-dir');

	if( empty($log_dirname) ) return;

	remove_old_files( WP_CONTENT_DIR.$log_dirname, $extension = 'log', $keep_days );

}

function remove_old_files( $path, $extension = false, $keep_days = 30 ){
 
    $max_age_in_seconds = $keep_days * 24 * 60 * 60;
 
    $time = time();
 
    $files = new \DirectoryIterator($path);
 
    foreach ($files as $file) {
 
        if ( $file->isDot() || !$file->isFile() ) continue;
 
        if ( $extension && strtolower($file->getExtension()) != strtolower($extension) ) continue;
 
        $file_path = $file->getRealPath();
 
        $file_age = $time - $file->getMTime();
 
        if ($file_age <= ($max_age_in_seconds)) continue;
 
        unlink($file_path);
 
    }
 
}