<?php

namespace wpsd_php_debug;

global $pagenow;

require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cleanup_cron' );

add_action( 'cleanup_main_cron', __NAMESPACE__.'\cleanup_main' );


function setup_cleanup_cron() {

	if ( !wp_next_scheduled( 'cleanup_main_cron' ) ){
		
		/**
		 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
		 *  
		 * time() will schedule and execute immediately after plugin activation
		 */
		
		$time = strtotime('+1 days 1:00 AM');

		// $time = time(); 

		wp_schedule_event( $time, 'daily', 'cleanup_main_cron' );

	}

	//TODO: continue with email reporting
	
	// $settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

	// if ( !wp_next_scheduled( 'cleanup_main_cron' ) && $settings['report_email']){
		
	// 	wp_schedule_event( time(), 'hourly', 'wpsd_debug_reporting_cron' );

	// }
	
}

//to be continued
/* 
function wpsd_debug_reporting_cron(){

	$settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

	
	$db_filepath = get_db_filepath();

	if (!file_exists($db_filepath) || !class_exists('SQLite3') ) return;

	$db = new \SQLite3($db_filepath);

	if (!$db) return;

	
	$cutoff_date = date('Y-m-d H:i:s', strtotime("-60 minutes"));

	$fatal_error = <<<SQL
SELECT error FROM error_log 
WHERE daytime > {$cutoff_date}
SQL;

}
*/

function cleanup_main(){
	
	$keep_days = 7;

	remove_old_logs( $keep_days );
	
	remove_old_sqlite_records( $keep_days );

	require_once WPSD_PHP_DEBUG_DIR.'admin/uninstall.php';

	delete_matched_files( ['meta.log'] );

	delete_option('wpsd-debug-values');
}

function remove_old_sqlite_records($keep_days){

	$db_filepath = get_db_filepath();

	if (!file_exists($db_filepath) || !class_exists('SQLite3') ) return;

	$db = new \SQLite3($db_filepath);

	if (!$db) return;

	$cutoff_date = date('Y-m-d H:i:s', strtotime("-$keep_days days"));

	$delete_log_query = <<<SQL
DELETE FROM error_log 
WHERE daytime < :cutoff_date
SQL;

	$delete_orphaned_meta_query = <<<SQL
DELETE FROM error_meta
WHERE meta_id NOT IN (
	SELECT DISTINCT meta_id 
	FROM error_log
)
SQL;

	$db->exec('BEGIN TRANSACTION');

	$stmt_log = $db->prepare($delete_log_query);
	$stmt_log->bindValue(':cutoff_date', $cutoff_date, SQLITE3_TEXT);
	$stmt_log->execute();

	$db->exec($delete_orphaned_meta_query);

	$db->exec('COMMIT');

	$db->exec('VACUUM');

	$db->close();

}




function remove_old_logs( $keep_days ){

	$log_dirname = get_option('wpsd-php-debug-dir');

	if( empty($log_dirname) ) return;

	remove_old_files( WP_CONTENT_DIR.$log_dirname, $extension = 'log', $keep_days );

}

function remove_old_files( $path, $extension = false, $keep_days = 30 ){
 
    $max_age_in_seconds = $keep_days * 24 * 60 * 60;
 
    $time = time();
 
    $files = new \DirectoryIterator($path);
 
    foreach ($files as $file) {
 
        if ( $file->isDot() || !$file->isFile() ) continue;
 
        if ( $extension && strtolower($file->getExtension()) != strtolower($extension) ) continue;
 
        $file_path = $file->getRealPath();
 
        $file_age = $time - $file->getMTime();
 
        if ($file_age <= ($max_age_in_seconds)) continue;
 
        unlink($file_path);
 
    }
 
}