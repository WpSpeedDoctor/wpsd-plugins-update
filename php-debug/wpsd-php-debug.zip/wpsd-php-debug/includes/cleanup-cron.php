<?php

namespace wpsd_php_debug;

global $pagenow;

require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cleanup_cron' );

add_action( 'cleanup_main_cron', __NAMESPACE__.'\cleanup_main' );

add_action( 'wpsd_debug_reporting_cron', __NAMESPACE__.'\wpsd_debug_reporting_cron' );


function setup_cleanup_cron() {

	if ( !wp_next_scheduled( 'cleanup_main_cron' ) ){
		
		/**
		 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
		 *  
		 * time() will schedule and execute immediately after plugin activation
		 */
		
		$time = strtotime('+1 days 1:00 AM');

		// $time = time(); 

		wp_schedule_event( $time, 'daily', 'cleanup_main_cron' );

	}

	$settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

	if ( !empty($settings['report_email']) && !wp_next_scheduled( 'wpsd_debug_reporting_cron' )){
		
		wp_schedule_event( time(), 'hourly', 'wpsd_debug_reporting_cron' );

	}
	
}

function wpsd_debug_reporting_cron(){

	$email = json_decode( get_option( 'wpsd-php-debug-settings'), true )['report_email']??'';

	if( empty($email) ) return;

	$errors = get_codes_count();

	if( !has_php_fatal_errors($errors) ) return;

	$subject = esc_html__('[ALERT] PHP Fatal errors detected on your website.', 'wpsd-php-debug' );
	
	$domain = parse_url( get_home_url() )['host'];

	$message = get_email_message_main( $subject, $errors );

	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		"From: noreply@{$domain}",
		"Reply-To: noreply@{$domain}"
	);

	wp_mail(
		$email,
		$subject,
		$message,
		$headers
	);

	run_integrity_db_check();

}

function has_php_fatal_errors($errors) {
	
	return !empty($errors[1]);
}

function get_email_message_main($subject, $errors) {
	
	$email_body = get_report_email_body( $errors );

	return <<<HTML
	<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width,initial-scale=1">
			<meta name="x-apple-disable-message-reformatting">
			<meta http-equiv="Content-Security-Policy" content="script-src &#39;unsafe-inline&#39;;">
			<title>{$subject}</title>
		</head>
		<body style="margin:0;padding:0;">
			{$email_body}
		</body>
	</html>
	HTML;
}

function get_report_email_body( $errors ){
	
	$text = [

		'breakdown' 	=> esc_html__('Here is the breakdown of all recorded errors during this period:', 'wpsd-php-debug' ),

		'period'	=> sprintf(
						_n(
							'Between %s and %s occurred %d PHP Fatal error.',
							'Between %s and %s occurred %d PHP Fatal errors.',
							$errors[1],
							'wpsd-php-debug'
						),
						date('Y-m-d H:i:s', strtotime('-1 hour')),
						date('Y-m-d H:i:s'),
						$errors[1]
					),

		'footnote'		=> sprintf(
								__("Sent from website %s, server IP: %s by plugin %s", 'wpsd-php-debug' ),
									get_home_url(),
									$_SERVER['SERVER_ADDR'],
									esc_html__( 'Advanced PHP Debug by WP Speed Doctor.', 'wpsd-php-debug' )
							),

		'error-type'	=> __("Error type", 'wpsd-php-debug' ),

		'count'			=> __("Count", 'wpsd-php-debug' ),

	];
	
	if( count($errors) === 1 ){

		return
		<<<HTML
		<p style="font-family: Arial, sans-serif;">
			{$text['period']}
		</p>
		<p style="font-family: Arial, sans-serif;">
			{$text['footnote']}
		</p>
		HTML;
		
	}

	$types = get_error_type_strings();

	$errors_breakdown_markup = '';

	foreach( $errors as $error_code => $count){

		$errors_breakdown_markup .= <<<HTML
		<tr>
			<td style="padding: 10px; border: 1px solid #ddd;">{$types[$error_code]}</td>
			<td style="padding: 10px; border: 1px solid #ddd;text-align: center;">{$count}</td>
		</tr>
		HTML;
	}

	return <<<HTML
	<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['period']}</p>
	<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['breakdown']}</p>
	<table style="border-collapse: collapse; font-family: Arial, sans-serif;">
		<thead>
			<tr>
				<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$text['error-type']}</th>
				<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$text['count']}</th>
			</tr>
		</thead>
		<tbody>
			{$errors_breakdown_markup}
		</tbody>
	</table>
	<br>
	<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['footnote']}</p>
	HTML;
	
	
}

function get_codes_count(){

	$db_filepath = get_db_filepath();

	if ( $db_filepath === '' ) return [];

	$db = new \SQLite3($db_filepath);

	if (!$db) return [];

	$cutoff_time = date('Y-m-d H:i:s', strtotime('-1 hour'));

	$query = <<<SQL
SELECT code, COUNT(*) as count 
FROM error_log 
WHERE daytime >= :cutoff_time
GROUP BY code
SQL;

	$stmt = $db->prepare($query);

	$stmt->bindValue(':cutoff_time', $cutoff_time, SQLITE3_TEXT);

	$result = $stmt->execute();

	if (!$result) return [];

	$codes_count = [];

	while ($row = $result->fetchArray(SQLITE3_ASSOC)){
		$codes_count[$row['code']] = $row['count'];
	}

	$db->close();

	return $codes_count;
}



function cleanup_main(){
	
	$keep_days = 7;

	remove_old_logs( $keep_days );
	
	remove_old_records_main( $keep_days );

	require_once WPSD_PHP_DEBUG_DIR.'admin/uninstall.php';

	delete_matched_files( ['meta.log'] );

	delete_option('wpsd-debug-values');
}

function run_integrity_db_check(){
	
	$db_filepath = get_db_filepath();
	
	$is_db_ok = has_db_integrity($db_filepath);

	if( $is_db_ok ) return true; 

	copy_recovery_file( $db_filepath );

	return false;
}

function remove_old_records_main( $keep_days ){

	$db_filepath = get_db_filepath();

	if ( empty($db_filepath) || !run_integrity_db_check() ) return;

	remove_old_sqlite_records( $keep_days, $db_filepath );
	
}

function copy_recovery_file( $db_filepath ){

	$date = date('Y-m-d_H-i-s');

	$broken_db_filepath = str_replace( '.sqlite',"-broken-{$date}.sqlite", $db_filepath);

	rename($db_filepath, $broken_db_filepath );

	create_sqlite_db();
}

function remove_old_sqlite_records( $keep_days, $db_filepath ){

	$db = new \SQLite3($db_filepath);

	if (!$db) return;

	$cutoff_date = date('Y-m-d H:i:s', strtotime("-$keep_days days"));

	$delete_log_query = <<<SQL
DELETE FROM error_log 
WHERE daytime < :cutoff_date
SQL;

	$delete_orphaned_meta_query = <<<SQL
DELETE FROM error_meta
WHERE meta_id NOT IN (
	SELECT DISTINCT meta_id 
	FROM error_log
)
SQL;

	$db->exec('BEGIN TRANSACTION');

	$stmt_log = $db->prepare($delete_log_query);
	$stmt_log->bindValue(':cutoff_date', $cutoff_date, SQLITE3_TEXT);
	$stmt_log->execute();

	$db->exec($delete_orphaned_meta_query);

	$db->exec('COMMIT');

	$db->exec('VACUUM');

	$db->close();

}


function has_db_integrity($db_filepath){

	$db = new \SQLite3($db_filepath);

	$integrity_result = $db->querySingle('PRAGMA integrity_check');
	
	$db->close();

	return $integrity_result === 'ok';
	
}

function remove_old_logs( $keep_days ){

	$log_dirname = get_option('wpsd-php-debug-dir');

	if( empty($log_dirname) ) return;

	remove_old_files( WP_CONTENT_DIR.$log_dirname, $extension = 'log', $keep_days );

}

function remove_old_files( $path, $extension = false, $keep_days = 30 ){
 
    $max_age_in_seconds = $keep_days * 24 * 60 * 60;
 
    $time = time();
 
    $files = new \DirectoryIterator($path);
 
    foreach ($files as $file) {
 
        if ( $file->isDot() || !$file->isFile() ) continue;
 
        if ( $extension && strtolower($file->getExtension()) != strtolower($extension) ) continue;
 
        $file_path = $file->getRealPath();
 
        $file_age = $time - $file->getMTime();
 
        if ($file_age <= ($max_age_in_seconds)) continue;
 
        unlink($file_path);
 
    }
 
}