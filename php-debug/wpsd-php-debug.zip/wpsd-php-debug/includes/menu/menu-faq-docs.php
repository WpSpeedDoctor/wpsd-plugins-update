<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsd-php-debug-body clear"><br>
<h4>Basic documentation</h4>
<ul style="list-style-type: disc;margin-left: 20px;">

    <li>
        To display PHP errors set in browser cookie `php-debug=1` 
    </li>
    <li>
        With function deb() you can display any variable on the front-end as floating window. Be careful on the production because it will be displayed to all users.
    </li>
    <li>
        Error reporting is set to `E_ALL` to make consistent metadata collection. It might change in the next release.
    </li>
    <li>
        Downloaded log file is containing data displayed, if filters been applied, downloaded log will contain only filtered data.
    </li>
    <li>
        Error log file has last part of IP in the filename. That's because if your system runs on various servers with load balancer, it's handy to have separated error by the server and avoid overwriting data.
    </li>
</ul>
</div>