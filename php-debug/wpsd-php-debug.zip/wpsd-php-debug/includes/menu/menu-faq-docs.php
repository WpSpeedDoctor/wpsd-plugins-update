<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsd-php-debug-body clear"><br>
<h4>Basic documentation</h4>
<ul style="list-style-type: disc;margin-left: 20px;">
	<li>
		With function deb() you can display any variable on the front-end as a floating window. The toggle in settings has to be on to display the data.
	</li>
	<li>
		Error reporting is set to `E_ALL`, you can exclude some errors from reporting in settings. 
	</li>
	<li>
		Downloaded log file is containing data displayed, if filters been applied, downloaded log will contain only filtered data.
	</li>
	<li>
		Error log file has last part of IP in the filename. That's because if your system runs on various servers with load balancer, it's handy to have separated error by the server and avoid overwriting data.
	</li>
	<li>
	   Search and Exclude fields in home menu support regex, but it must contain character `|` to activate regex.
	</li>
</ul>
</div>