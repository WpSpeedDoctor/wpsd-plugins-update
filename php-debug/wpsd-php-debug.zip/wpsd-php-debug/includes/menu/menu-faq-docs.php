<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$title = esc_html__('Basic documentation', 'wpsd-php-debug');

$texts = [
	esc_html__('With function deb() you can display any variable on the front-end as a floating window. The toggle in settings has to be on to display the data.', 'wpsd-php-debug'),
	esc_html__('Error reporting is set to `E_ALL`, you can exclude some errors from reporting in settings.', 'wpsd-php-debug'),
	esc_html__('Downloaded log file is containing data displayed, if filters been applied, downloaded log will contain only filtered data.', 'wpsd-php-debug'),
	esc_html__('Error log file has last part of IP in the filename. That\'s because if your system runs on various servers with load balancer, it\'s handy to have separated error by the server and avoid overwriting data.', 'wpsd-php-debug'),
	esc_html__('Search and Exclude fields in home menu support regex, but it must contain character `|` to activate regex.', 'wpsd-php-debug'),
	esc_html__('Display errors toggle sets cookie enabling to show PHP errors only to you. If you logout, cookie will remain valid and PHP errors will be displayed, but only to you.', 'wpsd-php-debug'),
	esc_html__('Function wpsd_dd() will set display values and display error cookies.', 'wpsd-php-debug'),
];

$li_markup = '<li>'.implode( "</li>\n<li>", $texts );

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<h4>{$title}</h4>
	<ul style="list-style-type: disc;margin-left: 20px;">
	{$li_markup}
	</ul>
</div>
HTML;
