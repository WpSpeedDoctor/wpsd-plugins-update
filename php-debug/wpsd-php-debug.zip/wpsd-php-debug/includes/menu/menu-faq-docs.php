<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$title = esc_html__('Basic documentation', 'wpsd-php-debug');

$texts = [
	esc_html__('When deleting logs, only error messages are deleted directly, followed by metadata that has no error message associated.', 'wpsd-php-debug'),
	esc_html__('With the function `deb( $value, $note )`, you can display any variable on the front-end as a floating window. The toggle in settings must be on to display the data.', 'wpsd-php-debug'),
	esc_html__('Function `deb()` will display location in file and function name.', 'wpsd-php-debug'),
	esc_html__('The function `debl($value, $note)` writes data into the SQLite error log. Use this instead `error_log()` because this cannot be captured to store in the database.', 'wpsd-php-debug'),
	esc_html__('The function `the_wpsd_used_php()` displays required PHP files and it\'s OPcache memory usage.', 'wpsd-php-debug'),
	esc_html__('On `localhost` and when `WP_ENVIRONMENT_TYPE === "staging"`, the settings to activate displaying `deb( $value, $note )` is automatically set to true.', 'wpsd-php-debug'),
	esc_html__('Error reporting is set to `E_ALL`, you can exclude errors from reporting and logging in the menu `settings`.', 'wpsd-php-debug'),
	esc_html__('Downloaded log file is containing data displayed, if filters been applied, downloaded log will contain only filtered data.', 'wpsd-php-debug'),
	esc_html__('The database filename is unique to the IP of the server. That\'s because if your system runs on various servers with load balancer, error logs would be overwritten. As this version, you can see only error from the currently accessing server.', 'wpsd-php-debug'),
	esc_html__('Display errors toggle sets cookie enabling to show PHP errors only to you. If you logout, cookie will remain in your browser and PHP errors will be displayed, but only to you.', 'wpsd-php-debug'),
	esc_html__('Function wpsd_dd() will set display values and display error cookies.', 'wpsd-php-debug'),
	esc_html__('Function `stw()` - "Stopwatch" start count and will display how long time passed from first called `stw()`', 'wpsd-php-debug'),
	esc_html__('Function `stw(true)` will show time from start or last start time rest and resets the start time', 'wpsd-php-debug'),
	esc_html__('Function `vd( $value, "identifier", $float=false)` - "var_dump" will display a variable in readable format.', 'wpsd-php-debug'),
	esc_html__('Thanks to HTMX and SQLite for amazing libraries.', 'wpsd-php-debug'),
	
];

$li_markup = '<li>'.implode( "</li>\n<li>", $texts );

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<h4>{$title}</h4>
	<ul class="docs-points">
	{$li_markup}
	</ul>
</div>
HTML;
