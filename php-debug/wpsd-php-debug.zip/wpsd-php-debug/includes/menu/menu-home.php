<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

display_search_bar();

function display_search_bar(){

	$log_files = get_select_log_filename_markup();
	
	if($log_files['latest_log_filename']) {
		
		$ajax_url = admin_url('/admin-ajax.php?php-debug-search');
		
		$nonce = get_nonce();
		
		the_form( $log_files, $ajax_url, $nonce );
		
	} else {
		
		display_no_log_files();

	}
}



function the_form($log_files, $ajax_url, $nonce){

	if(!$log_files || !$ajax_url || !$nonce) return false;

	$texts = get_form_texts();

	$error_types_markup = get_php_error_types_markup();

	echo <<<HTML
<br>
<form class="input-form" id="debugForm"
	hx-post="{$ajax_url}"
	hx-vals='{"action": "htmx-php-debug-search"}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-target="#display-data">
	<div class="form-elements-wrap">
		{$texts['log_file']}
		<select name="log-file">
			{$log_files['markup']}
		</select>
		{$log_files['ip_null_warning']}
		<button type="button" class="button button-primary download-button" onclick="triggerDownload()">
		{$texts['download_log']}
	</button>
	</div>
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button">
		<span class="dashicons dashicons-image-rotate"></span>
	</button>
	<input type="hidden" name="action" value="php-debug-search">
	<input type="text" name="search-keyword" placeholder="{$texts['search_placeholder']}">
	<input type="text" name="exclude-keyword" placeholder="{$texts['exclude_placeholder']}">
	<select name="error-type">
		{$error_types_markup}
	</select>
	<select name="order">
		<option value="desc">{$texts['newest_option']}</option>
		<option value="asc">{$texts['oldest_option']}</option>
	</select>
	{$texts['per_page']}
	<select name="per-page">
		<option>10</option>
		<option>50</option>
		<option>200</option>
		<option>1</option>
	</select>
	<input type="hidden" name="download" value="false">
	<input type="hidden" name="nonce" value="{$nonce}">
	</div>
</form>
<div id="display-data"
	hx-post="{$ajax_url}"
	hx-trigger="load"
	hx-headers='{"Content-Type": "application/json"}'
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals='{"action": "htmx-php-debug-search",
				"search-keyword": "",
				"exclude-keyword": "",
				"error-type": 0,
				"order": "desc",
				"log-file": "{$log_files['latest_log_filename']}",
				"nonce": "{$nonce}"}'>
	{$texts['loading']}
</div>
HTML;

the_inlined_js();

}

function get_form_texts(){

	return [
		'search_placeholder' => esc_html__('Search', 'wpsd-php-debug'),
		'exclude_placeholder' => esc_html__('Exclude', 'wpsd-php-debug'),
		'newest_option' => esc_html__('Newest', 'wpsd-php-debug'),
		'oldest_option' => esc_html__('Oldest', 'wpsd-php-debug'),
		'download_log' => esc_html__('Download log', 'wpsd-php-debug'),
		'loading' => esc_html__('Loading...', 'wpsd-php-debug'),
		'log_file' => esc_html__('Log file:', 'wpsd-php-debug'),
		'per_page' => esc_html__('Per page:', 'wpsd-php-debug'),
	];

}

function get_php_error_types_markup(){

	
	$output = '';
		
	foreach( get_error_type_strings() as $key => $name ){

		$output .= 
<<<HTML
<option value="{$key}">{$name}</option>
HTML;

	}
	
	return $output;
}

function get_select_log_filename_markup(){
	
	$result = '';

	$latest_log_filename = false;

	foreach( get_log_filenames() as $key => $filename) {

		if( !is_valid_log_filename( $filename ) ) continue;

		$latest_log_filename = $latest_log_filename ?: $filename;
		
        $result.=
<<<HTML
<option value="$filename">$filename</option>
HTML;

    }
	
	return [
		'markup' 				=>	$result,

		'latest_log_filename'	=>	$latest_log_filename,

		'ip_null_warning'		=>	get_null_warning($latest_log_filename)
		
	];
}

function get_null_warning($latest_log_filename){

	if( !str_contains($latest_log_filename,'null') ) return '';

	$text = esc_html__( "The default viewed log file is generated when the server's IP is unavailable, hence the 'null' in its name.", 'wpsd-php-debug');

	return <<<HTML
	<span class="ip-null-warning">&#x26A0;
		<span class="tooltip">$text</span>
	</span>
	HTML;

}

function is_valid_log_filename( $filename ){

	return arr_contains($filename,['error.log','current']);
}

function get_log_filenames(){

	$error_log_filepath = ini_get('error_log');

	$path = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$filenames = scandir($path);
	
	if( !str_contains( $error_log_filepath,$path ) ) $filenames[]= 'current-'.basename($error_log_filepath);
	
	rsort( $filenames );

	return $filenames;
}


/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_transient('wpsd-php-debug-nonce');

	if($nonce) return $nonce;

	$nonce = bin2hex(random_bytes(10));

	set_transient('wpsd-php-debug-nonce',$nonce, 5*60 ); //5 minutes

	return $nonce;
}

function display_no_log_files(){

	$text = esc_html__('No log files been found','wpsd-php-debug');

    echo 
<<<HTML
<br>
<p>
	$text
</p>
HTML;
}

function the_inlined_js(){
?>
<script>
//automatic post
const form = document.querySelector('.input-form');
let timeoutId;

function debounce(func, delay) {
	clearTimeout(timeoutId);
	timeoutId = setTimeout(func, delay);
}

form.addEventListener('input', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

form.addEventListener('change', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

//download
function triggerDownload() {
    var form = document.getElementById('debugForm');
    form.querySelector('input[name="download"]').value = "true";
    
    form.addEventListener('htmx:afterOnLoad', function resetDownload() {
        form.querySelector('input[name="download"]').value = "false";
        form.removeEventListener('htmx:afterOnLoad', resetDownload);
    });
    
    htmx.trigger(form, 'submit', {values: {download: "true"}});
}
</script>
<?php
}