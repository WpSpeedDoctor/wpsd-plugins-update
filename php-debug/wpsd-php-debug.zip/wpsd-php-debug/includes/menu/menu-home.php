<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

echo '<br>';
display_search_bar();

function display_search_bar(){

	if( empty(get_log_filenames())) return;
	the_inlined_css();

	$nonce = get_nonce();

	$log_files = get_select_log_filename_markup();

	if(!$log_files['latest_log_filename']) {

		?><p>No log files been found</p><?php

		return;
	}
	$ajax_url = admin_url('/wp-admin/admin-ajax.php?php-debug-search');
	?>
<form class="input-form" id="debugForm"
	hx-post="/?php-debug-search"
	hx-vals='{"action": "htmx-php-debug-search"}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-target="#display-data">
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button"><span class="dashicons dashicons-image-rotate"></span></button>
		<input type="hidden" name="action" value="php-debug-search">
		<input type="text" name="search-keyword" placeholder="<?=__('Search','wpsd-php-debug')?>">
		<input type="text" name="exclude-keyword" placeholder="<?=__('Exclude','wpsd-php-debug')?>">
		<select name="error-type">
			<?=get_php_error_types_markup()?>
		</select>
		<select name="order">
			<option value="desc"><?=__('Newest','wpsd-php-debug')?></option>
			<option value="asc"><?=__('Oldest','wpsd-php-debug')?></option>
		</select>
		Per page:
		<select name="per-page">
			<option>10</option>
			<option>50</option>
			<option>200</option>
		</select>
		Log file:
		<select name="log-file">
			<?=$log_files['markup']?>
		</select>
		<input type="hidden" name="download" value="false">
		<input type="hidden" name="nonce" value="<?=$nonce?>">
		<button type="button" class="button button-primary download-button" onclick="triggerDownload()"><?=__('Download log','wpsd-php-debug')?></button>
	</div>
</form>
<script>
function triggerDownload() {
    var form = document.getElementById('debugForm');
    form.querySelector('input[name="download"]').value = "true";
    
    form.addEventListener('htmx:afterOnLoad', function resetDownload() {
        form.querySelector('input[name="download"]').value = "false";
        form.removeEventListener('htmx:afterOnLoad', resetDownload);
    });
    
    htmx.trigger(form, 'submit', {values: {download: "true"}});
}
</script>

<div id="display-data" 

	hx-post="/?php-debug-search"
	hx-trigger="load" 
	hx-headers='{"Content-Type": "application/json"}'  
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals=
				'{"action": "htmx-php-debug-search",
				"search-keyword": "",
				"exclude-keyword": "",
				"error-type": 0,
				"order": "desc",
				"log-file": "<?=$log_files['latest_log_filename']?>",
				"nonce": "<?=$nonce?>"}'>
	<?=__('Loading...','wpsd-php-debug')?>
</div>


<script>
    const form = document.querySelector('.input-form');
    let timeoutId;

    function debounce(func, delay) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(func, delay);
    }

    form.addEventListener('input', function() {
        debounce(function() {
            form.dispatchEvent(new Event('submit'));
        }, 500);
    });

    form.addEventListener('change', function() {
        debounce(function() {
            form.dispatchEvent(new Event('submit'));
        }, 500);
    });
</script>
	<?php
}




function get_php_error_types_markup(){

	
	$output = '';
		
	foreach( get_error_type_strings() as $key => $name ){

		$output .= 
<<<HTML
<option value="{$key}">{$name}</option>
HTML;

	}
	return $output;
}

function get_select_log_filename_markup(){
	
	$result = '';

	$latest_log_filename = false;

	foreach( get_log_filenames() as $filename) {

		if( !is_valid_log_filename( $filename ) ) continue;

		$latest_log_filename = $latest_log_filename ?: $filename;

        $result.=
<<<HTML
<option value="$filename">$filename</option>
HTML;

    }

	return [
		'markup' 				=>	$result,
		'latest_log_filename'	=>	$latest_log_filename
	];
}

function is_valid_log_filename( $filename ){

	return arr_contains($filename,['error.log','current']);
}

function get_log_filenames(){

	$error_log_filepath = ini_get('error_log');

	$path = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$filenames = scandir($path);
	
	if( !str_contains( $error_log_filepath,$path ) ) $filenames[]= 'current-'.basename($error_log_filepath);
	
	rsort( $filenames );

	return $filenames;
}


/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_transient('wpsd-php-debug-nonce');

	if($nonce) return $nonce;

	$nonce = bin2hex(random_bytes(10));

	set_transient('wpsd-php-debug-nonce',$nonce, 5*60 ); //5 minutes

	return $nonce;
}


//inlined CSS because the life is too short for enqueueing 10 lines of CSS as an external file. 
function the_inlined_css(){
	?>
<style>
.passive{
	color:#c3c4c7;
}

.button-primary.download-button{
    margin-left: 10px;
    vertical-align: middle;
}

.pagination-page-number,
.pagination-button{
	padding:0 5px;
	cursor:pointer;
}
.pagination-page-number.passive{
	font-weight: 600;
}

/**
 * Metadata CSS
 */
.metadata-table{
	width: 100%; 
    table-layout: auto; 
    border-collapse: collapse;
}
.metadata-key{
	white-space: nowrap;
}
.metadata-value{

	white-space: break-spaces;
}

.metadata-key,
.metadata-value{
	padding:0 10px 10px 0;
	vertical-align: baseline;
}
.metadata-row{
	margin-bottom: 10px;
}

.iterable-table {
    width: 100%; 
    border-collapse: collapse;
}

.iterable-arrow {
    padding: 0 5px; 
}

.iterable-key {
    width: max-content;
    display: block;
}
.iterable-value {
    word-break: break-word;
    overflow-wrap: break-word; 
}
.words-unbreakable{
    word-break: keep-all;
}
.iterable-table, .iterable-wrap, .iterable-arrow{

    vertical-align: baseline;
	max-width: max-content;
}
button.form-reload {
    background: none;
    border: none;
    cursor: pointer;
}

.dashicons-image-rotate{
	vertical-align: text-bottom;
}
@keyframes rotateAnimation {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(-360deg);
  }
}

.form-reload:active .dashicons {
  animation: rotateAnimation 0.5s linear;
}
.form-elements-wrap {
    align-items: center;
    display: flex;
    column-gap: 6px;
}
</style>
	<?php
}
