<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

display_search_bar();

function display_search_bar(){


	the_form();
	// if($days_markup['day_selected']) {
	
	// } else {
		
	// 	display_no_log_files();

	// }
}



function the_form(){
	
	$texts = get_form_texts();

	$error_types_markup = get_php_error_types_markup();

	echo <<<HTML
<br>
<form class="input-form" id="debugForm"
	hx-post="{$texts['ajax_url']}"
	hx-vals='{"action": "htmx-php-debug-search"}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-indicator="#htmx-spinner"
	hx-target="#display-data">
	<div class="form-elements-wrap">
		{$texts['selected_date']}
		<select name="selected-day">
			{$texts['days_markup']}
		</select>
		{$texts['selected_db']}
		<select name="db-filename">
			{$texts['db_files_markup']}
		</select>
		<button type="button" class="button button-primary download-button" onclick="triggerDownload()">
			{$texts['download_log']}
		</button>
		<label class="switch">
		<input type="checkbox" id="display-metadata" name="display_meta" onchange="toggleCookie('wpsd-display-meta', this.checked)" {$texts['display_meta']}>
		<span class="slider"></span>
		</label>
	</div>
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button">
		<span class="dashicons dashicons-image-rotate"></span>
	</button>
	<input type="hidden" name="action" value="php-debug-search">
	<input type="text" name="search-keyword" placeholder="{$texts['search_placeholder']}">
	<input type="checkbox" name="search-regex"><span class="regex-checkbox">.*</span>
	<input type="text" name="exclude-keyword" placeholder="{$texts['exclude_placeholder']}">
	<input type="checkbox" name="exclude-regex"><span class="regex-checkbox">.*</span>
	<select name="error-type">
		{$error_types_markup}
	</select>
	<select name="order">
		<option value="desc">{$texts['newest_option']}</option>
		<option value="asc">{$texts['oldest_option']}</option>
	</select>
	{$texts['per_page']}
	<select name="per-page">
		<option>10</option>
		<option>50</option>
		<option>200</option>
		<option>1</option>
	</select>
	<button type="button" name="delete" class="pagination-button active log-delete-button" value="1" onclick="confirmDelete();">Delete</button>
	<input type="hidden" name="download" value="false">
	<input type="hidden" name="nonce" value="{$texts['nonce']}">
	</div>
</form>
<div id="display-data"
	hx-post="{$texts['ajax_url']}"
	hx-trigger="load"
	hx-headers='{"Content-Type": "application/json"}'
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals='{"action": "htmx-php-debug-search",
				"search-keyword": "",
				"exclude-keyword": "",
				"error-type": 0,
				"order": "desc",
				"selected-day": "{$texts['today']}",
				"nonce": "{$texts['nonce']}"}'>
</div>
<script>
function toggleCookie(cookieName, isChecked) {
	const dirString = 'wpsd-display-meta';

	if (isChecked) {
		document.cookie = cookieName + "=" + dirString + "; path=/";
	} else {
		document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
	}
}
</script>
HTML;

the_inlined_js();

}
//{$texts['loading']}
function get_form_texts(){

	return [
		'search_placeholder' => esc_html__('Search', 'wpsd-php-debug'),
		'exclude_placeholder' => esc_html__('Exclude', 'wpsd-php-debug'),
		'newest_option' => esc_html__('Newest', 'wpsd-php-debug'),
		'oldest_option' => esc_html__('Oldest', 'wpsd-php-debug'),
		'download_log' => esc_html__('Download log', 'wpsd-php-debug'),
		'loading' => esc_html__('Loading...', 'wpsd-php-debug'),
		'selected_date' => esc_html__('Date:', 'wpsd-php-debug'),
		'per_page' => esc_html__('Per page:', 'wpsd-php-debug'),
		'selected_db' => esc_html__('Database:', 'wpsd-php-debug'),
		'nonce' => get_nonce(),
		'ajax_url' => admin_url('/admin-ajax.php?php-debug-search'),
		'today' => date('Y-m-d'),
		'db_files_markup' => get_db_files_markup(),
		'days_markup' => get_days_markup(),
		'display_meta' => checked($_COOKIE['wpsd-display-meta'] ?? '', 'wpsd-display-meta', false)
	];

}

function get_db_files_markup(){

	$files = scandir( WP_CONTENT_DIR .get_option('wpsd-php-debug-dir').'/' );

	$this_server_db_file = basename(get_db_filepath_string());

	$output = '';

	foreach( $files as $filename){

		if( !str_ends_with($filename,'.sqlite') ) continue;
		
		$selected = $filename === $this_server_db_file ? 'selected' : '';

		$output .= 
<<<HTML
<option value="{$filename}" {$selected}>{$filename}</option>
HTML;
	
	}

	return $output;
}

function get_php_error_types_markup(){

	
	$output = '';
		
	foreach( get_error_type_strings() as $key => $name ){

		$output .= 
<<<HTML
<option value="{$key}">{$name}</option>
HTML;

	}
	
	return $output;
}

function get_days_markup(){
	
	$result = '';

	for($i = 0; $i < 7; $i++){

		$date  = date('Y-m-d', strtotime("-{$i} days") );

        $result.=
<<<HTML
<option value="$date">$date</option>
HTML;

    }
	
	return $result;
}

function is_valid_log_filename( $filename ){

	return arr_contains($filename,['error.log','current']);
}

function get_log_filenames(){

	$error_log_filepath = ini_get('error_log');

	$path = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$filenames = scandir($path);
	
	if( !str_contains( $error_log_filepath,$path ) ) $filenames[]= 'current-'.basename($error_log_filepath);
	
	rsort( $filenames );

	return $filenames;
}


/**
 * Generate nonce key and store in transient. This is because `wp_verify_nonce` is not available in must use plugin hook.
 */

function get_nonce(){

	$nonce = get_transient('wpsd-php-debug-nonce');

	if($nonce) return $nonce;

	$nonce = bin2hex(random_bytes(10));

	set_transient('wpsd-php-debug-nonce',$nonce, 5*60 ); //5 minutes

	return $nonce;
}

function display_no_log_files(){

	$text = esc_html__('No log files been found','wpsd-php-debug');

    echo 
<<<HTML
<br>
<p>
	$text
</p>
HTML;
}

function the_inlined_js(){

	$confirm_text = esc_html__('Are you sure you want to delete?','wpsd-php-debug');
	
	$regex_warning_text = esc_html__('Unable to delete data on regex query.','wpsd-php-debug');

?>
<script>
//Auto trigger post
const form = document.querySelector('.input-form');
let timeoutId;

function debounce(func, delay) {
	clearTimeout(timeoutId);
	timeoutId = setTimeout(func, delay);
}

form.addEventListener('input', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

form.addEventListener('change', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

//Download
function triggerDownload() {
    var form = document.getElementById('debugForm');
    form.querySelector('input[name="download"]').value = "true";
    
    form.addEventListener('htmx:afterOnLoad', function resetDownload() {
        form.querySelector('input[name="download"]').value = "false";
        form.removeEventListener('htmx:afterOnLoad', resetDownload);
    });
    
    htmx.trigger(form, 'submit', {values: {download: "true"}});
}

//Delete button
function confirmDelete() {
    var searchRegexCheckbox = document.querySelector('input[name="search-regex"]');
    var excludeRegexCheckbox = document.querySelector('input[name="exclude-regex"]');

    if (searchRegexCheckbox.checked || excludeRegexCheckbox.checked) {
        alert('<?php echo $regex_warning_text; ?>');
        return;
    }

    if (confirm('<?php echo $confirm_text; ?>')) {
        htmx.trigger('#debugForm', 'submit');
    }
}
</script>
<?php
}