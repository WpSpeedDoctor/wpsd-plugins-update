<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$settings = get_settings_data();

save_new_settings($settings);

$markup_values = get_markup_values($settings);
$text = [
	'save_additional_data' => __('Save additional data:', 'wpsd-php-debug'),
	'exclude_errors_logging' => __('Exclude errors from logging', 'wpsd-php-debug'),
	'save_settings' => __('Save Settings', 'wpsd-php-debug')
];

$excluded_errors_markup = get_excluded_errors_markup($settings);

$nonce_field = wp_nonce_field('wpsd-php-debug-settings-save', 'wpsd_php_debug_settings_nonce', true, false);

$display_data_markup = get_display_data_markup();

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<form method="post" action="" class="debug-plugin-settings">
		<div class="tables-wrap">
			<table>
				<thead>
					<tr>
						<th class="table-title" colspan="2"><strong>{$text['save_additional_data']}</strong></th>
					</tr>
				</thead>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv']['label']}</td>
					<td><input type="checkbox" id="srv" name="server" {$markup_values['srv']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv_keys']['label']}</td>
					<td><textarea id="srv_keys" name="server_keys" rows="{$markup_values['srv_keys']['rows']}" cols="40">{$markup_values['srv_keys']['value']}</textarea></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['pst']['label']}</td>
					<td><input type="checkbox" id="pst" name="post" {$markup_values['pst']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks']['label']}</td>
					<td><input type="checkbox" id="cks" name="cookies" {$markup_values['cks']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks_keys']['label']}</td>
					<td><textarea id="cks_keys" name="cookies_keys_full_value" rows="{$markup_values['cks_keys']['rows']}" cols="40">{$markup_values['cks_keys']['value']}</textarea></td>
				</tr>
			</table>
			<table>
				<thead>
					<tr>
						<th class="table-title" colspan="2">{$text['exclude_errors_logging']}</th>
					</tr>
				</thead>
				<tr>
					<td colspan="2">
						{$excluded_errors_markup}
					</td>
				</tr>
			</table>
			<div>
				{$display_data_markup}
			</div>
		</div>
		{$nonce_field}
		<input type="hidden" name="action" value="save_settings">
		<input type="submit" value="{$text['save_settings']}" class="button button-primary">
	</form>
</div>
HTML;


//end of display_errors

function get_display_data_markup() {

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	$display_error_cookie_key = 'wpsd-debug-display-errors';

	$display_value_cookie_key = 'wpsd-debug-display-values';
	
	$checked_display_errors = checked($_COOKIE[$display_error_cookie_key] ?? '', $dir_string, false);
	
	$checked_display_values = checked($_COOKIE[$display_value_cookie_key] ?? '', $dir_string, false);

	$title = esc_html__( 'Displaying data & useful info', 'wpsd-php-debug' );

	$text_display_cookies = esc_html__( 'This cookie will enable displaying debug values:', 'wpsd-php-debug' );
	
	$text_errors = esc_html__( 'Display PHP Errors', 'wpsd-php-debug' );

	$text_values = esc_html__( 'Display Debug Values', 'wpsd-php-debug' );


	$text_php_filepath = esc_html__( 'PHP error filepath', 'wpsd-php-debug' );

	$text_php_filepath_value = esc_html(ini_get('error_log'));

	$text_custom_filepath_allowed = esc_html__( 'Custom PHP error filepath allowed', 'wpsd-php-debug' );

	$text_custom_filepath_allowed_value = get_option( 'wpsd-php-ini-set-allowed') ? esc_html__( 'Yes', 'wpsd-php-debug' ) : esc_html__( 'No', 'wpsd-php-debug' );

	$text_note = esc_html__( 'Note: The Display Settings are not saved, they have to be manually activated after login.', 'wpsd-php-debug' );


	return <<<HTML
<table>
	<thead>
		<tr>
			<th class="table-title" colspan="2">{$title}</th>
		</tr>
	</thead>
	<tr>
		<td>$text_errors</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugToggle" onchange="toggleCookie('{$display_error_cookie_key}', this.checked)" {$checked_display_errors}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td>$text_values</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugValuesToggle" onchange="toggleCookie('{$display_value_cookie_key}', this.checked)" {$checked_display_values}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td colspan="2">{$text_note}</td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
	<td colspan="2">{$text_display_cookies}</td>
	</tr>
	<tr>
		<td><input type="text" id="cookieKey" class="input-field" value="{$display_value_cookie_key}" readonly size="22"></td>
		<td><input type="text" id="dirString" class="input-field" value="{$dir_string}" readonly></td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
		<td><label for="php_error_filepath">{$text_php_filepath}</label></td>
		<td>{$text_php_filepath_value}</td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
		<td><label for="php_custom_filepath">{$text_custom_filepath_allowed}</label></td>
		<td><input type="text" id="php_custom_filepath" class="input-field" value="{$text_custom_filepath_allowed_value}" readonly ></td>
	</tr>
</table>
<br>

<script>
function toggleCookie(cookieName, isChecked) {
	const dirString = '{$dir_string}';

	if (isChecked) {
		document.cookie = cookieName + "=" + dirString + "; path=/";
	} else {
		document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
	}
}
</script>
HTML;

}

function get_excluded_errors_markup( $settings ){

	$errors = get_error_type_strings();
	
	unset( $errors[0], $errors[99999]);

	$output = '';

	foreach( $errors as $error_code => $error_name ){

		$excluded_error = in_array( $error_code , $settings['recorded_errors']??[]) ? $error_code : '';

		$checked = checked( $error_code, $excluded_error , false);

		$output .= <<<HTML
<tr class="table-line">
	<td>
		<input type="checkbox" id="error-{$error_code}" name="recorded_errors[]" value="{$error_code}" {$checked} >
	</td>
	<td class="display-key">
		{$error_name}
	</td>
</tr>
HTML;


	}

	return $output;
}

function save_new_settings($settings){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return;

	update_option('wpsd-php-debug-settings', json_encode($settings));

}
function has_rights_to_save(){

	return	isset($_POST['wpsd_php_debug_settings_nonce']) &&

			wp_verify_nonce($_POST['wpsd_php_debug_settings_nonce'], 'wpsd-php-debug-settings-save') &&

			current_user_can( 'manage_options' );
}

function get_settings_data(){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return json_decode( get_option('wpsd-php-debug-settings'), true);

	if ( !has_rights_to_save() ) { 
		
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'wpsd-php-debug' ) );
	
	}
	
	$settings = [

		'server'					=> isset($_POST['server']),

		'server_keys'				=> $_POST['server_keys'] ? preg_split('/\r\n|[\r\n]/', $_POST['server_keys']) : [],
		
		'post'						=> isset($_POST['post']),
		
		'cookies'					=> isset($_POST['cookies']),
		
		'cookies_keys_full_value' 	=> $_POST['cookies_keys_full_value'] ?

											preg_split('/\r\n|[\r\n]/', $_POST['cookies_keys_full_value']) : 

											[],
		
		'recorded_errors'			=> get_recorded_errors()
	];
	
	generate_error_reporting_settings( $settings );
	
	return $settings;

}

function generate_error_reporting_settings($settings) {

	$error_reporting = E_ALL;

	foreach($settings['recorded_errors'] as $error_code){
		switch (true) {
			case $error_code == 1:
				$error_reporting &= ~E_ERROR;
				break;
			case $error_code == 2:
				$error_reporting &= ~E_WARNING;
				break;
			case $error_code == 4:
				$error_reporting &= ~E_PARSE;
				break;
			case $error_code == 8:
				$error_reporting &= ~E_NOTICE;
				break;
			case $error_code == 16:
				$error_reporting &= ~E_CORE_ERROR;
				break;
			case $error_code == 32:
				$error_reporting &= ~E_CORE_WARNING;
				break;
			case $error_code == 64:
				$error_reporting &= ~E_COMPILE_ERROR;
				break;
			case $error_code == 128:
				$error_reporting &= ~E_COMPILE_WARNING;
				break;
			case $error_code == 256:
				$error_reporting &= ~E_USER_ERROR;
				break;
			case $error_code == 512:
				$error_reporting &= ~E_USER_WARNING;
				break;
			case $error_code == 1024:
				$error_reporting &= ~E_USER_NOTICE;
				break;
			case $error_code == 2048:
				$error_reporting &= ~E_STRICT;
				break;
			case $error_code == 4096:
				$error_reporting &= ~E_RECOVERABLE_ERROR;
				break;
			case $error_code == 8192:
				$error_reporting &= ~E_DEPRECATED;
				break;
			case $error_code == 16384:
				$error_reporting &= ~E_USER_DEPRECATED;
				break;
		}
	}

	update_option('wpsd-php-debug-error-reporting', $error_reporting, 'yes');
}

function get_recorded_errors(){
	
	if( !is_valid_form_errors_input() ) return [];
	
	$default_php_errors = get_error_type_strings();

	foreach( $_POST['recorded_errors'] as $form_error_value ){

		$form_error_value_int = intval( $form_error_value );

		if( !(isset( $default_php_errors[$form_error_value_int] ) || $form_error_value_int === 0) ) die('Unable to save');

		$result[] = $form_error_value_int; 
	}

	return $result??[];
}

function is_valid_form_errors_input(){

	return is_array($_POST['recorded_errors']??false) && !empty($_POST['recorded_errors']);
}

function get_markup_values($settings){
	
	return [
		'srv' => [
			'label' => __( 'Server:', 'wpsd-php-debug' ),
			'checked' => $settings['server'] ? 'checked' : ''
		],
		'srv_keys' => [
			'label' => __( 'Server Keys (one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['server_keys'])),
			'rows' => max(2,count($settings['server_keys']) + 1)
		],
		'pst' => [
			'label' => __( 'Post:', 'wpsd-php-debug' ),
			'checked' => $settings['post'] ? 'checked' : ''
		],
		'cks' => [
			'label' => __( 'Cookies:', 'wpsd-php-debug' ),
			'checked' => $settings['cookies'] ? 'checked' : ''
		],
		'cks_keys' => [
			'label' => __( 'Cookies Keys Full Value<br>(one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['cookies_keys_full_value'])),
			'rows' => max(2, count($settings['cookies_keys_full_value']) + 1)
		]
	];
}
