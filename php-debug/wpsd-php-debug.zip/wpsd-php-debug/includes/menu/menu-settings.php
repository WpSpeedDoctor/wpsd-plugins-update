<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

?>
<div class="wpsd-php-debug-body clear"><br>
	<?php

	$settings = get_settings_data();

	save_new_settings($settings);

	$markup_values = get_markup_values($settings);


	the_inlined_css_settings_page();

	?>

	<form method="post" action="" class="debug-plugin-settings">
		<table>
			<tr class="table-line">
				<td class="display-key"><?= $markup_values['srv']['label'] ?></td>
				<td><input type="checkbox" id="srv" name="server" <?= $markup_values['srv']['checked'] ?>></td>
			</tr>
			<tr class="table-line">
				<td class="display-key"><?= $markup_values['srv_keys']['label'] ?></td>
				<td><textarea id="srv_keys" name="server_keys" rows="<?= $markup_values['srv_keys']['rows'] ?>" cols="40"><?= $markup_values['srv_keys']['value'] ?></textarea></td>
			</tr>
			<tr class="table-line">
				<td class="display-key"><?= $markup_values['pst']['label'] ?></td>
				<td><input type="checkbox" id="pst" name="post" <?= $markup_values['pst']['checked'] ?>></td>
			</tr>
			<tr class="table-line">
				<td class="display-key"><?= $markup_values['cks']['label'] ?></td>
				<td><input type="checkbox" id="cks" name="cookies" <?= $markup_values['cks']['checked'] ?>></td>
			</tr>
			<tr class="table-line">
				<td class="display-key"><?= $markup_values['cks_keys']['label'] ?></td>
				<td><textarea id="cks_keys" name="cookies_keys_full_value" rows="<?= $markup_values['cks_keys']['rows'] ?>" cols="40"><?= $markup_values['cks_keys']['value'] ?></textarea></td>
			</tr>
			<tr class="table-line">
			<?php wp_nonce_field( 'wpsd-php-debug-settings-save', 'wpsd_php_debug_settings_nonce' ); ?>
			
			<input type="hidden" name="action" value="save_settings">

				<td colspan="2"><input type="submit" value="<?= __( 'Save Settings', 'wpsd-php-debug' ) ?>" class="button button-primary"></td>
			</tr>
		</table>
	</form>
</div>
<hr>
<h4><?php echo __( 'Display PHP errors', 'wpsd-php-debug' ) ?></h4>
<p>
	This sets cookie `php-debug` and will show PHP error only to you. If you logout, cookie will remain valid and PHP errors will be displayed, but only to you.
</p>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 34px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:checked + .slider:before {
  transform: translateX(26px);
}
</style>
</head>
<body>
<label class="switch">
  <input type="checkbox" id="debugToggle" onchange="toggleCookie()" 
         <?php if (isset($_COOKIE['php-debug'])) echo 'checked'; ?>>
  <span class="slider"></span>
</label>

<script>
function toggleCookie() {
  const checkbox = document.getElementById('debugToggle');
  const checked = checkbox.checked;
  if (checked) {
    document.cookie = "php-debug=true; path=/";
  } else {
    document.cookie = "php-debug=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
  }
}
</script>
<?php


function save_new_settings($settings){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return;
	
	update_option('wpsd-php-debug-settings', json_encode($settings));

}
function has_rights_to_save(){

	return	isset($_POST['wpsd_php_debug_settings_nonce']) &&

			wp_verify_nonce($_POST['wpsd_php_debug_settings_nonce'], 'wpsd-php-debug-settings-save') &&

			current_user_can( 'manage_options' );
}

function get_settings_data(){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return json_decode( get_option('wpsd-php-debug-settings'), true);

	if ( !has_rights_to_save() ) { 
		
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'wpsd-php-debug' ) );
	
	}
	
	$settings = [

		'server' => isset($_POST['server']),

		'server_keys' => $_POST['server_keys'] ? preg_split('/\r\n|[\r\n]/', $_POST['server_keys']) : [],
		
		'post' => isset($_POST['post']),
		
		'cookies' => isset($_POST['cookies']),
		
		'cookies_keys_full_value' => $_POST['cookies_keys_full_value'] ? preg_split('/\r\n|[\r\n]/', $_POST['cookies_keys_full_value']) : [],
	
	];

	return $settings;

}

function get_markup_values($settings){
	
	return [
		'srv' => [
			'label' => __( 'Server:', 'wpsd-php-debug' ),
			'checked' => $settings['server'] ? 'checked' : ''
		],
		'srv_keys' => [
			'label' => __( 'Server Keys (one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['server_keys'])),
			'rows' => max(2,count($settings['server_keys']) + 1)
		],
		'pst' => [
			'label' => __( 'Post:', 'wpsd-php-debug' ),
			'checked' => $settings['post'] ? 'checked' : ''
		],
		'cks' => [
			'label' => __( 'Cookies:', 'wpsd-php-debug' ),
			'checked' => $settings['cookies'] ? 'checked' : ''
		],
		'cks_keys' => [
			'label' => __( 'Cookies Keys Full Value (one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['cookies_keys_full_value'])),
			'rows' => max(2, count($settings['cookies_keys_full_value']) + 1)
		]
	];
}

function the_inlined_css_settings_page(){

	?>
<style>
.debug-plugin-settings {
    width: 100%;
}

.table-line {
    display: table-row;
}

.display-key {
    vertical-align: top;
}

.table-line td {
    padding-bottom: 10px;
}

textarea {
    width: 100%;
    resize: vertical;
}

input[type="checkbox"] {
    margin-top: 5px;
}

input[type="submit"] {
    margin-top: 10px;
}

</style>
	<?php
}