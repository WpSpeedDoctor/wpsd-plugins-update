<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$settings = get_settings_data();

save_new_settings($settings);

$markup_values = get_markup_values($settings);

$text = [
	'save_additional_data'		=> __('Save additional data:', 'wpsd-php-debug'),
	'send_fatal_error_report'	=> __('Send fatal error report', 'wpsd-php-debug'),
	'exclude_errors_logging'	=> __('Exclude errors from logging', 'wpsd-php-debug'),
	'save_settings'				=> __('Save Settings', 'wpsd-php-debug')
];

$excluded_errors_markup = get_excluded_errors_markup($settings);

$nonce_field = wp_nonce_field('wpsd-php-debug-settings-save', 'wpsd_php_debug_settings_nonce', false, false);

$display_data_markup = get_display_data_markup();

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<form method="post" action="" class="debug-plugin-settings">
		<div class="tables-wrap">
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2"><strong>{$text['save_additional_data']}</strong></th>
					</tr>
				</thead>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv']['label']}</td>
					<td><input type="checkbox" id="srv" name="server" {$markup_values['srv']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv_keys']['label']}</td>
					<td><textarea id="srv_keys" name="server_keys" rows="{$markup_values['srv_keys']['rows']}" cols="40">{$markup_values['srv_keys']['value']}</textarea></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['pst']['label']}</td>
					<td><input type="checkbox" id="pst" name="post" {$markup_values['pst']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks']['label']}</td>
					<td><input type="checkbox" id="cks" name="cookies" {$markup_values['cks']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks_keys']['label']}</td>
					<td><textarea id="cks_keys" name="cookies_keys_full_value" rows="{$markup_values['cks_keys']['rows']}" cols="40">{$markup_values['cks_keys']['value']}</textarea></td>
				</tr>
				<tr>
					<th class="table-title" colspan="2"><br><strong>{$text['send_fatal_error_report']}</strong></th>
				</tr>
				<tr class="table-line">
					<td class="report-email">{$markup_values['report_email']['label']}</td>
					<td><input type="text" id="report_email" name="report_email" cols="40" value="{$markup_values['report_email']['value']}"></input></td>
				</tr>
			</table>
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2">{$text['exclude_errors_logging']}</th>
					</tr>
				</thead>
				<tr>
					<td colspan="2">
						{$excluded_errors_markup}
					</td>
				</tr>
			</table>
			<div>
				{$display_data_markup}
			</div>
		</div>
		{$nonce_field}
		<input type="hidden" name="action" value="save_settings">
		<input type="submit" value="{$text['save_settings']}" class="button button-primary">
	</form>
</div>
HTML;


//end of display_errors



function get_display_data_markup(){

	$texts = get_display_data_texts();

	return <<<HTML
<table class="wpsd-table">
	<thead>
		<tr>
			<th class="table-title" colspan="2">{$texts['title']}</th>
		</tr>
	</thead>
	<tr>
		<td>{$texts['text_errors']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugToggle" onchange="toggleCookie('{$texts['display_error_cookie_key']}', this.checked)" {$texts['checked_display_errors']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td>{$texts['text_values']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugValuesToggle" onchange="toggleCookie('{$texts['display_value_cookie_key']}', this.checked)" {$texts['checked_display_values']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td colspan="2">{$texts['text_note']}</td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
	<td colspan="2">{$texts['text_display_cookies']}</td>
	</tr>
	<tr>
		<td><input type="text" id="cookieKey" class="input-field" value="{$texts['display_value_cookie_key']}" readonly size="22"></td>
		<td><input type="text" id="dirString" class="input-field" value="{$texts['dir_string']}" readonly></td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
		<td><label for="php_custom_filepath">{$texts['text_custom_filepath_allowed']}</label></td>
		<td><input type="text" id="php_custom_filepath" class="input-field" value="{$texts['text_custom_filepath_allowed_value']}" readonly ></td>
	</tr>
	<tr><td><br style="visibility:hidden"></td></tr>
	<tr>
		<td><label for="php_error_filepath">{$texts['text_sqlite_version']}</label></td>
		<td>{$texts['sqlite_version']}</td>
	</tr>
</table>
<p>
{$texts['text_php_filepath']}:<br>
{$texts['text_php_filepath_value']}
<p>
{$texts['db_path_text']}
{$texts['db_path']}
</p>
<p>
{$texts['db_size_text']} {$texts['db_size']}
</p>
<script>
function toggleCookie(cookieName, isChecked) {
	const dirString = '{$texts['dir_string']}';

	if (isChecked) {
		document.cookie = cookieName + "=" + dirString + "; path=/";
	} else {
		document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
	}
}
</script>
HTML;

}

function get_display_data_texts(){

	$dir_string = substr(get_option('wpsd-php-debug-dir'), 6, 20);

	$display_error_cookie_key = 'wpsd-debug-display-errors';

	$display_value_cookie_key = 'wpsd-debug-display-values';
	
	$checked_display_errors = checked($_COOKIE[$display_error_cookie_key] ?? '', $dir_string, false);
	
	$checked_display_values = checked($_COOKIE[$display_value_cookie_key] ?? '', $dir_string, false);

	$db_filepath = get_db_filepath();

	return [
		'dir_string' => $dir_string,
		'display_error_cookie_key' => $display_error_cookie_key,
		'display_value_cookie_key' => $display_value_cookie_key,
		'checked_display_errors' => $checked_display_errors,
		'checked_display_values' => $checked_display_values,
		'title' => esc_html__( 'Displaying data & useful info', 'wpsd-php-debug' ),
		'text_display_cookies' => esc_html__( 'This cookie will enable displaying debug values:', 'wpsd-php-debug' ),
		'text_errors' => esc_html__( 'Display PHP Errors', 'wpsd-php-debug' ),
		'text_values' => esc_html__( 'Display Debug Values', 'wpsd-php-debug' ),
		'text_php_filepath' => esc_html__( 'PHP error filepath', 'wpsd-php-debug' ),
		'text_php_filepath_value' => esc_html(ini_get('error_log')),
		'text_custom_filepath_allowed' => esc_html__( 'Custom PHP error filepath allowed', 'wpsd-php-debug' ),
		'text_custom_filepath_allowed_value' => get_option( 'wpsd-php-ini-set-allowed') ? esc_html__( 'Yes', 'wpsd-php-debug' ) : esc_html__( 'No', 'wpsd-php-debug' ),
		'text_note' => esc_html__( 'Note: The Display Settings are not saved, they have to be manually activated after login.', 'wpsd-php-debug' ),
		'db_path_text' => esc_html__( 'Path to Sqlite database:', 'wpsd-php-debug' ),
		'db_path' => $db_filepath === '' ? esc_html__( 'Database is not created', 'wpsd-php-debug' ) : "<br>$db_filepath",
		'db_size_text' => esc_html__( 'Size of SQLite database:', 'wpsd-php-debug' ),
		'db_size' =>  $db_filepath === '' ? '-' : size_format( filesize( get_db_filepath() ) ),
		'text_sqlite_version' => esc_html__( 'SQLite version', 'wpsd-php-debug' ),
		'sqlite_version' => \SQLite3::version()['versionString']
	];

}


function get_excluded_errors_markup( $settings ){

	$errors = get_error_type_strings();
	
	unset( $errors[0], $errors[99999]);

	$output = '';

	foreach( $errors as $error_code => $error_name ){

		$excluded_error = in_array( $error_code , $settings['excluded_errors']??[]) ? $error_code : '';

		$checked = checked( $error_code, $excluded_error , false);

		$output .= <<<HTML
<tr class="table-line">
	<td>
		<input type="checkbox" id="error-{$error_code}" name="excluded_errors[]" value="{$error_code}" {$checked} >
	</td>
	<td class="display-key">
		{$error_name}
	</td>
</tr>
HTML;


	}

	return $output;
}

function save_new_settings($settings){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return;

	update_option('wpsd-php-debug-settings', json_encode($settings));

}
function has_rights_to_save(){

	return	isset($_POST['wpsd_php_debug_settings_nonce']) &&

			wp_verify_nonce($_POST['wpsd_php_debug_settings_nonce'], 'wpsd-php-debug-settings-save') &&

			current_user_can( 'manage_options' );
}

function get_settings_data(){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return json_decode( get_option('wpsd-php-debug-settings'), true);

	if ( !has_rights_to_save() ) { 
		
		wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'wpsd-php-debug' ) );
	
	}

	$settings = [

		'server'					=> get_textarea_values('server'),

		'server_keys'				=> $_POST['server_keys'] ? preg_split('/\r\n|[\r\n]/', $_POST['server_keys']) : [],
		
		'post'						=> isset($_POST['post']),
		
		'cookies'					=> isset($_POST['cookies']),
	
		'report_email'				=> get_validated_emails(),
		
		'excluded_errors'			=> get_excluded_errors(),

		'cookies_keys_full_value' 	=> get_textarea_values('cookies_keys_full_value')
	];
	
	generate_error_reporting_settings( $settings );
	
	return $settings;

}

function get_validated_emails(){

	if( empty($_POST['report_email']) || !str_contains($_POST['report_email'],'@'  )) return '';
	
	$input_string = $_POST['report_email']??'';

	$pieces = explode(',', $input_string);

	$filtered_emails = [];

	foreach ($pieces as $email){

		$filtered_emails[] = filter_var( trim($email), FILTER_VALIDATE_EMAIL );
	}

	return implode( ', ', $filtered_emails);

}

function get_textarea_values($post_key){

	if( !isset($_POST[$post_key]) || !is_string($_POST[$post_key]) ) return [];
	
	return $_POST[$post_key] === '' ? [] : preg_split('/\r\n|[\r\n]/', $_POST[$post_key]);
}

function generate_error_reporting_settings($settings) {

	$error_reporting = E_ALL;

	foreach($settings['excluded_errors'] as $error_code){
		switch (true) {
			case $error_code == 1:
				$error_reporting &= ~E_ERROR;
				break;
			case $error_code == 2:
				$error_reporting &= ~E_WARNING;
				break;
			case $error_code == 4:
				$error_reporting &= ~E_PARSE;
				break;
			case $error_code == 8:
				$error_reporting &= ~E_NOTICE;
				break;
			case $error_code == 16:
				$error_reporting &= ~E_CORE_ERROR;
				break;
			case $error_code == 32:
				$error_reporting &= ~E_CORE_WARNING;
				break;
			case $error_code == 64:
				$error_reporting &= ~E_COMPILE_ERROR;
				break;
			case $error_code == 128:
				$error_reporting &= ~E_COMPILE_WARNING;
				break;
			case $error_code == 256:
				$error_reporting &= ~E_USER_ERROR;
				break;
			case $error_code == 512:
				$error_reporting &= ~E_USER_WARNING;
				break;
			case $error_code == 1024:
				$error_reporting &= ~E_USER_NOTICE;
				break;
			case $error_code == 2048:
				$error_reporting &= ~E_STRICT;
				break;
			case $error_code == 4096:
				$error_reporting &= ~E_RECOVERABLE_ERROR;
				break;
			case $error_code == 8192:
				$error_reporting &= ~E_DEPRECATED;
				break;
			case $error_code == 16384:
				$error_reporting &= ~E_USER_DEPRECATED;
				break;
		}
	}

	update_option('wpsd-php-debug-error-reporting', $error_reporting, 'on');

}

function get_excluded_errors(){
	
	if( !is_valid_form_errors_input() ) return [];
	
	$default_php_errors = get_error_type_strings();

	foreach( $_POST['excluded_errors'] as $form_error_value ){

		$form_error_value_int = intval( $form_error_value );

		if( !(isset( $default_php_errors[$form_error_value_int] ) || $form_error_value_int === 0) ) die('Unable to save');

		$result[] = $form_error_value_int; 
	}

	return $result??[];
}

function is_valid_form_errors_input(){

	return is_array($_POST['excluded_errors']??false) && !empty($_POST['excluded_errors']);
}

function get_markup_values($settings){
	
	return [
		'srv' => [
			'label' => __( 'Server:', 'wpsd-php-debug' ),
			'checked' => $settings['server'] ? 'checked' : ''
		],
		'srv_keys' => [
			'label' => __( 'Server Keys<br>(one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['server_keys'])),
			'rows' => max(2,count($settings['server_keys']) + 1)
		],
		'pst' => [
			'label' => __( 'Post:', 'wpsd-php-debug' ),
			'checked' => $settings['post'] ? 'checked' : ''
		],
		'cks' => [
			'label' => __( 'Cookies:<br>(clamped values)', 'wpsd-php-debug' ),
			'checked' => $settings['cookies'] ? 'checked' : ''
		],
		'cks_keys' => [
			'label' => __( 'Cookies Keys Full Value<br>(one per line):', 'wpsd-php-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['cookies_keys_full_value'])),
			'rows' => max(2, count($settings['cookies_keys_full_value']) + 1)
		],
		'report_email' => [
			'label' => __( 'Send fatal error warning<br>to this email<br>leave empty to disable', 'wpsd-php-debug' ),
			'value' => $settings['report_email']??'',
			'rows' => 40
		]
	];
}
