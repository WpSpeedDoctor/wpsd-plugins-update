<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

$table_content = get_into_table_content();

echo <<<HTML
<table class="wpsd-info-table">
	$table_content
</table>
HTML;

return;

function get_into_table_content(){
		
	$info_data = get_info_tab_data();

	$table_content = '';

	foreach ( $info_data as $data ){

		$columns = get_columns_markup( $data );
		
		$table_content .= <<<HTML
		<tr id="{$data['name']}">{$columns}</tr>
		HTML;
	}

	return $table_content;
}

function get_columns_markup( $data ){

	if( !isset($data['value']) || $data['value'] === '' ){

		return <<<HTML
		<td colspan="2">{$data['text']}</td>
		HTML;
	}

	return <<<HTML
	<td >{$data['text']}</td>
	<td>{$data['value']}</td>
	HTML;

}

$texts = get_info_display_data_texts();

echo <<<HTML
<p>
{$texts['text_php_filepath']}:<br>
{$texts['text_php_filepath_value']}
<p>
{$texts['db_path_text']}
{$texts['db_path']}
</p>
<table class="wpsd-table">
	<tr>
		<td class="regex-checkbox">
			<label for="sqlite_version">
				{$texts['text_sqlite_version']}
			</label>
		</td>
		<td>
			{$texts['sqlite_version']}
		</td>
	</tr>
	<tr>
		<td class="regex-checkbox">
			<label for="db_size">
			{$texts['db_size_text']} 
			</label>
		</td>
		<td>{$texts['db_size']}</td>
	</tr>
	<tr>
		<td class="regex-checkbox">
			<label for="php_custom_filepath">
				{$texts['text_custom_filepath_allowed']}
			</label>
		</td>
		<td>
			{$texts['text_custom_filepath_allowed_value']}
		</td>
	</tr>
	<tr>
		<td><br></td>
	</tr>
	<tr>
		<td colspan="2">
			{$texts['cookie_info']}
		</td>
	</tr>
	<tr>
		<td>
			<input type="text" class="input-field" value="{$texts['display_error_cookie_key']}" readonly size="22">
		</td>
		<td>
			<input type="text" id="dirString" class="input-field" value="{$texts['cookie_nonce']}" readonly>
		</td>
	</tr>
	<tr>
		<td>
			<input type="text" class="input-field" value="{$texts['display_value_cookie_key']}" readonly size="22">
		</td>
		<td>
			<input type="text" class="input-field" value="{$texts['cookie_nonce']}" readonly>
		</td>
	</tr>
</table>
HTML;



function get_info_display_data_texts(){

	$cookies = get_debug_cookies();

	// $cookies->nonce
	// $cookies->display_errors
	// $cookies->display_values

	$db_filepath = get_db_filepath();
	
	return [
		'cookie_nonce' => $cookies->nonce,
		'display_error_cookie_key' => $cookies->display_errors,
		'display_value_cookie_key' => $cookies->display_values,
		'cookie_info'	=> esc_html__( 'Manually set cooies to display error and debug mssages', 'wpsd-php-debug' ),
		'text_php_filepath' => esc_html__( 'PHP error filepath', 'wpsd-php-debug' ),
		'text_php_filepath_value' => esc_html(ini_get('error_log')),
		'text_custom_filepath_allowed' => esc_html__( 'Custom PHP error filepath allowed', 'wpsd-php-debug' ),
		'text_custom_filepath_allowed_value' => get_wpsd_option( 'wpsd-ini-status') ? '<span>✔</span>' : '<span>✘</span>',
		'db_path_text' => esc_html__( 'Path to Sqlite database:', 'wpsd-php-debug' ),
		'db_path' => $db_filepath === '' ? esc_html__( 'Database is not created', 'wpsd-php-debug' ) : "<br>$db_filepath",
		'db_size_text' => esc_html__( 'Size of SQLite database:', 'wpsd-php-debug' ),
		'db_size' =>  $db_filepath === '' ? '-' : size_format( filesize( get_db_filepath() ) ),
		'text_sqlite_version' => esc_html__( 'SQLite version', 'wpsd-php-debug' ),
		'sqlite_version' => class_exists('SQLite3') ? \SQLite3::version()['versionString'] : 'Not present',
	];

}

function get_info_tab_data(){

	$cookies = get_debug_cookies();

	$db_filepath = get_db_filepath();

	$data = [

		[
			'name'	=> 'php_errors',
			'text'	=> esc_html__( 'PHP Error log', 'wpsd-php-debug' ),
		],
		[
			'name'	=> 'custom_filepath_allowed',
			'text'	=> esc_html__( 'Custom PHP error filepath allowed', 'wpsd-php-debug' ),
			'value'	=> get_wpsd_option( 'wpsd-ini-status') ? '<span>✔</span>' : '<span>✘</span>',
		],
		[
			'name'	=> 'php_filepath',
			'text'	=> esc_html__( 'PHP error file path', 'wpsd-php-debug' ),
			'value'	=> esc_html( ini_get('error_log') ),
		],		
		[
			'name'	=> 'space',
			'text'	=> '<span style="visibility:hidden"><br><span>',
		],
		[
			'name'	=> 'php_errors',
			'text'	=> esc_html__( 'SQLite database:', 'wpsd-php-debug' ),
		],
		[
				'name'	=> 'db_path_text',
				'text'	=> esc_html__( 'Path to Sqlite database:', 'wpsd-php-debug' ),
				'value'	=> $db_filepath ?: esc_html__( 'Database is not created', 'wpsd-php-debug' ),
		],
		[
			'name'	=> 'db_size_text',
			'text'	=> esc_html__( 'Size of SQLite database:', 'wpsd-php-debug' ),
			'value'	=> $db_filepath === '' ? '-' : size_format( filesize( get_db_filepath() ) ),
		],
	
		[
			'name'	=> 'sqlite_version',
			'text'	=> esc_html__( 'SQLite3 extention version', 'wpsd-php-debug' ),
			'value'	=> class_exists('SQLite3') ? \SQLite3::version()['versionString'] : esc_html__( 'Not active', 'wpsd-php-debug' ),
		],
		[
			'name'	=> 'space',
			'text'	=> '<span style="visibility:hidden"><br><span>',
		],
		[
			'name'	=> 'cookie_info',
			'text'	=> esc_html__( 'Manually set cookies to display error and debug mssages', 'wpsd-php-debug' ),
		],

		[
			'name'	=> 'display_error_cookie_key',
			'text'	=> $cookies->display_errors,
			'value'	=> $cookies->nonce,
		],
	
		[
			'name'	=> 'display_value_cookie_key',
			'text'	=> $cookies->display_values,
			'value'	=> $cookies->nonce,
		],
	];

	add_server_load( $data );

	add_global_server( $data );

	add_opcache_stats( $data );

	add_plugins_required_files( $data );

	return $data;
	
}

function add_plugins_required_files( &$data ){

	require_once WPSD_DEBUG_DIR.'includes/required-files.php';

	$usage = get_required_plugin_opcache_usage();
	
	if( empty( $usage ) ){

		return;
	}

	$data[] =  [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];
	
    $data[] = [
        'name'    => 'plugins_required_files',
        'text'    => esc_html__( 'Files of plugins currently required and thier used memory in the OPCache', 'wpsd-php-debug' ),
    ];

	foreach ( $usage as $plugin => $info ){

		$size_string = size_format( $info['memory_usage'] );
	
		$file_count = $info['files'] ?? 0;
	
		$file_text = sprintf(
			esc_html( _n( '%s in %d file', '%s in %d files', $file_count, 'wpsd-php-debug' ) ),
			$size_string,
			$file_count
		);
	
		$data[] = [
			'name'  => $plugin,
			'text'  => $plugin,
			'value' => $file_text,
		];
	
	}

}

function add_global_server( &$data ){

	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];

	$data[] = [
		'name'	=> 'server',
		'text'	=> esc_html__( '$_SERVER', 'wpsd-php-debug' ),
	];

	foreach( $_SERVER as $key => $value ){

		$data[] = [
			'name'	=> $key,
			'text'	=> $key,
			'value'	=> $value,
		];

	}

}

function add_opcache_stats( &$data ){

	switch(true){
		case !function_exists('opcache_get_status'):
		case !( $status = opcache_get_status(false) );
			return;
	}

	$used_memory        = $status['memory_usage']['used_memory'];

	$free_memory        = $status['memory_usage']['free_memory'];

	$wasted_memory      = $status['memory_usage']['wasted_memory'];

	$memory_total       = $used_memory + $free_memory + $wasted_memory;

	$used_percent       = $memory_total > 0 ? (int)( $used_memory / $memory_total * 100 ) : 0;

	$cached_files       = $status['opcache_statistics']['num_cached_scripts'];

	$hits               = $status['opcache_statistics']['hits'];

	$misses             = $status['opcache_statistics']['misses'];

	$buffer_size        = $status['interned_strings_usage']['buffer_size'];

	$interned_used      = $status['interned_strings_usage']['used_memory'];

	$interned_free      = $status['interned_strings_usage']['free_memory'];
	
	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];
	
	$data[] = [
		'name'	=> 'opcache',
		'text'	=> esc_html__( 'OPCache statistics', 'wpsd-php-debug' ),
	];

	$data[] = [
		'name'  => 'used_memory',
		'text'  => 'Memory Used',
		'value' => $used_memory,
	];
	
	$data[] = [
		'name'  => 'free_memory',
		'text'  => 'Memory Free',
		'value' => $free_memory,
	];
	
	$data[] = [
		'name'  => 'wasted_memory',
		'text'  => 'Memory Wasted',
		'value' => $wasted_memory,
	];
	
	$data[] = [
		'name'  => 'used_percent',
		'text'  => 'Memory Used (%)',
		'value' => $used_percent,
	];
	
	$data[] = [
		'name'  => 'num_cached_scripts',
		'text'  => 'Cached Files',
		'value' => $cached_files,
	];
	
	$data[] = [
		'name'  => 'hits',
		'text'  => 'Cache Hits',
		'value' => $hits,
	];
	
	$data[] = [
		'name'  => 'misses',
		'text'  => 'Cache Misses',
		'value' => $misses,
	];
	
	$data[] = [
		'name'  => 'buffer_size',
		'text'  => 'Interned Buffer Size',
		'value' => $buffer_size,
	];
	
	$data[] = [
		'name'  => 'interned_used',
		'text'  => 'Interned Memory Used',
		'value' => $interned_used,
	];
	
	$data[] = [
		'name'  => 'interned_free',
		'text'  => 'Interned Memory Free',
		'value' => $interned_free,
	];

}

function add_server_load( &$data ){

	$load = function_exists('sys_getloadavg') ? sys_getloadavg() : false;

	if( !is_array($load) || count($load) < 3 ) return;

	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];

	$data[] = [
		'name'	=> 'server',
		'text'	=> esc_html__( 'Server load', 'wpsd-php-debug' ),
	];

	$value = round($load[0], 2 ) .' / '. round($load[1], 2 ) .' / '. round( $load[2], 2 );

	$data[] = [
		'name'  => 'server_load',
		'text'  => 'Server Load (1/5/15 min)',
		'value' => $value,
	];

}
