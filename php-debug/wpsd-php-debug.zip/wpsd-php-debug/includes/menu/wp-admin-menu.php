<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


function admin_menu_main(){
    
	enqueue_plugins_assets();

	the_menu();

}


function the_menu(){
	
	$active_tab = $_GET['tab']??'home';
	
	$tab_arr = get_tabs_arr();

	if( !in_array( $active_tab, array_keys($tab_arr) ) ) wp_die('Page doesn\'t exist');


	the_header();

	if( class_exists('SQLite3') ) {

		display_tab_links($active_tab);
		
		include WPSD_PHP_DEBUG_DIR."includes/menu/{$tab_arr[$active_tab]['require']}";

	} else {
		
        echo '<p>'.esc_html__('The required PHP extension "SQLite3" is not installed. Please install it to use this plugin.', 'wpsd-php-debug'  ).'</p>';
	}

	the_footer();
}

function display_tab_links( $active_tab ){
	
	?><nav class="nav-tabs"><?php
	
	foreach (get_tabs_arr() as $slug => $tab_arr){
		
		$active_tab_class = ($slug === $active_tab) ? ' nav-tab-active' : '';
		
		$tab_qs = $slug == 'home' ? '':'&tab='.$slug;
		
		?>
		<a href="?page=wpsd-php-debug-page<?=$tab_qs?>" class="nav-tab<?=$active_tab_class?>">
			<?=$tab_arr['title']?>
		</a>
		<?php
	}
	
?></nav>
<div class="wpsd-php-debug-body clear">
<?php
}




function the_header() {

	$text = esc_html__('Advanced PHP and WordPress debug', 'wpsd-php-debug');

	echo <<<HTML
<div class="wrap php-debug-plugin-wrap">
	<h1>{$text}</h1>
HTML;

}

function the_footer(){

	//</div>wpsd-php-debug-body
?>	</div>
</div><?php
}


function enqueue_plugins_assets(){

	// "f"is there just to make it though WP function, not a real path or file
	$plugin_url_dir = plugin_dir_url(WPSD_PHP_DEBUG_DIR.'f'); 

    wp_register_style( 
		
		'wpsd-php-debug',

		"{$plugin_url_dir}assets/wpsd-php-debug.css",

		false,

		WPSD_PHP_DEBUG_VER
	);

    
	wp_enqueue_style( 'wpsd-php-debug' );

	wp_register_script( 
		
		'htmx',
	
		"{$plugin_url_dir}assets/htmx.min.js",

		false,
		
		'1.9.12',
		
		['strategy' => 'defer', 'in_footer' => true]
	);

	wp_enqueue_script( 'htmx' );
	
	
}

function get_tabs_arr(){

	return [
		
		'home'		=> [ 
				
			'title' 	=> __('Home','litespeed-crawler'),
			'require'	=> 'menu-home.php',
		],
		'settings'	=> [

			'title' 	=> __('Settings','litespeed-crawler'),
			'require'	=> 'menu-settings.php',
		],
		'docs'		=> [

			'title' 	=> __('FAQs & Docs','litespeed-crawler'),
			'require'	=> 'menu-faq-docs.php',
		]
		
	
	];

}
