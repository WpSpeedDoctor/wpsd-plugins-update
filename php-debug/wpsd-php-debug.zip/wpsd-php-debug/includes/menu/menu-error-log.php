<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

display_error_log();


function display_error_log(){
	
	$texts = get_error_form_texts();

	$nonce  = get_nonce();

	$this_server_error_log = basename( get_error_log_filename() );

	echo <<<HTML
<br>
<form class="input-form" id="debugForm"
	hx-post="{$texts['ajax_url']}"
	hx-vals='{
	"action": "htmx-php-debug-search",
	"source-error-log": "1",
	"nonce": "{$nonce}"
	}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-indicator="#htmx-spinner"
	hx-target="#display-data">
	{$texts['select_log_file']}
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button">
		<span class="dashicons dashicons-image-rotate"></span>
	</button>
	<input type="hidden" name="action" value="php-debug-search">
	<input type="text" name="search-keyword" placeholder="{$texts['search_placeholder']}">
	<input type="checkbox" name="search-regex"><span class="regex-checkbox">.*</span>
	<input type="text" name="exclude-keyword" placeholder="{$texts['exclude_placeholder']}">
	<input type="checkbox" name="exclude-regex"><span class="regex-checkbox">.*</span>
	<select name="order">
		<option value="desc">{$texts['newest_option']}</option>
		<option value="asc">{$texts['oldest_option']}</option>
	</select>
	{$texts['per_page']}
	<select name="per-page">
		<option>10</option>
		<option>50</option>
		<option>200</option>
		<option>1</option>
	</select>
	</div>
</form>
<img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18">
<div id="display-data"
hx-post="{$texts['ajax_url']}"
	hx-trigger="load"
	hx-headers='{"Content-Type": "application/json"}'
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals='{"action": "htmx-php-debug-search",
				"source-error-log": "1",
				"search-keyword": "",
				"exclude-keyword": "",
				"error-type": 0,
				"order": "desc",
				"nonce": "{$nonce}",
				"db-filename": "{$this_server_error_log}"
				}'>
</div>
<script>
//Auto trigger post
const form = document.querySelector('.input-form');
let timeoutId;

function debounce(func, delay) {
	clearTimeout(timeoutId);
	timeoutId = setTimeout(func, delay);
}

form.addEventListener('input', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

form.addEventListener('change', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});
</script>
HTML;
	
}


function get_error_form_texts(){

	return [
		'search_placeholder' => esc_html__('Search', 'wpsd-php-debug'),
		'exclude_placeholder' => esc_html__('Exclude', 'wpsd-php-debug'),
		'newest_option' => esc_html__('Newest', 'wpsd-php-debug'),
		'oldest_option' => esc_html__('Oldest', 'wpsd-php-debug'),
		'download_log' => esc_html__('Download log', 'wpsd-php-debug'),
		'loading' => esc_html__('Loading...', 'wpsd-php-debug'),
		'selected_date' => esc_html__('Date:', 'wpsd-php-debug'),
		'per_page' => esc_html__('Per page:', 'wpsd-php-debug'),
		'ajax_url' => admin_url('/admin-ajax.php?php-debug-search'),
		'today' => date('Y-m-d'),
		'select_log_file' => get_select_log_file_markup(),
	];

}

function get_select_log_file_markup(){

	$files = get_log_files();

	if( empty($files) ) return '';

	$text_select = esc_html__('Error log:', 'wpsd-php-debug');

	$this_server_error_log = basename( get_error_log_filename() );

	$output = '';

	foreach( $files as $filename){

		$selected = $this_server_error_log === $filename ? 'selected' : '';

		$output .= 
			<<<HTML
			<option value="{$filename}" {$selected}>{$filename}</option>
			HTML;
	
	}

	
	return
	<<<HTML
	<div class="form-elements-wrap">
		{$text_select}
		<select name="db-filename">
			{$output}
		</select>
	</div>
	HTML;
	
	
	return $output;
}

function get_log_files(){

	if(  get_option( 'wpsd-php-ini-set-allowed') !== '1' )	return [];
	
	$dir = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$this_server_error_log = get_error_log_filename();

	$log_files = glob("{$dir}/*.log");

	if( !$log_files ) return [];

	$file_data = [];

	foreach($log_files as $file){
		$file_data[] = [
			'file' => basename($file),
			'time' => filemtime($file)
		];
	}

	usort($file_data, function($a, $b){
		return $b['time'] - $a['time'];
	});

	$sorted_files = [];

	if( ($key = array_search($this_server_error_log, array_column($file_data, 'file'))) !== false ){

		$sorted_files[] = $file_data[$key]['file'];
		
		unset($file_data[$key]);
	
	}

	foreach($file_data as $file) $sorted_files[] = $file['file'];

	return $sorted_files;
}
