<?php

namespace wpsd_php_debug;

class sqlite_recorder{
	
	private $ip;

	private $db=[];

	private $log_dir;

	private $fragments_dir;

	public $available_ram;

	private $fragments;

	public $fragments_recorded = 0;

	public $has_all_loaded = false;

	public $has_fragments_to_record = false;

	public $debug = true;

	public $debug_message = '';

	private $directory;

	private $data_size = 0;

    public function __construct($ip){

		$this->available_ram = $this->get_available_ram()*0.10;

		$this->ip = is_numeric($ip) ? ".{$ip}" : false; 

		$this->log_dir = \WP_CONTENT_DIR.get_log_dir_string();

		$this->fragments_dir = $this->log_dir.'fragments/';

		$this->fragments = [];

		$this->directory = dir( $this->fragments_dir );

	}

	public function __destruct(){
	
		$this->close_all_sqlite_dbs();

		$this->directory->close();

	}

	public function record_fragments_files(){
		
		if( !$this->ip ){
			
            return;
		}

		while( !$this->has_all_loaded ){

			$this->load_fragments_to_ram();

			if( !$this->has_fragments_to_record ){
				
				$this->has_all_loaded = true;

				break;
			}
			
			$this->open_dbs();
			
			$this->record_metadata();
			
			$this->record_errors();

			$this->delete_fragments();

			$this->free_up_memory();

			if( $this->debug ) $this->debug_message = '';
		}

	}
	
	private function delete_fragments(){

		foreach( $this->fragments as $fragment ){
		
			unlink( $this->fragments_dir.$fragment['o'] );
		}
	}

	private function free_up_memory(){
		
		$this->fragments = [];
		
		gc_collect_cycles();

	}

	public function open_dbs(){

		$databases = array_unique(array_column($this->fragments,'f'));

		foreach( $databases as $db_filename ){
		
			$this->open_sqlite_db($db_filename);
		
		}

	}

	private function open_sqlite_db($db_filename){
		
		$db_filepath = $this->log_dir.$db_filename;
		
		if( !$this->is_db_created( $db_filename, $db_filepath ) ) return;
	
		try {
			
			$this->db[$db_filename] = new \SQLite3($db_filepath);

			$this->db[$db_filename]->enableExceptions( true );

			$this->db[$db_filename]->exec('PRAGMA synchronous = OFF');
			$this->db[$db_filename]->exec('PRAGMA journal_mode = MEMORY');
			$this->db[$db_filename]->exec('PRAGMA cache_size = 100000');
			$this->db[$db_filename]->exec('PRAGMA foreign_keys = OFF');
			$this->db[$db_filename]->exec('PRAGMA temp_store = MEMORY');
			$this->db[$db_filename]->exec('PRAGMA locking_mode = EXCLUSIVE');
			$this->db[$db_filename]->exec('PRAGMA auto_vacuum = NONE');
			$this->db[$db_filename]->exec('BEGIN EXCLUSIVE');
		
		} catch (\Exception $e) {
			
			if( $this->debug ){

				$error_message = $e->getMessage();
				
				$this->debug_message .= "{$db_filename} SQLite failed:\n{$error_message}\n\n";
			} 

			return false;
		}


	}

	private function close_all_sqlite_dbs(){

		foreach( $this->db as $db_filename => $db ){
			
            $db->close();
			
            unset( $this->db[$db_filename] );
		}
	}

	private function is_db_created( $db_filename, $db_filepath ){

		switch( true ){
			case isset( $this->db[$db_filename] ):
			case file_exists( $db_filepath ):
			case $is_created = create_sqlite_db($db_filepath);

				return true;
			
            default:
			
				if( $this->debug ) $this->debug_message .= "{$db_filename}  cannot be created\n";
				
				return false;

		}
	
	}

	public function load_fragments_to_ram(){

		$is_memory_full = false;

		while( ($fragment_filename = $this->directory->read()) !== false ){

			$this->add_to_fragments_to_record( $fragment_filename );			

			if(  $this->is_ram_exhausted() ){
				
				$this->data_size = 0;

				$is_memory_full = true;

				break;
			}

		}
		
		if( !$is_memory_full ){
		
			$this->has_all_loaded = true;
			
		}

		if( $this->debug ) $this->debug_message .= is_array($this->fragments) ? ('Fragments count: '.count( $this->fragments ).PHP_EOL) : "not array\n";

		$this->has_fragments_to_record = !empty($this->fragments);

	}

	public function record_errors(){

		$microtime_int = intval( microtime(true) );
			
		$start_time_measure = microtime(true)-$microtime_int;
		
		$commits = [];

		foreach( $this->fragments as $fragment ){
			
			if( empty($fragment['f']) ) continue;
			
			$this->fragments_recorded++;

			foreach( $fragment['e'] as $error ){

				$stmt = $this->db[$fragment['f']]->prepare( 
					'INSERT INTO error_log (meta_id, daytime, code, error) VALUES (:meta_id, :daytime, :code, :error)' 
				);

				$stmt->bindValue( ':meta_id', $fragment['m'], SQLITE3_INTEGER );
				$stmt->bindValue( ':daytime', $fragment['d'], SQLITE3_TEXT );
				$stmt->bindValue( ':code', $error[0], SQLITE3_INTEGER );
				$stmt->bindValue( ':error', $error[1], SQLITE3_TEXT );

				if( $stmt->execute() ){

					$commits[$fragment['f']] = true;
				
				} else {
					
					if( $this->debug ) $this->debug_message .= "{$fragment['f']} failed to insert error for meta{$fragment['m']}\n";

				}

			}

			
		}
		
		foreach( array_keys($commits) as $commit){

			$this->db[$commit]->exec( 'COMMIT' );
		}
		
		if( $this->debug ){

			$end_time_measure = microtime(true)-$microtime_int;
			
			$this->debug_message .= 'Errors recorded in '.tm( $start_time_measure, $end_time_measure ).PHP_EOL;
		}
		
	}
	public function record_metadata(){

		if( $this->debug ) {

			$microtime_int = intval( microtime(true) );
			
			$start_time_measure = microtime(true)-$microtime_int;
		}
				
		$commits =[];

		foreach ($this->fragments as &$fragment) {

			if( empty($this->db[$fragment['f']])){

				if( $this->debug ) $this->debug_message.= "{$fragment['f']} is not an opened DB\n";
                
				continue;
			}

			$stmt_meta = $this->db[$fragment['f']]->prepare('INSERT INTO error_meta (meta) VALUES (:meta)');
			$stmt_meta->bindValue(':meta', $fragment['m']??'', SQLITE3_TEXT);
			$stmt_meta->execute();
		
			$meta_id = $this->db[$fragment['f']]->lastInsertRowID();
		
			$fragment['m'] = $meta_id;
			
			$commits[$fragment['f']] = true;

		}
		
		// foreach(array_keys($commits) as $db_filename){

		// 	$this->db[$db_filename]->exec( 'COMMIT' );
		// }

		
		if( $this->debug ) {
			
			$end_time_measure = microtime(true)-$microtime_int;
			
			$this->debug_message .= 'Metadata recorded in '.tm( $start_time_measure, $end_time_measure ).PHP_EOL;
		} 

		//garbage collector called to free up ram for writing main database table
		gc_collect_cycles();

	}

	

	private function add_to_fragments_to_record( $fragment_filename ){

		if( $fragment_filename ==='.' || $fragment_filename ==='..' || !str_ends_with($fragment_filename, $this->ip ) ) {
			return;
		}	

		$fragment = $this->get_fragment( $fragment_filename );
	
		if(!$fragment) {
			return;
		}
		
		$this->fragments[] = $fragment;

	}

	/**
	 * Provides error log data and server metadata.
	 *
	 * @return array -
	 * - f => string - The filename of the error log.
	 * - d => string - The date and time of the log entry.
	 * - e => array - The error details array.
	 * 	- 0 => int - The error code.
	 * 	- 1 => string - The error message.
	 * - m => string - The server and request metadata.
	 * - o => string - The original fragment file.
	 */
	private function get_fragment( $fragment_filename ){

		$fragment_raw = file_get_contents( $this->fragments_dir.$fragment_filename );
	
		if( !$fragment_raw ) return false;
	
		$decompressed_content = gzdecode($fragment_raw);
	
		if( $decompressed_content === false ) return false;
		
		$this->data_size += strlen($decompressed_content);

		$fragment = unserialize( $decompressed_content );
	
		//added original fragment file into array
		$fragment['o'] = $fragment_filename;
	
		return $fragment;
	}

	private function is_ram_exhausted(){

		return $this->data_size > $this->available_ram;
		// return $this->get_available_ram() < 100000000;

		// return $this->available_ram - memory_get_usage(true) < ( $this->available_ram - (0.5 * $this->available_ram));
	}

	private function get_available_ram(){

		$memory_limit = ini_get('memory_limit');
	
		if($memory_limit === '-1') return false;
	
		$memory_limit_bytes = $this->convert_to_bytes($memory_limit);
	
		$current_usage = memory_get_usage(true);
	
		$available_memory = $memory_limit_bytes - $current_usage;
	
		return $available_memory;
	}

	private function convert_to_bytes($value){

		$unit = strtoupper(substr($value, -1));
	
		$value = (int)$value;
	
		switch($unit){
			case 'K': $value *= 1024; break;
			case 'M': $value *= 1024 ** 2; break;
			case 'G': $value *= 1024 ** 3; break;
		}
	
		return $value;
	}
}
