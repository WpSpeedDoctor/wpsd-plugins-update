<?php

namespace wpsd_php_debug;

function record_bulk_fragments($ip=false, $remove_different_ips = false ){

	$db =[];
	
	$batch_size = 1000;

	$log_dir_path = get_log_dir_string();

	$fragments_dir_path = WP_CONTENT_DIR.$log_dir_path.'fragments/' ;

	$directory = dir( $fragments_dir_path );

	$count = 0;

	while( ($file = $directory->read()) !== false ){

		if( $ip !== false && $file !=='.' && $file !=='..' && !str_ends_with($file,$ip) ) {

			if($remove_different_ips){
				
				unlink( $fragments_dir_path.$file );
			}

			continue;
		}
		
		$fragment = get_fragment( $file, $fragments_dir_path );
		
		if(!$fragment) continue;
		
		$db_filename = $fragment['f'];
		
		open_db( $db, $log_dir_path, $db_filename );
		
		$record_data[$db_filename][] = $fragment;
		
		$count++;

		if( $count >= $batch_size ){
			
			record_to_db( $db, $record_data );

			remove_fragment_file( $record_data, $fragments_dir_path );

		    $record_data = [];
        
			$count = 0;
			
		}
	}
	
	$directory->close();

	if( !empty($record_data) ){

		record_to_db( $db, $record_data);

		remove_fragment_file( $record_data, $fragments_dir_path );
	}

	close_db($db);
}

function remove_fragment_file( $record_data, $fragments_dir_path ){

	if( empty( $record_data ) || empty( $fragments_dir_path ) ) return false;

	foreach( $record_data as $db_filename => $entries ){

		foreach( $entries as $entry ){

			if( isset( $entry['s'] ) && $entry['s'] === true && ! empty( $entry['o'] ) ){

				$fragment_path = $fragments_dir_path . $entry['o'];

				if( file_exists( $fragment_path ) ){
					unlink( $fragment_path );
				}
			}
		}
	}

	return true;
}


function close_db($db){

	foreach( $db as $handle => $db_instance ){

	$db_instance -> close();
	
	}
}


function get_fragment( $file, $fragments_dir_path ){

	if(	$file === '.' || $file === '..' ) return false;
		
	$fragment_raw = file_get_contents( $fragments_dir_path.$file );

	if( !$fragment_raw ) return false;

	$decompressed_content = gzdecode($fragment_raw);

	if( $decompressed_content === false ) return false;

	$fragment = unserialize( $decompressed_content );
	
	//original fragment file
	$fragment['o'] = $file;

	return $fragment;
}




/*
'f' => $db_filename,
'd' => $daytime,
'e' => $wpsd_debug_errors,
'm' => $meta,
*/
function record_to_db( $db, &$record_data, $bulk_size = 100 ){

	record_async_meta( $record_data, $db );
	
	foreach( $record_data as $db_filename => &$entries ){
		
		if( ! isset( $db[ $db_filename ] ) || empty( $entries ) ) continue;
		
		$db_instance = $db[ $db_filename ];
		
		$success = true;

		foreach( $entries as &$entry ){

			if( empty( $entry['m_id'] ) || empty( $entry['e'] ) ) continue;

			foreach( $entry['e'] as $error ){

				if( empty( $error[0] ) || empty( $error[1] ) ) continue;

				$stmt = $db_instance->prepare( 
					'INSERT INTO error_log (meta_id, daytime, code, error) VALUES (:meta_id, :daytime, :code, :error)' 
				);

				$stmt->bindValue( ':meta_id', $entry['m_id'], SQLITE3_INTEGER );
				$stmt->bindValue( ':daytime', $entry['d'], SQLITE3_TEXT );
				$stmt->bindValue( ':code', $error[0], SQLITE3_INTEGER );
				$stmt->bindValue( ':error', $error[1], SQLITE3_TEXT );

				if( ! $stmt->execute() ){
					$success = false;
				}

				$has_commit = true;
			}

			$entry['s'] = $success;
		}

		// $db_instance->exec( 'COMMIT' );
	}
	
}

function record_async_meta( &$record_data, $db ){

	foreach( $record_data as $db_filename => &$entries ){

		$has_commit= false;

		if( ! isset( $db[ $db_filename ] ) || empty( $entries ) ) continue;

		$db_instance = $db[ $db_filename ];

		foreach( $entries as &$entry ){

			if( empty( $entry['m'] ) ) continue;

			$stmt = $db_instance->prepare( 'INSERT INTO error_meta (meta) VALUES (:meta)' );

			$stmt->bindValue( ':meta', $entry['m'], SQLITE3_TEXT );

			$stmt->execute();
			
			$has_commit = true;

			$entry['m_id'] = $db_instance->lastInsertRowID();
		}

		if($has_commit){

			$db_instance->exec( 'COMMIT' );
			
		}
	}
}



function insert_meta_bulk( $db_instance, $meta_values ){

	$query = 'INSERT INTO error_meta (meta) VALUES ';
	$placeholders = [];
	$params = [];

	foreach( $meta_values as $index => $meta ){
		$placeholders[] = "(:meta{$index})";
		$params[":meta{$index}"] = $meta;
	}

	$query .= implode( ',', $placeholders );

	$stmt = $db_instance->prepare( $query );

	foreach( $params as $key => $value ){
		$stmt->bindValue( $key, $value, SQLITE3_TEXT );
	}

	$stmt->execute();

	$first_id = $db_instance->lastInsertRowID();
	return range( $first_id, $first_id + count( $meta_values ) - 1 );
}


// open_db( $db, $fragment[0], $db_filename );

// 		if( $db[$db_filename] === false ) continue;

function open_db( &$db, $log_dir_path, $db_filename ){
	
	if( isset( $db[$db_filename] ) ) return;

	$db_filepath = WP_CONTENT_DIR.$log_dir_path.$db_filename;

	if( ! file_exists( $db_filepath ) ){

		$success = create_sqlite_db($db_filepath);

		if( ! $success ){

			// $db[$db_filename]= false;

			return;
		}
	}

	$db[$db_filename] = new \SQLite3($db_filepath);

	$db[$db_filename]->exec('PRAGMA locking_mode = EXCLUSIVE;');

	$db[$db_filename]->exec('BEGIN EXCLUSIVE;');

}