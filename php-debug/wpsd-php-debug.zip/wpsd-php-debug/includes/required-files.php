<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

function get_plugins_memory_usage(){

	$plugins = get_required_plugin_opcache_usage();

	$result = [];
	foreach ( $plugins as $name => $info ){
		
		$size_string = size_format( $info['memory_usage'] );

		$result[] = "$name {$size_string} in {$info['files']} files";
	
	}
	
	return $result;

}

function get_required_plugin_opcache_usage(){

	if ( !function_exists( 'opcache_get_status' ) ) return [];

	$status = opcache_get_status();

	if ( empty( $status['scripts'] ) ) return false;

	$required_files = get_required_files();

	$required_map = [];

	foreach ( $required_files as $file ){
		$required_map[ wp_normalize_path( $file ) ] = true;
	}

	$content_dir = wp_normalize_path( WP_CONTENT_DIR );

	// $plugin_dir = wp_normalize_path( WP_PLUGIN_DIR );

	// $theme_dir = wp_normalize_path( get_theme_root() );

	$plugins = [];

	foreach ( $status['scripts'] as $script ){

		$path = wp_normalize_path( $script['full_path'] );

		if ( !isset( $required_map[ $path ] ) ) continue;

		if ( !str_starts_with( $path, $content_dir ) ) continue;

		$relative = str_replace( $content_dir . '/', '', $path );

		$path_pieces = explode( '/', $relative );

		$plugin_slug = $path_pieces[1]??$path_pieces[0]??'N/A';

		if ( !isset( $plugins[ $plugin_slug ] ) ){
			$plugins[ $plugin_slug ] = [
				'files' => 0,
				'memory_usage' => 0,
			];
		}

		$plugins[ $plugin_slug ]['files']++;

		$plugins[ $plugin_slug ]['memory_usage'] += $script['memory_consumption'];
	}

	uasort( $plugins, function( $a, $b ){
		return $b['memory_usage'] <=> $a['memory_usage'];
	} );

	return $plugins;
}