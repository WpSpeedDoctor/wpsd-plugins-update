<?php

die;


//TODO: integrate into deb and debl
function unset_empty_values($data){
	
	if(is_array($data)){
		foreach($data as $key => $value){
			$new = unset_empty_values($value);

			if(is_empty($new)){
				unset($data[$key]);
			}else{
				$data[$key] = $new;
			}
		}
		return $data;
	}

	if(is_object($data)){
		foreach($data as $key => $value){
			$new = unset_empty_values($value);

			if(is_empty($new)){
				unset($data->$key);
			}else{
				$data->$key = $new;
			}
		}
		return $data;
	}

	return $data;
}

function is_empty($value){

	switch(true){

		case is_array($value) && count($value) === 0:

		case is_object($value) && count((array)$value) === 0:

		case $value === null:

		case $value === '':

		case $value === false:

		case $value === 0:

			return true;

	}

	return false;
}