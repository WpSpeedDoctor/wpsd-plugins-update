<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

defined( 'WPSD_DEBUG_DIR' ) || define( 'WPSD_DEBUG_DIR', WP_PLUGIN_DIR.'/wpsd-php-debug/' );

require_once WPSD_DEBUG_DIR.'includes/universal-functions.php';

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}

//MARK: Activation
/**
 * Main setup functions
 */
function plugin_activation_main(){

	update_settings_to_latest_version();

	activate_local_mu_plugins();

	create_debug_log_folder();
	
	create_sqlite_db();

	require_once WPSD_DEBUG_DIR.'includes/display-cookies.php';

	set_display_cookies();

}

//MARK: Deactivation
function plugin_deactivation_main(){

	remove_mu_plugin();

	unschedule_cleanup_cron();
}

/*
 * Activation functions beginning
 */

function create_debug_log_folder(){

	$log_dir_path = get_db_dir();

	create_folder_with_index( WP_CONTENT_DIR.'/database/' );

	create_folder_with_index( $log_dir_path );

	create_folder_with_index( $log_dir_path.'fragments/' );

}

function create_folder_with_index( $dir_path ){

	$index_markup = <<<HTML
		<?php
		Silence is gold
		HTML;

	if( !is_dir( $dir_path ) ){

		wp_mkdir_p($dir_path);
	}

	$index_filepath = trailingslashit( $dir_path ).'index.php';

	if( !file_exists( $index_filepath) ){

		file_put_contents( $index_filepath, $index_markup );
	}

}


if( !function_exists(__NAMESPACE__.'\is_ini_set_allowed') ){
		
	function is_ini_set_allowed(){

		$error_log_original = ini_get('error_log');

		ini_set('error_log', ABSPATH.'/error-test.log' );

		$error_log_new  = ini_get('error_log');

		return $error_log_original !== $error_log_new;

	}
}

function activate_local_mu_plugins(){
	
	create_mu_plugin_wp_folder();

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) return;

	file_put_contents( $mu_loader_filepath, generate_loader_for_local_mu_plugins() );

}

function generate_loader_for_local_mu_plugins(){

	$plugin_basedir = basename(WPSD_DEBUG_DIR);

	$mu_plugin_name = __( "Advanced PHP Debug by WP Speed Doctor", 'wpsd-php-debug' );

	$mu_plugin_description = __( "Enhanced data collection of PHP errors, easy to log and display data", 'wpsd-php-debug' );
	
	$mu_plugin_author = "WP Speed Doctor";

	$mu_plugin_url = "https://wpspeeddoctor.com/";

	$text_domain = 'wpsd-php-debug';

	return 

"<?php

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/
Description: {$mu_plugin_description}
Version: ".WPSD_DEBUG_VER."
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

@include WP_PLUGIN_DIR.'/{$plugin_basedir}/must-use-plugin/mu-handler.php';
";

	
}


function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR ) ) return;
	
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}



/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return WPMU_PLUGIN_DIR."/0000-wpsd-php-debug.php";
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ){

		unlink( $mu_loader_filepath );
	} 

}

function unschedule_cleanup_cron(){
	
	$timestamp = wp_next_scheduled( 'cleanup_main_cron' );

	wp_unschedule_event( $timestamp, 'cleanup_main_cron' );

}

/**
 * Deactivation functions end
 */

/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(WPSD_DEBUG_DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ) {

	$page_link = admin_url( 'tools.php?page=wpsd-php-debug-page' );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">Menu</a>
		HTML;

	return array_merge( $actions,[$menu_link] );

}

function get_default_settings(){

	return [

		//stores $_SERVER
		'server'				=> true, 

		//store values of these $_SERVER keys
		'server_keys'			=>[ 

			'REQUEST_URI',
			'REQUEST_METHOD',
			'REMOTE_ADDR',
			'HTTP_REFERER',
			'HTTP_USER_AGENT',
	
		], 

		//stores $_POST
		'post'						=> true, 

		//stored $_COOKIES
		'cookies'					=> false, 

		//store values of these keys
		'cookies_keys_full_value'	=> [ 
			
			// 'wmc_current_currency'
		
		],

		//List of excluded error codes
		'excluded_errors'			=> [
			2,8,8192
		]

	];
}

function update_settings_to_latest_version(){

	require_once WPSD_DEBUG_DIR.'admin/uninstall.php';

	migrate_old_settings();

	create_debug_log_folder();

	$defaults = [
		'wpsd-debug-settings' => get_default_settings(),
		'wpsd-reporting' => 24565,//default error code
		'wpsd-debug-async' => '0',
		'wpsd-ini-status' => is_ini_set_allowed() ? '1' : '0',
	];

	foreach( $defaults as $key => $value ){

		if( get_wpsd_option( $key ) === false ){

			$autoload = $key === 'wpsd-debug-settings' ? 'off' : 'on';

			update_wpsd_option( $key, $value, $autoload );

		}
	}

	update_wpsd_option('wpsd-debug-ver', WPSD_DEBUG_VER, 'on' );

}

function migrate_old_settings(){
	
	if( get_wpsd_option( 'wpsd-php-debug-dir') !== false ){
		
		move_log_dir();
	}

	$migrated_options = [
		'wpsd-php-debug-settings' => 'wpsd-debug-settings',
		'wpsd-php-debug-error-reporting' => 'wpsd-reporting',
		'wpsd-php-ini-set-allowed' => 'wpsd-ini-status',
		'wpsd-php-debug-async' => 'wpsd-debug-async',
	];

	foreach( $migrated_options as $old_key => $new_key ){

		if( get_wpsd_option( $old_key ) !== false ){

			$value = get_wpsd_option( $old_key );

			if( $new_key === 'wpsd-debug-settings' ){

				$autoload =  'off';
				if( !is_array($value) ){
					$value = json_decode( $value,true );
				}
			
			} else {

				$autoload = 'on';
			}

			update_wpsd_option( $new_key, $value, $autoload );

			delete_wpsd_option( $old_key );

		}
	}

}

function move_log_dir(){

	$old_dir_piece = get_wpsd_option( 'wpsd-php-debug-dir');

	$old_log_dir = WP_CONTENT_DIR.$old_dir_piece;

	$new_log_dir = WP_CONTENT_DIR.get_log_dir_string();

	$wp_database_dir = WP_CONTENT_DIR.'/database/';

	create_folder_with_index( $wp_database_dir );

	if( file_exists($old_log_dir) ){

		rename( $old_log_dir, $new_log_dir );
	}

	delete_wpsd_option( 'wpsd-php-debug-dir' );

}

function get_existing_tables_names(){

	global $wpdb;

	$list_of_tables = $wpdb->get_results('SHOW FULL TABLES', ARRAY_A);

	return wp_list_pluck($list_of_tables, 'Tables_in_'.$wpdb->dbname);

}
