<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

defined( 'WPSD_PHP_DEBUG_DIR' ) || define( 'WPSD_PHP_DEBUG_DIR', WP_CONTENT_DIR.'/plugins/wpsd-php-debug/' );

require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}


/**
 * Main setup functions
 */
function plugin_activation_main(){

	create_default_plugin_settings();

	activate_local_mu_plugins();

	create_debug_log_folder();
	
	require_once WPSD_PHP_DEBUG_DIR.'includes/universal-functions.php';

	create_sqlite_db();
}


function plugin_deactivation_main(){

	remove_mu_plugin();

	unschedule_cleanup_cron();
}

/*
 * Activation functions beginning
 */


function create_debug_log_folder(){
	
	if ( file_exists( WP_CONTENT_DIR.get_option('wpsd-php-debug-dir') ) ) return;
	
	mkdir( WP_CONTENT_DIR.get_option('wpsd-php-debug-dir'), 0755 );

}

function create_default_plugin_settings(){

	
	if( get_option('wpsd-php-debug-dir') === false ){
		
		//first time plugin been activated
		add_option( 'wpsd-php-debug-dir', '/logs-'.bin2hex( random_bytes(10) ).'/' );

	} else {

		//update settings to for newer version
		$settings = json_decode( get_option( 'wpsd-php-debug-settings'), true );

		if( !empty( $settings['excluded_errors'] ) && reset( $settings['excluded_errors'] ) === true  ){
	
			$settings['excluded_errors'] = array_keys( $settings['excluded_errors']??[] );
	
			update_option( 'wpsd-php-debug-settings', json_encode($settings) );
		
		}

	}
	
	if( get_option('wpsd-php-debug-error-reporting' ) === false ){
	
		update_option('wpsd-php-debug-error-reporting', E_ALL );
		
	}
	
	if( get_option('wpsd-php-debug-settings') === false ) {
	
		add_option( 'wpsd-php-debug-settings', json_encode( get_default_settings() ), '','no' );
	
	}
	
	//some hosting doesn't allow to change filepath to error log.
	update_option( 'wpsd-php-ini-set-allowed', is_ini_set_allowed() ? '1':'0');
	
}

if( !function_exists(__NAMESPACE__.'\is_ini_set_allowed') ){
		
	function is_ini_set_allowed(){

		$error_log_original = ini_get('error_log');

		ini_set('error_log', ABSPATH.'/error.log' );

		$error_log_new  = ini_get('error_log');

		return $error_log_original !== $error_log_new;

	}
}

function activate_local_mu_plugins(){
	
	create_mu_plugin_wp_folder();

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) return;

	file_put_contents( $mu_loader_filepath, generate_loader_for_local_mu_plugins() );

}

function generate_loader_for_local_mu_plugins(){

	$plugin_basedir = basename(WPSD_PHP_DEBUG_DIR);

	$mu_plugin_name = __( "Advanced PHP Debug by WP Speed Doctor", 'wpsd-php-debug' );

	$mu_plugin_description = __( "Enhanced data collection of PHP errors, easy to log and display data", 'wpsd-php-debug' );
	
	$mu_plugin_author = "WP Speed Doctor";

	$mu_plugin_url = "https://wpspeeddoctor.com/";

	$text_domain = 'wpsd-php-debug';

	return 

"<?php

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/
Description: {$mu_plugin_description}
Version: ".WPSD_PHP_DEBUG_VER."
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

@include_once WP_PLUGIN_DIR.'/{$plugin_basedir}/must-use-plugin/mu-handler.php';
";

	
}


function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR ) ) return;
	
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}



/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return WPMU_PLUGIN_DIR."/0000-wpsd-php-debug.php";
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) unlink( $mu_loader_filepath );

}

function unschedule_cleanup_cron(){
	
	$timestamp = wp_next_scheduled( 'cleanup_main_cron' );

	wp_unschedule_event( $timestamp, 'cleanup_main_cron' );

}

/**
 * Deactivation functions end
 */

/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(WPSD_PHP_DEBUG_DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ) {

	$page_link = admin_url( 'tools.php?page=wpsd-php-debug-page' );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">Menu</a>
		HTML;

	return array_merge( $actions,[$menu_link] );

}

function get_default_settings(){

	return [

		//stores $_SERVER
		'server'				=> true, 

		//store values of these $_SERVER keys
		'server_keys'			=>[ 

			'REQUEST_URI',
			'REQUEST_METHOD',
			'REMOTE_ADDR',
			'HTTP_REFERER',
			'HTTP_USER_AGENT',
	
		], 

		//stores $_POST
		'post'						=> true, 

		//stored $_COOKIES
		'cookies'					=> true, 

		//store values of these keys
		'cookies_keys_full_value'	=> [ 
			
			// 'wmc_current_currency'
		
		],

		//List of excluded error codes
		'excluded_errors'			=> []

	];
}