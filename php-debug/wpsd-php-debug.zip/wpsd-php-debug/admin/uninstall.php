<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

require_once WPSD_DEBUG_DIR.'includes/universal-functions.php';

function plugin_uninstall_main(){

	delete_matched_files( ['sqlite','meta.log'] );

	delete_wpsd_option( 'wpsd-debug-settings' );

	delete_wpsd_option( 'wpsd-reporting');

	delete_wpsd_option( 'wpsd-ini-status' );

	delete_wpsd_option('wpsd-debug-ver');

	delete_wpsd_option('wpsd-debug-async');

	delete_fragments_folder();
}

function delete_fragments_folder(){

	$dir = WP_CONTENT_DIR.get_log_dir_string().'/fragments/';
	
	if( !is_dir($dir) ) return;

	$d = dir($dir);

	while( ($file = $d->read() ) !== false){

			if( $file==='.' || $file==='..' ) continue;

			unlink($dir . DIRECTORY_SEPARATOR . $file);
	}

	$d->close();

	rmdir($dir);

}

function delete_wpsd_option( $name ){

	return is_multisite() ? delete_site_option( $name ) : delete_option( $name );
}

function delete_matched_files($needles){

	$path = WP_CONTENT_DIR.get_log_dir_string();

	$files = scandir($path);
	
	foreach( $files as $file ){
		
		foreach ($needles as $needle){

			if( str_contains( $file, $needle ) ) unlink( $path.$file );
		}
	}	
}