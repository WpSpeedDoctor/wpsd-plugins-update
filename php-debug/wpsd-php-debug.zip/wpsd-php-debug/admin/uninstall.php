<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){

    //TODO
    //remove settings
    //remove error logs

}


