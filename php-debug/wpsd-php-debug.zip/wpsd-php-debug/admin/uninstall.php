<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){

	delete_matched_files( ['sqlite','meta.log'] );

	delete_option( 'wpsd-php-debug-dir' );

	delete_option( 'wpsd-php-debug-settings' );

	delete_option( 'wpsd-php-debug-error-reporting' );

	delete_option( 'wpsd-php-ini-set-allowed' );

	delete_transient('wpsd-php-debug-nonce');

}


function delete_matched_files($needles){

	$path = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$files = scandir($path);

	
	foreach( $files as $file ){
		
		foreach ($needles as $needle){

			if( str_contains( $file, $needle ) ) unlink( $path.$file );
		}
	}	
}