<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){

    delete_meta_files();

    delete_option( 'wpsd-php-debug-dir' );

	delete_option( 'wpsd-php-debug-settings' );

	delete_option( 'wpsd-php-debug-error-reporting' );

	delete_option( 'wpsd-php-ini-set-allowed' );

    delete_transient('wpsd-php-debug-nonce');

}


function delete_meta_files(){

    $path = WP_CONTENT_DIR.get_option('wpsd-php-debug-dir');

	$files = scandir($path);

    foreach( $files as $file ){

        if( str_contains( $file,'-meta.log' ) ) unlink( $path.$file );
    }
}