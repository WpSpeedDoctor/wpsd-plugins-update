<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

if( !isset($_GET['aaa']) ) return;

