<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;


switch($_GET['act']){

	case 'hook-content':

		add_filter('the_content', function($content){

			// ini_set('display_errors', '1');
		
			// ini_set('display_startup_errors', 1);
		
			// error_reporting(E_ALL);
			$content .= $a.'qwe';
		
			return $content;
		
		});
		
		break;
	case 'php-files':

		the_wpsd_used_php();
		break;

	case 'recovery':

		require WPSD_DEBUG_DIR.'includes/recovery-sqlite.php';

		
		$microtime_int = intval( microtime(true) );
		$start_time_measure = microtime(true)-$microtime_int;
		
		recover_broken_sqlite_db( get_db_filepath() );

		$end_time_measure = microtime(true)-$microtime_int;
		dtm( $start_time_measure, $end_time_measure );
		
		
		break;

	case 'is-file':
		
        
		deb( file_exists( WPSD_DEBUG_DIR.'/must-use-plugin/ajax/source-error-log.php') , basename(__FILE__).' at '.__LINE__ );
		
		break;
		
	case 'rmdir':

		$dir = __DIR__.'/a/';

		if(!is_dir($dir)){
			return;
		}
	
		$d = dir($dir);
	
		while(($file = $d->read()) !== false){

				if(  $file==='.' || $file==='..') continue;

				unlink($dir . DIRECTORY_SEPARATOR . $file);
		}
	
		$d->close();

		rmdir($dir);
		break;

	case 'fragment':
		
		
		deb( 'not active' , basename(__FILE__).' at '.__LINE__ );
		
		
		
		// $microtime_int = intval( microtime(true) );
		// $start_time_measure = microtime(true)-$microtime_int;
		
		// // require WPSD_DEBUG_DIR.'includes/fragments-recorder.php';

		// // record_bulk_fragments();

		// // record_fragments_into_db();
		
		// $end_time_measure = microtime(true)-$microtime_int;
		// dtm( $start_time_measure, $end_time_measure );
		
		
		
		
		
		break;
	case 'fatal':

		qwe();
		break;
	case 'tm':

		
		$microtime_int = intval( microtime(true) );
		$start_time_measure = microtime(true)-$microtime_int;

		for($i=1;$i<10000;++$i){


		}
		$end_time_measure = microtime(true)-$microtime_int;
		dtm( $start_time_measure, $end_time_measure );
		
		break;
	

	case 'hook':
		add_action('wp', __NAMESPACE__.'\wp_hook_callable' );
		break;
	case 'blog-id':
		
		break;
	case 'vd':
		vd(uniqid());die;
		break;

	case 'warning':
		
		echo $asdfghjk;

		break;

	case 'warnings':

		warnings();
		// deb('warning');
		// echo $asd1;
		// echo $asd2;
		// echo $asd3;
		// echo $asd4;
		// echo $asd5;
		// echo $asd6;
		// echo $asd7;
		// echo $as8;
		// echo $asd9;
		// echo $asd10;
		// echo $asd11;
		break;

	case 'deb':
// vd('abc');
		// define('WPSD_DEBUG_TEST', uniqid() );

		// deb(WPSD_DEBUG_TEST);

		deb(microtime(true));
	
	// deb(time() , basename(__FILE__).' at '.__LINE__ );
	// deb(time() , basename(__FILE__).' at '.__LINE__ );
	
		break;

	case 'multi';

		for($i=1;$i<30;++$i){
		multi_curl();
		}
		break;

	case 'stw':

		stw();

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);
		
		break;
		
}



function warnings(){
	// 1. Undefined variable notice
echo $undefined_variable;

// 2. Array index undefined notice
$array = ['key' => 'value'];
echo $array['undefined_key'];

// 3. Division by zero warning
$non_object = 123;
echo $non_object->property;

// 4. Invalid argument supplied for foreach warning
foreach ($undefined_variable as $item) {
    echo $item;
}

// 5. Missing argument warning
$float = 123.45;
$array = [$float => 'value'];

// 6. Deprecated function warning (if applicable to your PHP version)
$string = '';
$string++;

// 7. Using a non-object warning
$non_object = null;
echo $non_object->property;

// 8. Invalid argument supplied for array_merge warning
array_key_exists(null, ['key' => 'value']);

// 9. Creating default object from empty value warning
$instance = new MyClass();

// Accessing the deprecated property
echo $instance->deprecated_property;

}

class MyClass {
    /** @deprecated Use $new_property instead */
    public $deprecated_property = "This is deprecated.";

    public $new_property = "Use this instead.";
}


function is_new_lock_set_(){
	global $wpdb;

	$result = $wpdb->query("UPDATE {$wpdb->options} SET option_value = '1' WHERE option_name = 'wpsd-php-debug-lock-x' AND option_value = '0'");

	
	deb( $result , basename(__FILE__).' at '.__LINE__ );
	
}


function wp_hook_callable(){

	// update_site_option('asd','qwe');
// deb( get_site_option('asd') , basename(__FILE__).' at '.__LINE__ );


// $microtime_int = intval( microtime(true) );
// $start_time_measure = microtime(true)-$microtime_int;
// get_wpsd_option('wpsd-debug-values');
// $end_time_measure = microtime(true)-$microtime_int;
// dtm( $start_time_measure, $end_time_measure );



}

function multi_curl(){

	$home_url = get_home_url();

	$urls = [
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",

	// ];
	// $urls = [
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",

	];

	$multi_handle = curl_multi_init();

	$curl_handles = [];

	foreach( $urls as $key => $url ){

		$parsed_url = parse_url($url);

		$full_base = "http://{$_SERVER['SERVER_ADDR']}{$parsed_url['path']}";

		$query_string = ($parsed_url['query'] ?? '') === '' 
			? "?thread={$key}" 
			: "?{$parsed_url['query']}&thread={$key}";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $full_base . $query_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Host: ' . $parsed_url['host']]);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_multi_add_handle($multi_handle, $ch);
		$curl_handles[] = $ch;
	}

	do {
		curl_multi_exec($multi_handle, $running);
		curl_multi_select($multi_handle);
	} while( $running > 0 );

	$results = [];
	foreach( $curl_handles as $ch ){
		$response = curl_multi_getcontent($ch);
		$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$body = substr($response, $header_size);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$redirect_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		$error = curl_error($ch);

		$results[] = [
			'content' => htmlentities( mb_substr($body, 0, 100)),
			'error' => $error,
			'response_code' => $http_code,
			'redirect_url' => $redirect_url,
		];

		curl_multi_remove_handle($multi_handle, $ch);
		curl_close($ch);
	}

	curl_multi_close($multi_handle);

		

// die( '<span style="white-space: pre;line-height: 2;">'.var_export( $results ,true ).'</span>' );

	// return $results;
}
