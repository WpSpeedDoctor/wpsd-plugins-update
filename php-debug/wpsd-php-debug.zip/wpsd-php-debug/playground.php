<?php

namespace wpsd_php_debug;

defined( 'ABSPATH' ) || exit;

switch($_GET['wpsd-debug-action']){

	// case 'new-set':
		// is_new_lock_set_();
	// 	break;
	case 'vd':
		vd(uniqid());die;
		break;

	case 'warning':
		echo $asd;
		break;
	case 'fatal':
		none_existing_function();
		break;

	case 'deb':
		define('WPSD_DEBUG_TEST', uniqid() );

		deb(WPSD_DEBUG_TEST);
		break;
	
	case 'multi';

		multi_curl();

		break;

}

function multi_curl(){

	$home_url = get_home_url();

	$urls = [
		"{$home_url}/?wpsd-debug-action=warning",
		"{$home_url}/?wpsd-debug-action=warning",
		"{$home_url}/?wpsd-debug-action=warning",
		"{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",
		// "{$home_url}/?wpsd-debug-action=warning",

	];

	$multi_handle = curl_multi_init();

	$curl_handles = [];
	foreach( $urls as $key => $url ){
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "$url&thread={$key}");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_multi_add_handle($multi_handle, $ch);
		$curl_handles[] = $ch;
	}

	do {
		curl_multi_exec($multi_handle, $running);
		curl_multi_select($multi_handle);
	} while( $running > 0 );

	$results = [];
	foreach( $curl_handles as $ch ){
		$results[] = curl_multi_getcontent($ch);
		curl_multi_remove_handle($multi_handle, $ch);
		curl_close($ch);
	}

	curl_multi_close($multi_handle);

	// return $results;
}


// function is_new_lock_set_(){
// 	global $wpdb;

// 	$result = $wpdb->query("UPDATE {$wpdb->options} SET option_value = '1' WHERE option_name = 'wpsd-php-debug-lock-x' AND option_value = '0'");

	
// 	deb( $result , basename(__FILE__).' at '.__LINE__ );
	
// }
