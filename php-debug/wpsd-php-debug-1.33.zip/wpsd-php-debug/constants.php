<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

class Consts {

	const SLUG				= 'wpsd-debug';

	const VER				= '1.33';

	const NS				= __NAMESPACE__;

	const DIR				= __DIR__.DIRECTORY_SEPARATOR;

	const DB_DIR			= WP_CONTENT_DIR.'/database/'. self::SLUG . DIRECTORY_SEPARATOR;

	const FRAGMENTS_DIR		= self::DB_DIR.'fragments/';

	const PAGE_ADMIN		= self::SLUG.'-admin';

	
	const COOKIE_DISPLAY_ERRORS		= self::SLUG.'-error';

	const COOKIE_DISPLAY_VALUES		= self::SLUG.'-values';

	const COOKIE_DISPLAY_ADMIN_BAR	= self::SLUG.'-admin-bar';
	
	const COOKIE_DISPLAY_PHP_FILES	= self::SLUG.'-php-files';


	const OPTION_MULTI_IP	= self::SLUG.'-multi-ip';

	const OPTION_SETTINGS	= self::SLUG.'-settings';

	const OPTION_REPORTING	= self::SLUG.'-reporting';

	const OPTION_INI_STATUS = self::SLUG.'-ini-status';

	const OPTION_VER		= self::SLUG.'-ver';


	const CRON_CLEANUP		= 'wpsd_debug_cleanup';

	const CRON_REPORTING	= 'wpsd_debug_reporting';

	/**
	 * Generating own nonce key, this is because `wp_verify_nonce` is not available in must use plugin hook.
	 */
		
	static function get_nonce(){

		static $nonce;

		if( !$nonce ){
			$nonce = hash( 'fnv164', NONCE_SALT. date('d-m') );
		}

	return $nonce;
	
	}
}

define( 'WPSD_DEBUG_NS', __NAMESPACE__ );

if( !defined( 'REQUEST_FRONTEND' ) ){

	define( 'REQUEST_FRONTEND', 1 );
	define( 'REQUEST_AJAX', 2 );
	define( 'REQUEST_ADMIN', 3 );
	define( 'REQUEST_CRON', 4 );
	define( 'REQUEST_LOGIN', 5 );
	define( 'REQUEST_XMLRPC', 6 );
	define( 'REQUEST_EMPTY', 7 );
	define( 'REQUEST_REST', 8 );
	define( 'REQUEST_SITEMAP', 9 );
	define( 'REQUEST_DIRECT', 10 );
	define( 'REQUEST_404', 11 );
	define( 'REQUEST_FEED', 12 );
	define( 'REQUEST_CLI', 13 );
}

if( !defined('WPSD_URI_PATH') ){

	define('WPSD_URI_PATH', strstr( $_SERVER['REQUEST_URI']??'', '?', true ) ?: $_SERVER['REQUEST_URI']??'');
} 

if ( !defined( 'WPSD_REQUEST_TYPE' ) ) {
	
	/**
	 * @var int
	 * REQUEST_FRONTEND -	1
	 * REQUEST_AJAX -		2
	 * REQUEST_ADMIN -		3
	 * REQUEST_CRON -		4
	 * REQUEST_LOGIN -		5
	 * REQUEST_XMLRPC -		6
	 * REQUEST_EMPTY -		7
	 * REQUEST_REST -		8
	 * REQUEST_SITEMAP -	9
	 * REQUEST_DIRECT -		10
	 * REQUEST_404 -		11
	 * REQUEST_FEED -		12
	 * REQUEST_CLI -		13
	 */
	define( 'WPSD_REQUEST_TYPE', get_wp_request_type() );

}

function get_wp_request_type(){

	switch(true){

		case wp_doing_ajax() || isset( $_GET['wc-ajax'] ):
			return REQUEST_AJAX;

		case is_admin():
			return REQUEST_ADMIN;

		case wp_doing_cron():
			return REQUEST_CRON;

		case is_callable( 'login_header' ):
			return REQUEST_LOGIN;

		case defined( 'XMLRPC_REQUEST' ):
			return REQUEST_XMLRPC;

		case defined( 'WP_CLI' ):
			return REQUEST_CLI;

		case WPSD_URI_PATH === '':
			return REQUEST_EMPTY;

		//wp_is_json_request() is making false positives for front-end requests
		case str_contains( WPSD_URI_PATH,'/wp-json/' ): 
			return REQUEST_REST;
		
		case ( $extension = strstr(WPSD_URI_PATH,'.') ) === null:
		//fallthough, never true

		case $extension ==='.xml' && str_contains( WPSD_URI_PATH, 'sitemap' ):
			return REQUEST_SITEMAP;

		case $extension ==='.php':
			return REQUEST_DIRECT;

		case $extension !== false:
			return REQUEST_404;

		case str_ends_with( WPSD_URI_PATH, '/feed/' ) || str_ends_with( WPSD_URI_PATH, '/feed' ):
			return REQUEST_FEED;

		default:
			return REQUEST_FRONTEND;
	}

}
