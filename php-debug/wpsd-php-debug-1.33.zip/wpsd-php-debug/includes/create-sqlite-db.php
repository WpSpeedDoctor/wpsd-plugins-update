<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/**
 * @return bool 
 * - true when file exists or is successfully created
 * - false if could not be created.
 */

function create_sqlite_db($db_filepath=false){

	if( !class_exists('SQLite3') ) {

		log('Could not create SQLite database, SQLite3 extension is not installed', basename(__FILE__).' at '.__LINE__, true);

		return false;
	}

	if( !$db_filepath ){

		$db_filepath = get_db_filepath();
	}
	
	if( file_exists($db_filepath) ) return true;

	try{

		$db = new \SQLite3($db_filepath);

		$db->enableExceptions( true );
		
	} catch ( \Exception $e ){

		log('Unable to create SQLite database, probably issue writing to the filesystem',basename(__FILE__).' at '.__LINE__,true);
	
		return false;
	}

	$query = <<<SQL
		CREATE TABLE error_log (
		event_id INTEGER PRIMARY KEY AUTOINCREMENT,
		meta_id INTEGER NOT NULL,
		daytime TEXT NOT NULL,
		code INTEGER NOT NULL,
		error TEXT NOT NULL
		);
		SQL;

	if (!$db->exec($query)) {

		$db->close();

		log('Unable to create SQLite table `error_log`',basename(__FILE__).' at '.__LINE__,true);
	
		return false;
	}

	$query = <<<SQL
		CREATE TABLE error_meta (
		meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
		meta TEXT NOT NULL
		);
		SQL;

	if (!$db->exec($query)) {

		$db->close();

		log('Unable to create SQLite table `error_meta`',basename(__FILE__).' at '.__LINE__,true);

		return false;
	}

	$db->close();

	return true;

}