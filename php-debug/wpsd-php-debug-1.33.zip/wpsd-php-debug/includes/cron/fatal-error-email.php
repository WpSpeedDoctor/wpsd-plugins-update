<?php

namespace WPSD\debug\v2;

function send_notification_email($errors){

	$domain = parse_url( get_home_url(),PHP_URL_HOST );
	
	$subject = sprintf( __('[ALERT] on %s was detected PHP Fatal error.', 'wpsd-debug' ), strtoupper($domain)  );
	
	$message = get_email_message( $errors );
	
	// file_put_contents( ABSPATH.'email.html',  $message );
	
	// return;
	
	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		"From: noreply@{$domain}",
		"Reply-To: noreply@{$domain}"
	);
	
	\wp_mail(
		$email,
		$subject,
		$message,
		$headers
	);
}

function get_email_message( $errors ){
	
	$text = [

		'breakdown' 	=> __('Here is the breakdown of all recorded errors during this period:', 'wpsd-debug' ),

		'period'	=> sprintf(
						_n(
							'Between %s and %s occurred %d PHP Fatal error.',
							'Between %s and %s occurred %d PHP Fatal errors.',
							$errors['counts'][1],
							'wpsd-debug'
						),
						date('Y-m-d H:i:s', strtotime('-1 hour')),
						date('Y-m-d H:i:s'),
						$errors['counts'][1]
					),

		'footnote'		=> sprintf(
								__("Sent from website %s, server IP: %s by plugin %s", 'wpsd-debug' ),
									get_home_url(),
									$_SERVER['SERVER_ADDR'],
									__( 'Advanced PHP Debug by WP Speed Doctor.', 'wpsd-debug' )
							),

		'error-type'	=> __("Error type", 'wpsd-debug' ),

		'count'			=> __("Count", 'wpsd-debug' ),

	];
	
	require_once Consts::DIR.'includes/error-names.php';

	$types = get_error_type_strings();

	$errors_breakdown_markup = '';

	foreach( $errors['counts'] as $error_code => $count){

		$errors_breakdown_markup .= <<<HTML
		<tr>
			<td style="padding: 10px; border: 1px solid #ddd;">{$types[$error_code]}</td>
			<td style="padding: 10px; border: 1px solid #ddd;text-align: center;">{$count}</td>
		</tr>
		HTML;
	}

	return <<<HTML
	<html lang="en">
	<body style="margin:0;padding:0;">
		<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['period']}</p>
		<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['breakdown']}</p>
		<table style="border-collapse: collapse; font-family: Arial, sans-serif;">
			<thead>
				<tr>
					<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$text['error-type']}</th>
					<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$text['count']}</th>
				</tr>
			</thead>
			<tbody>
				{$errors_breakdown_markup}
			</tbody>
		</table>
		<br>
	<div style="white-space: pre;line-height: 2; font-family: Arial, sans-serif;">
	Last fatal error:<br>
	{$errors['last_fatal_error']}
	</div>
		<br>
		<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$text['footnote']}</p>
		</body>
	</html>
	HTML;
	
}