<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

add_action('set_auth_cookie', __NAMESPACE__ . '\check_admin_on_auth', 10, 5);

function check_admin_on_auth($auth_cookie, $expire, $expiration, $user_id, $scheme){

	switch(true){
		case !$user_id:
		//fallthrough	
		case is_null( $user = get_userdata($user_id) ):
		case !$user:
		case !in_array('administrator', (array) $user->roles, true):
			return false;
	
		default:
			require_once Consts::DIR.'includes/universal-functions.php';

			require_once Consts::DIR.'includes/login/display-cookies.php';

			set_display_cookies($is_admin_at_login=true);
			break;
	}

}