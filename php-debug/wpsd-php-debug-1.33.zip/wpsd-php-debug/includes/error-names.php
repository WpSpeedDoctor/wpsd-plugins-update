<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function get_error_type_strings(){
		
	return [
		0 =>		__( 'All','wpsd-debug'),
		32768 =>	__( 'Database error','wpsd-debug'),
		1 =>		__(	'E_FATAL_ERROR','wpsd-debug'),
		2 =>		__(	'E_WARNING','wpsd-debug'),
		4 =>		__(	'E_PARSE','wpsd-debug'),
		8 =>		__(	'E_NOTICE','wpsd-debug'),
		16 =>		__(	'E_CORE_ERROR','wpsd-debug'),
		32 =>		__(	'E_CORE_WARNING','wpsd-debug'),
		64 =>		__(	'E_COMPILE_ERROR','wpsd-debug'),
		128 =>		__(	'E_COMPILE_WARNING','wpsd-debug'),
		256 =>		__(	'E_USER_ERROR','wpsd-debug'),
		512 =>		__(	'E_USER_WARNING','wpsd-debug'),
		1024 =>		__(	'E_USER_NOTICE','wpsd-debug'),
		4096 =>		__(	'E_RECOVERABLE_ERROR','wpsd-debug'),
		8192 =>		__(	'E_DEPRECATED','wpsd-debug'),
		16384 =>	__( 'E_USER_DEPRECATED','wpsd-debug'),
		99999 =>	__( 'debl()','wpsd-debug')
	
	];
}