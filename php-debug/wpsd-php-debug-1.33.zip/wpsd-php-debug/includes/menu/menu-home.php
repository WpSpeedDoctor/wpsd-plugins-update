<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

display_search_bar();

function display_search_bar(){
	
	$texts = get_form_texts();

	$error_types_markup = get_php_error_types_markup();

	echo <<<HTML
<br>
<form class="input-form" id="debugForm"
	hx-post="{$texts['ajax_url']}"
	hx-vals='{"action": "htmx-php-debug-search"}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-indicator="#htmx-spinner"
	hx-target="#display-data">
	<div class="form-elements-wrap">
		{$texts['selected_date']}
		{$texts['days_markup']}
		{$texts['selected_db']}
		<select name="db-filename">
			{$texts['db_files_markup']}
		</select>
		<!-- //TODO: Fix download -->
		<!-- <button type="button" class="button button-primary download-button" onclick="triggerDownload()">
			{$texts['download_log']}
		</button> -->
		{$texts['display_meta_text']}
		<label class="switch">
			<input type="checkbox" id="display-metadata" name="display_meta" onchange="toggleCookie('wpsd-display-meta', '1', this.checked)" {$texts['display_meta']}>
		<span class="slider"></span>
		</label>
		{$texts['record_fragments_text']}
		<label class="switch">
			<input type="checkbox" id="record-fragments" name="record-fragments" onchange="toggleCookie('record-fragments', '1', this.checked)" {$texts['record-fragments']}>
		<span class="slider"></span>
		</label>
	</div>
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button">
		<span class="dashicons dashicons-image-rotate"></span>
	</button>
	<input type="hidden" name="action" value="php-debug-search">
	<input type="text" name="search-keyword" placeholder="{$texts['search_placeholder']}">
	<input type="checkbox" name="search-regex"><span class="regex-checkbox">.*</span>
	<input type="text" name="exclude-keyword" placeholder="{$texts['exclude_placeholder']}">
	<input type="checkbox" name="exclude-regex"><span class="regex-checkbox">.*</span>
	<select name="error-type">
		{$error_types_markup}
	</select>
	<select name="order">
		<option value="desc">{$texts['newest_option']}</option>
		<option value="asc">{$texts['oldest_option']}</option>
	</select>
	{$texts['per_page']}
	<select name="per-page">
		<option>10</option>
		<option>50</option>
		<option>200</option>
		<option>1</option>
	</select>
	<button type="button" name="delete" class="pagination-button active log-delete-button" value="1" onclick="confirmDelete();">Delete</button>
	<input type="hidden" name="download" value="false">
	<input type="hidden" name="nonce" value="{$texts['nonce']}">
	</div>
</form>
<div id="display-data"
	hx-post="{$texts['ajax_url']}"
	hx-trigger="load"
	hx-headers='{"Content-Type": "application/json"}'
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals='{$texts["htmx-first-json"]}'>
	<img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18">
</div>
<script>
function toggleCookie(cookieName, cookieValue, isChecked) {

	if (isChecked) {
		document.cookie = cookieName + "=" + cookieValue + "; path=/";
	} else {
		document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
	}
}
</script>
HTML;

the_inlined_js();

}
//{$texts['loading']}
function get_form_texts(){

	return [
		'search_placeholder'	=> __('Search', 'wpsd-debug'),
		'exclude_placeholder'	=> __('Exclude', 'wpsd-debug'),
		'newest_option'			=> __('Newest', 'wpsd-debug'),
		'oldest_option'			=> __('Oldest', 'wpsd-debug'),
		'download_log'			=> __('Download log', 'wpsd-debug'),
		'loading'				=> __('Loading...', 'wpsd-debug'),
		'selected_date'			=> __('Date:', 'wpsd-debug'),
		'per_page'				=> __('Per page:', 'wpsd-debug'),
		'selected_db'			=> __('Database:', 'wpsd-debug'),
		'display_meta_text'		=> __('Display metadata:', 'wpsd-debug'),
		'record_fragments_text'	=> __('Record fragments:', 'wpsd-debug'),
		'nonce'					=> Consts::get_nonce(),
		'ajax_url'				=> admin_url('/admin-ajax.php?php-debug-search'),
		'today'					=> date('Y-m-d'),
		'db_files_markup'		=> get_db_files_markup(),
		'days_markup'			=> get_days_markup(),
		'display_meta'			=> checked($_COOKIE['wpsd-display-meta'] ?? '', '1', false),
		'record-fragments'		=> checked($_COOKIE['record-fragments'] ?? '0', '1', false),
		'htmx-first-json'		=> get_first_request_json()

	];

}

function get_first_request_json(){

	$data = [
		"action" => "htmx-php-debug-search",
		"db-filename" => get_this_site_db_filename(),
		"record-fragments" => empty($_COOKIE['record-fragments']) ? '' : '1',
		"search-keyword" => "",
		"exclude-keyword" => "",
		"display_meta"		=> ($_COOKIE['wpsd-display-meta']??false) ? 'on' : '',
		"error-type" => 0,
		"order" => "desc",
		"selected-day" => date('Y-m-d'),
		"nonce" => Consts::get_nonce()
	];

	return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
}

function get_db_files_markup(){

	$files = scandir( Consts::DB_DIR );

	$this_server_db_filename = get_this_site_db_filename();

	$output = '';

	foreach( $files as $filename){

		if( !str_ends_with($filename,'.sqlite') ) continue;
		
		$selected = $filename === $this_server_db_filename ? 'selected' : '';

		$output .= 
<<<HTML
<option value="{$filename}" {$selected}>{$filename}</option>
HTML;
	
	}

	return $output;
}

function get_php_error_types_markup(){

	require_once Consts::DIR.'includes/error-names.php';
	
	$output = '';
		
	foreach( get_error_type_strings() as $key => $name ){

		$output .= 
<<<HTML
<option value="{$key}">{$name}</option>
HTML;

	}
	
	return $output;
}

function get_days_markup(){
	
	$date =  date('Y-m-d');

	return <<<HTML
	<input 
		type="date" 
		name="selected-day" 
		max="{$date}" 
		value="{$date}">
	HTML;
}

function is_valid_log_filename( $filename ){

	switch(true){
		case str_contains( $filename, 'error.log' ):
		case str_contains( $filename, 'current' ):
			return true;
		default:
		    return false;
	}

}

function display_no_log_files(){

	$text = __('No log files been found','wpsd-debug');

    echo 
<<<HTML
<br>
<p>
	$text
</p>
HTML;
}

function the_inlined_js(){

	$confirm_text = __('Are you sure you want to delete?','wpsd-debug');
	
	$regex_warning_text = __('Unable to delete data on regex query.','wpsd-debug');

?>
<script>
//Auto trigger post
const form = document.querySelector('.input-form');
let timeoutId;

function debounce(func, delay) {
	clearTimeout(timeoutId);
	timeoutId = setTimeout(func, delay);
}

form.addEventListener('input', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

form.addEventListener('change', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

//Download
function triggerDownload() {
    var form = document.getElementById('debugForm');
    form.querySelector('input[name="download"]').value = "true";
    
    form.addEventListener('htmx:afterOnLoad', function resetDownload() {
        form.querySelector('input[name="download"]').value = "false";
        form.removeEventListener('htmx:afterOnLoad', resetDownload);
    });
    
    htmx.trigger(form, 'submit', {values: {download: "true"}});
}

//Delete button
function confirmDelete() {
    var searchRegexCheckbox = document.querySelector('input[name="search-regex"]');
    var excludeRegexCheckbox = document.querySelector('input[name="exclude-regex"]');

    if (searchRegexCheckbox.checked || excludeRegexCheckbox.checked) {
        alert('<?php echo $regex_warning_text; ?>');
        return;
    }

    if (confirm('<?php echo $confirm_text; ?>')) {
        htmx.trigger('#debugForm', 'submit');
    }
}
</script>
<?php
}