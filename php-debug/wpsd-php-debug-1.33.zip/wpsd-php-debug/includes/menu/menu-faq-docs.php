<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$title = __('Basic documentation', 'wpsd-debug');

$texts = [
	__('When deleting logs, only error messages are deleted directly, followed by metadata that has no error message associated.', 'wpsd-debug'),
	__('With the function `deb( $value, $note )`, you can display any variable on the front-end as a floating window. The toggle in settings must be on to display the data.', 'wpsd-debug'),
	__('Function `deb()` will display location in file and function name.', 'wpsd-debug'),
	__('The function `debl($value, $note)` writes data into the SQLite error log. Use this instead `error_log()` because this cannot be captured to store in the database.', 'wpsd-debug'),
	__('The function `the_wpsd_used_php()` displays included PHP files and it\'s OPcache memory usage.', 'wpsd-debug'),
	__('On `localhost` and when `WP_ENVIRONMENT_TYPE === "staging"`, the settings to activate displaying `deb( $value, $note )` is automatically set to true.', 'wpsd-debug'),
	__('Error reporting is set to `E_ALL`, you can exclude errors from reporting and logging in the menu `settings`.', 'wpsd-debug'),
	__('Downloaded log file is containing data displayed, if filters been applied, downloaded log will contain only filtered data.', 'wpsd-debug'),
	__('The database filename is unique to the IP of the server. That\'s because if your system runs on various servers with load balancer, error logs would be overwritten. As this version, you can see only error from the currently accessing server.', 'wpsd-debug'),
	__('Display errors toggle sets cookie enabling to show PHP errors only to you. If you logout, cookie will remain in your browser and PHP errors will be displayed, but only to you.', 'wpsd-debug'),
	__('Function wpsd_dd() will set display values and display error cookies.', 'wpsd-debug'),
	__('Function `stw()` - "Stopwatch" start count and will display how long time passed from first called `stw()`', 'wpsd-debug'),
	__('Function `stw(true)` will show time from start or last start time rest and resets the start time', 'wpsd-debug'),
	__('Function `vd( $value, "identifier", $float=false)` - "var_dump" will display a variable in readable format.', 'wpsd-debug'),
	__('If you run server on load balancer or want to separate errors from production and staging check `Server IP in filenames`.', 'wpsd-debug'),
	__('PHP Errors log is as default WP wp-content/debug.log, with new day debug log is moved to archive, where sqlite DB is stored.', 'wpsd-debug'),
	__('PHP Errors for multisite will have `-site1` or `-site2` suffix in debug.log so it can be distinguished where error happened.', 'wpsd-debug'),
	__('Fragments are logs that are awaiting to be inserted into the SQLite DB. They\'ve been created when DB is busy writing on another thread.', 'wpsd-debug'),
	__('Fragments are inserted automatically on cron or when DB is read in admin menu.', 'wpsd-debug'),
	__('Thanks to HTMX and SQLite for amazing libraries.', 'wpsd-debug'),
	
];

$li_markup = '<li>'.implode( "</li>\n<li>", $texts );

$body_class= Consts::SLUG.'-body';

echo <<<HTML
<div class="{$body_class} clear">
	<h3>{$title}</h3>
	<ul class="docs-points">
	{$li_markup}
	</ul>
</div>
HTML;
