<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$settings = get_settings_data();

save_new_settings($settings);

$markup_values = get_markup_values($settings);

$text = [
	'save_additional_data'		=> __('Basic settings:', 'wpsd-debug'),
	'send_fatal_error_report'	=> __('Send fatal error report', 'wpsd-debug'),
	'exclude_errors_logging'	=> __('Exclude errors from logging', 'wpsd-debug'),
	'save_settings'				=> __('Save Settings', 'wpsd-debug'),
];

$excluded_errors_markup = get_excluded_errors_markup($settings);

$nonce_field = wp_nonce_field('wpsd-php-debug-settings-save', 'wpsd_php_debug_settings_nonce', false, false);

$display_data_markup = get_display_data_markup();

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<form method="post" action="" class="debug-plugin-settings">
		<div class="tables-wrap">
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2"><strong>{$text['save_additional_data']}</strong></th>
					</tr>
				</thead>
				<tr class="table-line">
					<td class="display-key">{$markup_values['keep']['label']}</td>
					<td>
						<input type="number" min="1" max="3650" id="keep" name="keep" value="{$markup_values['keep']['value']}">
						{$markup_values['keep']['description']}
					</td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv']['label']}</td>
					<td><input type="checkbox" id="srv" name="server" {$markup_values['srv']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv_keys']['label']}</td>
					<td><textarea id="srv_keys" name="server_keys" rows="{$markup_values['srv_keys']['rows']}" cols="40">{$markup_values['srv_keys']['value']}</textarea></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['pst']['label']}</td>
					<td><input type="checkbox" id="pst" name="post" {$markup_values['pst']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['mip']['label']}</td>
					<td>
						<span class="desc-wrapper">
							<input type="checkbox" id="multi-ip" name="multi-ip" {$markup_values['mip']['checked']}>
							{$markup_values['mip']['description']}
						</span>
					</td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks']['label']}</td>
					<td><input type="checkbox" id="cks" name="cookies" {$markup_values['cks']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['cks_keys']['label']}</td>
					<td><textarea id="cks_keys" name="cookies_keys_full_value" rows="{$markup_values['cks_keys']['rows']}" cols="40">{$markup_values['cks_keys']['value']}</textarea></td>
				</tr>
				<tr>
					<th class="table-title" colspan="2"><br><strong>{$text['send_fatal_error_report']}</strong></th>
				</tr>
				<tr class="table-line">
					<td class="report-email">{$markup_values['report_email']['label']}</td>
					<td><input type="text" id="report_email" name="report_email" cols="40" value="{$markup_values['report_email']['value']}"></input></td>
				</tr>
			</table>
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2">{$text['exclude_errors_logging']}</th>
					</tr>
				</thead>
				<tr>
					<td colspan="2">
						{$excluded_errors_markup}
					</td>
				</tr>
			</table>
			<div>
				{$display_data_markup}
			</div>
		</div>
		{$nonce_field}
		<input type="hidden" name="action" value="save_settings">
		<input type="submit" value="{$text['save_settings']}" class="button button-primary">
	</form>
</div>
HTML;


//end of display_errors



function get_display_data_markup(){

	$texts = get_display_data_texts();

	return <<<HTML
<table class="wpsd-table">
	<thead>
		<tr>
			<th class="table-title" colspan="2">{$texts['title']}</th>
		</tr>
	</thead>
	<tr>
		<td>{$texts['text_errors']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugToggle" onchange="toggleCookie('{$texts['display_errors']}', this.checked)" {$texts['checked_display_errors']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td>{$texts['text_values']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugValuesToggle" onchange="toggleCookie('{$texts['display_values']}', this.checked)" {$texts['checked_display_values']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td>{$texts['text_admin_bar']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugAdminBarToggle" onchange="toggleCookie('{$texts['display_admin_bar']}', this.checked)" {$texts['checked_display_admin_bar']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td>{$texts['text_php_files']}</td>
		<td>
			<label class="switch">
				<input type="checkbox" id="debugPhpFiles" onchange="toggleCookie('{$texts['display_php_files']}', this.checked)" {$texts['checked_display_php_files']}>
				<span class="slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<td colspan="2">{$texts['text_note']}</td>
	</tr>
</table>
{$texts['script']}
HTML;

}

function get_display_data_texts(){

	$nonce = Consts::get_nonce();

	$checked_display_errors = checked($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] ?? '', $nonce, false);
	
	$checked_display_values = checked($_COOKIE[Consts::COOKIE_DISPLAY_VALUES] ?? '', $nonce, false);
	
	$checked_display_admin_bar = checked($_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR] ?? '', $nonce, false);

	$checked_display_php_files = checked($_COOKIE[Consts::COOKIE_DISPLAY_PHP_FILES] ?? '', $nonce, false);


	$script = <<<HTML
	<script>
	function toggleCookie(cookieName, isChecked) {
		const dirString = '{$nonce}';

		if (isChecked) {
			document.cookie = cookieName + "=" + dirString + "; path=/";
		} else {
			document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
		}
	}
	</script>
	HTML;

	return [
		'checked_display_errors'	=> $checked_display_errors,
		'checked_display_values'	=> $checked_display_values,
		'checked_display_admin_bar' => $checked_display_admin_bar,
		'checked_display_php_files' => $checked_display_php_files,
		'display_errors'			=> Consts::COOKIE_DISPLAY_ERRORS,
		'display_values'			=> Consts::COOKIE_DISPLAY_VALUES,
		'display_admin_bar'			=> Consts::COOKIE_DISPLAY_ADMIN_BAR,
		'display_php_files'			=> Consts::COOKIE_DISPLAY_PHP_FILES,
		'title'						=> __( 'Displaying data on the front-end', 'wpsd-debug' ),
		'text_display_cookies'		=> __( 'This cookie will enable displaying debug values:', 'wpsd-debug' ),
		'text_errors'				=> __( 'Display PHP Errors', 'wpsd-debug' ),
		'text_values'				=> __( 'Display Debug Values', 'wpsd-debug' ),
		'text_admin_bar'			=> __( 'Display menu in WP Admin bar', 'wpsd-debug' ),
		'text_php_files'			=> __( 'Display PHP files in WP Admin bar', 'wpsd-debug' ),
		'text_note'					=> __( 'Note: The Display Settings are not saved, they have to be manually activated after login.', 'wpsd-debug' ),
		'script'					=> $script,
	];

}


function get_excluded_errors_markup( $settings ){

	require_once Consts::DIR.'includes/error-names.php';

	$errors = get_error_type_strings();
	
	unset( $errors[0], $errors[99999]);

	$output = '';

	foreach( $errors as $error_code => $error_name ){

		$excluded_error = in_array( $error_code , $settings['excluded_errors']??[]) ? $error_code : '';

		$checked = checked( $error_code, $excluded_error , false);

		$output .= <<<HTML
<tr class="table-line">
	<td>
		<input type="checkbox" id="error-{$error_code}" name="excluded_errors[]" value="{$error_code}" {$checked} >
	</td>
	<td class="display-key">
		{$error_name}
	</td>
</tr>
HTML;


	}

	return $output;
}

function save_new_settings($settings){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return;

	update_wpsd_option(Consts::OPTION_SETTINGS, $settings);

}
function has_rights_to_save(){

	return	isset($_POST['wpsd_php_debug_settings_nonce']) &&

			wp_verify_nonce($_POST['wpsd_php_debug_settings_nonce'], 'wpsd-php-debug-settings-save') &&

			current_user_can( 'manage_options' );
}

function get_settings_data(){

	$old_setting = get_plugin_settings();

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return $old_setting;

	if ( !has_rights_to_save() ) { 
		
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'wpsd-debug' ) );
	
	}

	$settings = [

		'server'					=> get_textarea_values('server'),

		'server_keys'				=> $_POST['server_keys'] ? preg_split('/\r\n|[\r\n]/', $_POST['server_keys']) : [],
		
		'keep'						=> (intval($_POST['keep']??0) > 0 && intval($_POST['keep']) < 3650 ) ? intval($_POST['keep']) : 30,

		'post'						=> isset($_POST['post']),

		'multi-ip'					=> isset($_POST['multi-ip']),

		'cookies'					=> isset($_POST['cookies']),
	
		'report_email'				=> get_validated_emails(),
		
		'excluded_errors'			=> get_excluded_errors(),

		'cookies_keys_full_value' 	=> get_textarea_values('cookies_keys_full_value')
	];
	
	generate_error_reporting_settings( $settings );
	
	generate_mutli_ip_settings( $settings );

	rename_files_when_multi_ip_changes($old_setting,$settings);

	return $settings;

}

function rename_files_when_multi_ip_changes($old_setting, $settings){
	
	if( boolval($old_setting['multi-ip']) === boolval( $settings['multi-ip'] ) ) return;

	$s = get_files_strings();
	
	$ip_string = '-ip'.get_server_last_ip_number();

	if( $settings['multi-ip'] ){

		$log_filename_new = str_replace('debug','debug'.$ip_string , $s->log_filename);

		$db_filename_new = str_replace('error-log','error-log'.$ip_string , get_removed_ip($s->db_filename));

		$db_filename = get_removed_ip($s->db_filename);

	} else {

		$db_filename = $s->db_filename;

		$db_filename_new = get_removed_ip($s->db_filename);
	
		$log_filename_new = get_removed_ip($s->log_filename);
	}
	
	$db_filepath = $s->db_dir.DIRECTORY_SEPARATOR.$db_filename;

	$log_filepath  = $s->log_dir.DIRECTORY_SEPARATOR.$s->log_filename;

	$db_filepath_new = $s->db_dir.DIRECTORY_SEPARATOR.$db_filename_new;

	$error_log_filepath_new = $s->log_dir.DIRECTORY_SEPARATOR.$log_filename_new;

	if( !file_exists($error_log_filepath_new) && file_exists($log_filepath) ){
		
		rename( $log_filepath, $error_log_filepath_new );

		if( get_wpsd_option( Consts::OPTION_INI_STATUS) ){
			ini_set( 'error_log', $error_log_filepath_new );
		}
	}
	
	if( !file_exists($db_filepath_new) && file_exists($db_filepath) ){
		
		rename( $db_filepath, $db_filepath_new );
		
		get_db_filepath($db_filepath_new);
	}
}

function get_removed_ip($string){

	return preg_replace('/-ip(\d+|null)/', '', $string);
}

function get_files_strings(){

	$error_log_filepath = ini_get('error_log');

	$error_log_filename = basename($error_log_filepath);

	$error_log_dir = dirname($error_log_filepath);

	$db_filepath = get_db_filepath();

	$db_filename = basename($db_filepath);

	$db_dir = dirname($db_filepath);

	return (object)[

		'log_filename' => $error_log_filename,

		'log_dir' => $error_log_dir,

		'db_filename' => $db_filename,

		'db_dir' => $db_dir
	];

}

function generate_mutli_ip_settings( $settings ){

	update_wpsd_option( Consts::OPTION_MULTI_IP, $settings['multi-ip'] ? '1' : '0','yes'  );

}

function get_validated_emails(){

	if( empty($_POST['report_email']) || !str_contains($_POST['report_email'],'@'  )) return '';
	
	$input_string = $_POST['report_email']??'';

	$pieces = explode(',', $input_string);

	$filtered_emails = [];

	foreach ($pieces as $email){

		$filtered_emails[] = filter_var( trim($email), FILTER_VALIDATE_EMAIL );
	}

	return implode( ', ', $filtered_emails);

}

function get_textarea_values($post_key){

	if( !isset($_POST[$post_key]) || !is_string($_POST[$post_key]) ) return [];
	
	return $_POST[$post_key] === '' ? [] : preg_split('/\r\n|[\r\n]/', $_POST[$post_key]);
}

function generate_error_reporting_settings($settings) {

	$error_reporting = E_ALL;

	foreach($settings['excluded_errors'] as $error_code){
		switch (true) {
			case $error_code == 1:
				$error_reporting &= ~E_ERROR;
				break;
			case $error_code == 2:
				$error_reporting &= ~E_WARNING;
				break;
			case $error_code == 4:
				$error_reporting &= ~E_PARSE;
				break;
			case $error_code == 8:
				$error_reporting &= ~E_NOTICE;
				break;
			case $error_code == 16:
				$error_reporting &= ~E_CORE_ERROR;
				break;
			case $error_code == 32:
				$error_reporting &= ~E_CORE_WARNING;
				break;
			case $error_code == 64:
				$error_reporting &= ~E_COMPILE_ERROR;
				break;
			case $error_code == 128:
				$error_reporting &= ~E_COMPILE_WARNING;
				break;
			case $error_code == 256:
				$error_reporting &= ~E_USER_ERROR;
				break;
			case $error_code == 512:
				$error_reporting &= ~E_USER_WARNING;
				break;
			case $error_code == 1024:
				$error_reporting &= ~E_USER_NOTICE;
				break;
			case $error_code == 4096:
				$error_reporting &= ~E_RECOVERABLE_ERROR;
				break;
			case $error_code == 8192:
				$error_reporting &= ~E_DEPRECATED;
				break;
			case $error_code == 16384:
				$error_reporting &= ~E_USER_DEPRECATED;
				break;
		}
	}

	update_wpsd_option(Consts::OPTION_REPORTING, $error_reporting, 'yes');

}

function get_excluded_errors(){
	
	if( !is_valid_form_errors_input() ) return [];
	
	require_once Consts::DIR.'includes/error-names.php';
	
	$default_php_errors = get_error_type_strings();

	foreach( $_POST['excluded_errors'] as $form_error_value ){

		$form_error_value_int = intval( $form_error_value );

		if( !(isset( $default_php_errors[$form_error_value_int] ) || $form_error_value_int === 0) ) die('Unable to save');

		$result[] = $form_error_value_int; 
	}

	return $result??[];
}

function is_valid_form_errors_input(){

	return is_array($_POST['excluded_errors']??false) && !empty($_POST['excluded_errors']);
}

function get_markup_values($settings){
	
	return [
		'srv' => [
			'label' => __( 'Server:', 'wpsd-debug' ),
			'checked' => $settings['server'] ? 'checked' : ''
		],
		'keep' => [
			'label' => __( 'Keep records', 'wpsd-debug' ),
			'value' => $settings['keep']??'30',//default 30 days
			'description' => __( 'Days', 'wpsd-debug' )
		],
		'srv_keys' => [
			'label' => __( 'Server Keys<br>(one per line):', 'wpsd-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['server_keys'])),
			'rows' => max(2,count($settings['server_keys']) + 1)
		],
		'pst' => [
			'label' => __( 'Post:', 'wpsd-debug' ),
			'checked' => $settings['post'] ? 'checked' : ''
		],
		'fragments' => [
			'label' => __( 'Async save errors', 'wpsd-debug' ),
			'checked' => ($settings['fragments']??false) ? 'checked' : '',
			'description' => __( 'Recommended for high traffic sites.', 'wpsd-debug' ),
		],
		'mip' => [
			'label' => __( 'Server IP in filenames', 'wpsd-debug' ),
			'checked' => ($settings['multi-ip']??'0') ? 'checked' : '',
			'description' => __( 'Recommended for websites with load balancers.', 'wpsd-debug' ),
		],
		'cks' => [
			'label' => __( 'Cookies:<br>(clamped values)', 'wpsd-debug' ),
			'checked' => $settings['cookies'] ? 'checked' : ''
		],
		'cks_keys' => [
			'label' => __( 'Cookies Keys Full Value<br>(one per line):', 'wpsd-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['cookies_keys_full_value'])),
			'rows' => max(2, count($settings['cookies_keys_full_value']) + 1)
		],
		'report_email' => [
			'label' => __( 'Send fatal error warning<br>to this email<br>leave empty to disable', 'wpsd-debug' ),
			'value' => $settings['report_email']??'',
			'rows' => 40
		],
	];
}
