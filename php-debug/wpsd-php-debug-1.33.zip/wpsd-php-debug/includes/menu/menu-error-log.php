<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

display_error_log();


function display_error_log(){
	
	$texts = get_error_form_texts();

	$nonce = Consts::get_nonce();

	$this_server_error_log = basename(ini_get('error_log'));

	echo <<<HTML
<br>
<form class="input-form" id="debugForm"
	hx-post="{$texts['ajax_url']}"
	hx-vals='{
	"action": "htmx-php-debug-search",
	"source-error-log": "1",
	"nonce": "{$nonce}"
	}'
	hx-headers='{"Content-Type": "application/x-www-form-urlencoded"}'
	hx-indicator="#htmx-spinner"
	hx-target="#display-data">
	{$texts['select_log_file']}
	<div class="form-elements-wrap">
	<button type="button" class="form-reload" onclick="htmx.trigger('#debugForm', 'submit');" class="button">
		<span class="dashicons dashicons-image-rotate"></span>
	</button>
	<input type="hidden" name="action" value="php-debug-search">
	<input type="text" name="search-keyword" placeholder="{$texts['search_placeholder']}">
	<input type="checkbox" name="search-regex"><span class="regex-checkbox">.*</span>
	<input type="text" name="exclude-keyword" placeholder="{$texts['exclude_placeholder']}">
	<input type="checkbox" name="exclude-regex"><span class="regex-checkbox">.*</span>
	<select name="order">
		<option value="desc">{$texts['newest_option']}</option>
		<option value="asc">{$texts['oldest_option']}</option>
	</select>
	{$texts['per_page']}
	<select name="per-page">
		<option>10</option>
		<option>50</option>
		<option>200</option>
		<option>1</option>
	</select>
	</div>
</form>
<img class="htmx-indicator" id="htmx-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18">
<div id="display-data" class="metadata-value"
hx-post="{$texts['ajax_url']}"
	hx-trigger="load"
	hx-headers='{"Content-Type": "application/json"}'
	hx-swap="innerHTML"
	hx-target="#display-data"
	hx-vals='{"action": "htmx-php-debug-search",
				"source-error-log": "1",
				"search-keyword": "",
				"exclude-keyword": "",
				"error-type": 0,
				"order": "desc",
				"nonce": "{$nonce}",
				"db-filename": "{$this_server_error_log}"
				}'>
</div>
<script>
//Auto trigger post
const form = document.querySelector('.input-form');
let timeoutId;

function debounce(func, delay) {
	clearTimeout(timeoutId);
	timeoutId = setTimeout(func, delay);
}

form.addEventListener('input', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});

form.addEventListener('change', function() {
	debounce(function() {
		form.dispatchEvent(new Event('submit'));
	}, 500);
});
</script>
HTML;
		
	require Consts::DIR.'includes/menu/htmx-error-handler.php';

	the_inlined_htmx_error_handler();

}

function get_error_form_texts(){

	return [
		'search_placeholder'	=> __('Search', 'wpsd-debug'),
		'exclude_placeholder'	=> __('Exclude', 'wpsd-debug'),
		'newest_option'			=> __('Newest', 'wpsd-debug'),
		'oldest_option'			=> __('Oldest', 'wpsd-debug'),
		'download_log'			=> __('Download log', 'wpsd-debug'),
		'loading'				=> __('Loading...', 'wpsd-debug'),
		'selected_date'			=> __('Date:', 'wpsd-debug'),
		'per_page'				=> __('Per page:', 'wpsd-debug'),
		'ajax_url'				=> admin_url('/admin-ajax.php?php-debug-search'),
		'today'					=> date('Y-m-d'),
		'select_log_file'		=> get_select_log_file_markup(),

	];

}

function get_select_log_file_markup(){

	$files = get_log_files_groups();

	if( empty($files['current']) && empty($files['other'])) return '';

	$text_select = __('Error log:', 'wpsd-debug');

	$output = get_select_options_markup($files);
	
	return
	<<<HTML
	<div class="form-elements-wrap">
		{$text_select}
		<select name="db-filename">
			{$output}
		</select>
	</div>
	HTML;
	
	
	return $output;
}

function get_select_options_markup($files){

	$output_current = get_select_log_file_group_markup( $files['current']??[] );

	if( empty( $files['other']) ) return $output_current;

	$text_current_label = is_multisite() ? __('This site', 'wpsd-debug') : __('This server', 'wpsd-debug');
	
	$text_other_label = is_multisite() ? __('Other site', 'wpsd-debug') : __('Other server', 'wpsd-debug');

	$output_other = get_select_log_file_group_markup( $files['other']??[] );

	return <<<HTML
	<optgroup label="{$text_current_label}">
		$output_current
	</optgroup>
	<optgroup label="{$text_other_label}">
		$output_other
	</optgroup>
	HTML;

}

function get_select_log_file_group_markup($files){

	$this_server_error_log = basename(ini_get('error_log'));

	$output = '';

	foreach( $files as $filename){

		$selected = $this_server_error_log === $filename ? 'selected' : '';

		$output .= 
			<<<HTML
			<option value="{$filename}" {$selected}>{$filename}</option>
			HTML;
	
	}

	return $output;
}

function get_log_files_groups(){

	$main_debug = get_debug_files(WP_CONTENT_DIR);

	$archived_debugs = get_debug_files(Consts::DB_DIR);

	$files = array_merge($main_debug, $archived_debugs);

	if( get_wpsd_option(Consts::OPTION_MULTI_IP) ){

		$current_string = get_multisite_and_ip_string();

		$current = [];

		$other = [];

		foreach( $files as $file ){

			if( str_contains($file, $current_string ) ){

				$current[] = $file;

			} else{

				$other[] = $file;
			}
		}

	} else {

		$current = $files;
		$other = [];
	}

	$sorted_files= [
		'current'	=> $current,
		'other'		=> $other
	];

	return $sorted_files;

}

function get_debug_files($dir){

	if( !is_dir($dir) ) return [];

	$files = scandir($dir);

	if( !$files ) return [];

	$debug_files = [];

	foreach($files as $file){

		if( str_starts_with($file, 'debug') && str_ends_with($file,'.log') ){

			$debug_files[] = $file;

		}

	}

	return $debug_files;

}



/**
 * Sorted by the time, newer first
 */
function get_log_files_list(){
	
	$log_files = glob( Consts::DB_DIR.'/*.log');

	if( empty($log_files) ) return [];

	$file_data = [];

	foreach($log_files as $file){
		$file_data[] = [
			'file' => basename($file),
			'time' => filemtime($file)
		];
	}

	usort($file_data, function($a, $b){
		return $b['time'] - $a['time'];
	});

	return array_column( $file_data, 'file' );

}