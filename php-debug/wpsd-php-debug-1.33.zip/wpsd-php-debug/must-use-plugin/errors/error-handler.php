<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

set_php_error_reporting();

set_error_handler( __NAMESPACE__.'\error_handler');

register_shutdown_function( __NAMESPACE__.'\store_php_fatal_error');

define('QM_DISABLE_ERROR_HANDLER',true);

//some plugins change error reporting, this will re-assign the error_reporting
// add_action('plugins_loaded', __NAMESPACE__.'\\error_handling_main', PHP_INT_MAX );

// add_action('init', __NAMESPACE__.'\error_handling_main', PHP_INT_MAX );

// add_action('wp', __NAMESPACE__.'\error_handling_main', PHP_INT_MAX );



function store_php_fatal_error(){
	
	global $EZSQL_ERROR;
	
	if( !empty($EZSQL_ERROR) ) {
		
		foreach( $EZSQL_ERROR as $sql_errors ){
			// 32768 is arbitrary code for database error.
			error_handler( 32768 , "{$sql_errors['error_str']}\n\n{$sql_errors['query']}" , '', '' );
			
		}
	}

	if( !isset(error_get_last()['type']) ) return;

	switch( error_get_last()['type'] ){

		case E_ERROR:
		case E_PARSE:
		case E_CORE_ERROR:
		case E_COMPILE_ERROR:
		case E_USER_ERROR:

			$last_error = error_get_last();

			error_handler( $last_error['type'], $last_error['message'], $last_error['file'], $last_error['line'] );
			break;
	}
	
}

//MARK:Error handler
function error_handler( $error_code, $error_string, $error_file, $error_line ){
	
	$settings = get_plugin_settings();
	
	if( in_array( (int) $error_code , $settings['excluded_errors']??[] ) ){

		return;
	}

	// 0=> error code
	// 1=> (string) error data and stack 
	$stored_message = $error_string;

	if( !empty($error_file) && !str_contains($error_string, $error_file ) ){

		$stored_message .= "\n\n{$error_file}:{$error_line}";
	}

	if( !str_contains($error_string,'Stack trace:') && $error_code !== 32768 ){

		$stored_message .= "\n\n".get_stack(new \Exception);
	}
	
	errors_storage( [
		
		0 => $error_code,

		1 => remove_abspath( $stored_message ),

	]);

	if( !defined('WPSD_DEBUG_SHUTDOWN') ){

		define('WPSD_DEBUG_SHUTDOWN', true );

		register_shutdown_function( __NAMESPACE__.'\debug_shutdown_main' );

	}
	
	require_once Consts::DIR.'must-use-plugin/errors/functions-error-handler.php';

	move_older_error_log_to_archive();

	return false;
}

function errors_storage( $data_input='', $retreive=false ){

	static $wpsd_debug_errors;

	if( $retreive ){

		return $wpsd_debug_errors;

	}

	$wpsd_debug_errors[] = $data_input;

}

function get_stack($exception){
	
	$stack = remove_abspath( $exception->getTraceAsString() );

	$start = strpos($stack, "\n") + 1;

	return substr($stack, $start, strrpos($stack, "\n") - $start);

}

function remove_abspath( $string ){

	if( PHP_OS !== 'WINNT' ) return str_replace( ABSPATH, '/', $string);

	$string = str_replace('\\','/', $string );

	$abspath = str_replace('\\','/', ABSPATH );
	
	return str_replace( $abspath, '/', $string);
}

function debug_shutdown_main(){

	if( defined('WPSD_DEBUG_SHUTDOWN_MAIN') ){
		return;
	}

	define( 'WPSD_DEBUG_SHUTDOWN_MAIN', true );
	
	Consts::DIR.'must-use-plugin/errors/functions-error-handler.php';

	record_php_errors();

	display_fatal_error_data();
}

function set_php_error_reporting(){

	ini_set('log_errors', '1' );

	ini_set('ignore_repeated_errors', '1' );
	
	ini_set('ignore_repeated_source', '1' );
	
	error_reporting( get_wpsd_option( Consts::OPTION_REPORTING) );

	activate_display_errors();
	
	//some hostings don't allow to change `error_log` PHP settings
	if( get_wpsd_option(Consts::OPTION_INI_STATUS) ){

			ini_set( 'error_log', get_error_log_filepath() );
		
	}

}

function get_error_log_filepath(){
	
	if( defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG) && is_writable(WP_DEBUG_LOG) ){
		
		return WP_DEBUG_LOG;
		
	}
	
	return WP_CONTENT_DIR.'/debug'.get_multisite_and_ip_string().'.log';

}

function activate_display_errors(){

	$display_error = is_error_displayed();

	ini_set('display_errors', $display_error );

	ini_set('display_startup_errors', $display_error );
}

function is_error_displayed(){
	
	switch(true){

		case !isset($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS]):
		case !is_screen_output_allowed():
		case $_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] != Consts::get_nonce():
			return false;
		default:
			return true;
	}

}

function is_screen_output_allowed(){
	
	switch( WPSD_REQUEST_TYPE ){

		case REQUEST_FRONTEND:
		case REQUEST_ADMIN:
		case REQUEST_LOGIN:
		case REQUEST_DIRECT:
		case REQUEST_404:
			return true;
		default:
			return false;

	}
	
}