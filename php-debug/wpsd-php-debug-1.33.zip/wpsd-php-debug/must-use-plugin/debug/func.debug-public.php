<?php
/**
 * legacy file placeholder to avoid fatal error when migrating to the new version.
 */
namespace wpsd_php_debug;


function display_debug_data(){}

function tm(){}