<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require_once Consts::DIR.'includes/universal-functions.php';

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}

//MARK: Activation
/**
 * Main setup functions
 */
function plugin_activation_main(){

	update_settings_to_latest_version();
	
	set_autoload_settings();

	activate_local_mu_plugins();

	create_debug_log_folder();
	
	require_once Consts::DIR.'includes/create-sqlite-db.php';

	create_sqlite_db();

	require_once Consts::DIR.'includes/login/display-cookies.php';

	set_display_cookies();

}

//MARK: Deactivation
function plugin_deactivation_main(){

	remove_mu_plugin();

	unschedule_cleanup_cron();

	require_once Consts::DIR.'includes/login/display-cookies.php';

	delete_plugin_cookies();

}

/*
 * Activation functions beginning
 */

function create_debug_log_folder(){

	create_folder_with_index_php( WP_CONTENT_DIR.'/database/' );

	create_folder_with_index_php( Consts::DB_DIR );

	create_folder_with_index_php( Consts::FRAGMENTS_DIR );

}

function create_folder_with_index_php( $dir_path ){
	
	if( !is_dir( $dir_path ) ){
		
		wp_mkdir_p($dir_path);
	}
	
	$index_filepath = trailingslashit( $dir_path ).'index.php';
	
	if( !file_exists( $index_filepath) ){
		
		$index_markup = <<<HTML
			<?php
			//Silence is gold
			HTML;

		file_put_contents( $index_filepath, $index_markup );
	}

}

//does anybody remembers why I made this function pluggable?
if( !function_exists(__NAMESPACE__.'\is_ini_set_allowed') ){
		
	function is_ini_set_allowed(){

		$error_log_original = ini_get('error_log');

		ini_set('error_log', WP_CONTENT_DIR.'/debug-test.log' );
		
		$error_log_new  = ini_get('error_log');

		ini_set('error_log', $error_log_original );
		
		return $error_log_original !== $error_log_new;

	}
}

function activate_local_mu_plugins(){
	
	create_mu_plugin_wp_folder();

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) return;

	file_put_contents( $mu_loader_filepath, generate_loader_for_local_mu_plugins() );

}

function generate_loader_for_local_mu_plugins(){

	$plugin_basedir = basename(Consts::DIR);

	$mu_plugin_name = __( "Advanced PHP Debug by WP Speed Doctor", 'wpsd-debug' );

	$mu_plugin_description = __( "Enhanced data collection of PHP errors, easy to log and display data", 'wpsd-debug' );
	
	$mu_plugin_author = "WP Speed Doctor";

	$mu_plugin_url = "https://wpspeeddoctor.com/";

	$text_domain = 'wpsd-debug';

	return 

"<?php

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/
Description: {$mu_plugin_description}
Version: ".Consts::VER."
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

@include WP_PLUGIN_DIR.'/{$plugin_basedir}/must-use-plugin/mu-handler.php';
";

	
}

function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR ) ) return;
	
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}

/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return WPMU_PLUGIN_DIR."/0000-wpsd-php-debug.php";
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ){

		unlink( $mu_loader_filepath );
	} 

}

function unschedule_cleanup_cron(){
	
	$timestamp = wp_next_scheduled( 'cleanup_main_cron' );

	wp_unschedule_event( $timestamp, 'cleanup_main_cron' );

}

/**
 * Deactivation functions end
 */

/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(Consts::DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ) {

	$page_link = admin_url( 'tools.php?page='.Consts::PAGE_ADMIN );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">Menu</a>
		HTML;

	return array_merge( $actions,[$menu_link] );

}

function get_default_settings(){

	return [

		'keep'					=> 30,
		
		//stores $_SERVER
		'server'				=> true, 

		//store values of these $_SERVER keys
		'server_keys'			=>[ 

			'REQUEST_URI',
			'REQUEST_METHOD',
			'REMOTE_ADDR',
			'HTTP_REFERER',
			'HTTP_USER_AGENT',
	
		], 

		//stores $_POST
		'post'						=> true,

		'multi-ip'					=> false,

		//stored $_COOKIES
		'cookies'					=> false, 

		//store values of these keys
		'cookies_keys_full_value'	=> [ 
			
			// 'wmc_current_currency'
		
		],

		//List of excluded error codes
		'excluded_errors'			=> [
			2,8,8192
		]

	];
}

function update_settings_to_latest_version(){

	require_once Consts::DIR.'admin/uninstall.php';
	
	migrate_old_settings();

	create_debug_log_folder();

	add_new_settings_into_plugin_settings();

	append_ht_to_db_files();
	
	update_wpsd_option(Consts::OPTION_VER, Consts::VER, 'yes' );

}

function add_new_settings_into_plugin_settings(){
	
	$settings = get_plugin_settings();
	
	$updated = false;

	$new_settings =[

		'multi-ip'	=> get_wpsd_option( Consts::OPTION_MULTI_IP ),
		'keep'		=> 30,
	];

	if( empty($settings) ){
		
		$settings = get_default_settings();

		$updated = true;

	} else{

		foreach( $new_settings as $key => $value){

			if( !isset($settings[$key]) ){
				$updated = true;
				$settings[$key] = $value;
			}
		}

	}

	if( !$updated ) return;

	update_wpsd_option(Consts::OPTION_SETTINGS, $settings, 'no' );

}

function migrate_old_settings(){
	
	move_log_dir();

	$migrated_options = [
		'wpsd-php-debug-settings'			=> Consts::OPTION_SETTINGS,
		'wpsd-php-debug-error-reporting'	=> Consts::OPTION_REPORTING,
		'wpsd-php-ini-set-allowed' 			=> Consts::OPTION_INI_STATUS,
		'wpsd-ini-status'					=> Consts::OPTION_INI_STATUS,
		'wpsd-reporting'					=> Consts::OPTION_REPORTING,
	];

	foreach( $migrated_options as $old_key => $new_key ){

		if( get_wpsd_option( $old_key ) !== false ){

			$value = get_wpsd_option( $old_key );

			if( $new_key === Consts::OPTION_SETTINGS ){

				$autoload =  'no';
				if( !is_array($value) ){
					$value = json_decode( $value,true );
				}
			
			} else {

				$autoload = 'yes';
			}

			update_wpsd_option( $new_key, $value, $autoload );

			delete_wpsd_option( $old_key );

		}
	}

	$deprecated_settings=[
			'wpsd-php-debug-async'
	];

	foreach($deprecated_settings as $old_key){
		delete_wpsd_option( $old_key );
	}
}

function set_autoload_settings($args = []){

	$defaults = [
		Consts::OPTION_REPORTING	=> 24565,//default error code
		Consts::OPTION_INI_STATUS	=> is_ini_set_allowed() ? '1' : '0',
		Consts::OPTION_MULTI_IP		=> $args[Consts::OPTION_MULTI_IP]??'0',
	];

	foreach( $defaults as $key => $value ){

		if( get_wpsd_option( $key ) !== false ){
			continue;
		}

		update_wpsd_option( $key, $value, 'yes' );

	}
}

function move_log_dir(){

	$old_dir_name = get_wpsd_option( 'wpsd-php-debug-dir');

	if( $old_dir_name === false ){
		return;
	}

	create_folder_with_index_php( WP_CONTENT_DIR.'/database/' );

	$old_log_dir = WP_CONTENT_DIR.$old_dir_name;

	if( file_exists($old_log_dir) ){

		rename( $old_log_dir, Consts::DB_DIR );

		append_ht_to_db_files();
	}

	delete_wpsd_option( 'wpsd-php-debug-dir' );

}

function append_ht_to_db_files(){

	append_string_to_filename(Consts::DB_DIR,'.sqlite');

	append_string_to_filename(Consts::FRAGMENTS_DIR ,'.'.get_server_last_ip_number());

}

function append_string_to_filename($dir_path,$extension){

	if( empty($dir_path) || empty($extension) ) return false;

	$dir = dir($dir_path);

	if( !$dir ) return false;

	while(false !== ($file = $dir->read())){

		$full_path = $dir_path.DIRECTORY_SEPARATOR.$file;
		
		switch(true){
			case $file === '.':
			case $file === '..':
			case is_dir($full_path):
			case str_starts_with($file,'.ht.'):
			case !str_ends_with($file,$extension):
				continue 2;
		}

		rename( $full_path, $dir_path.DIRECTORY_SEPARATOR.'.ht.'.$file );
	}

	$dir->close();

	return true;
}
