<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;


function get_input_match_data( $input ){

	$data = get_db_data( $input );

	return filter_data_with_regex( $data, $input );
}


/**
 * @return array -
 * - total => int - The total count of results from the database.
 * - meta => array - Metadata about the database query.
 * - error => array - The error log data retrieved from the database.
 */

 function get_db_data( $input ){
	
	$filter_arg = get_query_filter_argument( $input );

	$query = get_query($input, $filter_arg );
	
	$start_time_measure = hrtime(true);

	$data = get_sqlite_query($query, $input['db-filename']);

	$end_time_measure = hrtime(true);
	
	if(empty($data) ) {

		$result['search-query-time'] 	= tm( $start_time_measure, $end_time_measure );

		return $result;
	}
	
	$result['total'] 		= $input['display-pagination'] ? get_count( $input ) : 0;
	
	$result['search-query-time'] 	= tm( $start_time_measure, $end_time_measure );



	foreach( $data as $event ){

		$event_meta_id = (int) $event['meta_id']??0;

		$result['error'][] =[
			'daytime' => $event['daytime']??'unknown',
            'code' => (int) $event['code']??0,
            'message' => $event['error']??'',
            'meta_id' => $event_meta_id,

		];

		;

		if( !isset( $result['meta'][$event_meta_id]) ){
			$result['meta'][$event_meta_id] = $event['meta'];
		} 
	}

	return $result;

}
function get_query_filter_argument( $input ){

	return empty( $input['search-regex'] ) && empty( $input['exclude-regex'] ) ? 'default' : 'all';
	
}

function get_count( $input ){

	$query = get_query($input,'count');

	return get_sqlite_query($query, $input['db-filename'])[0]['total']??0;	
		
}

function get_query($input, $filter = 'default'){

	$conditions = [];

	$where = $sort = $limit = '';

	$error_condition = get_error_type_condition($input['error-type'] ?? Consts::PHP_ERRORS, 'error_log.code');

	if( $error_condition !== '' ){

		$conditions[] = $error_condition;

	}

	if(!empty($input['selected-day'])){

		$selected_day = \SQLite3::escapeString($input['selected-day']);

		$conditions[] = <<<HTML
			(error_log.daytime >= '{$selected_day} 00:00:00' AND error_log.daytime <=  '{$selected_day} 23:59:59')
			HTML;
	}

	if( empty($input['search-regex']) && ( !empty($input['search-keyword']) || $input['search-keyword'] ==='0') ){

		$search_keyword = \SQLite3::escapeString($input['search-keyword']);

		$conditions[] = "(error_log.error LIKE '%$search_keyword%' OR error_meta.meta LIKE '%$search_keyword%')";
	}

	if( empty( $input['exclude-regex']) && (!empty($input['exclude-keyword']) || $input['exclude-keyword'] === '0') ){

		$exclude_keyword = \SQLite3::escapeString($input['exclude-keyword']);

		$conditions[] = "(error_log.error NOT LIKE '%$exclude_keyword%' AND error_meta.meta NOT LIKE '%$exclude_keyword%')";
	}

	if(!empty($conditions)){

		$conditions_sql = implode(" AND ", $conditions);

		$where = <<<SQL
		WHERE $conditions_sql
		SQL;
	}

	switch ($filter) {

		case 'count':

			$query = <<<SQL
				SELECT COUNT(*) as total
				FROM error_log
				INNER JOIN error_meta ON error_log.meta_id = error_meta.meta_id
				$where
				SQL;
				return $query;

		case 'all':

			$sort = $limit = '';
			break;

		default:

			$order = isset($input['order']) && strtolower($input['order']) === 'desc' ? 'DESC' : 'ASC';
		
			$sort = <<<SQL
			ORDER BY error_log.daytime $order
			SQL;

			if(isset($input['per-page']) && intval($input['per-page']) > 0){
				$per_page = intval($input['per-page']);
				$current_page = isset($input['current-page']) ? intval($input['current-page']) : 0;
				$offset = $current_page * $per_page;
				$limit = <<<SQL
				LIMIT $per_page OFFSET $offset
				SQL;
			}
			break;
	}

	$query = <<<SQL
	SELECT error_log.event_id, error_log.meta_id, error_log.code, error_log.error, error_meta.meta, error_log.daytime
	FROM error_log
	INNER JOIN error_meta ON error_log.meta_id = error_meta.meta_id
	$where
	$sort
	$limit
	SQL;

	return $query;
}

