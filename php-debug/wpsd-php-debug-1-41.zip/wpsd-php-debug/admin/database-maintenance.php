<?php

namespace WPSD\debug\v2;

defined('ABSPATH') || exit;

require_once Consts::DIR.'includes/database-info.php';

function database_maintenance_ajax(){

	$texts = [

		'forbidden' => __('You do not have permission to maintain this database.', 'wpsd-debug'),

		'invalid' => __('Invalid database or operation.', 'wpsd-debug'),

		'failed' => __('Database maintenance failed.', 'wpsd-debug'),

		'keep_today' => __('Kept only today and vacuumed the database.', 'wpsd-debug'),

		'zipped' => __('ZIP created.', 'wpsd-debug'),

		'zip_failed' => __('Could not create the ZIP file.', 'wpsd-debug'),

	];

	$nonce = $_POST['nonce'] ?? '';

	if( !current_user_can('manage_options') || !is_string($nonce) || !wp_verify_nonce(wp_unslash($nonce), 'wpsd-debug-db-maintenance') ){

		wp_die(esc_html($texts['forbidden']), '', ['response' => 403]);

		return false;

	}

	$filename = $_POST['db-filename'] ?? '';

	$filename = is_string($filename) ? wp_unslash($filename) : '';

	$operation = $_POST['operation'] ?? '';

	if( !in_array($operation, ['vacuum', 'keep-today', 'zip'], true) || get_database_info_filepath($filename) === false ){

		wp_die(esc_html($texts['invalid']), '', ['response' => 400]);

		return false;

	}

	if( $operation === 'zip' ){

		require_once Consts::DIR.'includes/database-zip.php';

		$zip_status = create_database_zip($filename) ? $texts['zipped'] : $texts['zip_failed'];

		echo get_database_info_row($filename, '', !empty($_POST['vacuumed']), $zip_status);

		wp_die();

		return;

	}

	$status = $texts['failed'];

	$vacuumed = maintain_sqlite_database($filename, $operation);

	if( $vacuumed ){

		$status = $operation === 'vacuum' ? '' : $texts['keep_today'];

	}

	echo get_database_info_row($filename, $status, $vacuumed);

	wp_die();

}

function maintain_sqlite_database($filename, $operation){

	$filepath = get_database_info_filepath($filename);

	if( $filepath === false || !class_exists('SQLite3') || !in_array($operation, ['vacuum', 'keep-today'], true) ){

		return false;

	}

	$db = null;

	$transaction_started = false;

	try{

		$db = new \SQLite3($filepath, SQLITE3_OPEN_READWRITE);

		$db->enableExceptions(true);

		$db->busyTimeout(5000);

		if( $operation === 'keep-today' ){

			$today = date('Y-m-d').' 00:00:00';

			$tomorrow = date('Y-m-d', strtotime('+1 day')).' 00:00:00';

			$db->exec('BEGIN IMMEDIATE');

			$transaction_started = true;

			$stmt = $db->prepare('DELETE FROM error_log WHERE daytime < :today OR daytime >= :tomorrow');

			$stmt->bindValue(':today', $today, SQLITE3_TEXT);

			$stmt->bindValue(':tomorrow', $tomorrow, SQLITE3_TEXT);

			$result = $stmt->execute();

			$result->finalize();

			$stmt->close();

			$db->exec('DELETE FROM error_meta WHERE NOT EXISTS (SELECT 1 FROM error_log WHERE error_log.meta_id = error_meta.meta_id)');

			$db->exec('COMMIT');

			$transaction_started = false;

		}

		return $db->exec('VACUUM');

	}catch(\Throwable $exception){

		return false;

	}finally{

		if( $db !== null ){

			if( $transaction_started ){

				$db->exec('ROLLBACK');

			}

			$db->close();

		}

	}

}
