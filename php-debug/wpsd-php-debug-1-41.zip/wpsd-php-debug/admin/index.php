<?php
//Silence is gold