<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

switch( $_POST['action'] ){

	case 'wpsd-debug-db-maintenance':

		require_once Consts::DIR.'admin/database-maintenance.php';

		add_action('wp_ajax_wpsd-debug-db-maintenance', __NAMESPACE__.'\database_maintenance_ajax');

		break;

	case 'update-plugin':

		require_once Consts::DIR.'admin/update.php';

		break;

	case 'htmx-php-debug-search':

		if( !function_exists( __NAMESPACE__.'\set_php_error_reporting') ){

			require_once Consts::DIR.'must-use-plugin/ajax/ajax-handler.php';

		}

		break;
}