(() => {
	async function copy_text(text){
		if( navigator.clipboard && navigator.clipboard.writeText ){
			try {
				await navigator.clipboard.writeText(text);
				return;
			} catch {}
		}

		const previous_focus = document.activeElement;
		const input = document.createElement('textarea');

		input.value = text;
		input.style.position = 'fixed';
		input.style.opacity = '0';
		document.body.appendChild(input);
		input.select();

		try {
			document.execCommand('copy');
		} finally {
			input.remove();
			previous_focus?.focus({preventScroll: true});
		}
	}

	document.addEventListener('dblclick', event => {
		const location = event.target.closest('.wpsd-event-location');

		if( location ){
			const path = location.textContent;
			copy_text(path.slice(Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\')) + 1));
		}
	});

	document.addEventListener('click', event => {
		const value = event.target.closest('.wpsd-metadata-copy');

		if( value ){
			copy_text(value.textContent);
		}
	});

	function sync_event_toggle(event_element){
		const button = event_element.querySelector('.wpsd-event-toggle');
		const metadata_toggle = event_element.querySelector('.wpsd-toggle');

		if( !button ){
			return;
		}

		const expanded = Array.from(event_element.querySelectorAll('details')).every(section => section.open) && (!metadata_toggle || metadata_toggle.checked);
		const label = expanded ? button.dataset.collapseLabel : button.dataset.expandLabel;

		button.setAttribute('aria-expanded', String(expanded));
		button.setAttribute('aria-label', label);
		button.title = label;
	}

	function set_event_expanded(event_element, expanded){
		event_element.querySelectorAll('details').forEach(section => {
			section.open = expanded;
		});

		const metadata_toggle = event_element.querySelector('.wpsd-toggle');

		if( metadata_toggle ){
			metadata_toggle.checked = expanded;
		}

		sync_event_toggle(event_element);
	}

	function initialize_event_displays(root = document){
		const events = Array.from(root.querySelectorAll('.wpsd-record-container'));

		if( root.matches && root.matches('.wpsd-record-container') ){
			events.unshift(root);
		}

		events.forEach(event_element => {
			if( event_element.dataset.wpsdInitialized ){
				return;
			}

			event_element.dataset.wpsdInitialized = 'true';
			set_event_expanded(event_element, event_element.dataset.wpsdExpanded === 'true');
		});
	}

	document.addEventListener('click', event => {
		const button = event.target.closest('.wpsd-event-toggle');

		if( !button ){
			return;
		}

		set_event_expanded(button.closest('.wpsd-record-container'), button.getAttribute('aria-expanded') !== 'true');
	});

	document.addEventListener('change', event => {
		if( event.target.matches('#display-metadata') ){
			document.querySelectorAll('.wpsd-record-container').forEach(event_element => {
				set_event_expanded(event_element, event.target.checked);
			});

			return;
		}

		if( event.target.matches('.wpsd-toggle') ){
			sync_event_toggle(event.target.closest('.wpsd-record-container'));
		}
	});

	document.addEventListener('toggle', event => {
		if( !event.target.matches('details') ){
			return;
		}

		const event_element = event.target.closest('.wpsd-record-container');

		if( event_element ){
			sync_event_toggle(event_element);
		}
	}, true);

	document.addEventListener('htmx:afterSwap', event => {
		initialize_event_displays(event.target);
	});

	if( document.readyState === 'loading' ){
		document.addEventListener('DOMContentLoaded', () => initialize_event_displays());
	} else {
		initialize_event_displays();
	}
})();
