<?php

namespace WPSD\debug\v2;

class Event_Metadata_Display extends Event_Display{

	public static function get_html($data){

		if( !is_array($data) ){

			return false;

		}

		$texts = [

			Stored_Event::META_URI => __('URI', 'wpsd-debug'),

			Stored_Event::META_IP => __('IP address', 'wpsd-debug'),

			Stored_Event::META_USERNAME => __('Username', 'wpsd-debug'),

			Stored_Event::META_REQUEST_TYPE => __('Request type', 'wpsd-debug'),

			Stored_Event::META_SERVER => __('Server', 'wpsd-debug'),

			Stored_Event::META_POST => __('POST', 'wpsd-debug'),

			Stored_Event::META_TIMESTAMP => __('Timestamp', 'wpsd-debug'),

		];

		$request_types = [

			1 => __('Frontend', 'wpsd-debug'),

			2 => __('AJAX', 'wpsd-debug'),

			3 => __('Admin', 'wpsd-debug'),

			4 => __('Cron', 'wpsd-debug'),

			5 => __('Login', 'wpsd-debug'),

			6 => __('XML-RPC', 'wpsd-debug'),

			7 => __('Empty', 'wpsd-debug'),

			8 => __('REST', 'wpsd-debug'),

			9 => __('Sitemap', 'wpsd-debug'),

			10 => __('Direct', 'wpsd-debug'),

			11 => __('404', 'wpsd-debug'),

			12 => __('Feed', 'wpsd-debug'),

			13 => __('CLI', 'wpsd-debug'),

		];

		$request_type = $data[Stored_Event::META_REQUEST_TYPE] ?? null;

		if( is_int($request_type) && isset($request_types[$request_type]) ){

			$data[Stored_Event::META_REQUEST_TYPE] = $request_types[$request_type];

		}

		$rows = '';

		foreach($texts as $key => $text){

			if( !array_key_exists($key, $data) || $data[$key] === null ){

				continue;

			}

			$value = $data[$key];

			$value_html = static::get_collection_html($value);

			if( $key === Stored_Event::META_URI && is_string($value) ){

				$value_html = static::get_uri_html($value);

			}

			$rows .= static::get_row_html($text, $value_html);

			if( $key === Stored_Event::META_URI && is_string($value) ){

				$uri = parse_url($value);

				if( !isset($uri['query']) || $uri['query'] === '' ){

					continue;

				}

				$rows .= static::get_row_html(__('Path', 'wpsd-debug'), static::get_copy_html($uri['path'] ?? ''));

				$rows .= static::get_row_html(__('Query string', 'wpsd-debug'), static::get_copy_html($uri['query'] ?? ''));

			}

		}

		if( $rows === '' ){

			return '';

		}

		return <<<HTML
		<dl class="wpsd-event-fields">{$rows}</dl>
		HTML;

	}

	protected static function get_uri_html($uri){

		$value_html = static::get_copy_html($uri);

		$path = parse_url($uri);

		if( $path === false || $uri === '' ){

			return $value_html;

		}

		$url = !isset($path['scheme']) ? '/'.ltrim($uri, '/') : $uri;

		$url = esc_url($url, ['http', 'https']);

		if( $url === '' ){

			return $value_html;

		}

		$texts = ['open' => __('Open URI in a new window', 'wpsd-debug')];

		$title = static::escape($texts['open']);

		return <<<HTML
		<div class="wpsd-metadata-uri">{$value_html}<a href="{$url}" target="_blank" rel="noopener noreferrer" title="{$title}" aria-label="{$title}"><span class="dashicons dashicons-external no-underline" aria-hidden="true"></span></a></div>
		HTML;

	}

	protected static function get_row_html($label, $value_html){

		$label = static::get_copy_html($label);

		return <<<HTML
		<dt>{$label}</dt><dd>{$value_html}</dd>
		HTML;

	}

	protected static function get_copy_html($value){

		$texts = ['copy' => __('Click to copy', 'wpsd-debug')];

		$title = static::escape($texts['copy']);

		$value = static::escape(static::get_value_text($value));

		return <<<HTML
		<button type="button" class="wpsd-metadata-copy" title="{$title}">{$value}</button>
		HTML;

	}

	protected static function get_collection_html($data, $depth = 0){

		if( !is_array($data) || $data === [] || $depth >= 16 ){

			return static::get_copy_html(static::get_value_text($data, $depth));

		}

		$rows = '';

		foreach($data as $key => $value){

			$value_html = static::get_collection_html($value, $depth + 1);

			$rows .= static::get_row_html((string) $key, $value_html);

		}

		return <<<HTML
		<dl class="wpsd-event-fields">{$rows}</dl>
		HTML;

	}

}
