<?php

namespace WPSD\debug\v2;

class Php_Event_Display extends Event_Display{

	protected static function get_message_html($message){

		return static::get_value_html($message);

	}

}
