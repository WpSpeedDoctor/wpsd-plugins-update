<?php

namespace WPSD\debug\v2;

class Email_Event_Display extends Event_Display{

	protected static function get_message_html($message){

		if( !is_array($message) ){

			return static::get_value_html($message);

		}

		$texts = [

			Stored_Event::EMAIL_FROM => __('From', 'wpsd-debug'),

			Stored_Event::EMAIL_TO => __('To', 'wpsd-debug'),

			Stored_Event::EMAIL_SUBJECT => __('Subject', 'wpsd-debug'),

			Stored_Event::EMAIL_ERROR => __('Error', 'wpsd-debug'),

		];

		return static::get_fields_html($message, $texts);

	}

}
