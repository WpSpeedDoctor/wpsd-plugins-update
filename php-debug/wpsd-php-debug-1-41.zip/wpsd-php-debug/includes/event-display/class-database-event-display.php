<?php

namespace WPSD\debug\v2;

class Database_Event_Display extends Event_Display{

	protected static function get_message_html($message){

		if( !is_array($message) ){

			return static::get_value_html($message);

		}

		$texts = [

			Stored_Event::DATABASE_ERROR => __('Database error', 'wpsd-debug'),

			Stored_Event::DATABASE_QUERY => __('Query', 'wpsd-debug'),

		];

		return static::get_fields_html($message, $texts);

	}

}
