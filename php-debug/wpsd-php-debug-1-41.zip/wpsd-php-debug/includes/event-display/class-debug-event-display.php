<?php

namespace WPSD\debug\v2;

class Debug_Event_Display extends Event_Display{

	public static function get_html($data){

		return static::get_value_html($data);

	}

}
