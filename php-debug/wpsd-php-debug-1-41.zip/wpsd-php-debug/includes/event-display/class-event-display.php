<?php

namespace WPSD\debug\v2;

defined('ABSPATH') || exit;

require_once Consts::DIR.'includes/class-stored-event.php';

class Event_Display{

	public static function render($message, $code){

		if( !is_string($message) ){

			return false;

		}

		if( (int) $code === 99999 ){

			require_once __DIR__.'/class-debug-event-display.php';

			return Debug_Event_Display::get_html($message);

		}

		$data = json_decode($message, true);

		if( !is_array($data) || !array_is_list($data) || count($data) !== Stored_Event::MESSAGE_STACK + 1 ){

			return static::get_value_html($message);

		}

		switch((int) $code){

			case 32768:

				require_once __DIR__.'/class-database-event-display.php';

				return Database_Event_Display::get_html($data);

			case 65536:

			case 65538:

				require_once __DIR__.'/class-http-event-display.php';

				return Http_Event_Display::get_html($data);

			case 65537:

				require_once __DIR__.'/class-email-event-display.php';

				return Email_Event_Display::get_html($data);

		}

		require_once __DIR__.'/class-php-event-display.php';

		return Php_Event_Display::get_html($data);

	}

	public static function render_email($message, $code){

		$html = static::render($message, $code);

		if( $html === false ){

			return false;

		}

		return str_replace(

			['<details', '</details>', '<summary>', '</summary>'],

			['<div', '</div>', '<strong>', '</strong><br>'],

			$html

		);

	}

	public static function render_meta($message){

		if( !is_string($message) ){

			return false;

		}

		$data = json_decode($message, true);

		if( !is_array($data) || !array_is_list($data) || !in_array(count($data), [Stored_Event::META_REQUEST_TYPE + 1, Stored_Event::META_IP + 1, Stored_Event::META_URI + 1], true) ){

			return static::get_value_html($message);

		}

		require_once __DIR__.'/class-event-metadata-display.php';

		return Event_Metadata_Display::get_html($data);

	}

	public static function get_html($data){

		if( !is_array($data) ){

			return false;

		}

		$message_html = static::get_message_html($data[Stored_Event::MESSAGE_TEXT] ?? null);

		$location_html = static::get_location_html($data);

		$stack_html = static::get_stack_html($data[Stored_Event::MESSAGE_STACK] ?? null);

		return <<<HTML
		<div class="wpsd-event-message">{$message_html}</div>
		{$location_html}
		{$stack_html}
		HTML;

	}

	protected static function get_message_html($message){

		return static::get_value_html($message);

	}

	protected static function get_location_html($data){

		$file = $data[Stored_Event::MESSAGE_FILE] ?? null;

		if( !is_string($file) || $file === '' ){

			return '';

		}

		$texts = ['copy' => __('Double-click to copy filename and line', 'wpsd-debug')];

		$file = ltrim(str_replace(ABSPATH, '', $file), '/');

		$line = $data[Stored_Event::MESSAGE_LINE] ?? null;

		$location = static::escape($file.($line !== null ? ':'.static::get_value_text($line) : ''));

		$title = static::escape($texts['copy']);

		return <<<HTML
		<div class="wpsd-event-location" title="{$title}">{$location}</div>
		HTML;

	}

	protected static function get_fields_html($data, $texts){

		if( !is_array($data) ){

			return false;

		}

		$rows = '';

		foreach($texts as $key => $text){

			if( !array_key_exists($key, $data) || $data[$key] === null ){

				continue;

			}

			$label = static::escape($text);

			$value_html = static::get_value_html($data[$key]);

			$rows .= <<<HTML
			<dt>{$label}</dt><dd>{$value_html}</dd>
			HTML;

		}

		if( $rows === '' ){

			return '';

		}

		return <<<HTML
		<dl class="wpsd-event-fields">{$rows}</dl>
		HTML;

	}

	protected static function get_value_html($value){

		$value = static::escape(static::get_value_text($value));

		return <<<HTML
		<pre class="wpsd-event-value">{$value}</pre>
		HTML;

	}

	protected static function get_value_text($value, $depth = 0){

		if( $depth >= 16 ){

			return '…';

		}

		switch(true){

			case is_string($value):

				return $value;

			case is_bool($value):

				return $value ? 'true' : 'false';

			case $value === null:

				return 'null';

			case is_array($value):

				if( count($value) === 2 && array_is_list($value) && is_int($value[Stored_Event::VALUE_TYPE]) ){

					$data = $value[Stored_Event::VALUE_DATA];

					switch($value[Stored_Event::VALUE_TYPE]){

						case Stored_Event::TYPE_OBJECT:

							if( is_string($data) ){

								return $data.' ('.__('object', 'wpsd-debug').')';

							}

							break;

						case Stored_Event::TYPE_RESOURCE:

							if( is_string($data) ){

								return $data.' ('.__('resource', 'wpsd-debug').')';

							}

							break;

						case Stored_Event::TYPE_FLOAT:

							if( is_string($data) ){

								return $data;

							}

							break;

						case Stored_Event::TYPE_TRUNCATED:

							if( $data === true ){

								return __('Truncated', 'wpsd-debug');

							}

					}

				}

				$rows = [];

				foreach($value as $key => $item){

					$rows[] = $key.' => '.static::get_value_text($item, $depth + 1);

				}

				return $rows ? "[\n".implode("\n", $rows)."\n]" : '[]';

			case is_scalar($value):

				return (string) $value;

		}

		return '';

	}

	protected static function get_stack_html($stack){

		if( !is_array($stack) || empty($stack[Stored_Event::STACK_FRAMES]) || !is_array($stack[Stored_Event::STACK_FRAMES]) ){

			return '';

		}

		$texts = [

			'stack' => __('Stack trace', 'wpsd-debug'),

			'arguments' => __('Arguments', 'wpsd-debug'),

			'internal' => __('Internal function', 'wpsd-debug'),

		];

		$frames_html = '';

		foreach($stack[Stored_Event::STACK_FRAMES] as $frame){

			if( !is_array($frame) ){

				continue;

			}

			$file = $frame[Stored_Event::FRAME_FILE] ?? $texts['internal'];

			$line = $frame[Stored_Event::FRAME_LINE] ?? null;

			$location = static::escape(static::get_value_text($file).($line !== null ? ':'.static::get_value_text($line) : ''));

			$call = static::escape(static::get_value_text($frame[Stored_Event::FRAME_CLASS] ?? '').static::get_value_text($frame[Stored_Event::FRAME_TYPE] ?? '').static::get_value_text($frame[Stored_Event::FRAME_FUNCTION] ?? ''));

			$arguments_html = '';

			if( !empty($frame[Stored_Event::FRAME_ARGS]) ){

				$arguments = static::get_value_html($frame[Stored_Event::FRAME_ARGS]);

				$arguments_label = static::escape($texts['arguments']);

				$arguments_html = <<<HTML
				<details><summary>{$arguments_label}</summary>{$arguments}</details>
				HTML;

			}

			$frames_html .= <<<HTML
			<li><code>{$call}()</code><br><span>{$location}</span>{$arguments_html}</li>
			HTML;

		}

		$stack_label = static::escape($texts['stack']);

		return <<<HTML
		<details class="wpsd-event-stack"><summary>{$stack_label}</summary><ol>{$frames_html}</ol></details>
		HTML;

	}

	protected static function escape($value){

		return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

	}

}
