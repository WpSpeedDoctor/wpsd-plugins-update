<?php

namespace WPSD\debug\v2;

class Http_Event_Display extends Event_Display{

	protected static function get_message_html($message){

		if( !is_array($message) ){

			return static::get_value_html($message);

		}

		$texts = [

			Stored_Event::HTTP_MESSAGE_METHOD => __('Method', 'wpsd-debug'),

			Stored_Event::HTTP_MESSAGE_URL => __('URL', 'wpsd-debug'),

			Stored_Event::HTTP_MESSAGE_CODE => __('Status or error code', 'wpsd-debug'),

			Stored_Event::HTTP_MESSAGE_TEXT => __('Status or error message', 'wpsd-debug'),

		];

		return static::get_fields_html($message, $texts);

	}

	public static function get_html($data){

		if( !is_array($data) ){

			return false;

		}

		$html = parent::get_html($data);

		$http_data = $data[Stored_Event::MESSAGE_STACK][Stored_Event::STACK_HTTP_REQUEST] ?? null;

		if( !is_array($http_data) ){

			return $html;

		}

		$texts = [

			'request' => __('Request', 'wpsd-debug'),

			'response' => __('Response', 'wpsd-debug'),

			'status_code' => __('Status code', 'wpsd-debug'),

			'status_message' => __('Status message', 'wpsd-debug'),

			'headers' => __('Headers', 'wpsd-debug'),

			'body' => __('Body', 'wpsd-debug'),

			'cookies' => __('Cookies', 'wpsd-debug'),

			'filename' => __('Filename', 'wpsd-debug'),

			'transport_class' => __('Transport class', 'wpsd-debug'),

			'error_code' => __('Error code', 'wpsd-debug'),

			'error_message' => __('Error message', 'wpsd-debug'),

			'error_data' => __('Error data', 'wpsd-debug'),

			'body_preview' => __('Body preview', 'wpsd-debug'),

			'url' => __('URL', 'wpsd-debug'),

			'method' => __('Method', 'wpsd-debug'),

			'timeout' => __('Timeout', 'wpsd-debug'),

			'redirection' => __('Redirection', 'wpsd-debug'),

			'http_version' => __('HTTP version', 'wpsd-debug'),

			'user_agent' => __('User agent', 'wpsd-debug'),

			'blocking' => __('Blocking', 'wpsd-debug'),

			'ssl_verify' => __('SSL verification', 'wpsd-debug'),

			'compress' => __('Compress', 'wpsd-debug'),

			'decompress' => __('Decompress', 'wpsd-debug'),

			'stream' => __('Stream', 'wpsd-debug'),

			'limit_response_size' => __('Response size limit', 'wpsd-debug'),

		];

		$response_texts = array_map(static function($field) use ($texts){

			return $texts[$field];

		}, Stored_Event::HTTP_RESPONSE_FIELDS);

		$request_texts = array_map(static function($field) use ($texts){

			return $texts[$field];

		}, Stored_Event::HTTP_REQUEST_FIELDS);

		$response_html = static::get_fields_html($http_data[Stored_Event::HTTP_RESPONSE] ?? [], $response_texts);

		$request_html = static::get_fields_html($http_data[Stored_Event::HTTP_REQUEST] ?? [], $request_texts);

		$response_label = static::escape($texts['response']);

		$request_label = static::escape($texts['request']);

		return <<<HTML
		{$html}
		<details class="wpsd-event-http"><summary>{$request_label}</summary>{$request_html}</details>
		<details class="wpsd-event-http"><summary>{$response_label}</summary>{$response_html}</details>
		HTML;

	}

}
