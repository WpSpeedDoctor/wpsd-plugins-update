<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require_once Consts::DIR.'includes/emergency-access.php';

$settings = get_settings_data();

save_new_settings($settings);

$markup_values = get_markup_values($settings);

$text = [
	'save_additional_data'		=> __('Basic settings:', 'wpsd-debug'),
	'reporting' => __('Reporting', 'wpsd-debug'),

	'frequency' => esc_html__('Maximum reporting frequency', 'wpsd-debug'),

	'frequency_description' => esc_html__('Limit the number of reporting emails sent in any 60-minute period. Once the limit is reached, further reports are skipped until an email allowance becomes available.', 'wpsd-debug'),

	'report_interval' => esc_html__('Check for report content', 'wpsd-debug'),

	'report_interval_description' => esc_html__('How often reporting runs to collect new content. An email is sent only when the report has content and the hourly email limit allows it.', 'wpsd-debug'),

	'report_php_fatal' => esc_html__('Report PHP Fatal errors', 'wpsd-debug'),

	'report_php_error_locations' => esc_html__('Elevated locations of PHP errors', 'wpsd-debug'),

	'php_error_locations_description' => esc_html__('Report when the number of distinct filename:line locations in JSON-recorded PHP errors is more than 20% higher than during the matching period yesterday. Repeated errors at the same location count once. The email lists the current locations and marks those absent yesterday. The period length follows Check for report content.', 'wpsd-debug'),
	'exclude_errors_logging'	=> __('Exclude errors from logging', 'wpsd-debug'),
	'exclude_logging_strings'	=> __('Exclude logging strings:', 'wpsd-debug'),
	'save_settings'				=> __('Save Settings', 'wpsd-debug'),
];

$excluded_errors_markup = get_excluded_errors_markup($settings);

$report_frequency_markup = get_report_frequency_markup($settings);

$report_interval_markup = get_report_interval_markup($settings);

$settings_tooltips = get_settings_tooltips($markup_values, $text);

$report_php_fatal_checked = checked($settings['report_php_fatal'] ?? true, true, false);

$report_php_error_locations_checked = checked($settings['report_php_error_locations'] ?? true, true, false);

$excluded_logging_strings = htmlspecialchars(implode("\n", $settings['excluded_logging_strings']??[]));

$excluded_logging_strings_rows = max(2, count($settings['excluded_logging_strings']??[]) + 1);

$nonce_field = wp_nonce_field('wpsd-php-debug-settings-save', 'wpsd_php_debug_settings_nonce', false, false);

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<form method="post" action="" class="debug-plugin-settings">
		<div class="tables-wrap">
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2"><strong>{$text['save_additional_data']}</strong></th>
					</tr>
				</thead>
				<tr class="table-line">
					<td class="display-key">{$markup_values['keep']['label']}</td>
					<td>
						<input type="number" min="1" max="3650" id="keep" name="keep" value="{$markup_values['keep']['value']}">
						{$markup_values['keep']['description']}
					</td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['srv_keys']['label']} {$settings_tooltips['server_keys']}</td>
					<td><textarea id="srv_keys" name="server_keys" rows="{$markup_values['srv_keys']['rows']}" cols="40">{$markup_values['srv_keys']['value']}</textarea></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['pst']['label']}</td>
					<td><input type="checkbox" id="pst" name="post" {$markup_values['pst']['checked']}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key">{$markup_values['mip']['label']} {$settings_tooltips['multi_ip']}</td>
					<td>
						<input type="checkbox" id="multi-ip" name="multi-ip" {$markup_values['mip']['checked']}>
					</td>
				</tr>
				<tr class="table-line">
					<td class="display-key"><label for="emergency-uri">{$markup_values['emergency_uri']['label']}</label> {$settings_tooltips['emergency_uri']}</td>
					<td>
						<input type="text" id="emergency-uri" name="emergency_uri" value="{$markup_values['emergency_uri']['value']}" placeholder="/emergency-access">
					</td>
				</tr>
				<tr>
					<th class="table-title" colspan="2"><br><h2>{$text['reporting']}</h2></th>
				</tr>
				<tr class="table-line">
					<td class="report-email"><label for="report_email">{$markup_values['report_email']['label']}</label> {$settings_tooltips['report_email']}</td>
					<td><input type="text" id="report_email" name="report_email" size="40" value="{$markup_values['report_email']['value']}"></td>
				</tr>
				<tr class="table-line">
					<td><label for="report_interval">{$text['report_interval']}</label> {$settings_tooltips['report_interval']}</td>
					<td>
						<select id="report_interval" name="report_interval">{$report_interval_markup}</select>
					</td>
				</tr>
				<tr class="table-line">
					<td><label for="report_frequency">{$text['frequency']}</label> {$settings_tooltips['report_frequency']}</td>
					<td>
						<select id="report_frequency" name="report_frequency">{$report_frequency_markup}</select>
					</td>
				</tr>
				<tr class="table-line">
					<td><label for="report_php_fatal">{$text['report_php_fatal']}</label></td>
					<td><input type="checkbox" id="report_php_fatal" name="report_php_fatal" {$report_php_fatal_checked}></td>
				</tr>
				<tr class="table-line">
					<td class="display-key"><label for="report_php_error_locations">{$text['report_php_error_locations']}</label> {$settings_tooltips['php_error_locations']}</td>
					<td>
						<input type="checkbox" id="report_php_error_locations" name="report_php_error_locations" {$report_php_error_locations_checked}>
					</td>
				</tr>
			</table>
			<table class="wpsd-table">
				<thead>
					<tr>
						<th class="table-title" colspan="2">{$text['exclude_errors_logging']}</th>
					</tr>
				</thead>
				<tr>
					<td colspan="2">
						{$excluded_errors_markup}
					</td>
				</tr>
				</table>
				<div class="table-line">
					<label class="display-key" for="excluded_logging_strings">{$text['exclude_logging_strings']}</label> {$settings_tooltips['excluded_logging_strings']}
					<textarea id="excluded_logging_strings" name="excluded_logging_strings" rows="{$excluded_logging_strings_rows}" cols="40">{$excluded_logging_strings}</textarea>
				</div>
			</div>
		{$nonce_field}
		<input type="hidden" name="action" value="save_settings">
		<input type="submit" value="{$text['save_settings']}" class="button button-primary wpsd-button mt10">
	</form>
</div>
HTML;

//end of display_errors


function get_excluded_errors_markup( $settings ){

	require_once Consts::DIR.'includes/error-names.php';

	$errors = get_error_type_strings();
	
	unset( $errors[0], $errors[99999]);

	$output = '';

	foreach( $errors as $error_code => $error_name ){

		$excluded_error = in_array( $error_code , $settings['excluded_errors']??[]) ? $error_code : '';

		$checked = checked( $error_code, $excluded_error , false);

		$output .= <<<HTML
<tr class="table-line">
	<td>
		<input type="checkbox" id="error-{$error_code}" name="excluded_errors[]" value="{$error_code}" {$checked} >
	</td>
	<td class="display-key">
		{$error_name}
	</td>
</tr>
HTML;


	}

	return $output;
}

function save_new_settings($settings){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return;

	update_wpsd_option(Consts::OPTION_SETTINGS, $settings);

	WPSD_Debug_Reporting::setup_cron();

}
function has_rights_to_save(){

	return	isset($_POST['wpsd_php_debug_settings_nonce']) &&

			wp_verify_nonce($_POST['wpsd_php_debug_settings_nonce'], 'wpsd-php-debug-settings-save') &&

			current_user_can( 'manage_options' );
}

function get_settings_data(){

	$old_setting = get_plugin_settings();

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return $old_setting;

	if ( !has_rights_to_save() ) { 
		
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'wpsd-debug' ) );
	
	}

	$emergency_uri = $_POST['emergency_uri'] ?? '';

	$emergency_uri = sanitize_emergency_uri(is_string($emergency_uri) ? wp_unslash($emergency_uri) : false);

	if( $emergency_uri === false ){

		wp_die(esc_html__('Emergency URI must be a site-relative path such as /emergency-access, without a query string or a reserved WordPress path.', 'wpsd-debug'));

		return false;

	}

	$settings = [

		'server_keys'				=> array_values(array_filter(array_map('trim', get_textarea_values('server_keys')), 'strlen')),
		
		'keep'						=> (intval($_POST['keep']??0) > 0 && intval($_POST['keep']) < 3650 ) ? intval($_POST['keep']) : 30,

		'post'						=> isset($_POST['post']),

		'multi-ip'					=> isset($_POST['multi-ip']),

	
		'emergency_uri' => $emergency_uri,

		'report_email' => get_validated_emails(),

		'report_frequency' => in_array((int) ($_POST['report_frequency'] ?? 1), [1, 5, 10], true) ? (int) ($_POST['report_frequency'] ?? 1) : 1,

		'report_interval' => in_array((int) ($_POST['report_interval'] ?? 60), [5, 10, 15, 30, 60], true) ? (int) ($_POST['report_interval'] ?? 60) : 60,

		'report_php_fatal' => isset($_POST['report_php_fatal']),

		'report_php_error_locations' => isset($_POST['report_php_error_locations']),
		
		'excluded_errors'			=> get_excluded_errors(),

		'excluded_logging_strings'	=> get_textarea_values('excluded_logging_strings'),

	];
	
	generate_error_reporting_settings( $settings );
	
	generate_mutli_ip_settings( $settings );

	rename_files_when_multi_ip_changes($old_setting,$settings);

	return $settings;

}

function rename_files_when_multi_ip_changes($old_setting, $settings){
	
	if( boolval($old_setting['multi-ip']) === boolval( $settings['multi-ip'] ) ) return;

	$s = get_files_strings();
	
	$ip_string = '-ip'.get_server_last_ip_number();

	if( $settings['multi-ip'] ){

		$log_filename_new = str_replace('debug','debug'.$ip_string , $s->log_filename);

		$db_filename_new = str_replace('error-log','error-log'.$ip_string , get_removed_ip($s->db_filename));

		$db_filename = get_removed_ip($s->db_filename);

	} else {

		$db_filename = $s->db_filename;

		$db_filename_new = get_removed_ip($s->db_filename);
	
		$log_filename_new = get_removed_ip($s->log_filename);
	}
	
	$db_filepath = $s->db_dir.DIRECTORY_SEPARATOR.$db_filename;

	$log_filepath  = $s->log_dir.DIRECTORY_SEPARATOR.$s->log_filename;

	$db_filepath_new = $s->db_dir.DIRECTORY_SEPARATOR.$db_filename_new;

	$error_log_filepath_new = $s->log_dir.DIRECTORY_SEPARATOR.$log_filename_new;

	if( !file_exists($error_log_filepath_new) && file_exists($log_filepath) ){
		
		rename( $log_filepath, $error_log_filepath_new );

		if( get_wpsd_option( Consts::OPTION_INI_STATUS) ){
			ini_set( 'error_log', $error_log_filepath_new );
		}
	}
	
	if( !file_exists($db_filepath_new) && file_exists($db_filepath) ){
		
		rename( $db_filepath, $db_filepath_new );
		
		get_db_filepath($db_filepath_new);
	}
}

function get_removed_ip($string){

	return preg_replace('/-ip(\d+|null)/', '', $string);
}

function get_files_strings(){

	$error_log_filepath = ini_get('error_log');

	$error_log_filename = basename($error_log_filepath);

	$error_log_dir = dirname($error_log_filepath);

	$db_filepath = get_db_filepath();

	$db_filename = basename($db_filepath);

	$db_dir = dirname($db_filepath);

	return (object)[

		'log_filename' => $error_log_filename,

		'log_dir' => $error_log_dir,

		'db_filename' => $db_filename,

		'db_dir' => $db_dir
	];

}

function generate_mutli_ip_settings( $settings ){

	update_wpsd_option( Consts::OPTION_MULTI_IP, $settings['multi-ip'] ? '1' : '0','yes'  );

}

function get_validated_emails(){

	$input = $_POST['report_email'] ?? '';

	if( !is_string($input) || $input === '' ){

		return '';

	}

	$emails = array_map('trim', explode(',', wp_unslash($input)));

	$emails = array_filter($emails, 'is_email');

	return implode(', ', $emails);

}

function get_textarea_values($post_key){

	if( !isset($_POST[$post_key]) || !is_string($_POST[$post_key]) ) return [];
	
	return $_POST[$post_key] === '' ? [] : preg_split('/\r\n|[\r\n]/', $_POST[$post_key]);
}

function generate_error_reporting_settings($settings) {

	$error_reporting = E_ALL;

	foreach ($settings['excluded_errors'] as $error_code) {
		
		if(!is_numeric($error_code)){
			continue;
		}

		$error_reporting &= ~match (intval($error_code)) {
			
			1 => E_ERROR,
			
			2 => E_WARNING,
			
			4 => E_PARSE,
			
			8 => E_NOTICE,
			
			16 => E_CORE_ERROR,
			
			32 => E_CORE_WARNING,
			
			64 => E_COMPILE_ERROR,
			
			128 => E_COMPILE_WARNING,
			
			256 => E_USER_ERROR,
			
			512 => E_USER_WARNING,
			
			1024 => E_USER_NOTICE,
			
			4096 => E_RECOVERABLE_ERROR,
			
			8192 => E_DEPRECATED,
			
			16384 => E_USER_DEPRECATED,
			
			default => 0,
			
		};
		
	}

	update_wpsd_option(Consts::OPTION_REPORTING, $error_reporting, 'yes');

}

function get_excluded_errors($post_key='excluded_errors'){
	
	if( !is_valid_form_errors_input($post_key) ) return [];
	
	require_once Consts::DIR.'includes/error-names.php';
	
	$default_php_errors = get_error_type_strings();

	foreach( $_POST[$post_key] as $form_error_value ){

		$form_error_value_int = intval( $form_error_value );

		if( !(isset( $default_php_errors[$form_error_value_int] ) || $form_error_value_int === 0) ) die('Unable to save');

		$result[] = $form_error_value_int; 
	}

	return $result??[];
}

function is_valid_form_errors_input($post_key='excluded_errors'){

	return is_array($_POST[$post_key]??false) && !empty($_POST[$post_key]);
}

function get_markup_values($settings){
	
	return [
		'keep' => [
			'label' => __( 'Keep records', 'wpsd-debug' ),
			'value' => $settings['keep']??'30',//default 30 days
			'description' => __( 'Days', 'wpsd-debug' )
		],
		'srv_keys' => [
			'label' => __( 'Server Keys:', 'wpsd-debug' ),
			'value' => htmlspecialchars(implode("\n", $settings['server_keys'])),
			'rows' => max(2,count($settings['server_keys']) + 1)
		],
		'pst' => [
			'label' => __( 'Post:', 'wpsd-debug' ),
			'checked' => $settings['post'] ? 'checked' : ''
		],
		'fragments' => [
			'label' => __( 'Async save errors', 'wpsd-debug' ),
			'checked' => ($settings['fragments']??false) ? 'checked' : '',
			'description' => __( 'Recommended for high traffic sites.', 'wpsd-debug' ),
		],
		'mip' => [
			'label' => __( 'Server IP in filenames', 'wpsd-debug' ),
			'checked' => ($settings['multi-ip']??'0') ? 'checked' : '',
			'description' => __( 'Enable when this site runs on multiple server via load balancer, it will add IP to the DB filename preventing overwrite when file sync happens.', 'wpsd-debug' ),
		],
		'emergency_uri' => [

			'label' => esc_html__('Emergency URI', 'wpsd-debug'),

			'value' => esc_attr($settings['emergency_uri'] ?? ''),

			'description' => esc_html__('Enter a URI such as /emergency-access, different from yur custom login URI. This will allow you to access the error logs with all other plugins and theme temporarily deactivated. Leave empty to disable.', 'wpsd-debug'),

		],
		'report_email' => [
			'label' => __( 'Reporting email', 'wpsd-debug' ),
			'value' => esc_attr($settings['report_email'] ?? ''),
			'rows' => 40
		],
	];
}

function get_report_frequency_markup($settings){

	$frequency = (int) ($settings['report_frequency'] ?? 1);

	$markup = '';

	foreach( [1, 5, 10] as $value ){

		$selected = selected($frequency, $value, false);

		$texts = [

			'label' => esc_html(sprintf(_n('%d email per hour', '%d emails per hour', $value, 'wpsd-debug'), $value)),

		];

		$markup .= <<<HTML
		<option value="{$value}" {$selected}>{$texts['label']}</option>
		HTML;

	}

	return $markup;

}

function get_report_interval_markup($settings){

	$minutes = (int) ($settings['report_interval'] ?? 60);

	$minutes = in_array($minutes, [5, 10, 15, 30, 60], true) ? $minutes : 60;

	$markup = '';

	foreach( [5, 10, 15, 30, 60] as $value ){

		$selected = selected($minutes, $value, false);

		$texts = [

			'label' => $value === 60 ? esc_html__('Every hour', 'wpsd-debug') : esc_html(sprintf(__('Every %d minutes', 'wpsd-debug'), $value)),

		];

		$markup .= <<<HTML
		<option value="{$value}" {$selected}>{$texts['label']}</option>
		HTML;

	}

	return $markup;

}

function get_settings_tooltips($markup_values, $text){

	$descriptions = [

		'server_keys' => esc_html__('Saves only the listed $_SERVER keys and values when available. Enter one server key per line. Leave empty to disable saving $_SERVER data.', 'wpsd-debug'),

		'multi_ip' => esc_html($markup_values['mip']['description']),

		'emergency_uri' => $markup_values['emergency_uri']['description'],

		'report_email' => esc_html__('Leave empty to disable reporting. Separate multiple email addresses with commas.', 'wpsd-debug'),

		'report_interval' => $text['report_interval_description'],

		'report_frequency' => $text['frequency_description'],

		'php_error_locations' => $text['php_error_locations_description'],

		'excluded_logging_strings' => esc_html__('Enter one logging string per line.', 'wpsd-debug'),

	];

	$markup = [];

	foreach( $descriptions as $key => $description ){

		$markup[$key] = get_settings_tooltip($key, $description);

	}

	return $markup;

}

function get_settings_tooltip($key, $description){

	$texts = [

		'icon' => esc_html__('i', 'wpsd-debug'),

		'label' => esc_attr__('More information', 'wpsd-debug'),

	];

	$tooltip_id = esc_attr('wpsd-setting-help-'.$key);

	return <<<HTML
	<span class="wpsd-setting-help">
		<button type="button" class="wpsd-setting-help-icon" aria-label="{$texts['label']}" aria-describedby="{$tooltip_id}">{$texts['icon']}</button>
		<span id="{$tooltip_id}" class="wpsd-setting-help-popup" role="tooltip">{$description}</span>
	</span>
	HTML;

}
