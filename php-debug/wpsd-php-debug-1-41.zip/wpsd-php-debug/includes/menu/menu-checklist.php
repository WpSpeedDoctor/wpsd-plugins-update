<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$checklist_data = get_checklist_data();

$table_content = '';

foreach($checklist_data as $data){

	$table_content .= <<<HTML
	<tr id="{$data['name']}">
		<td>{$data['text']}</td>
		<td>{$data['description']}</td>
		<td>{$data['value']}</td>
	</tr>
	HTML;

}

echo <<<HTML
<table class="wpsd-checklist-table">
	{$table_content}
</table>
HTML;

function get_checklist_data(){

	$opcache_status = function_exists('opcache_get_status') ? opcache_get_status(false) : false;

	$sqlite_version = class_exists('SQLite3') ? \SQLite3::version()['versionString'] : false;

	$php_versions = implode(', ', get_checklist_php_minimum_versions());

	$texts = [

		'php_version' => __('PHP version', 'wpsd-debug'),

		'php_requirement' => __('Current: %1$s. Minimum version: %2$s', 'wpsd-debug'),

		'sqlite_version' => __('SQLite3 version', 'wpsd-debug'),

		'sqlite_requirement' => __('Current: %1$s. Required: %2$s or newer.', 'wpsd-debug'),

		'unavailable' => __('Unavailable', 'wpsd-debug'),

	];

	return [
		[
			'name' => 'php_version',
			'text' => $texts['php_version'],
			'description' => esc_html(sprintf($texts['php_requirement'], PHP_VERSION, $php_versions)),
			'value' => get_checklist_icon(is_checklist_php_version_supported(PHP_VERSION)),
		],
		[
			'name' => 'sqlite_version',
			'text' => $texts['sqlite_version'],
			'description' => esc_html(sprintf($texts['sqlite_requirement'], $sqlite_version ?: $texts['unavailable'], '3.54.0')),
			'value' => get_checklist_icon(is_checklist_sqlite_version_supported($sqlite_version)),
		],
		[
			'name'	=> 'custom_filepath_allowed',
			'text'	=> __( 'Custom PHP error filepath allowed', 'wpsd-debug' ),
			'description'	=> 'boolval(OPTION_INI_STATUS) === true',
			'value'	=> get_checklist_icon( boolval(get_wpsd_option( Consts::OPTION_INI_STATUS )) ),
		],
		[
			'name'	=> 'opcache_enabled',
			'text'	=> __( 'Opcache enabled', 'wpsd-debug' ),
			'description'	=> "function_exists('opcache_get_status')",
			'value'	=> get_checklist_icon( function_exists('opcache_get_status') ),
		],
		[
			'name'	=> 'opcache_memory_used',
			'text'	=> __( 'Available OPcache memory', 'wpsd-debug' ),
			'description'	=> get_opcache_memory_description($opcache_status),
			'value'	=> get_checklist_icon( is_opcache_memory_available($opcache_status) ),
		],
		[
			'name'	=> 'interned_memory_free',
			'text'	=> __( 'Available interned strings memory', 'wpsd-debug' ),
			'description'	=> get_interned_memory_description($opcache_status),
			'value'	=> get_checklist_icon( has_free_interned_memory($opcache_status) ),
		],
		[
			'name'	=> 'jit_enabled',
			'text'	=> __( 'JIT enabled', 'wpsd-debug' ),
			'description'	=> "ini_get('opcache.jit') == '1' && buffer_size > 0",
			'value'	=> get_checklist_jit_icon(),
		],
		[
			'name'	=> 'pcre_jit_enabled',
			'text'	=> __( 'PCRE JIT enabled', 'wpsd-debug' ),
			'description'	=> "ini_get('pcre.jit') == '1'",
			'value'	=> get_checklist_icon( ini_get('pcre.jit') == '1' ),
		],
		[
			'name'	=> 'apcu_available',
			'text'	=> __( 'APCu available', 'wpsd-debug' ),
			'description'	=> "extension_loaded('apcu') && apcu_enabled()",
			'value'	=> get_checklist_icon( extension_loaded('apcu') && function_exists('apcu_enabled') && apcu_enabled() ),
		],
	];

}

function get_opcache_memory_description($status){

	if(!is_array($status)){

		return __('memory_usage unavailable','wpsd-debug');

	}

	$memory_usage = $status['memory_usage'] ?? [];

	$free_memory = $memory_usage['free_memory'] ?? 0;

	return size_format($free_memory).' > '.size_format(100 * KB_IN_BYTES);

}

function get_interned_memory_description($status){

	if(!is_array($status)){

		return __('interned_strings_usage unavailable','wpsd-debug');

	}

	$free_memory = $status['interned_strings_usage']['free_memory'] ?? 0;

	return size_format($free_memory).' > '.size_format(10 * KB_IN_BYTES);

}

function is_opcache_memory_available($status){

	if(!is_array($status)){

		return false;

	}

	return ($status['memory_usage']['free_memory'] ?? 0) > 100 * KB_IN_BYTES;

}

function has_free_interned_memory($status){

	if(!is_array($status)){

		return false;

	}

	return ($status['interned_strings_usage']['free_memory'] ?? 0) > 10 * KB_IN_BYTES;

}

function get_checklist_jit_icon(){

	switch(true){

		case ini_get('opcache.jit') != '1':

		case !is_string( ini_get('opcache.jit_buffer_size') ):

		case ($buffer_size = rtrim(strtolower( ini_get('opcache.jit_buffer_size')),'gmkb')) === null:

		case !is_numeric($buffer_size):

		case intval($buffer_size) === 0:

			return get_checklist_icon(false);

		default:

			return get_checklist_icon(true);

	}

}

function get_checklist_icon($bool){

	return $bool ? '<span class="wpsd-debug-icon icon-true">✔</span>' : '<span class="wpsd-debug-icon icon-false">✘</span>';

}

function get_checklist_php_minimum_versions(){

	return [

		'8.5' => '8.5.12',

		'8.4' => '8.4.27',

		'8.3' => '8.3.36',

		'8.2' => '8.2.35',

	];

}

function is_checklist_php_version_supported($version){

	if( !is_string($version) ){

		return false;

	}

	$parts = explode('.', $version);

	if( count($parts) < 3 || !ctype_digit($parts[0]) || !ctype_digit($parts[1]) ){

		return false;

	}

	$branch = $parts[0].'.'.$parts[1];

	$minimum_versions = get_checklist_php_minimum_versions();

	if( !isset($minimum_versions[$branch]) ){

		return false;

	}

	return version_compare($version, $minimum_versions[$branch], '>=');

}

function is_checklist_sqlite_version_supported($version){

	return is_string($version) && version_compare($version, '3.54.0', '>=');

}
