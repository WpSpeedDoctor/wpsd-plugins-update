<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$title = __('Basic documentation', 'wpsd-debug');

$texts = [
	__('When deleting logs, only error messages are deleted directly, followed by metadata that has no error message associated.', 'wpsd-debug'),
	__('With the function `deb( $value, $note )`, you can display any variable on the front-end as a floating window. Enable "Display Debug Values" in the Toggles tab to display the data.', 'wpsd-debug'),
	__('Function `deb()` will display location in file and function name.', 'wpsd-debug'),
	__('The function `debl($value, $note)` writes data into the SQLite error log. Use this instead `error_log()` because this cannot be captured to store in the database.', 'wpsd-debug'),
	__('The function `the_wpsd_used_php()` displays included PHP files and it\'s OPcache memory usage.', 'wpsd-debug'),
	__('The function `get_wpsd_plugin_included_files($slug)` gets files of plugin slug and it\'s OPcache memory usage.', 'wpsd-debug'),
	__('On `localhost` and when `WP_ENVIRONMENT_TYPE === "staging"`, the settings to activate displaying `deb( $value, $note )` is automatically set to true.', 'wpsd-debug'),
	__('Error reporting is set to `E_ALL`, you can exclude errors from reporting and logging in the menu `settings`.', 'wpsd-debug'),
	__('Use the `wpsd-debug-errors` filter to modify the event array after logging-string exclusions. Each event contains its error code at index 0 and its stored message at index 1. Return the modified event array; structured messages remain JSON strings.', 'wpsd-debug'),
	__('Use the `wpsd-debug-meta` filter to modify the request metadata array before JSON encoding. Access fields with the `WPSD\debug\v2\Stored_Event::META_*` constants and return the modified array, preserving its numeric field positions.', 'wpsd-debug'),
	__('The database filename is unique to the IP of the server. That\'s because if your system runs on various servers with load balancer, error logs would be overwritten. As this version, you can see only error from the currently accessing server.', 'wpsd-debug'),
	__('Display errors toggle sets cookie enabling to show PHP errors only to you. If you logout, cookie will remain in your browser and PHP errors will be displayed, but only to you.', 'wpsd-debug'),
	__('Function wpsd_dd() will set display values and display error cookies.', 'wpsd-debug'),
	__('Function `stw()` - "Stopwatch" start count and will display how long time passed from first called `stw()`', 'wpsd-debug'),
	__('Function `stw(true)` will show time from start or last start time rest and resets the start time', 'wpsd-debug'),
	__('Function `vd( $value, "identifier", $float=false)` - "var_dump" will display a variable in readable format.', 'wpsd-debug'),
	__('If you run server on load balancer or want to separate errors from production and staging check `Server IP in filenames`.', 'wpsd-debug'),
	__('PHP Errors log is as default WP wp-content/debug.log, with new day debug log is moved to archive, where sqlite DB is stored.', 'wpsd-debug'),
	__('PHP Errors for multisite will have `-site1` or `-site2` suffix in debug.log so it can be distinguished where error happened.', 'wpsd-debug'),
	__('Fragments are logs that are awaiting to be inserted into the SQLite DB. They\'ve been created when DB is busy writing on another thread.', 'wpsd-debug'),
	__('Fragments are inserted automatically on cron or when DB is read in admin menu.', 'wpsd-debug'),
	__('Function tm($start_time,$end_time) where inputs $start_time & $end_time=hrtime(true) returns time elapsed in human readable format.', 'wpsd-debug'),
	__('Function tm($start_time,$end_time,true) returns integer time elapsed in microseconds.', 'wpsd-debug'),
	__('The Fetch tab runs callbacks registered on the `wpsd-debug-fetch` action in a separate request and displays their output and execution time.', 'wpsd-debug'),
	__('In Fetch, choose when to run the callbacks: now, plugins_loaded, init, or WP Ajax. The value field passes text to the callback as its argument.', 'wpsd-debug'),
	__('The Fetch callable selector lets you run one registered callback or choose All to run every callback registered on `wpsd-debug-fetch`.', 'wpsd-debug'),
	__('The Toggles tab controls PHP error display, debug values, the debug admin bar menu, included PHP files, plugin filtering on debug pages, and dark mode.', 'wpsd-debug'),
	__('Toggle changes apply through cookies in your browser. Click Save to store your preferences for your WordPress user and restore them after login.', 'wpsd-debug'),
	__('Enable "Display menu in WP Admin bar" in Toggles to see PHP execution time and concise error previews. Enable "Display PHP files in WP Admin bar" to include PHP file details.', 'wpsd-debug'),
	__('The "Disable plugins on debug pages" toggle keeps only plugins whose paths contain `wpsd` active on the plugin debug page.', 'wpsd-debug'),
	__('The Admin bar menu tab lets you select admin pages and submenu pages to use as shortcuts under the site name in the WordPress admin bar.', 'wpsd-debug'),
	__('Select the shortcuts you need and click Save Admin Menus. Your selection is saved for your WordPress user. Enable "Display menu in WP Admin bar" in Toggles to display the shortcuts.', 'wpsd-debug'),
	__('Reporting is disabled when the reporting email is empty. Check for report content controls how often reporting runs: every 5, 10, 15, or 30 minutes, or every hour (default). Maximum reporting emails per hour separately limits delivery to 1, 5, or 10 emails in any 60-minute period. Empty reports are not emailed.', 'wpsd-debug'),
	__('Report PHP Fatal errors includes the fatal error count, error breakdown, latest fatal error, and failed emails in the check period. Elevated locations of PHP errors compares distinct filename:line locations from JSON-recorded PHP errors against the matching period yesterday and reports increases above 20%. Repeated errors at one location count once; the email lists current locations and marks those absent yesterday. The period length follows Check for report content. Both options are enabled by default.', 'wpsd-debug'),
	__('Plugins can use add_filter with wpsd-debug-reporting and two arguments: the report array and period array. Append HTML to report[content] and a short subject hint to report[subject][]. Return the report array. The period contains start and end Unix timestamps and settings. Subjects start with [Report] followed by the collected hints.', 'wpsd-debug'),
	__('Thanks to HTMX and SQLite for amazing libraries.', 'wpsd-debug'),
	// __('', 'wpsd-debug'),
	
];

$li_markup = '<li>'.implode( "</li>\n<li>", $texts );

$body_class= Consts::SLUG.'-body';

echo <<<HTML
<div class="{$body_class} clear">
	<h3>{$title}</h3>
	<ul class="docs-points">
	{$li_markup}
	</ul>
</div>
HTML;
