<?php

namespace WPSD\debug\v2;

defined('ABSPATH') || exit;

function get_database_info_filepath($filename){

	if( !is_string($filename) || $filename === '' || str_contains($filename, "\0") || basename($filename) !== $filename || !str_ends_with($filename, '.sqlite') ){

		return false;

	}

	$directory = realpath(Consts::DB_DIR);

	$filepath = realpath(Consts::DB_DIR.$filename);

	if( $directory === false || $filepath === false || dirname($filepath) !== $directory || !is_file($filepath) ){

		return false;

	}

	return $filepath;

}

function get_databases_info(){

	if( !is_dir(Consts::DB_DIR) ){

		return false;

	}

	$files = scandir(Consts::DB_DIR);

	if( $files === false ){

		return false;

	}

	$texts = [

		'filename' => esc_html__('Database filename', 'wpsd-debug'),

		'size' => esc_html__('Size', 'wpsd-debug'),

		'start' => esc_html__('Start date', 'wpsd-debug'),

		'end' => esc_html__('End date', 'wpsd-debug'),

		'vacuum' => esc_html__('Vacuum', 'wpsd-debug'),

		'keep_today' => esc_html__('Keep only today', 'wpsd-debug'),

		'zipit' => esc_html__('Zipit', 'wpsd-debug'),

	];

	$rows = '';

	foreach($files as $filename){

		if( !get_database_info_filepath($filename) ){

			continue;

		}

		$rows .= get_database_info_row($filename);

	}

	return <<<HTML
	<table class="wpsd-db-info-table">
		<thead>
			<tr>
				<th>{$texts['filename']}</th>
				<th>{$texts['size']}</th>
				<th>{$texts['start']}</th>
				<th>{$texts['end']}</th>
				<th>{$texts['vacuum']}</th>
				<th>{$texts['keep_today']}</th>
				<th>{$texts['zipit']}</th>
			</tr>
		</thead>
		<tbody>{$rows}</tbody>
	</table>
	HTML;

}

function get_database_info_row($filename, $status = '', $vacuumed = false, $zip_status = ''){

	$filepath = get_database_info_filepath($filename);

	if( $filepath === false ){

		return false;

	}

	clearstatcache(true, $filepath);

	$size = esc_html(size_format(filesize($filepath)));

	$db_dates = fetch_start_end_dates($filename);

	$start = esc_html($db_dates['start_date'] ?? '-');

	$end = esc_html($db_dates['end_date'] ?? '-');

	require_once Consts::DIR.'includes/database-zip.php';

	$filename_label = esc_html($filename);

	$zip_info = get_database_zip_info($filename);

	if( $zip_info !== false && is_file($zip_info['path']) ){

		$zip_url = esc_url($zip_info['url']);

		$filename_label = <<<HTML
		<a href="{$zip_url}" download>{$filename_label}</a>
		HTML;

	}

	$row_id = 'wpsd-database-'.md5($filename);

	$ajax_url = esc_url(admin_url('admin-ajax.php'));

	$request = [

		'action' => 'wpsd-debug-db-maintenance',

		'nonce' => wp_create_nonce('wpsd-debug-db-maintenance'),

		'db-filename' => $filename,

		'vacuumed' => $vacuumed ? '1' : '',

	];

	$vacuum_values = esc_attr(wp_json_encode($request + ['operation' => 'vacuum']));

	$keep_values = esc_attr(wp_json_encode($request + ['operation' => 'keep-today']));

	$zip_values = esc_attr(wp_json_encode($request + ['operation' => 'zip']));

	$texts = [

		'vacuum' => esc_html__('Vacuum', 'wpsd-debug'),

		'vacuumed' => esc_html__('DB vacuumed', 'wpsd-debug'),

		'keep_today' => esc_html__('Keep only today', 'wpsd-debug'),

		'zipit' => esc_html__('Zipit', 'wpsd-debug'),

	];

	$vacuum_html = $texts['vacuumed'];

	if( !$vacuumed ){

		$vacuum_html = <<<HTML
		<button type="button" class="button wpsd-button" hx-post="{$ajax_url}" hx-vals="{$vacuum_values}" hx-target="#{$row_id}" hx-swap="outerHTML" hx-sync="closest tr:drop" hx-disabled-elt="this">{$texts['vacuum']}</button>
		HTML;

	}

	$status = esc_html($status);

	$zip_status = esc_html($zip_status);

	return <<<HTML
	<tr id="{$row_id}">
		<td>{$filename_label}</td>
		<td>{$size}</td>
		<td>{$start}</td>
		<td>{$end}</td>
		<td>{$vacuum_html}</td>
		<td><button type="button" class="button wpsd-button" hx-post="{$ajax_url}" hx-vals="{$keep_values}" hx-target="#{$row_id}" hx-swap="outerHTML" hx-sync="closest tr:drop" hx-disabled-elt="this">{$texts['keep_today']}</button><span class="wpsd-db-status" role="status">{$status}</span></td>
		<td><button type="button" class="button wpsd-button" hx-post="{$ajax_url}" hx-vals="{$zip_values}" hx-target="#{$row_id}" hx-swap="outerHTML" hx-sync="closest tr:drop" hx-disabled-elt="this">{$texts['zipit']}</button><span class="wpsd-db-status" role="status">{$zip_status}</span></td>
	</tr>
	HTML;

}

function fetch_start_end_dates($filename){

	$filepath = get_database_info_filepath($filename);

	if( $filepath === false || !class_exists('SQLite3') ){

		return false;

	}

	$sqlite = null;

	try{

		$sqlite = new \SQLite3($filepath, SQLITE3_OPEN_READONLY);

		$sqlite->enableExceptions(true);

		$result = $sqlite->query('SELECT MIN(daytime) AS start_date, MAX(daytime) AS end_date FROM error_log');

		return $result->fetchArray(SQLITE3_ASSOC);

	}catch(\Throwable $exception){

		return false;

	}finally{

		if( $sqlite !== null ){

			$sqlite->close();

		}

	}

}
