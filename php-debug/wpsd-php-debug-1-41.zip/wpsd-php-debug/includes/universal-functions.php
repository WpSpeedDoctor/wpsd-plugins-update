<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function get_plugin_settings(){

	$settings = get_wpsd_option( Consts::OPTION_SETTINGS );

	if( !is_array($settings) ){

		return false;

	}

	if( !array_key_exists('report_php_error_locations', $settings) && array_key_exists('report_elevated_records', $settings) ){

		$settings['report_php_error_locations'] = $settings['report_elevated_records'];

	}

	unset($settings['report_elevated_records']);

	return $settings;

}

function get_remote_ip(){

	foreach(['HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR'] as $key){

		$ip = $_SERVER[$key] ?? null;

		if( is_string($ip) && filter_var($ip, FILTER_VALIDATE_IP) !== false ){

			return $ip;

		}

	}

	return false;

}

/**
 * The file path to the SQLite database or an empty string if SQLite3 is not available or the file does not exist.
 * @return string 
*/

function get_db_filepath($new=false){

	static $db_filepath;
	
	switch(true){
		case !$db_filepath:
			$db_filepath = Consts::DB_DIR.get_this_site_db_filename();
			break;
		case $new:
			$db_filepath = $new;
			break;
	}

	return $db_filepath;
}

function get_this_site_db_filename(){

	static $filename;

	$filename || $filename = '.ht.error-log'.get_multisite_and_ip_string().'.sqlite';
	
	return $filename;

}

function get_multisite_and_ip_string(){
	
	static $ip_multi_string;
	
	if( !$ip_multi_string ){

		$ip_multi_string = get_wpsd_option( Consts::OPTION_MULTI_IP ) ? '-ip'.get_server_last_ip_number() : '';
		
		$ip_multi_string .= is_multisite() ? '-site'.get_current_blog_id() : '';
	}

	return $ip_multi_string;
}


function update_wpsd_option( $name, $value, $autoload = false ){

	return is_multisite() ? update_site_option( $name, $value ) : update_option( $name, $value, $autoload);
}

function get_wpsd_option($name){

	return is_multisite() ? get_site_option( $name ) : get_option( $name );
}

function get_wpsd_transient($name){

	return is_multisite() ? get_site_transient( $name ) : get_transient( $name );
}

function set_wpsd_transient( $name, $value, $timeout = 30 * MINUTE_IN_SECONDS ){ //default 30 minutes

	return is_multisite() ? set_site_transient( $name, $value, $timeout ) : set_transient( $name, $value, $timeout);
}


function get_db_prefix(){

	static $prefix;

	if( !$prefix ){
		
		global $wpdb;
		
		$prefix = is_multisite() ? $wpdb->base_prefix : $wpdb->prefix;
	}

	return $prefix;
}

/**
 * 0 is last ip number when not selected multi IP option
 */
function get_ip_string(){

	static $ip_string;

	switch(true){

		case $ip_string !== null:
			break;

		case !get_wpsd_option( Consts::OPTION_MULTI_IP ):
			$ip_string = '.0';
			break;
		default:
			$ip_string = '.'.get_server_last_ip_number();
			break; 
	}

	return $ip_string;

}

/**
 * Returns last digit of IPv4 or IPv6 or `null`
 * 
 * @return string last part of IP address
 */

function get_server_last_ip_number(){

    static $ip;

	if( $ip === null ){

		$server_ip = $_SERVER['SERVER_ADDR'] ?? '.null';
		
		$pos = strrpos( $server_ip, '.' ) ?: strrpos( $server_ip, ':' );
		
		$ip = substr( $server_ip, $pos + 1 );
	}

	return $ip;
}

function log( $message, $location='', $forced=false){
	
	switch(true){
		case $forced:
		case !defined('WP_DEBUG') || !WP_DEBUG:
			break;
		default:
			return;
	}

	error_log("WPSD Debug at {$location}: $message");
}