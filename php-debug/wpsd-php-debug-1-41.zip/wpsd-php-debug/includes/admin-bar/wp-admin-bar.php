<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;


global $current_user;

switch(true){
	case empty($current_user->ID):
	case !in_array('administrator', $current_user->roles, true):
	case $_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR] !== Consts::get_nonce():
		break;
	default:
		add_action('admin_bar_menu', __NAMESPACE__ . '\\admin_bar_main', 31);
		break;
}
		

function admin_bar_main($wp_admin_bar){

	add_custom_admin_bar_menus($wp_admin_bar);

	add_menu_debug_values();

}

function add_menu_debug_values(){

	add_admin_bar_menu([
		'id'    => 'php-time',
		'title' => <<<'HTML'
				<div id="wpsd-debug-menu" class="ab-item" aria-expanded="false">
					<span id="php-time-value">-----------</span>
				</div>
				HTML,
		'meta'  => [
			'class' => 'menupop',
		],
	]);

	//nonce is checked before requiring the file.
	if(!empty($_COOKIE[Consts::COOKIE_DISPLAY_PHP_FILES])){
		
		require_once Consts::DIR.'includes/admin-bar/included-files.php';
		
		add_action('admin_bar_menu', __NAMESPACE__ . '\\add_menu_included_files', 36);

	}

	// mu-plugin been loaded
	if( is_callable('tm') ){
		
		defined('WPSD_PHP_TIME_SHUTDOWN') || define('WPSD_PHP_TIME_SHUTDOWN', true);
	}
}

function add_php_time_script(){
	
	$end_time_measure = microtime(true);

	$wpsd_debug_errors = is_callable( __NAMESPACE__.'\\errors_storage' ) ? errors_storage('',true) : [];

	$start_time_measure = defined('WP_START_TIMESTAMP') ? WP_START_TIMESTAMP : floatval($_SERVER['REQUEST_TIME_FLOAT']);

	$time_measure = tm( $start_time_measure, $end_time_measure );

	$submenu_html = get_admin_bar_submenu($wpsd_debug_errors);

	$style = empty($wpsd_debug_errors) ? '' : 'background:#7a4040;padding:0 5px;';

	$json_submenu = json_encode($submenu_html);
	$json_time = json_encode($time_measure);
	$json_style = json_encode($style);

	echo <<<HTML
<script id="wpsd-debug-admin-bar">
document.addEventListener('DOMContentLoaded', function(){
	const value = {$json_time};
	const html = {$json_submenu};
	const style = {$json_style};

	const span = document.getElementById('php-time-value');

	if(span){
		span.textContent = value;
	}

	const parentLi = document.getElementById('wp-admin-bar-php-time');

	if(parentLi){
		parentLi.insertAdjacentHTML('beforeend', html);

		const debug = document.getElementById('wpsd-debug-menu');

		if(debug && style){
			debug.setAttribute('style', style);
		}
	}
});
</script>
HTML;

}

function get_admin_bar_submenu($wpsd_debug_errors){

	$items = '';

	$submenu = get_submenu_data( $wpsd_debug_errors );
	
	$template = (object)[

		'linked' => <<<'HTML'
			<a class="ab-item" role="menuitem" href="%s">%s</a>
			HTML,

		'not_linked' => <<<'HTML'
			<div class="ab-item" role="menuitem" style="padding: 0 10px;display: inline-block;">%s</div>
			HTML,

		'li' => <<<'HTML'
			<li role="group" id="wpsd-debug-submenu-%s">%s</li>
			HTML
	];
	
	foreach( $submenu as $i => $item ){
		
		$label = str_replace("\n", '<br>', esc_html(strip_tags($item['label'])));

		$content = isset($item['url']) ? sprintf($template->linked, $item['url'], $label) : sprintf($template->not_linked, $label);

		$items .= sprintf($template->li, $i, $content);

	}
	
	return <<<HTML
<div class="ab-sub-wrapper">
	<ul role="menu" id="wp-admin-bar-php-time-default" class="ab-submenu" aria-label="PHP Time">
		{$items}
	</ul>
</div>
HTML;

}

function get_submenu_data( $wpsd_debug_errors ){
	
	$root = 'admin.php?page='.Consts::PAGE_ADMIN;

	require_once Consts::DIR.'includes/menu/wp-admin-menu.php';

	$tabs_arr = get_tabs_arr();

	$submenu = [
		[
			'label' => $tabs_arr['home']['title'],
			'url'   => admin_url( $root ),
		],
		[
			'label' => $tabs_arr['error-log']['title'],
			'url'   => admin_url( $root.'&tab=error-log' ),
		],
		[
			'label' => $tabs_arr['toggles']['title'],
			'url'   => admin_url( $root.'&tab=toggles' ),
		],
		[
			'label' => $tabs_arr['settings']['title'],
			'url'   => admin_url( $root.'&tab=settings' ),
		],
		[
			'label' => $tabs_arr['info']['title'],
			'url'   => admin_url( $root.'&tab=info' ),
		],
	];

	if( !empty($wpsd_debug_errors) ){

		$errors_in_submenu = '';
		
		require_once Consts::DIR.'includes/error-names.php';

		$errors_names = get_error_type_strings();

		foreach( $wpsd_debug_errors as $key => $wpsd_error ){
			
			$summary = get_admin_bar_error_summary($wpsd_error, $errors_names);

			if( $summary !== false ){

				$errors_in_submenu .= $summary."\n";

			}

			if( $key === 19 ){

				$errors_in_submenu .= '...';

				break;
			}
		}

		if($errors_in_submenu){

			$submenu[] = [
				'label' => '-----'
			];

			$submenu[] = [
				'label' => $errors_in_submenu
			];
		}

	}

	return $submenu;
}

function get_admin_bar_error_summary($event, $error_names){

	if( !is_array($event) || !is_string($event[1] ?? null) ){

		return false;

	}

	require_once Consts::DIR.'includes/class-stored-event.php';

	$code = (int) ($event[0] ?? 0);

	$texts = ['unknown' => __('Unknown error', 'wpsd-debug')];

	$type = $error_names[$code] ?? $texts['unknown'];

	$message = $event[1];

	$file = '';

	$line = null;

	$data = $code === 99999 ? null : json_decode($message, true);

	if( is_array($data) && array_is_list($data) && count($data) === Stored_Event::MESSAGE_STACK + 1 ){

		$message = $data[Stored_Event::MESSAGE_TEXT];

		$file = is_string($data[Stored_Event::MESSAGE_FILE]) ? $data[Stored_Event::MESSAGE_FILE] : '';

		$line = $data[Stored_Event::MESSAGE_LINE];

		if( is_array($message) ){

			switch($code){

				case 32768:

					$message = $message[Stored_Event::DATABASE_ERROR] ?? '';

					break;

				case 65536:

				case 65538:

					$message = $message[Stored_Event::HTTP_MESSAGE_TEXT] ?? '';

					break;

				case 65537:

					$message = $message[Stored_Event::EMAIL_ERROR] ?? '';

					break;

				default:

					$message = '';

			}

		}

	}

	if( !is_scalar($message) && $message !== null ){

		return false;

	}

	$message_lines = explode("\n", str_replace("\r", '', (string) $message));

	if( $data === null && $code !== 99999 ){

		$location = $message_lines[2] ?? '';

		$separator = strrpos($location, ':');

		if( $separator !== false && is_numeric(substr($location, $separator + 1)) ){

			$file = substr($location, 0, $separator);

			$line = substr($location, $separator + 1);

		}

	}

	$message = $message_lines[0];

	$file = str_replace(str_replace('\\', '/', ABSPATH), '/', str_replace('\\', '/', $file));

	$summary = [$type, $message];

	if( $file !== '' ){

		$summary[] = $file;

	}

	if( is_numeric($line) ){

		$summary[] = (string) $line;

	}

	return implode(' | ', $summary);

}

function add_admin_bar_menu($args){

	global $wp_admin_bar;

	$menu_id    = $args['id']??'wpsd-main-menu';

	$menu_title = $args['title']??'Menu';

	$wp_admin_bar->add_node([
		'id'    => $menu_id,
		'title' => $menu_title,
		'meta'  => [
			'class' => 'menupop',
		],
	]);

	$submenu = $args['submenu']??[];

	foreach( $submenu as $item ){

		$submenu_id    = $item['id']??'';

		$submenu_title = $item['title']??'';

		if( !$submenu_id || !$submenu_title ) continue;

		$wp_admin_bar->add_node([
			'id'     => $submenu_id,
			'parent' => $menu_id,
			'title'  => $submenu_title,
		]);
	}
}




function add_custom_admin_bar_menus($wp_admin_bar){

	$items = get_user_meta(get_current_user_id(), Consts::USERMETA_ADMIN_BAR_MENUS, true) ?: [];

	foreach($items as $index => $item){

		$wp_admin_bar->add_node([
			'id' => 'wpsd-admin-menu-'.$index,
			'parent' => 'site-name',
			'title' => $item['name'],
			'href' => admin_url($item['path']),
		]);

	}

}
