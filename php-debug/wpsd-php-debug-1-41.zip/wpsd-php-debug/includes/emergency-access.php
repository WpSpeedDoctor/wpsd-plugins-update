<?php

namespace WPSD\debug\v2;

defined('ABSPATH') || exit;

function sanitize_emergency_uri($uri){

	if( !is_string($uri) ){

		return false;

	}

	$uri = trim($uri);

	if( $uri === '' ){

		return '';

	}

	$uri = '/'.trim($uri, '/');

	$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_/.';

	if( $uri === '/' || strlen($uri) > 200 || strspn($uri, $characters) !== strlen($uri) || str_contains($uri, '//') ){

		return false;

	}

	$segments = explode('/', substr($uri, 1));

	if( in_array('.', $segments, true) || in_array('..', $segments, true) || in_array($segments[0], ['wp-admin', 'wp-login.php', 'wp-cron.php', 'wp-json', 'xmlrpc.php'], true) ){

		return false;

	}

	return $uri;

}

function is_emergency_access_request($uri){

	$uri = sanitize_emergency_uri($uri);

	if( !$uri || !is_string($_SERVER['REQUEST_URI'] ?? null) ){

		return false;

	}

	$path = wp_parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

	$emergency_path = wp_parse_url(home_url($uri), PHP_URL_PATH);

	return is_string($path) && is_string($emergency_path) && rtrim($path, '/') === rtrim($emergency_path, '/');

}


function authenticate_emergency_admin(){

	$nonce = $_POST['wpsd_emergency_nonce'] ?? null;

	$username = $_POST['log'] ?? null;

	$password = $_POST['pwd'] ?? null;

	if( !is_string($nonce) || !wp_verify_nonce($nonce, 'wpsd-emergency-login') || !is_string($username) || $username === '' || !is_string($password) || $password === '' ){

		return false;

	}

	$remote_addr = get_remote_ip();

	$remote_addr = is_string($remote_addr) ? $remote_addr : '';

	$attempt_key = 'wpsd-emergency-'.hash_hmac('sha256', $remote_addr, wp_salt('auth'));

	$attempts = (int) get_transient($attempt_key);

	if( $attempts >= 10 ){

		return false;

	}

	$user = wp_authenticate($username, $password);

	if( is_wp_error($user) || !$user instanceof \WP_User || !user_can($user, 'manage_options') || (!in_array('administrator', $user->roles, true) && !(is_multisite() && is_super_admin($user->ID))) ){

		set_transient($attempt_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
		
		sleep(2);

		return false;

	}

	delete_transient($attempt_key);

	return $user;

}

function run_emergency_login($uri){


	sleep(1);

	if( is_multisite() ){

		ms_cookie_constants();

	}

	wp_cookie_constants();

	wp_ssl_constants();

	require_once ABSPATH.WPINC.'/pluggable.php';

	$action = home_url(sanitize_emergency_uri($uri));

	if( force_ssl_admin() && !is_ssl() ){

		wp_safe_redirect(set_url_scheme($action, 'https'));

		exit;

	}

	nocache_headers();

	header('X-Robots-Tag: noindex, nofollow');

	header('X-Frame-Options: SAMEORIGIN');

	$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

	if( !in_array($method, ['GET', 'POST'], true) ){

		status_header(405);

		header('Allow: GET, POST');

		sleep(5);

		exit;

	}

	$texts = [

		'title' => esc_html__('Emergency access', 'wpsd-debug'),

		'description' => esc_html__('Sign in with an administrator account to open the debug logs with other plugins disabled.', 'wpsd-debug'),

		'username' => esc_html__('Username or email address', 'wpsd-debug'),

		'password' => esc_html__('Password', 'wpsd-debug'),

		'submit' => esc_html__('Log in', 'wpsd-debug'),

		'failed' => esc_html__('Sign-in failed. Check your administrator credentials and try again later.', 'wpsd-debug'),

	];

	$error_html = '';

	if( $method === 'POST' ){

		$user = authenticate_emergency_admin();

		if( $user !== false ){

			wp_set_current_user($user->ID);

			wp_set_auth_cookie($user->ID, false, is_ssl());

			do_action('wp_login', $user->user_login, $user);

			setcookie(Consts::COOKIE_DISABLE_PLUGINS, Consts::get_nonce(), ['expires' => 0, 'path' => '/', 'secure' => is_ssl(), 'httponly' => false, 'samesite' => 'Lax']);

			$_COOKIE[Consts::COOKIE_DISABLE_PLUGINS] = Consts::get_nonce();

			wp_safe_redirect(admin_url('admin.php?page='.Consts::PAGE_ADMIN));

			exit;

		}

		sleep(5);

		status_header(403);

		$error_html = <<<HTML
		<p role="alert">{$texts['failed']}</p>
		HTML;
	
	}

	$action = esc_url($action);

	$nonce_html = wp_nonce_field('wpsd-emergency-login', 'wpsd_emergency_nonce', false, false);

	$language = esc_attr(str_replace('_', '-', get_locale()));

	$charset = esc_attr(get_option('blog_charset', 'UTF-8'));

	header('Content-Type: text/html; charset='.get_option('blog_charset', 'UTF-8'));

	echo <<<HTML
	<!doctype html>
	<html lang="{$language}">
	<head>
		<meta charset="{$charset}">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>{$texts['title']}</title>
		<style>
			:root{color-scheme:light dark}
			body{font:16px/1.5 sans-serif;background:#f0f0f1;margin:0;padding:2rem 1rem}
			main{max-width:26rem;margin:5vh auto;background:#fff;padding:1.5rem;border-radius:4px}
			h1{margin-top:0}
			label{display:block;margin-top:1rem}
			input{box-sizing:border-box;width:100%;padding:.6rem;font:inherit}
			button{margin-top:1rem;padding:.6rem 1rem;font:inherit;cursor:pointer}
			[role=alert]{color:#b32d2e}
			@media(prefers-color-scheme:dark){
				body{background:#101314;color:#e4e7eb}
				main{background:#1d2327}
				input,button{background:#2c3338;color:#e4e7eb;border:1px solid #68737d}
				input:focus-visible,button:focus-visible{outline:2px solid #72aee6;outline-offset:2px}
				[role=alert]{color:#ff8b8b}
			}
		</style>
	</head>
	<body>
		<main>
			<h1>{$texts['title']}</h1>
			<p>{$texts['description']}</p>
			{$error_html}
			<form method="post" action="{$action}">
				{$nonce_html}
				<label for="wpsd-emergency-user">{$texts['username']}</label>
				<input id="wpsd-emergency-user" type="text" name="log" autocomplete="username" required autofocus>
				<label for="wpsd-emergency-password">{$texts['password']}</label>
				<input id="wpsd-emergency-password" type="password" name="pwd" autocomplete="current-password" required>
				<button type="submit">{$texts['submit']}</button>
			</form>
		</main>
	</body>
	</html>
	HTML;

	exit;

}
