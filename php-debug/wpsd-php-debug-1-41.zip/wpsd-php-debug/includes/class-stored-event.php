<?php

namespace WPSD\debug\v2;

class Stored_Event{

	const MESSAGE_TEXT = 0;

	const MESSAGE_FILE = 1;

	const MESSAGE_LINE = 2;

	const MESSAGE_STACK = 3;

	const STACK_FRAMES = 0;

	const STACK_HTTP_REQUEST = 1;

	const FRAME_FILE = 0;

	const FRAME_LINE = 1;

	const FRAME_FUNCTION = 2;

	const FRAME_CLASS = 3;

	const FRAME_TYPE = 4;

	const FRAME_ARGS = 5;

	const VALUE_TYPE = 0;

	const VALUE_DATA = 1;

	const TYPE_OBJECT = 0;

	const TYPE_RESOURCE = 1;

	const TYPE_FLOAT = 2;

	const TYPE_TRUNCATED = 3;

	const HTTP_MESSAGE_METHOD = 0;

	const HTTP_MESSAGE_URL = 1;

	const HTTP_MESSAGE_CODE = 2;

	const HTTP_MESSAGE_TEXT = 3;

	const EMAIL_FROM = 0;

	const EMAIL_TO = 1;

	const EMAIL_SUBJECT = 2;

	const EMAIL_ERROR = 3;

	const DATABASE_ERROR = 0;

	const DATABASE_QUERY = 1;

	const META_USERNAME = 0;

	const META_SERVER = 1;

	const META_POST = 2;

	const META_COOKIES = 3;

	const META_TIMESTAMP = 4;

	const META_REQUEST_TYPE = 5;

	const META_IP = 6;

	const META_URI = 7;

	const HTTP_RESPONSE = 0;

	const HTTP_REQUEST = 1;

	const HTTP_RESPONSE_FIELDS = [

		'status_code',

		'status_message',

		'headers',

		'body',

		'cookies',

		'filename',

		'transport_class',

		'error_code',

		'error_message',

		'error_data',

		'body_preview',

	];

	const HTTP_REQUEST_FIELDS = [

		'url',

		'method',

		'timeout',

		'redirection',

		'http_version',

		'user_agent',

		'blocking',

		'headers',

		'body',

		'ssl_verify',

		'compress',

		'decompress',

		'stream',

		'filename',

		'limit_response_size',

	];

}
