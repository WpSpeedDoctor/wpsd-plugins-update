<?php

namespace WPSD\debug\v2;

defined('ABSPATH') || exit;

require_once Consts::DIR.'includes/database-info.php';

function get_database_zip_info($filename){

	if( get_database_info_filepath($filename) === false ){

		return false;

	}

	$uploads = wp_upload_dir(null, false);

	if( !empty($uploads['error']) || empty($uploads['basedir']) || empty($uploads['baseurl']) ){

		return false;

	}

	$entry = str_starts_with($filename, '.ht.') ? substr($filename, 4) : $filename;

	$archive = 'wpsd-debug-'.sanitize_file_name(pathinfo($entry, PATHINFO_FILENAME)).'.zip';

	return [

		'directory' => $uploads['basedir'].'/wpsd-debug',

		'path' => $uploads['basedir'].'/wpsd-debug/'.$archive,

		'url' => $uploads['baseurl'].'/wpsd-debug/'.rawurlencode($archive),

		'entry' => $entry,

	];

}

function create_database_zip($filename){

	if( !class_exists('ZipArchive') || !class_exists('SQLite3') ){

		return false;

	}

	$info = get_database_zip_info($filename);

	if( $info === false || !wp_mkdir_p($info['directory']) ){

		return false;

	}

	$source = $snapshot = $zip = null;

	$snapshot_path = $zip_path = false;

	try{

		$snapshot_path = tempnam(sys_get_temp_dir(), 'wpsd-debug-db-');

		$zip_path = tempnam($info['directory'], '.wpsd-debug-');

		if( $snapshot_path === false || $zip_path === false ){

			return false;

		}

		$source = new \SQLite3(get_database_info_filepath($filename), SQLITE3_OPEN_READONLY);

		$source->enableExceptions(true);

		$source->busyTimeout(5000);

		$snapshot = new \SQLite3($snapshot_path);

		$snapshot->enableExceptions(true);

		if( !$source->backup($snapshot) ){

			return false;

		}

		$snapshot->close();

		$snapshot = null;

		$source->close();

		$source = null;

		$zip = new \ZipArchive();

		if( $zip->open($zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true ){

			$zip = null;

			return false;

		}

		if( !$zip->addFile($snapshot_path, $info['entry']) ){

			return false;

		}

		$closed = $zip->close();

		$zip = null;

		if( !$closed || !rename($zip_path, $info['path']) ){

			return false;

		}

		return true;

	}catch(\Throwable $exception){

		return false;

	}finally{

		if( $zip !== null ){

			$zip->close();

		}

		if( $snapshot !== null ){

			$snapshot->close();

		}

		if( $source !== null ){

			$source->close();

		}

		foreach([$snapshot_path, $zip_path] as $temporary_path){

			if( $temporary_path !== false && is_file($temporary_path) ){

				unlink($temporary_path);

			}

		}

	}

}

function delete_database_zip_files(){

	$uploads = wp_upload_dir(null, false);

	if( !empty($uploads['error']) || empty($uploads['basedir']) ){

		return false;

	}

	$directory = $uploads['basedir'].'/wpsd-debug';

	if( !is_dir($directory) ){

		return true;

	}

	$files = scandir($directory);

	if( $files === false ){

		return false;

	}

	$deleted = true;

	foreach($files as $filename){

		$filepath = $directory.'/'.$filename;

		if( !str_starts_with($filename, 'wpsd-debug-') || !str_ends_with($filename, '.zip') || !is_file($filepath) || is_link($filepath) ){

			continue;

		}

		if( !unlink($filepath) ){

			$deleted = false;

		}

	}

	return $deleted;

}
