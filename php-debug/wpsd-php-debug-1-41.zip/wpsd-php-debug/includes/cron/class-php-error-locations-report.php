<?php

namespace WPSD\debug\v2;

abstract class WPSD_Debug_PHP_Error_Locations_Report{

	private const INCREASE_THRESHOLD_PERCENT = 20;

	private const SQLITE_BUSY_TIMEOUT_MS = 1000;

	private const DATETIME_FORMAT = 'Y-m-d H:i:s';

	private const PREVIOUS_DAY = '-1 day';

	private const PERIOD_CURRENT = 'current';

	private const PERIOD_YESTERDAY = 'yesterday';

	private const LOCATION_SEPARATOR = ':';

	private const MIN_LINE_NUMBER = 1;

	public static function contribute($report, $period){

		if( !($period['settings']['report_php_error_locations'] ?? true) || !class_exists('SQLite3') ){

			return $report;

		}

		$db_filepath = get_db_filepath();

		if( $db_filepath === '' || !file_exists($db_filepath) ){

			return $report;

		}

		$start = $period['end'] - WPSD_Debug_Reporting::get_interval();

		try{

			$locations = self::get_period_locations($db_filepath, $start, $period['end']);

		} catch( \Exception $exception ){

			return $report;

		}

		if( !$locations || count($locations[self::PERIOD_CURRENT]) <= count($locations[self::PERIOD_YESTERDAY]) * (1 + self::INCREASE_THRESHOLD_PERCENT / 100) ){

			return $report;

		}

		$texts = [

			'title' => esc_html__('Elevated locations of PHP errors', 'wpsd-debug'),

			'period' => esc_html(sprintf(__('Between %s and %s, PHP errors occurred at %d distinct filename:line locations, compared with %d during the same period yesterday (more than %d%% higher).', 'wpsd-debug'), date(self::DATETIME_FORMAT, $start), date(self::DATETIME_FORMAT, $period['end']), count($locations[self::PERIOD_CURRENT]), count($locations[self::PERIOD_YESTERDAY]), self::INCREASE_THRESHOLD_PERCENT)),

		];

		$locations_markup = self::get_locations_markup($locations);

		$report['content'] .= <<<HTML
		<h2>{$texts['title']}</h2>
		<p>{$texts['period']}</p>
		<ul>{$locations_markup}</ul>
		HTML;

		$report['subject'][] = __('Elevated locations of PHP errors', 'wpsd-debug');

		return $report;

	}

	private static function get_period_locations($db_filepath, $start, $end){

		$db = new \SQLite3($db_filepath, SQLITE3_OPEN_READONLY);

		$db->enableExceptions(true);

		$db->busyTimeout(self::SQLITE_BUSY_TIMEOUT_MS);

		try{

			$periods = [

				self::PERIOD_CURRENT => [$start, $end],

				self::PERIOD_YESTERDAY => [strtotime(self::PREVIOUS_DAY, $start), strtotime(self::PREVIOUS_DAY, $end)],

			];

			$locations = [];

			foreach( $periods as $key => [$period_start, $period_end] ){

				$locations[$key] = self::get_locations($db, $period_start, $period_end);

			}

			return $locations;

		} finally{

			$db->close();

		}

	}

	private static function get_locations($db, $start, $end){

		require_once Consts::DIR.'includes/class-stored-event.php';

		$codes = implode(',', Consts::PHP_ERROR_CODES);

		$query = 'SELECT error FROM error_log WHERE daytime >= :start AND daytime < :end AND code IN ('.$codes.')';

		$stmt = $db->prepare($query);

		$stmt->bindValue(':start', date(self::DATETIME_FORMAT, $start), SQLITE3_TEXT);

		$stmt->bindValue(':end', date(self::DATETIME_FORMAT, $end), SQLITE3_TEXT);

		$result = $stmt->execute();

		$locations = [];

		while( $row = $result->fetchArray(SQLITE3_ASSOC) ){

			$location = self::get_error_location($row['error']);

			if( $location === false ){

				continue;

			}

			$locations[$location] = true;

		}

		$result->finalize();

		ksort($locations, SORT_STRING);

		return $locations;

	}

	private static function get_error_location($error){

		$message = json_decode($error);

		if( !is_array($message) || count($message) !== Stored_Event::MESSAGE_STACK + 1 ){

			return false;

		}

		$file = $message[Stored_Event::MESSAGE_FILE] ?? null;

		$line = $message[Stored_Event::MESSAGE_LINE] ?? null;

		if( !is_string($file) || trim($file) === '' || !is_int($line) || $line < self::MIN_LINE_NUMBER ){

			return false;

		}

		return $file.self::LOCATION_SEPARATOR.$line;

	}

	private static function get_locations_markup($locations){

		$texts = [

			'new' => esc_html__('Not recorded during the same period yesterday', 'wpsd-debug'),

			'existing' => esc_html__('Also recorded during the same period yesterday', 'wpsd-debug'),

		];

		$markup = '';

		foreach( $locations[self::PERIOD_CURRENT] as $location => $recorded ){

			$status = isset($locations[self::PERIOD_YESTERDAY][$location]) ? $texts['existing'] : $texts['new'];

			$location = esc_html($location);

			$markup .= <<<HTML
			<li><code>{$location}</code> — {$status}</li>
			HTML;

		}

		return $markup;

	}

}
