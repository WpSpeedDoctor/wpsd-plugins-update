<?php

namespace WPSD\debug\v2;

abstract class WPSD_Debug_PHP_Error_Report{

	public static function contribute($report, $period){

		if( !($period['settings']['report_php_fatal'] ?? true) ){

			return $report;

		}

		try{

			$errors = self::get_errors($period['start'], $period['end']);

		} catch( \Exception $exception ){

			return $report;

		}

		$count = (int) ($errors['counts'][E_ERROR] ?? 0);

		if( !$count ){

			return $report;

		}

		$report['content'] .= self::get_message($errors, $period['start'], $period['end']);

		$report['subject'][] = sprintf(_n('%d PHP Fatal error', '%d PHP Fatal errors', $count, 'wpsd-debug'), $count);

		return $report;

	}

	private static function get_errors($start, $end){

		if( !class_exists('SQLite3') ){

			return false;

		}

		$db_filepath = get_db_filepath();

		if( $db_filepath === '' || !file_exists($db_filepath) ){

			return false;

		}

		$db = new \SQLite3($db_filepath, SQLITE3_OPEN_READONLY);

		$db->enableExceptions(true);

		$db->busyTimeout(1000);

		try{

			$query = 'SELECT code, COUNT(*) AS count FROM error_log WHERE daytime >= :start AND daytime < :end AND code NOT IN (99999,32768) GROUP BY code';

			$result = self::query_period($db, $query, $start, $end);

			$counts = [];

			while( $row = $result->fetchArray(SQLITE3_ASSOC) ){

				$counts[(int) $row['code']] = (int) $row['count'];

			}

			$result->finalize();

			if( empty($counts[E_ERROR]) ){

				return false;

			}

			require_once Consts::DIR.'includes/event-display/class-event-display.php';

			return [

				'counts' => $counts,

				'last_fatal_error' => self::get_last_fatal_error($db, $start, $end),

				'failed_emails' => self::get_failed_emails($db, $start, $end),

			];

		} finally{

			$db->close();

		}

	}

	private static function query_period($db, $query, $start, $end){

		$stmt = $db->prepare($query);

		$stmt->bindValue(':start', date('Y-m-d H:i:s', $start), SQLITE3_TEXT);

		$stmt->bindValue(':end', date('Y-m-d H:i:s', $end), SQLITE3_TEXT);

		return $stmt->execute();

	}

	private static function get_last_fatal_error($db, $start, $end){

		$query = 'SELECT error_log.error, error_meta.meta FROM error_log LEFT JOIN error_meta ON error_meta.meta_id = error_log.meta_id WHERE error_log.code = 1 AND daytime >= :start AND daytime < :end ORDER BY event_id DESC LIMIT 1';

		$result = self::query_period($db, $query, $start, $end);

		$row = $result->fetchArray(SQLITE3_ASSOC);

		$result->finalize();

		if( !$row ){

			return '';

		}

		return Event_Display::render_email($row['error'], E_ERROR).'<hr>'.Event_Display::render_meta($row['meta'] ?? '');

	}

	private static function get_failed_emails($db, $start, $end){

		$query = 'SELECT error FROM error_log WHERE daytime >= :start AND daytime < :end AND code = 65537 ORDER BY event_id DESC';

		$result = self::query_period($db, $query, $start, $end);

		$markup = '';

		while( $row = $result->fetchArray(SQLITE3_ASSOC) ){

			$markup .= Event_Display::render_email($row['error'], 65537).'<hr>';

		}

		$result->finalize();

		return $markup;

	}

	private static function get_message($errors, $start, $end){
		
		$texts = [

			'breakdown' 	=> __('Here is the breakdown of all recorded errors during this period:', 'wpsd-debug' ),

			'period'	=> sprintf(
							_n(
								'Between %s and %s occurred %d PHP Fatal error.',
								'Between %s and %s occurred %d PHP Fatal errors.',
								$errors['counts'][1],
								'wpsd-debug'
							),
							date('Y-m-d H:i:s', $start),
							date('Y-m-d H:i:s', $end),
							$errors['counts'][1]
						),

			'error-type'	=> __("Error type", 'wpsd-debug' ),

			'count'			=> __("Count", 'wpsd-debug' ),

			'last_fatal_error' => __('Last fatal error:', 'wpsd-debug'),

			'failed-emails'	=> __("Failed emails:", 'wpsd-debug' ),

		];
		
		require_once Consts::DIR.'includes/error-names.php';

		$types = get_error_type_strings();

		$errors_breakdown_markup = '';

		foreach( $errors['counts'] as $error_code => $count){

			$error_name = esc_html($types[$error_code] ?? (string) $error_code);

			$errors_breakdown_markup .= <<<HTML
			<tr>
				<td style="padding: 10px; border: 1px solid #ddd;">{$error_name}</td>
				<td style="padding: 10px; border: 1px solid #ddd;text-align: center;">{$count}</td>
			</tr>
			HTML;

		}

		return <<<HTML
			<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$texts['period']}</p>
			<p style="border-collapse: collapse; font-family: Arial, sans-serif;">{$texts['breakdown']}</p>
			<table style="border-collapse: collapse; font-family: Arial, sans-serif;">
				<thead>
					<tr>
						<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$texts['error-type']}</th>
						<th style="background-color: #9b9b9b; color: #ddd; padding: 10px; border: 1px solid #ddd;">{$texts['count']}</th>
					</tr>
				</thead>
				<tbody>
					{$errors_breakdown_markup}
				</tbody>
			</table>
			<br>
		<div style="white-space: pre;line-height: 2; font-family: Arial, sans-serif;">
		{$texts['last_fatal_error']}<br>
		{$errors['last_fatal_error']}
		</div>
			<br>
		<div style="white-space: pre;line-height: 2; font-family: Arial, sans-serif;">
		{$texts['failed-emails']}<br>
		{$errors['failed_emails']}
		</div>
			<br>
		HTML;
		
	}

}
