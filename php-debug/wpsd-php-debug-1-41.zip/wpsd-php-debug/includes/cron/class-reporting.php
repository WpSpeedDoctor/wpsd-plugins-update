<?php

namespace WPSD\debug\v2;

abstract class WPSD_Debug_Reporting{

	const HOOK = 'wpsd-debug-reporting';

	const STATE_OPTION = 'wpsd-debug-report-state';

	const LOCK_OPTION = 'wpsd-debug-report-lock';

	public static function get_frequency(){

		$frequency = (int) (get_plugin_settings()['report_frequency'] ?? 1);

		return in_array($frequency, [1, 5, 10], true) ? $frequency : 1;

	}

	public static function get_interval(){

		$minutes = (int) (get_plugin_settings()['report_interval'] ?? 60);

		return (in_array($minutes, [5, 10, 15, 30, 60], true) ? $minutes : 60) * MINUTE_IN_SECONDS;

	}

	public static function schedules($schedules){

		foreach( [5, 10, 15, 30] as $minutes ){

			$schedules['wpsd_debug_reporting_every_'.$minutes.'_minutes'] = [

				'interval' => $minutes * MINUTE_IN_SECONDS,

				'display' => sprintf(__('Debug reporting: every %d minutes', 'wpsd-debug'), $minutes),

			];

		}

		return $schedules;

	}

	public static function setup_cron(){

		if( empty(get_plugin_settings()['report_email']) ){

			wp_clear_scheduled_hook(Consts::CRON_REPORTING);

			return false;

		}

		$minutes = (int) (self::get_interval() / MINUTE_IN_SECONDS);

		$schedule = $minutes === 60 ? 'hourly' : 'wpsd_debug_reporting_every_'.$minutes.'_minutes';

		if( wp_get_schedule(Consts::CRON_REPORTING) !== $schedule ){

			wp_clear_scheduled_hook(Consts::CRON_REPORTING);

			wp_schedule_event(time(), $schedule, Consts::CRON_REPORTING);

		}

		return true;

	}

	public static function run(){

		$settings = get_plugin_settings();

		if( empty($settings['report_email']) || !self::acquire_lock() ){

			return false;

		}

		try{

			record_bulk_fragments_cron();

			run_integrity_db_check();

			return self::report($settings);

		} finally{

			is_multisite() ? delete_site_option(self::LOCK_OPTION) : delete_option(self::LOCK_OPTION);

		}

	}

	private static function acquire_lock(){

		$lock = (int) get_wpsd_option(self::LOCK_OPTION);

		if( $lock && $lock < time() - 5 * MINUTE_IN_SECONDS ){

			is_multisite() ? delete_site_option(self::LOCK_OPTION) : delete_option(self::LOCK_OPTION);

		}

		return is_multisite() ? add_site_option(self::LOCK_OPTION, time()) : add_option(self::LOCK_OPTION, time(), '', false);

	}

	private static function report($settings){

		$end = time();

		$frequency = self::get_frequency();

		$state = get_wpsd_option(self::STATE_OPTION);

		$state = is_array($state) ? $state : [];

		$sent = array_values(array_filter($state['sent'] ?? [], static function($timestamp) use ($end){

			return $timestamp > $end - HOUR_IN_SECONDS;

		}));

		$start = max((int) ($state['last_check'] ?? 0), $end - self::get_interval());

		if( $start >= $end ){

			return false;

		}

		if( count($sent) >= $frequency ){

			update_wpsd_option(self::STATE_OPTION, ['last_check' => $end, 'sent' => $sent]);

			return false;

		}

		$period = ['start' => $start, 'end' => $end, 'settings' => $settings];

		$report = apply_filters(self::HOOK, ['content' => '', 'subject' => []], $period);

		if( !is_array($report) || !is_string($report['content'] ?? null) || trim($report['content']) === '' ){

			update_wpsd_option(self::STATE_OPTION, ['last_check' => $end, 'sent' => $sent]);

			return false;

		}

		$subject_hints = array_filter((array) ($report['subject'] ?? []), 'is_string');

		$subject_hint = sanitize_text_field(implode(', ', $subject_hints));

		$subject = trim('[Report] '.$subject_hint);

		$domain = wp_parse_url(get_home_url(), PHP_URL_HOST);

		$headers = ['Content-Type: text/html; charset=UTF-8'];

		if( $domain ){

			$headers[] = "From: noreply@{$domain}";

			$headers[] = "Reply-To: noreply@{$domain}";

		}

		$message = self::get_message($report['content']);

		if( !wp_mail($settings['report_email'], $subject, $message, $headers) ){

			return false;

		}

		$sent[] = $end;

		update_wpsd_option(self::STATE_OPTION, ['last_check' => $end, 'sent' => $sent]);

		return true;

	}

	private static function get_message($content){

		$texts = [

			'footnote' => esc_html(sprintf(__('Sent from website %s, server IP: %s by plugin %s', 'wpsd-debug'), get_home_url(), $_SERVER['SERVER_ADDR'] ?? '', __('Advanced PHP Debug by WP Speed Doctor.', 'wpsd-debug'))),

		];

		$language = esc_attr(get_bloginfo('language'));

		return <<<HTML
		<html lang="{$language}">
		<body style="margin:0;padding:0;font-family:Arial,sans-serif;">
		{$content}
		<p>{$texts['footnote']}</p>
		</body>
		</html>
		HTML;

	}

}
