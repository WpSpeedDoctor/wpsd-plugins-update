<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$table_content = get_into_table_content();

echo <<<HTML
<table class="wpsd-info-table">
	$table_content
</table>
HTML;

return;

function get_into_table_content(){
		
	$info_data = get_info_tab_data();

	$table_content = '';

	foreach ( $info_data as $data ){

		$columns = get_columns_markup( $data );
		
		$table_content .= <<<HTML
		<tr id="{$data['name']}">{$columns}</tr>
		HTML;
	}

	return $table_content;
}

function get_columns_markup( $data ){

	if( !isset($data['value']) || $data['value'] === '' ){

		return <<<HTML
		<td colspan="2">{$data['text']}</td>
		HTML;
	}

	return <<<HTML
	<td >{$data['text']}</td>
	<td>{$data['value']}</td>
	HTML;

}

function get_info_tab_data(){

	$db_filepath = get_db_filepath();

	$data = [

		[
			'name'	=> 'php_errors',
			'text'	=> __( 'PHP Error log', 'wpsd-debug' ),
		],
		[
			'name'	=> 'custom_filepath_allowed',
			'text'	=> __( 'Custom PHP error filepath allowed', 'wpsd-debug' ),
			'value'	=> get_true_false_icon( get_wpsd_option( Consts::OPTION_INI_STATUS ) ),
		],
		[
			'name'	=> 'php_filepath',
			'text'	=> __( 'PHP error file path', 'wpsd-debug' ),
			'value'	=> esc_html( ini_get('error_log') ),
		],		
		[
			'name'	=> 'php_version',
			'text'	=> __( 'PHP version', 'wpsd-debug' ),
			'value'	=> PHP_VERSION,
		],
		[
			'name'	=> 'opcache_enabled',
			'text'	=> __( 'Opcache enabled', 'wpsd-debug' ),
			'value'	=> get_true_false_icon( function_exists('opcache_get_status') ),
		],
		[
			'name'	=> 'jit_enabled',
			'text'	=> __( 'JIT enabled', 'wpsd-debug' ),
			'value'	=> get_jit_display_value(),
		],
		[
			'name'	=> 'pcre_jit_enabled',
			'text'	=> __( 'PCRE JIT enabled', 'wpsd-debug' ),
			'value'	=> get_true_false_icon(	ini_get('pcre.jit') ),
		],
		[
			'name'	=> 'space',
			'text'	=> '<span style="visibility:hidden"><br><span>',
		],
		[
			'name'	=> 'php_errors',
			'text'	=> __( 'SQLite database:', 'wpsd-debug' ),
		],
		[
				'name'	=> 'db_path_text',
				'text'	=> __( 'Path to Sqlite database:', 'wpsd-debug' ),
				'value'	=> $db_filepath ?: __( 'Database is not created', 'wpsd-debug' ),
		],
		[
			'name'	=> 'db_size_text',
			'text'	=> __( 'Size of SQLite database:', 'wpsd-debug' ),
			'value'	=> $db_filepath === '' ? '-' : size_format( filesize( get_db_filepath() ) ),
		],
	
		[
			'name'	=> 'sqlite_version',
			'text'	=> __( 'SQLite3 extention version', 'wpsd-debug' ),
			'value'	=> class_exists('SQLite3') ? \SQLite3::version()['versionString'] : __( 'Not active', 'wpsd-debug' ),
		],
		[
			'name'	=> 'dbs-info',
			'text'	=> __( 'Databases info', 'wpsd-debug' ),
			'value'	=> get_databases_info(),
		],
		[
			'name'	=> 'space',
			'text'	=> '<span style="visibility:hidden"><br><span>',
		],
		[
			'name'	=> 'cookie_info',
			'text'	=> __( 'Manually set cookies to display error and debug mssages', 'wpsd-debug' ),
		],

		[
			'name'	=> 'display_error_cookie_key',
			'text'	=> Consts::COOKIE_DISPLAY_ERRORS,
			'value'	=> Consts::get_nonce(),
		],
	
		[
			'name'	=> 'display_value_cookie_key',
			'text'	=> Consts::COOKIE_DISPLAY_VALUES,
			'value'	=> Consts::get_nonce(),
		],
	];

	add_server_load( $data );

	add_global_server( $data );

	add_opcache_stats( $data );

	return $data;
	
}

function get_databases_info(){

	$files = scandir( Consts::DB_DIR );

	$html = <<<HTML
	<style>
		.wpsd-db-info-table{
			border-collapse: collapse;
		}

		.wpsd-db-info-table th,
		.wpsd-db-info-table td{
			padding-right: 20px;
			border: none;
		}

		.wpsd-db-info-table th:first-child,
		.wpsd-db-info-table td:first-child{
			text-align: left;
		}
	</style>

	<table class="wpsd-db-info-table">
		<thead>
			<tr>
				<th>Database filename</th>
				<th>Size</th>
				<th>Start date</th>
				<th>End date</th>
			</tr>
		</thead>
		<tbody>
	HTML;

	foreach( $files as $filename ){

		if( !str_ends_with($filename,'.sqlite') ) continue;

		$size = size_format( filesize( Consts::DB_DIR.$filename ) );

		$db_dates = fetch_start_end_dates( $filename );

		$start = $db_dates['start_date'] ?? '-';

		$end = $db_dates['end_date'] ?? '-';

		$html .= <<<HTML
		<tr>
			<td>{$filename}</td>
			<td>{$size}</td>
			<td>{$start}</td>
			<td>{$end}</td>
		</tr>
		HTML;
	}

	$html .= <<<HTML
		</tbody>
	</table>
	HTML;

	return $html;
}


function fetch_start_end_dates( $filename ){

	$db_filepath = Consts::DB_DIR.$filename;

	if( !file_exists( $db_filepath ) ) return [];

	try {

		$sqlite = new \SQLite3( $db_filepath );

		$query = "SELECT MIN(daytime) AS start_date, MAX(daytime) AS end_date FROM error_log";

		$result = $sqlite->query( $query );

		if( !$result ) return [];

		$db_dates = $result->fetchArray(SQLITE3_ASSOC);

		$sqlite->close();

		unset( $sqlite );

		return $db_dates;

	} catch ( \Exception $e ) {

		error_log( $e );

		return [
			'start_date' => '-',
			'end_date' => '-'
		];

	}
}

function get_jit_display_value(){
	
	switch(true){
		case ini_get('opcache.jit') !== '1':
		case !is_string( ini_get('opcache.jit_buffer_size') ):
		
		//fallthough
		case ($buffer_size = rtrim(strtolower( ini_get('opcache.jit_buffer_size')),'gmkb')) === null:
		case !is_numeric($buffer_size):
		case intval($buffer_size) === 0:
			return get_true_false_icon(false);

		default:
			return get_true_false_icon(true);
	}
}

function get_true_false_icon($bool){

	return $bool ? '<span class="wpsd-debug-icon icon-true">✔</span>' : '<span class="wpsd-debug-icon icon-false">✘</span>';
}

function add_global_server( &$data ){

	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];

	$data[] = [
		'name'	=> 'server',
		'text'	=> __( '$_SERVER', 'wpsd-debug' ),
	];

	foreach( $_SERVER as $key => $value ){

		//apparently the value can be an array, observed in WP playground
		$value_markup = is_array($value) ? print_r($value, true) : $value;

		$data[] = [
			'name'	=> htmlentities($key),
			'text'	=> htmlentities($key),
			'value'	=> htmlentities($value_markup),
		];

	}

}

function add_opcache_stats( &$data ){

	switch(true){
		case !function_exists('opcache_get_status'):
		case !( $status = opcache_get_status(false) );
			return;
	}

	$used_memory        = $status['memory_usage']['used_memory'];

	$free_memory        = $status['memory_usage']['free_memory'];

	$wasted_memory      = $status['memory_usage']['wasted_memory'];

	$memory_total       = $used_memory + $free_memory + $wasted_memory;

	$used_percent       = $memory_total > 0 ? (int)( $used_memory / $memory_total * 100 ) : 0;

	$cached_files       = $status['opcache_statistics']['num_cached_scripts'];

	$hits               = $status['opcache_statistics']['hits'];

	$misses             = $status['opcache_statistics']['misses'];

	$buffer_size        = $status['interned_strings_usage']['buffer_size'];

	$interned_used      = $status['interned_strings_usage']['used_memory'];

	$interned_free      = $status['interned_strings_usage']['free_memory'];
	
	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];
	
	$data[] = [
		'name'	=> 'opcache',
		'text'	=> __( 'OPCache statistics', 'wpsd-debug' ),
	];

	$data[] = [
		'name'  => 'used_memory',
		'text'  => 'Memory Used',
		'value' => $used_memory,
	];
	
	$data[] = [
		'name'  => 'free_memory',
		'text'  => 'Memory Free',
		'value' => $free_memory,
	];
	
	$data[] = [
		'name'  => 'wasted_memory',
		'text'  => 'Memory Wasted',
		'value' => $wasted_memory,
	];
	
	$data[] = [
		'name'  => 'used_percent',
		'text'  => 'Memory Used (%)',
		'value' => $used_percent,
	];
	
	$data[] = [
		'name'  => 'num_cached_scripts',
		'text'  => 'Cached Files',
		'value' => $cached_files,
	];
	
	$data[] = [
		'name'  => 'hits',
		'text'  => 'Cache Hits',
		'value' => $hits,
	];
	
	$data[] = [
		'name'  => 'misses',
		'text'  => 'Cache Misses',
		'value' => $misses,
	];
	
	$data[] = [
		'name'  => 'buffer_size',
		'text'  => 'Interned Buffer Size',
		'value' => $buffer_size,
	];
	
	$data[] = [
		'name'  => 'interned_used',
		'text'  => 'Interned Memory Used',
		'value' => $interned_used,
	];
	
	$data[] = [
		'name'  => 'interned_free',
		'text'  => 'Interned Memory Free',
		'value' => $interned_free,
	];

}

function add_server_load( &$data ){

	$load = function_exists('sys_getloadavg') ? sys_getloadavg() : false;

	if( !is_array($load) || count($load) < 3 ) return;

	$data[] = [
		'name'	=> 'space',
		'text'	=> '<span style="visibility:hidden"><br><span>',
	];

	$data[] = [
		'name'	=> 'server',
		'text'	=> __( 'Server load', 'wpsd-debug' ),
	];

	$value = round($load[0], 2 ) .' / '. round($load[1], 2 ) .' / '. round( $load[2], 2 );

	$data[] = [
		'name'  => 'server_load',
		'text'  => 'Server Load (1/5/15 min)',
		'value' => $value,
	];

}
