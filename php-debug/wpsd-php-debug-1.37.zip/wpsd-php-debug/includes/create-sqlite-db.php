<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/**
 * @return bool 
 * - true when file exists or is successfully created
 * - false if could not be created.
 */

function create_sqlite_db($db_filepath=false){

	if( !class_exists('SQLite3') ) {

		log('Could not create SQLite database, SQLite3 extension is not installed', basename(__FILE__).' at '.__LINE__, true);

		return false;
	}

	if( !$db_filepath ){

		$db_filepath = get_db_filepath();
	}
	
	if( file_exists($db_filepath) ) return true;

	try{

		$db = new \SQLite3($db_filepath);

		$db->enableExceptions( true );
		
	} catch ( \Exception $e ){

		log('Unable to create SQLite database, probably issue writing to the filesystem',basename(__FILE__).' at '.__LINE__,true);
	
		return false;
	}

	$query = <<<SQL
		CREATE TABLE error_log (
		event_id INTEGER PRIMARY KEY AUTOINCREMENT,
		meta_id INTEGER NOT NULL,
		daytime TEXT NOT NULL,
		code INTEGER NOT NULL,
		error TEXT NOT NULL
		);
		CREATE INDEX idx_error_log_daytime ON error_log(daytime);
		CREATE TABLE error_meta (
		meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
		meta TEXT NOT NULL
		);
		SQL;

	if (!$db->exec($query)) {

		$db->close();

		log('Unable to create SQLite table `error_log`',basename(__FILE__).' at '.__LINE__,true);
	
		return false;
	}

	$db->close();

	return true;

}

function add_db_index(){

	$db_filepath = get_db_filepath();

	if( !file_exists($db_filepath) ) return false;

	try{

		$db = new \SQLite3($db_filepath);

		$db->enableExceptions( true );

		$query = "PRAGMA index_list('error_log')";

		$result = $db->query( $query );

		$index_exists = false;

		while( $row = $result->fetchArray(SQLITE3_ASSOC) ){

			if( $row['name'] === 'idx_error_log_daytime' ){

				$index_exists = true;

				break;
			}
		}

		if( !$index_exists ){

			$db->exec( "CREATE INDEX idx_error_log_daytime ON error_log(daytime)" );
		}

		$db->close();

		return true;

	} catch( \Exception $e ){

		log( 'Error adding SQLite index: '.$e->getMessage(), basename(__FILE__).' at '.__LINE__, true );

		return false;
	}
}

