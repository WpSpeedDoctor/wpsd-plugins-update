<?php
//legacy file placeholder to avoid fatal error when migrating to the new version.