<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/**
 * Legacy function for Time Measure
 * @param float $start_time_measure
 * @param float $end_time_measure
 * @param bool $microseconds_output
 * @return string|int
 */

function tm_microtime( $start_time_measure, $end_time_measure, $microseconds_output = false  ) {

	$precision = get_precision_wpsd($start_time_measure, $end_time_measure);

	if( is_callable('bcsub') ){
	
		$start_time_measure_formatted = get_bcsub_formatted_number_wpsd($start_time_measure, $precision);
		
		$end_time_measure_formatted = get_bcsub_formatted_number_wpsd($end_time_measure, $precision);

		$difference = (float) bcsub( $end_time_measure_formatted, $start_time_measure_formatted, $precision );
	
	} else {

		$difference = (float) number_format( $end_time_measure- $start_time_measure , $precision, '.', '');
	}

	switch (true) {

		case $microseconds_output:
			return intval( $difference * 1e6 );

		case $difference >= 1: // More than or equal to 1 second
			$elapsed_time = (string) round($difference, 3 );
			$time_unit = 's';
			break;

		case $difference * 1e3 >= 1: // More than or equal to 1 millisecond
			$elapsed_time =  (string) round($difference * 1e3, 2 );
			$time_unit = 'ms';
			break;

		case $difference * 1e6 >= 1: // More than or equal to 1 microsecond
			$elapsed_time = (string) intval( $difference * 1e6 );
			$time_unit = 'μs';
			break;

		default: // Nanoseconds
			$elapsed_time =  (string) intval( $difference * 1e9 );
			$time_unit = 'ns';
			break;
	}

	return "$elapsed_time $time_unit";
}

function get_bcsub_formatted_number_wpsd($number, $precision){

	return number_format($number, $precision , '.', '');
}





/**
 * get safe decimal number so no value has a scientific notation eg. 7.104873657E-5 as it's not valid for bcsub()
 * 
 * @return int
 */

function get_precision_wpsd($start_time_measure, $end_time_measure){

	$numbers = [
		$start_time_measure,
		$end_time_measure
	];

	$precision = intval( ini_get('precision') )+1;

	foreach( $numbers as $number_raw ){
		
		$number  = get_bcsub_formatted_number_wpsd( $number_raw, $precision );

		if( !str_contains( $number, 'e' ) ) continue;

		while( str_contains( $number, 'e' ) && --$precision > 1 ){

			$number  = get_bcsub_formatted_number_wpsd( $number_raw, $precision );
		}
	
	}

	return $precision;

}


/**
 * WPSD Display Debug sets errors and values displaying cookies. 
 */
function wpsd_dd(){

	if( !isset($_COOKIE[Consts::COOKIE_DISPLAY_VALUES] )) {

		setcookie(
			Consts::COOKIE_DISPLAY_VALUES,
			Consts::get_nonce(),
			0
		);
	}

	if( !isset($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] )) {

		setcookie(
			Consts::COOKIE_DISPLAY_ERRORS,
			Consts::get_nonce(),
			0
		);
	}

}