<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

//TODO:Remove in future, it's here only to prevent PHP fatal error on rare occurrence
if( !function_exists( __NAMESPACE__.'\get_wpsd_option') ){
	function get_wpsd_option($name){

		return is_multisite() ? get_site_option( $name ) : get_option( $name );
	}
}

// 0=> error code
// 1=> error string

function record_php_errors(){

	$wpsd_debug_errors = errors_storage('',true);

	if( !$wpsd_debug_errors ){

		return;
	} 

	$timestamp = defined('WP_START_TIMESTAMP') ? WP_START_TIMESTAMP : microtime(true);

	$daytime = date('Y-m-d H:i:s', (int) $timestamp );

	$meta = get_php_error_metadata($timestamp);

	$sql_stored_success = false;

	$sql_stored_success = record_event_to_db( get_db_filepath(), $daytime, $wpsd_debug_errors, $meta );

	if(!$sql_stored_success){

		store_fragment( get_this_site_db_filename(), $meta, $daytime, $timestamp );

	}
	
}

/**
 * @return boolean true if the data been successfully stored
 */
function record_event_to_db( $db_filepath, $daytime, $wpsd_debug_errors, $meta ){
	
	require_once Consts::DIR.'includes/create-sqlite-db.php';

	if( !create_sqlite_db($db_filepath) ) {

		return false;
	}

	try {
			
		$db = new \SQLite3( $db_filepath );

		$db->enableExceptions( true );

		$db->exec('PRAGMA synchronous = OFF');
		$db->exec('PRAGMA journal_mode = MEMORY');
		$db->exec('PRAGMA cache_size = 100000');
		$db->exec('PRAGMA foreign_keys = OFF');
		$db->exec('PRAGMA temp_store = MEMORY');
		$db->exec('PRAGMA locking_mode = EXCLUSIVE');
		$db->exec('PRAGMA auto_vacuum = NONE');
		$db->exec('BEGIN EXCLUSIVE');

	} catch ( \Exception $e) {
		
		//DB is locked by another thread writing into the database
		return false;

	}
	
	if( empty($db) ){

		return false; 
	} 
	
	$meta_id = record_event_meta( $db, $meta );

	if( $meta_id === false ) return false;

	$stmt = $db->prepare('INSERT INTO error_log (meta_id, daytime, code, error) VALUES (:meta_id, :daytime, :code, :error)');

	foreach( $wpsd_debug_errors as $error_event ){

		$stmt->bindValue(':meta_id', $meta_id, SQLITE3_INTEGER);
		
		$stmt->bindValue(':daytime', $daytime, SQLITE3_TEXT);
		
		$stmt->bindValue(':code', $error_event[0], SQLITE3_INTEGER);
		
		$stmt->bindValue(':error', $error_event[1], SQLITE3_TEXT);

		$stmt->execute();
	}

	$db->exec('END TRANSACTION');

	$db->close();
	
	return true;
}

function record_event_meta( $db, $meta ) {

	$query = <<<SQL
		INSERT INTO error_meta (meta)
		VALUES (:meta);
		SQL;

	$stmt = $db->prepare($query);

	if (!$stmt){

		log( "couldn't prepare SQLite statement for metadata table", basename(__FILE__).' at '.__LINE__);

		return false;
	}

	$stmt->bindValue(':meta', $meta, SQLITE3_TEXT);
		
	$result = $stmt->execute();
	
	if( !$result ){

		log( "couldn't write metadata into SQLite database", basename(__FILE__).' at '.__LINE__);
		
		return false;
	}

	$meta_id = $db->lastInsertRowID();
		
	return $meta_id;
}

function store_fragment( $db_filename, $meta,$daytime, $timestamp ){

	$random_string = bin2hex( random_bytes(5) );

	$fragment_filepath = Consts::FRAGMENTS_DIR.'.ht.'.$timestamp.$random_string.get_ip_string();

	$stored_array = [
		'f' => $db_filename,
		'd' => $daytime,
		'e' => errors_storage('',true),
		'm' => $meta,

	];

	file_put_contents( $fragment_filepath, serialize($stored_array) );
	
}

function the_line_with_error( $last_error ){

	if( !is_php_error_file_valid_filepath( $last_error ) ) return '';

	$php_error_line = get_file_line( $last_error['file'], (int) $last_error['line'] );

	[ $message, $stack_trace ] = explode( 'Stack trace:', $last_error['message']);

	echo
<<<HTML

Line with error:


$php_error_line

Type: {$last_error['type']}

Message: {$message}

File: {$last_error['file']}

Line: {$last_error['line']}

Stack trace: $stack_trace



HTML;

}

function is_php_error_file_valid_filepath( $last_error ){

	return 
	
		file_exists( $last_error['file']??'' ) &&
			
		is_readable( $last_error['file']??'' ) &&
		
		is_numeric( $last_error['line']??false );
}

function get_file_line( $filename, $line_number ) {

	$handle = fopen( $filename, 'r' );
	
	if (!$handle ) return 'N/A';

	$current_line = 1;

	while (( $line = fgets( $handle ) ) !== false ) {

		if ( $current_line == $line_number ) {
		
			fclose( $handle );
		
			return $line;
		}
		
		$current_line++;
	}

	fclose( $handle );
	
	return 'N/A';
}

function get_sanitized_uri(){

	$uri = $_SERVER['REQUEST_URI']??$_SERVER['PHP_SELF']??'N/A';

	if( empty($_SERVER['QUERY_STRING']) || !str_contains( $_SERVER['QUERY_STRING'],'pass' ) ) return $uri;

	return preg_replace_callback('/(pass(?:word)?=)[^&]*/i', function ($matches) {
		return ($matches[1]??'') . '***removed***';
	}, $uri);
}

function get_php_error_metadata( $timestamp ){
	
	$settings = get_plugin_settings();
	
	$result = get_logged_in_user_from_cookies();

	$result .= get_server_superglobal( $settings );
	
	$result .= get_sanitized_post_superglobal($settings);

	$result .= get_sanitized_cookies_superglobal( $settings );

	return "{$result}\nTimestamp: {$timestamp}";
			
}

function get_logged_in_user_from_cookies( ){

	foreach( $_COOKIE??[] as $key => $value ) {

		if( str_starts_with( $key,'wordpress_logged_in_' ) ) {
			
			return 'Username: '.get_cookie_username($value).PHP_EOL.PHP_EOL;
			
		}
	}
		
	return '';
}

//call if Fatal PHP error doesn't show the message
function display_fatal_error_data( ){

	$last_error = error_get_last();

	if( !is_fatal_error($last_error) || !is_error_displayed() ) return;
	
	?>
	<style type="text/css">
	@media (prefers-color-scheme: dark ) {
		html {
			background: #222!important;
		}
		body#error-page {
			background: #333;
		}
		body#error-page {
			background: #333;
			color: #ccc;
			font-size: 20px;
		}
	}
	</style>
	<div style="white-space: break-spaces">
	<?php

	the_line_with_error( $last_error ).'<br>';

	?></div><?php
	

}


function is_fatal_error( $last_error ){
	
	switch( intval( $last_error['type']??0 ) ){

		case 1:
		case 4:
		case 16:
		case 64:
			
			return true;
			break;

		default:
			return false;
		break;
	}
	
}


function get_sanitized_post_superglobal( $settings ){

	if ( empty( $_POST ) || empty($settings['post']) ) return '';

	$result = '';

	foreach( array_keys( $_POST ) as $key ){

		switch(true){

			case $key === 'pwd':
			case str_contains($key, 'pass' ):
			case str_contains($key, 'nonce' ):
				$value = '***';
				break;
			default:
				$value = sanitize_text_field( $_POST[$key] );
				break;
		}

		$result .= "$key => {$value}\n";
	}

	return $result === '' ? '' : "\nPOST:\n$result"; 
}

function get_server_superglobal( $settings ){

	if( empty($settings['server']) ) return '';

	$result = '';

	foreach( $settings['server_keys'] as $key ){

		if( !isset( $_SERVER[$key] ) ) continue;

		$result .= $key === 'REQUEST_URI' ? 'REQUEST_URI => '.get_sanitized_uri()."\n" : "$key => {$_SERVER[$key]}\n";
			
	}

	return $result === '' ? '' : "SERVER:\n$result"; 
}

function get_sanitized_cookies_superglobal( $settings ){
	
	if( empty( $_COOKIE ) || empty($settings['cookies']) ) return '';

	$result = '';

	foreach( $_COOKIE as $key => $nonce ){

		if( is_cookie_key_excluded_string( $key ) ) continue;
		
		//multiple cookies with the same name is passed as an array, therefore value has to be iterated.
		foreach( (array) $nonce as $multi_key => $multi_value ){

			$stored_value = is_full_value_stored( $key,$settings ) ? $multi_value : get_truncated_value( $multi_value );
			
			$result_key = $multi_key === 0 ? $key : "{$key}_{$multi_key}";
			
			$result .= "$result_key => $stored_value\n";

		}

	}

	return $result === '' ? '' : "\nCookies:\n$result"; 
}

function get_truncated_value( $nonce ){

	if( strlen( $nonce ) < 6 ) return $nonce; 

	return substr( $nonce, 0, 5 )."...";
}

function is_full_value_stored( $key, $settings ){

	return !empty( $settings['cookies_keys_full_value'] ) && in_array( $key, $settings['cookies_keys_full_value'] );
}

function is_cookie_key_excluded_string( $key ){

	switch( true ){

		case str_contains( $key, 'wordpress_logged_in'):
		case str_contains( $key, 'nonce'):
			return true;
			break;
	
		default:
			return false;

	}
}

function get_cookie_username( $nonce ){

	return get_str_before( $nonce, '|' );

}

function get_str_before( $string, $before_char ){

	return str_contains( $string, $before_char ) ? substr( $string, 0, strpos( $string, $before_char ) ) : $string;
}

function move_older_error_log_to_archive(){
	
	$error_log_filepath = ini_get( 'error_log' );

	if( !file_exists($error_log_filepath) ) {
		file_put_contents( $error_log_filepath, '');
		return;
	}

	$file_date = date('Y-m-d', filemtime($error_log_filepath) );

	if( $file_date === date('Y-m-d') || filesize($error_log_filepath) < 10 ) return;

	$debug_archive_filepath = get_debug_archive_filepath($file_date);

	if( file_exists($debug_archive_filepath) ){

		append_log_to_archived_file( $error_log_filepath, $debug_archive_filepath );

	} else {

		rename( $error_log_filepath, $debug_archive_filepath );
		
	}
	
	file_put_contents( $error_log_filepath, '');
	
}

function append_log_to_archived_file( $src_filepath, $dest_filepath ){

	if( !is_readable($src_filepath) || !is_writable($dest_filepath) ){

		return false;
	}

	$src_content = file_get_contents($src_filepath);

	if( $src_content === false ){

		return false;
	}

	$write = file_put_contents($dest_filepath, $src_content, FILE_APPEND);

	if( $write === false ){

		return false;
	}

	unlink($src_filepath);

	return true;
}


function get_debug_archive_filepath($file_date){
	
	static $debug_archive_dir;

	if(!$debug_archive_dir){

		$debug_archive_dir = Consts::DB_DIR.'debug-'.$file_date.get_multisite_and_ip_string().'.log';
	}

	return $debug_archive_dir;

}