<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function get_plugin_included_files($slug){
	$files = get_wpsd_content_included_files();
	
	foreach(array_keys($files) as $key){

		if( !str_contains($key,$slug) ){
			unset($files[$key]);
		}
	}

	arsort($files,SORT_NUMERIC);

	return $files;
}

function get_plugins_memory_usage( $output_table = false ){

	$plugins = get_included_plugin_opcache_usage();

	if( !is_array( $plugins ) || !$plugins ) return false;

	$result = [];

	if( !$output_table ){

		foreach( $plugins as $name => $info ){

			$size_string = size_format( $info['memory_usage'] );

			$result[] = "$name {$size_string} in {$info['files']} files";

		}

		return $result;

	}

	$texts = [
		'plugin'		=> __( 'Plugin', 'wpsd-debug' ),
		'memory'		=> __( 'Memory usage', 'wpsd-debug' ),
		'files'			=> __( 'Files', 'wpsd-debug' )
	];

	$rows = '';

	foreach( $plugins as $name => $info ){

		$size_string = size_format( $info['memory_usage'] );

		$rows .= <<<HTML
			<tr>
				<td>{$name}</td>
				<td>{$size_string}</td>
				<td>{$info['files']}</td>
			</tr>
HTML;

	}

	$table = <<<HTML
		<table class="widefat striped">
			<thead>
				<tr>
					<th>{$texts['plugin']}</th>
					<th>{$texts['memory']}</th>
					<th>{$texts['files']}</th>
				</tr>
			</thead>
			<tbody>
				{$rows}
			</tbody>
		</table>
HTML;

	return $table;

}

function get_wpsd_content_included_files($all_folders = false){

	switch(true){
		case !function_exists( 'opcache_get_status' ):
		case empty($opcache_scripts_raw = opcache_get_status()['scripts']??[]);
			return [];
			break;
	}

	$content_dir = wp_normalize_path( WP_CONTENT_DIR );

	$content_length = strlen( $content_dir );

	$opcache_scripts =[];

	foreach($opcache_scripts_raw as $script_data){

		$path = wp_normalize_path( $script_data['full_path'] );
		
		if( !str_starts_with($path, $content_dir) ){
			continue;
		}

		$key = substr( $path, $content_length );

		if( !$all_folders && !(str_starts_with($key,'/plugins/') || str_starts_with($key,'/themes/')) ){
			continue;
		}

		$opcache_scripts[ $key ] = $script_data['memory_consumption'];
	}
	
	$result = [];

	foreach( get_included_files() as $file ){

		$path = wp_normalize_path( $file );

		if( !str_starts_with($path, $content_dir) ){
			continue;
		}

		$key = substr( $path, $content_length );

		if( !isset( $opcache_scripts[ $key ] ) ) continue;
		
		$result[$key]=$opcache_scripts[ $key ];
	}


	return $result;

}

function get_included_plugin_opcache_usage(){

	if ( !function_exists( 'opcache_get_status' ) ) return [];

	$status = opcache_get_status();

	if ( empty( $status['scripts'] ) ) return false;

	$included_files = get_included_files();

	$included_map = [];

	foreach ( $included_files as $file ){
		$included_map[ wp_normalize_path( $file ) ] = true;
	}

	$content_dir = wp_normalize_path( WP_CONTENT_DIR );

	$plugins = [];

	foreach ( $status['scripts'] as $script ){

		$path = wp_normalize_path( $script['full_path'] );

		if ( !isset( $included_map[ $path ] ) ) continue;

		if ( !str_starts_with( $path, $content_dir ) ) continue;

		$relative = str_replace( $content_dir . '/', '', $path );

		$path_pieces = explode( '/', $relative );

		$plugin_slug = $path_pieces[1]??$path_pieces[0]??'N/A';

		if ( !isset( $plugins[ $plugin_slug ] ) ){
			$plugins[ $plugin_slug ] = [
				'files' => 0,
				'memory_usage' => 0,
			];
		}

		$plugins[ $plugin_slug ]['files']++;

		$plugins[ $plugin_slug ]['memory_usage'] += $script['memory_consumption'];
	}

	uasort( $plugins, function( $a, $b ){
		return $b['memory_usage'] <=> $a['memory_usage'];
	} );

	return $plugins;
}

/**
 * Functions for admin menu
 */

function add_menu_included_files(){
	
	$plugins = get_included_plugin_opcache_usage();

	if( !is_array( $plugins ) ) return;

	add_admin_bar_menu([
		'id'    => 'wpsd-main-menu',
		'title' => __('PHP files','wpsd-debug'),
		'submenu' => get_used_files_submenu_markup()
	]);
	
}

function get_used_files_submenu_markup(){

	$plugins = get_included_plugin_opcache_usage();

	$max_name   = 0;
	$max_memory = 0;
	$max_files = 0;

	$texts=(object)[
		'name'		=> __( 'Plugin name', 'wpsd-debug' ),
		'memory'	=> __( 'Memory usage', 'wpsd-debug' ),
		'files'		=> __( 'Files count', 'wpsd-debug' )
	];
	
	// 1. Find max lengths for each column
	foreach( $plugins as $name => $info ){
		$memory = size_format( (int) $info['memory_usage'] );
		$max_name   = max($max_name, mb_strlen($name));
		$max_memory = max($max_memory, mb_strlen($memory));
		$max_files  = max($max_files, mb_strlen($info['files']));
	}

	$max_name   = max( $max_name, mb_strlen( $texts->name ) );
	$max_memory = max( $max_memory, mb_strlen( $texts->memory ) )+1;
	$max_files  = max( $max_files, mb_strlen( $texts->files ) );

	$result = [];

	// 2. Add header
	$header = implode( ' ', [
		'<span style="display:inline-block;width:'.$max_name.'ch;">'.$texts->name.'</span>',
		'<span style="display:inline-block;width:'.$max_memory.'ch;">'.$texts->memory.'</span>',
		'<span style="display:inline-block;width:'.$max_files.'ch;">'.$texts->files.'</span>'
	] );

	$result[] = [
		'id'    => 'used-files-header',
		'title' => $header,
		'meta'  => [
			'class'    => 'no-click',
			'tabindex' => '-1',
		],
	];
	
	$max_memory = (int) ($max_memory*1.2);

	// 3. Add each plugin row
	foreach( $plugins as $name => $info ){

		$files  = (int) $info['files'];
		$memory = size_format( (int) $info['memory_usage'] );

		$title = sprintf(
			'<span style="white-space:pre;font-family:monospace;">' .
			'<span style="display:inline-block;width:%dch;">%s</span>' .
			'<span style="display:inline-block;width:%dch;">%s</span>' .
			'<span style="display:inline-block;width:%dch;">%s</span>' .
			'</span>',
			$max_name, $name,
			$max_memory, $memory,
			$max_files, $files
		);

		$result[] = [
			'id'    => 'used-files-'.$name,
			'title' => $title,
			'meta'  => [
				'class'    => 'no-click',
				'tabindex' => '-1',
			],
		];

	}

	return $result;

}
