<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

add_action('admin_bar_menu', __NAMESPACE__ . '\\add_menu_debug_values', 35);

function add_menu_debug_values(){

	add_admin_bar_menu([
		'id'    => 'php-time',
		'title' => '<div id="wpsd-debug-menu" class="ab-item" aria-expanded="false"><span id="php-time-value">-----------</span></div>',
		'meta'  => [
			'class' => 'menupop',
		],
	]);

	//nonce is checked before requiring the file.
	if(!empty($_COOKIE[Consts::COOKIE_DISPLAY_PHP_FILES])){
		
		require_once Consts::DIR.'includes/admin-bar/included-files.php';
		
		add_action('admin_bar_menu', __NAMESPACE__ . '\\add_menu_included_files', 36);

	}

	// mu-plugin been loaded
	if( is_callable('tm') ){
		
		register_shutdown_function(__NAMESPACE__ . '\\add_php_time_script');
	}
}

function add_php_time_script(){
	
	$end_time_measure = microtime(true);

	$wpsd_debug_errors = is_callable( __NAMESPACE__.'\\errors_storage' ) ? errors_storage('',true) : [];

	$start_time_measure = defined('WP_START_TIMESTAMP') ? WP_START_TIMESTAMP : floatval($_SERVER['REQUEST_TIME_FLOAT']);

	$time_measure = tm( $start_time_measure, $end_time_measure );

	$submenu_html = get_admin_bar_submenu($wpsd_debug_errors);

	$style = empty($wpsd_debug_errors) ? '' : 'background:#7a4040;padding:0 5px;';

	$json_submenu = json_encode($submenu_html);
	$json_time = json_encode($time_measure);
	$json_style = json_encode($style);

	echo <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function(){
	const value = {$json_time};
	const html = {$json_submenu};
	const style = {$json_style};

	const span = document.getElementById('php-time-value');

	if(span){
		span.textContent = value;
	}

	const parentLi = document.getElementById('wp-admin-bar-php-time');

	if(parentLi){
		parentLi.insertAdjacentHTML('beforeend', html);

		const debug = document.getElementById('wpsd-debug-menu');

		if(debug && style){
			debug.setAttribute('style', style);
		}
	}
});
</script>
HTML;

}

function get_admin_bar_submenu($wpsd_debug_errors){

	$items = '';

	$submenu = get_submenu_data( $wpsd_debug_errors );

	foreach( $submenu as $i => $item ){
		$content = isset($item['url'])
			? "<a class=\"ab-item\" role=\"menuitem\" href=\"{$item['url']}\">{$item['label']}</a>"
			: "<div class=\"ab-item\" role=\"menuitem\" style=\"padding: 0 10px;display: inline-block;\">{$item['label']}</div>";

		$items .=	<<<HTML
					<li role="group" id="wpsd-debug-submenu-{$i}">{$content}</li>
					HTML;
	}

    
	return <<<HTML
<div class="ab-sub-wrapper">
	<ul role="menu" id="wp-admin-bar-php-time-default" class="ab-submenu" aria-label="PHP Time">
		{$items}
	</ul>
</div>
HTML;

}

function get_submenu_data( $wpsd_debug_errors ){
	
	$root = 'tools.php?page='.Consts::PAGE_ADMIN;

	$submenu = [
		[
			'label' => __('Debug log', 'wpsd-debug' ),
			'url'   => admin_url( $root ),
		],
		[
			'label' => __('PHP errors', 'wpsd-debug' ),
			'url'   => admin_url( $root.'&tab=error-log' ),
		],
		[
			'label' => __('Settings', 'wpsd-debug'),
			'url'   => admin_url( $root.'&tab=settings' ),
		],
		[
			'label' => __('Info', 'wpsd-debug'),
			'url'   => admin_url( $root.'&tab=info' ),
		],
	];

	if( !empty($wpsd_debug_errors) ){

		$errors_in_submenu = '';
		
		require_once Consts::DIR.'includes/error-names.php';

		$errors_names = get_error_type_strings();

		foreach( $wpsd_debug_errors as $key => $wpsd_error ){
			
			$error_lines = explode("\n", $wpsd_error[1] );

			if((int)$wpsd_error[0]===99999){

				$errors_in_submenu .= <<<HTML
				{$errors_names[$wpsd_error[0]]}: {$error_lines[0]}<br>
				HTML;
			
			} else {

				$error_lines[2] ??='';

				$errors_in_submenu .= <<<HTML
				{$errors_names[$wpsd_error[0]]} | {$error_lines[0]} | {$error_lines[2]}<br>
				HTML;
			}

			if( $key === 19 ){

				$errors_in_submenu .= '...';

				break;
			}
		}

		if($errors_in_submenu){

			$submenu[] = [
				'label' => '-----'
			];

			$submenu[] = [
				'label' => $errors_in_submenu
			];
		}

	}

	return $submenu;
}

function add_admin_bar_menu($args){

	global $wp_admin_bar;

	$menu_id    = $args['id']??'wpsd-main-menu';

	$menu_title = $args['title']??'Menu';

	$wp_admin_bar->add_node([
		'id'    => $menu_id,
		'title' => $menu_title,
		'meta'  => [
			'class' => 'menupop',
		],
	]);

	$submenu = $args['submenu']??[];

	foreach( $submenu as $item ){

		$submenu_id    = $item['id']??'';

		$submenu_title = $item['title']??'';

		if( !$submenu_id || !$submenu_title ) continue;

		$wp_admin_bar->add_node([
			'id'     => $submenu_id,
			'parent' => $menu_id,
			'title'  => $submenu_title,
		]);
	}
}
