<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function set_display_cookies($is_admin_at_login=false){

	$user_can = $is_admin_at_login || current_user_can( 'administrator' );
	
	if( !$user_can ){
		return;
	} 
	
	setcookie( Consts::COOKIE_DISPLAY_ADMIN_BAR, Consts::get_nonce(), 0,'/'	);

	$_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR] = Consts::get_nonce();
	
	// automatically set cookies to display debug values for localhost and staging
	if( is_local_or_staging() ){

		set_cookies_for_display_debug_values();
	}
	
}

function set_cookies_for_display_debug_values(){

	if( !isset($_COOKIE[Consts::COOKIE_DISPLAY_VALUES]) ){
		
		setcookie( Consts::COOKIE_DISPLAY_VALUES, Consts::get_nonce(), 0, '/' );
		
        $_COOKIE[Consts::COOKIE_DISPLAY_VALUES] = Consts::get_nonce();
	}

}

function delete_plugin_cookies(){

	$cookies_to_delete = [
		Consts::COOKIE_DISPLAY_ADMIN_BAR,
		Consts::COOKIE_DISPLAY_ERRORS,
		Consts::COOKIE_DISPLAY_VALUES,
		Consts::COOKIE_DISPLAY_PHP_FILES,
	];

	foreach( $cookies_to_delete as $cookie ){

		setcookie( $cookie, '', time()-3600, '/' );

		unset( $_COOKIE[$cookie] );

	}

}

function set_cookies_after_login($user){

	if( !user_can($user, 'manage_options') ) return;

	require_once Consts::DIR.'includes/universal-functions.php';

	require_once Consts::DIR.'includes/login/display-cookies.php';

	set_display_cookies($is_admin_at_login=true);
}

function is_local_or_staging(){
	
	return ($_SERVER['SERVER_ADDR']??'') === '127.0.0.1' || defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE === 'staging';
}