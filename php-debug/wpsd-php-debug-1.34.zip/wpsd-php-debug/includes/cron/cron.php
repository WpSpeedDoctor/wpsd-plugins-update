<?php

namespace WPSD\debug\v2;

require_once Consts::DIR.'includes/universal-functions.php';

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cron' );

add_action( Consts::CRON_CLEANUP, __NAMESPACE__.'\\'.Consts::CRON_CLEANUP );

add_action( Consts::CRON_REPORTING, __NAMESPACE__.'\\'.Consts::CRON_REPORTING );


function setup_cron() {

	if ( !wp_next_scheduled( Consts::CRON_CLEANUP ) ){
		
		/**
		 * strtotime('tomorrow 1:00 AM') will schedule for next morning 1AM and will first time execute
		 *  
		 * time() will schedule and execute immediately after plugin activation
		 */
		
		$time = strtotime('+1 days 0:01 AM');

		// $time = time(); 

		wp_schedule_event( $time, 'daily', Consts::CRON_CLEANUP );

	}

	if ( !empty(get_plugin_settings()['report_email']) && !wp_next_scheduled( Consts::CRON_REPORTING )){
		
		wp_schedule_event( time(), 'hourly', Consts::CRON_REPORTING );

	}
	
}

/**
 * This function must be named as Consts::CRON_REPORTING value
 */
function wpsd_debug_reporting(){

	require_once Consts::DIR.'includes/cron/cron-private.php';

	run_debug_reporting();

}


/**
 * This function must be named as Consts::CRON_CLEANUP value
 */

function wpsd_debug_cleanup(){
	
	require_once Consts::DIR.'includes/cron/cron-private.php';
	
	run_ajax_move_old_logs();
	
}

