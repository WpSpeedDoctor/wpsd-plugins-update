<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function the_inlined_htmx_error_handler(){

	$texts = [];

	$texts['error'] =	__('⚠ An error occurred:','wpsd-debug');

	$texts['timeout'] =	__('Request timed out.','wpsd-debug');

	echo <<<HTML
	<script>
		function show_htmx_warning(event, message){
			const sourceEl = event.detail && event.detail.elt ? event.detail.elt : null;

			if(!sourceEl) return;

			const targetSelector = sourceEl.getAttribute('hx-target');

			if(!targetSelector) return;

			const target = document.querySelector(targetSelector);

			if(!target) return;

			target.innerHTML = `<div class="notice notice-warning is-dismissible iterable-key">\${message}</div>`;
		}

		function extract_htmx_error_kind(event){
			const info = event && event.detail && event.detail.errorInfo && event.detail.errorInfo.error ? String(event.detail.errorInfo.error) : '';

			if(!info) return '';

			const lower = info.toLowerCase();

			const fromPos = lower.indexOf(' from ');

			const httpPos = lower.indexOf(' http');

			let cut = -1;

			if(fromPos !== -1 && httpPos !== -1){
				cut = Math.min(fromPos, httpPos);
			}else if(fromPos !== -1){
				cut = fromPos;
			}else if(httpPos !== -1){
				cut = httpPos;
			}

			return cut !== -1 ? info.slice(0, cut).trim() : info.trim();
		}

		document.body.addEventListener('htmx:error', function(event){
			const kind = extract_htmx_error_kind(event);

			const base = '{$texts['error']}';

			const message = kind ? `\${base} \${kind}` : base;

			show_htmx_warning(event, message);
		});

		document.body.addEventListener('htmx:timeout', function(event){
			show_htmx_warning(event, '{$texts['timeout']}');
		});
	</script>
	HTML;
}