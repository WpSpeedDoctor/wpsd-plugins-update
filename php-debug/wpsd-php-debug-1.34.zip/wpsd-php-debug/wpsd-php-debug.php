<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced PHP Debug by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Enhanced data collection of PHP errors, easy to log and display data
* Version: 1.34
* Updated: 2025-09-12
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-debug
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
* Requires PHP extension: sqlite3
*/	

require_once __DIR__.'/constants.php';

switch( WPSD_REQUEST_TYPE ){

	case REQUEST_AJAX:
		
		isset($_POST['action']) && require Consts::DIR.'admin/request-ajax.php';
		
		break;

	case REQUEST_ADMIN:
		
		$file = __FILE__;//necessary for register_activation_hook
		require Consts::DIR.'admin/request-back-end.php';
		unset($file);
		break;
	
	case REQUEST_CRON:
			
		require_once Consts::DIR.'includes/cron/cron.php';
		
		break;
	
	case REQUEST_LOGIN:
	case REQUEST_FRONTEND:
		add_action('wp_logout', function(){
			require_once Consts::DIR.'includes/login/display-cookies.php';
			delete_plugin_cookies();
			}
		);
		
		break;

}

/**
 * Setting cookies on login
 */
switch(true){

	case isset($_COOKIE[LOGGED_IN_COOKIE]):
	case ($_SERVER['REQUEST_METHOD']??'') !== 'POST':
	case !in_array(WPSD_REQUEST_TYPE, [REQUEST_FRONTEND, REQUEST_ADMIN, REQUEST_LOGIN]):
		break;
	default:
		add_action('wp_login', function($user_login, $user){
			require_once Consts::DIR.'includes/login/display-cookies.php';
			set_cookies_after_login($user);
			}, 99, 2
		);
		break;		
		
}

/**
 * Displaying admin bar
 */
switch(true){

	case !isset($_COOKIE[LOGGED_IN_COOKIE]):
	case !isset($_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR]):
	case !in_array(WPSD_REQUEST_TYPE, [REQUEST_FRONTEND, REQUEST_ADMIN, REQUEST_404]):
	case $_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR] !== Consts::get_nonce():
		break;
	default:
		require_once Consts::DIR.'includes/admin-bar/wp-admin-bar.php';
		break;
}

// if( isset($_GET['act']) ){

// 	require Consts::DIR.'playground.php';

// }