<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

global $pagenow;

$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

/**
 * Plugin setup
 */
if ( $page_now === 'plugins.php' ) {
	
	require_once Consts::DIR.'admin/setup.php';

	plugin_setup_main($file);

}	

/**
 * Admin menus
 */

add_action('admin_menu', __NAMESPACE__.'\admin_menu');

if ( $page_now === 'tools.php' && ($_GET['page']??'') == Consts::PAGE_ADMIN ) {

	require Consts::DIR.'includes/menu/wp-admin-menu.php';
}

function admin_menu() {

	add_submenu_page(
		'tools.php',
	//add_menu_page( 
		__( "Advanced PHP Debug", 'wpsd-debug' ), 
		__( "Advanced PHP Debug", 'wpsd-debug' ), 
		'administrator', 
		Consts::PAGE_ADMIN, 
		__NAMESPACE__.'\admin_menu_main',
		4
	);
}


/**
 * Other back-end parts
 */

require_once Consts::DIR.'admin/update.php';

require_once Consts::DIR.'includes/cron/cron.php';
