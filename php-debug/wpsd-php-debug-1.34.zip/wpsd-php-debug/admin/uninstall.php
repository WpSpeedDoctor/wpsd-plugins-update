<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require_once Consts::DIR.'includes/universal-functions.php';

function plugin_uninstall_main(){

	// delete_matched_files( ['sqlite','log'] );

	$options = [

		Consts::OPTION_SETTINGS,
		Consts::OPTION_REPORTING,
		Consts::OPTION_INI_STATUS,
		Consts::OPTION_VER,
		Consts::OPTION_MULTI_IP,

	];

	foreach ( $options as $option ){

		delete_wpsd_option( $option );

	}

	remove_dir(Consts::DB_DIR);

	remove_empty_db_folder();

	// delete_fragments_folder();

	// if( file_exists(get_debug_data_filepath_wpsd()) ){

	// 	unlink( get_debug_data_filepath_wpsd() );
	// } 
}

// function delete_fragments_folder(){

// 	if( !is_dir(Consts::FRAGMENTS_DIR) ) return;

// 	$d = dir(Consts::FRAGMENTS_DIR);

// 	while( ($file = $d->read() ) !== false){

// 			if( $file==='.' || $file==='..' ) continue;

// 			unlink(Consts::FRAGMENTS_DIR . $file);
// 	}

// 	$d->close();

// 	rmdir(Consts::FRAGMENTS_DIR);

// }

function remove_empty_db_folder(){

	$db_folder_path = WP_CONTENT_DIR.'/database/';

	$db_folder_content = scandir($db_folder_path);

	$db_folder_content = array_diff($db_folder_content,['.','..','index.php']);

	if(!empty($db_folder_content)){
		return;
	}

	remove_dir($db_folder_path);
}


function delete_wpsd_option( $name ){

	return is_multisite() ? delete_site_option( $name ) : delete_option( $name );
}

function delete_matched_files($needles){

	$files = scandir(Consts::DB_DIR);
	
	foreach( $files as $file ){
		
		foreach ($needles as $needle){

			if( str_contains( $file, $needle ) ) unlink( Consts::DB_DIR.$file );
		}
	}	
}

function remove_dir($dir){
	
	if (!is_dir($dir)){
		return false;
	}
	
	$items = array_diff(scandir($dir), ['.', '..']);
	
	foreach($items as $item){
		
		$path = $dir . DIRECTORY_SEPARATOR . $item;
		
		if (is_dir($path)){

			remove_dir($path);
			
		}else{

			unlink($path);
		}
	}

	return rmdir($dir);
}
