<?php

namespace WPSD\debug\v2;

use WPSD\admin_darkmode\ADM_Consts;

defined( 'ABSPATH' ) || exit;

require_once __DIR__.'/constants.php';

require_once Consts::DIR.'includes/universal-functions.php';


if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	return;
}

// delete_matched_files( ['sqlite','log'] );

$options = [

	Consts::OPTION_SETTINGS,
	Consts::OPTION_REPORTING,
	Consts::OPTION_INI_STATUS,
	Consts::OPTION_VER,
	Consts::OPTION_MULTI_IP,
	Consts::USERMETA_ADMIN_BAR_MENUS,

];

foreach ( $options as $option ){

	delete_wpsd_option( $option );

}

delete_metadata( 'user', 0, Consts::USERMETA_TOGGLES, '', true );
delete_metadata( 'user', 0, Consts::USERMETA_ADMIN_BAR_MENUS, '', true );

remove_dir(Consts::DB_DIR);

remove_empty_db_folder();

remove_darkmode_folder();

is_multisite() ? delete_site_transient( Consts::TRANSIENT_MENUS ) : delete_transient( Consts::TRANSIENT_MENUS);
is_multisite() ? delete_site_transient( Consts::SLUG ) : delete_transient( Consts::SLUG);

wpsd_remove_debug_cleanup_cron();


/**
 * Functions only beyond this point
 */

function wpsd_remove_debug_cleanup_cron(){

	$timestamp = wp_next_scheduled( Consts::CRON_CLEANUP );

	if ( false === $timestamp ) {
		return;
	}

	wp_unschedule_event( $timestamp, Consts::CRON_CLEANUP );
	wp_clear_scheduled_hook( Consts::CRON_CLEANUP );
}

function remove_empty_db_folder(){

	$db_folder_path = WP_CONTENT_DIR.'/database/';

	$db_folder_content = scandir($db_folder_path);

	$db_folder_content = array_diff($db_folder_content,['.','..','index.php']);

	if(!empty($db_folder_content)){
		return;
	}

	remove_dir($db_folder_path);
}


function delete_wpsd_option( $name ){

	return is_multisite() ? delete_site_option( $name ) : delete_option( $name );
}



function remove_dir($dir){
	
	if (!is_dir($dir)){
		return false;
	}
	
	$items = array_diff(scandir($dir), ['.', '..']);
	
	foreach($items as $item){
		
		$path = $dir . DIRECTORY_SEPARATOR . $item;
		
		if (is_dir($path)){

			remove_dir($path);
			
		}else{

			unlink($path);
		}
	}

	return rmdir($dir);
}

function remove_darkmode_folder(){

	require_once Consts::DIR.'includes/dark-mode/uninstall.php';

}