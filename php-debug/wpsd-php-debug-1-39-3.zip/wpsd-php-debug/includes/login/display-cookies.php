<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function set_display_cookies($is_admin_at_login=false){

	$user_can = $is_admin_at_login || current_user_can( 'administrator' );
	
	if( !$user_can ){
		return;
	} 
	
	set_saved_toggle_cookies();
}

function set_saved_toggle_cookies($user_id=0){

	$saved_toggles = get_saved_toggles($user_id);

	if( !is_array($saved_toggles) ){

		foreach( get_toggle_cookie_names() as $cookie_name ){

			delete_toggle_cookie($cookie_name);
		}

		set_toggle_cookie(Consts::COOKIE_DISPLAY_ADMIN_BAR);

		return;
	}

	foreach( get_toggle_cookie_names() as $cookie_name ){

		switch(true){

			case !empty($saved_toggles[$cookie_name]):
				set_toggle_cookie($cookie_name);
				break;

			default:
				delete_toggle_cookie($cookie_name);
				break;
		}
	}

}

function set_cookies_for_display_debug_values(){

	if( !isset($_COOKIE[Consts::COOKIE_DISPLAY_VALUES]) ){
		
		setcookie( Consts::COOKIE_DISPLAY_VALUES, Consts::get_nonce(), 0, '/' );
		
        $_COOKIE[Consts::COOKIE_DISPLAY_VALUES] = Consts::get_nonce();
	}

}

function delete_plugin_cookies(){

	foreach( get_toggle_cookie_names() as $cookie ){

		delete_toggle_cookie($cookie);

	}

}

function get_saved_toggles($user_id=0){

	$user_id = $user_id ?: get_current_user_id();

	if( !$user_id ){
		return false;
	}

	$saved_toggles = get_user_meta($user_id, Consts::USERMETA_TOGGLES, true);

	if( !is_array($saved_toggles) ){
		return false;
	}

	return $saved_toggles;
}

function get_toggle_cookie_names(){

	return [
		Consts::COOKIE_DISPLAY_ADMIN_BAR,
		Consts::COOKIE_DISPLAY_ERRORS,
		Consts::COOKIE_DISPLAY_VALUES,
		Consts::COOKIE_DISPLAY_PHP_FILES,
		Consts::COOKIE_DISABLE_PLUGINS,
		Consts::COOKIE_DARK_MODE,
	];
}

function set_toggle_cookie($cookie_name){

	setcookie( $cookie_name, Consts::get_nonce(), 0, '/' );

	$_COOKIE[$cookie_name] = Consts::get_nonce();
}

function delete_toggle_cookie($cookie_name){

	setcookie( $cookie_name, '', time()-3600, '/' );

	unset( $_COOKIE[$cookie_name] );
}

function set_cookies_after_login($user){

	if( !user_can($user, 'manage_options') ) return;

	require_once Consts::DIR.'includes/universal-functions.php';

	require_once Consts::DIR.'includes/login/display-cookies.php';

	set_saved_toggle_cookies($user->ID);
}

function is_local_or_staging(){
	
	return ($_SERVER['SERVER_ADDR']??'') === '127.0.0.1' || defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE === 'staging';
}
