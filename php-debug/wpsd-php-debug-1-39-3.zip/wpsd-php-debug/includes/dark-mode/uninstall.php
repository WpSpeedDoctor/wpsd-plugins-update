<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

class_exists(__NAMESPACE__.'\ADM_Consts') || require __DIR__.'/class-adm-consts.php';

$uploads = ADM_Consts::get_uploads();

$dir = rtrim( $uploads['basedir'], '/\\' ) . '/' . ADM_Consts::ASSETS_DIR;

if ( false === is_dir( $dir ) ) {

	return false;

}

$iterator = new \RecursiveIteratorIterator(
	new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
	\RecursiveIteratorIterator::CHILD_FIRST
);

foreach ( $iterator as $item ) {

	if ( $item->isDir() ) {

		rmdir( $item->getPathname() );

		continue;

	}

	unlink( $item->getPathname() );

}

rmdir( $dir );
