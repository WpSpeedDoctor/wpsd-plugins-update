<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

class ADM_Builder {

	private const COMMENT_PATTERN = '/\/\*.*?\*\//s';

	private const HEX_COLOR_PATTERN = '/(?<![\w-])#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})(?![\w-])/i';

	private const REPLACE_ORIGINAL = [
		'color-mix(in srgb, var(--wp-admin-theme-color) 8%, white)' => '#f6f7f7',
		'fill%3D%22%231e1e1e%22' => 'fill%3D%22%23aaa%22',
		'border: solid #50575e;' => '',
	];

	private const COLORS = [
		'border-1e1e1e' => '#666',
		'f0f0f1' => '#f5f5f5',
		'c3c4c7' => '#f5f5f5',
		'bg-1d2327' => '#1d2327',
		'bg-2c3338' => '#1a1a1a',
		'72aee6' => '#7db9f0',
		'a7aaad' => '#969ca5',
		'bg-3c434a' => '#3c434a',
		'bg-f0f0f1' => '#3c434a',
		'2c3338' => '#d5d8dc',
		'bg-fff' => '#111',
		'000' => '#d5d8dc',
		'fff' => '#f5f5f5',
		'bg-d63638' => '#d63638',
		'8c8f94' => '#aeb3ba',
		'2271b1' => '#5aa9e6',
		'bg-f0f6fc' => '#1a1d22',
		'bg-ffffff' => '#1a1d22',
		'135e96' => '#2271b1',
		'3c434a' => '#c4c8ce',
		'3858e9' => '#65afe7',
		'043959' => '#9acdf1',
		'1d2327' => '#b5bac1',
		'646970' => '#b5bac1',
		'50575e' => '#c4c8ce',
		'bg-f1f1f1' => '#151515',
		'f1f1f1' => '#1a1d22',
		'0a4b78' => '#8bc5ee',
		'3582c4' => '#68afe7',
		'bg-c5d9ed' => '#c5d9ed',
		'bg-f6f7f7' => '#1a1d22',
		'bg-2271b1' => '#2271b1',
		'd63638' => '#f06a6c',
		'bg-c3c4c7' => '#1a1d22',
		'1e1e1e' => '#c5d9ed',
		'dcdcde' => '#484d55',
		'f6f7f7' => '#22252b',
		'b32d2e' => '#ef6b6d',
		'007017' => '#50bd6d',
		'bg-646970' => '#646970',
		'4ab866' => '#68d083',
		'bg-eff9f1' => '#24272d',
		'f0b849' => '#f2c45c',
		'bg-fef8ee' => '#24272d',
		'cc1818' => '#ff6b6b',
		'bg-fcf0f0' => '#24272d',
		'68de7c' => '#76df89',
		'9ec2e6' => '#77afd9',
		'bg-dcdcde' => '#1a1d22',
		'787c82' => '#aeb3ba',
		'dba617' => '#e5bd4f',
		'bg-f0c33c' => '#f0c33c',
		'fafafa' => '#24272d',
		'949494' => '#a9aeb5',
		'bg-f0f0f0' => '#151515',
		'757575' => '#b1b6bd',
		'cccccc' => '#555b64',
		'bg-ffabaf' => '#ffabaf',
		'e65054' => '#f06b70',
		'bg-facfd2' => '#facfd2',
		'f86368' => '#ff7479',
		'bg-f5e6ab' => '#f5e6ab',
		'f0c33c' => '#f2ca55',
		'bg-b8e6bf' => '#b8e6bf',
		'bg-fcf9e8' => '#1a1d22',
		'4f94d4' => '#72b5eb',
		'fff972' => '#f6e76d',
		'bg-151515' => '#151515',
		'e9e9ed' => '#30333a',
		'bg-b32d2e' => '#b32d2e',
		'bg-3858e9' => '#3858e9',
		'996800' => '#e3b94f',
		'bg-000' => '#000',
		'ddd' => '#454a52',
		'bg-fcf0f1' => '#1a1d22',
		'00ba37' => '#57cf78',
		'bg-edfaef' => '#edfaef',
		'bg-68de7c' => '#68de7c',
		'183ad6' => '#7690ff',
		'83b4d8' => '#86bee6',
		'bg-50575e' => '#50575e',
		'bg-ebe8e5' => '#ebe8e5',
		'bg-ececec' => '#ececec',
		'bg-000000' => '#000000',
		'000000' => '#f5f6f7',
		'bg-0073aa' => '#0073aa',
		'32373c' => '#d0d4d9',
		'23282d' => '#dde0e4',
		'555d66' => '#bdc2c9',
		'bg-f86368' => '#f86368',
		'111' => '#f0f1f3',
		'0085ba' => '#66bee9',
		'096484' => '#7fc5e5',
		'46403c' => '#c8c4c1',
		'523f6d' => '#c3a8e2',
		'e14d43' => '#f47770',
		'627c83' => '#aec5cb',
		'dd823b' => '#eda35f',
		'8a8a8a' => '#aeb3ba',
		'd8d8d8' => '#484d55',
		'bg-2145e6' => '#2145e6',
		'2145e6' => '#7890ff',
		'bg-183ad6' => '#183ad6',
		'bg-e2e2e2' => '#e2e2e2',
		'e2e2e2' => '#3d4249',
		'ffffff' => '#202329',
		'dddddd' => '#454a52',
		'bg-1e1e1e' => '#2f2f2f',
		'f0f0f0' => '#1c1f24',
		'7b90ff' => '#91a2ff',
		'bg-fbfbfc' => '#fbfbfc',
		'2f2f2f' => '#d5d8dc',
		'bg-ccc' => '#ccc',
		'bg-949494' => '#949494',
		'ccc' => '#555b64',
		'bg-2f2f2f' => '#2f2f2f',
		'bg-e0e0e0' => '#e0e0e0',
		'e0e0e0' => '#41464e',
		'bg-ddd' => '#ddd',
		'bg-4ab866' => '#4ab866',
		'bg-cc1818' => '#cc1818',
		'7a00df' => '#c47cff',
		'007cba' => '#69b9e8',
		'005a87' => '#83c8ed',
	];

	public static function main() {

	if ( ADM_Consts::REWRITE_CSS || false === is_dir( ADM_Consts::get_assets_dir() ) ) {

		self::remove_old_assets_dirs();

		self::write_admin_darkmode_styles();

	}

}

	private static function remove_old_assets_dirs() {

	$assets_dir = ADM_Consts::get_assets_dir();

	$assets_parent_dir = dirname( $assets_dir );

	if ( false === is_dir( $assets_parent_dir ) ) {

		return false;

	}

	$dirs = glob( $assets_parent_dir . '/*', GLOB_ONLYDIR );

	if ( false === $dirs ) {

		return false;

	}

	foreach ( $dirs as $dir ) {

		if ( $assets_dir === $dir ) {

			continue;

		}

		self::remove_dir( $dir );

	}

	return true;

}

	private static function remove_dir( $dir ) {

	if ( false === is_dir( $dir ) ) {

		return false;

	}

	$iterator = new \RecursiveIteratorIterator(
		new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
		\RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $item ) {

		$path = $item->getPathname();

		if ( $item->isDir() && false === $item->isLink() ) {

			rmdir( $path );

			continue;

		}

		unlink( $path );

	}

	return rmdir( $dir );

}

	private static function process_admin_html( $html ) {

	$html = preg_replace_callback(
		ADM_Consts::LINK_TAG_PATTERN,
		function( $matches ) {

			$tag = $matches[0];

			$url = $matches[2];

			if ( str_contains( $url, ADM_Consts::get_url() ) ) {

				return $tag;

			}

			if ( false === str_contains( $url, ADM_Consts::WP_ADMIN_PATH ) && false === str_contains( $url, ADM_Consts::WP_INCLUDES_PATH ) ) {

				return $tag;

			}

			$darkmode_url = self::get_admin_darkmode_style_url( $url );

			if ( false === $darkmode_url ) {

				return $tag;

			}

			$darkmode_tag = self::get_darkmode_link_tag( $tag, $url, $darkmode_url );

			return $tag . "\n" . $darkmode_tag;

		},
		$html
	);

	return $html;

}

	private static function write_admin_darkmode_styles() {

	$dirs = [
		ABSPATH . 'wp-admin',
		ABSPATH . 'wp-includes',
	];

	foreach ( $dirs as $dir ) {

		self::write_admin_darkmode_styles_from_dir( $dir );

	}

	return true;

}

	private static function write_admin_darkmode_styles_from_dir( $dir ) {

	if ( false === is_dir( $dir ) ) {

		return false;

	}

	$iterator = new \RecursiveIteratorIterator(
		new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS )
	);

	foreach ( $iterator as $item ) {

		$path = $item->getPathname();


		if ( false === $item->isFile() || str_contains($path,'block') ) {

			continue;

		}

		if ( ADM_Consts::CSS_EXTENSION !== substr( $path, -4 ) ) {

			continue;

		}

		if ( ADM_Consts::MIN_CSS_EXTENSION === substr( $path, -8 ) ) {

			$source_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, ADM_Consts::CSS_EXTENSION, $path );

			if ( file_exists( $source_path ) ) {

				continue;

			}

		}

		$core_path = self::get_admin_core_path_from_file( $path );

		if ( false === $core_path ) {

			continue;

		}

		self::write_admin_darkmode_style( $core_path );

	}

	return true;

}

	private static function get_admin_core_path_from_file( $path ) {

	$path = wp_normalize_path( $path );

	$base_path = trailingslashit( wp_normalize_path( ABSPATH ) );

	if ( false === str_starts_with( $path, $base_path ) ) {

		return false;

	}

	return '/' . ltrim( substr( $path, strlen( $base_path ) ), '/' );

}

	private static function get_admin_darkmode_style_url( $url ) {

	$path = wp_parse_url( $url, PHP_URL_PATH );

	if ( false === $path ) {

		return false;

	}

	$core_path = strstr( $path, ADM_Consts::WP_ADMIN_PATH );

	if ( false === $core_path ) {

		$core_path = strstr( $path, ADM_Consts::WP_INCLUDES_PATH );

	}

	if ( false === $core_path || ADM_Consts::CSS_EXTENSION !== substr( $core_path, -4 ) ) {

		return false;

	}

	$relative_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, ADM_Consts::CSS_EXTENSION, $core_path );

	$relative_path = substr( $relative_path, 0, -4 ) . ADM_Consts::DARKMODE_CSS_EXTENSION;

	$destination_path = ADM_Consts::get_assets_dir() . $relative_path;

	if ( false === file_exists( $destination_path ) ) {

		return false;

	}

	return ADM_Consts::get_url() . $relative_path;

}

	private static function write_admin_darkmode_style( $core_path ) {

	if ( false === is_string( $core_path ) ) {

		return false;

	}

	if ( false === str_starts_with( $core_path, ADM_Consts::WP_ADMIN_PATH ) && false === str_starts_with( $core_path, ADM_Consts::WP_INCLUDES_PATH ) ) {

		return false;

	}

	if ( ADM_Consts::CSS_EXTENSION !== substr( $core_path, -4 ) ) {

		return false;

	}

	$original_path = ABSPATH . ltrim( $core_path, '/' );

	$source_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, ADM_Consts::CSS_EXTENSION, $original_path );

	if ( false === file_exists( $source_path ) ) {

		$source_path = $original_path;

	}

	if ( false === file_exists( $source_path ) ) {

		return false;

	}

	$relative_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, ADM_Consts::CSS_EXTENSION, $core_path );

	$relative_path = substr( $relative_path, 0, -4 ) . ADM_Consts::DARKMODE_CSS_EXTENSION;

	$destination_path = ADM_Consts::get_assets_dir() . $relative_path;

	$destination_url = ADM_Consts::get_url() . $relative_path;

	if ( false === ADM_Consts::REWRITE_CSS && file_exists( $destination_path ) ) {

		return $destination_url;

	}

	$destination_dir = dirname( $destination_path );

	if ( false === wp_mkdir_p( $destination_dir ) ) {

		return false;

	}

	$css = file_get_contents( $source_path );

	if ( false === $css ) {

		return false;

	}

	$css = self::replace_original_css_colors( $css );

	$css = preg_replace( self::COMMENT_PATTERN, '', $css );

	$position = 0;

	$css = self::filter_darkmode_css_rules( $css, $position );

	if ( '' === $css ) {

		return false;

	}

	if ( false === file_put_contents( $destination_path, $css ) ) {

		return false;

	}

	return $destination_url;

}

	private static function replace_original_css_colors( $css ) {

	static $search;

	static $replace;

	if ( null === $search ) {

		$search = array_keys( self::REPLACE_ORIGINAL );

		$replace = array_values( self::REPLACE_ORIGINAL );

	}

	if ( empty( $search ) ) {

		return $css;

	}

	return str_replace( $search, $replace, $css );

}

	private static function get_darkmode_link_tag( $tag, $url, $darkmode_url ) {

	$darkmode_tag = str_replace( $url, esc_url( $darkmode_url ), $tag );

	return preg_replace_callback(
		ADM_Consts::ID_ATTRIBUTE_PATTERN,
		function( $matches ) {

			return 'id=' . $matches[1] . $matches[2] . '-' . ADM_Consts::SLUG . $matches[1];

		},
		$darkmode_tag
	);

}

	private static function filter_darkmode_css_rules( $css, &$position ) {

	$output = '';

	$length = strlen( $css );

	while ( $position < $length ) {

		$open_position = self::find_css_token( $css, $position, '{' );

		$close_position = self::find_css_token( $css, $position, '}' );

		if ( false === $open_position ) {

			$position = $length;

			break;

		}

		if ( false !== $close_position && $close_position < $open_position ) {

			$position = $close_position + 1;

			break;

		}

		$selector = trim( substr( $css, $position, $open_position - $position ) );

		$position = $open_position + 1;

		if ( '' === $selector ) {

			continue;

		}

		if ( self::is_darkmode_group_rule( $selector ) ) {

			$inner_css = self::filter_darkmode_css_rules( $css, $position );

			if ( '' !== $inner_css ) {

				$output .= $selector . '{' . $inner_css . '}';

			}

			continue;

		}

		if ( '@' === $selector[0] ) {

			self::skip_css_block( $css, $position );

			continue;

		}

		$close_position = self::find_css_token( $css, $position, '}' );

		if ( false === $close_position ) {

			$position = $length;

			break;

		}

		$body = substr( $css, $position, $close_position - $position );

		$position = $close_position + 1;

		$filtered_body = self::filter_darkmode_css_declarations( $body );

		if ( '' === $filtered_body ) {

			continue;

		}

		$output .= $selector . '{' . $filtered_body . '}';

	}

	return $output;

}

	private static function is_darkmode_group_rule( $selector ) {

	switch ( true ) {

		case str_starts_with( $selector, '@media' ):

		case str_starts_with( $selector, '@supports' ):

		case str_starts_with( $selector, '@container' ):

		case str_starts_with( $selector, '@layer' ):

			return true;

	}

	return false;

}

	private static function skip_css_block( $css, &$position ) {

	$level = 1;

	$length = strlen( $css );

	while ( $position < $length && 0 < $level ) {

		$next_position = self::find_css_token( $css, $position, '{}' );

		if ( false === $next_position ) {

			$position = $length;

			return false;

		}

		switch ( $css[ $next_position ] ) {

			case '{':

				$level++;

				break;

			case '}':

				$level--;

				break;

		}

		$position = $next_position + 1;

	}

	return true;

}

	private static function filter_darkmode_css_declarations( $body ) {

	$output = '';

	$declarations = self::get_css_declarations( $body );

	$color_property_groups = self::get_darkmode_color_property_groups( $declarations );

	foreach ( $declarations as $declaration ) {

		$colon_position = self::find_css_token( $declaration, 0, ':' );

		if ( false === $colon_position ) {

			continue;

		}

		$property = strtolower( trim( substr( $declaration, 0, $colon_position ) ) );

		$property_group = self::get_darkmode_property_group( $property );

		if ( false === self::is_darkmode_color_property( $property ) ) {

			continue;

		}

		$color_prefix = '';

		switch ( true ) {

			case str_starts_with( $property, 'background' ):

				$color_prefix = 'bg-';

				break;

			case str_starts_with( $property, 'border' ):

				$color_prefix = 'border-';

				break;

		}

		$declaration = trim( $declaration );

		$darkmode_declaration = self::replace_darkmode_declaration_colors( $declaration, $color_prefix );

		if ( false === $darkmode_declaration ) {

			if ( '' === $property_group || false === isset( $color_property_groups[ $property_group ] ) ) {

				continue;

			}

			$output .= $declaration . ';';

			continue;

		}

		$output .= $darkmode_declaration . ';';

	}

	return $output;

}

	private static function get_darkmode_color_property_groups( $declarations ) {

	$property_groups = [];

	foreach ( $declarations as $declaration ) {

		$colon_position = self::find_css_token( $declaration, 0, ':' );

		if ( false === $colon_position ) {

			continue;

		}

		$property = strtolower( trim( substr( $declaration, 0, $colon_position ) ) );

		$property_group = self::get_darkmode_property_group( $property );

		if ( '' === $property_group ) {

			continue;

		}

		if ( 1 !== preg_match( self::HEX_COLOR_PATTERN, $declaration ) ) {

			continue;

		}

		$property_groups[ $property_group ] = true;

	}

	return $property_groups;

}

	private static function get_darkmode_property_group( $property ) {

	switch ( true ) {

		case str_starts_with( $property, 'background' ):

			return 'background';

		case str_starts_with( $property, 'border' ):

			return 'border';

	}

	return '';

}

	private static function get_css_declarations( $body ) {

	$declarations = [];

	$position = 0;

	$length = strlen( $body );

	while ( $position < $length ) {

		$semicolon_position = self::find_css_token( $body, $position, ';' );

		if ( false === $semicolon_position ) {

			$declarations[] = substr( $body, $position );

			break;

		}

		$declarations[] = substr( $body, $position, $semicolon_position - $position );

		$position = $semicolon_position + 1;

	}

	return $declarations;

}

	private static function find_css_token( $css, $position, $tokens ) {

	$quote = '';

	$parentheses = 0;

	$length = strlen( $css );

	while ( $position < $length ) {

		$char = $css[ $position ];

		if ( '' !== $quote ) {

			if ( '\\' === $char ) {

				$position += 2;

				continue;

			}

			if ( $char === $quote ) {

				$quote = '';

			}

			$position++;

			continue;

		}

		switch ( $char ) {

			case '"':

			case "'":

				$quote = $char;

				break;

			case '(':

				$parentheses++;

				break;

			case ')':

				if ( 0 < $parentheses ) {

					$parentheses--;

				}

				break;

			default:

				if ( 0 === $parentheses && false !== strpos( $tokens, $char ) ) {

					return $position;

				}

				break;

		}

		$position++;

	}

	return false;

}

	private static function is_darkmode_color_property( $property ) {

	switch ( $property ) {

		case 'color':

		case '-webkit-text-fill-color':

			return true;

	}

	if ( str_starts_with( $property, 'background' ) ) {

		return true;

	}

	return str_starts_with( $property, 'border' );

}

	private static function replace_darkmode_declaration_colors( $declaration, $color_prefix ) {

	$changed = false;

	$declaration = preg_replace_callback(
		self::HEX_COLOR_PATTERN,
		function( $matches ) use ( $color_prefix, &$changed ) {

			$value = strtolower( $matches[1] );

			$name = $color_prefix . $value;

			$changed = true;

			return self::get_darkmode_color( $name );

		},
		$declaration
	);

	if ( false === $changed ) {

		return false;

	}

	return $declaration;

}

	private static function get_darkmode_color( $name ) {

	if ( false === isset( self::COLORS[ $name ] ) ) {

		return '#' . str_replace( [ 'bg-', 'border-' ], '', $name );

	}

	return self::COLORS[ $name ];

}

}
