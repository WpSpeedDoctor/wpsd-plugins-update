<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: WPSD Admin Dark Mode
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Dark mode in WP admin
* Version: 1.3
* Updated: 2026-07-03
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-adm
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

switch(true){
	case !isset($_COOKIE[LOGGED_IN_COOKIE]):
	case wp_doing_ajax():
	case !is_admin():
	// case isset($_GET['disable-wpsd-adm']):
	case class_exists(__NAMESPACE__.'\ADM_Consts'):
		return;
}

class_exists(__NAMESPACE__.'\ADM_Consts') || require __DIR__.'/class-adm-consts.php';


if( ADM_Consts::REWRITE_CSS === true || !is_dir( ADM_Consts::get_assets_dir() ) ){

	if(ADM_Consts::REWRITE_CSS === true){

		defined('CONCATENATE_SCRIPTS') || define('CONCATENATE_SCRIPTS', false);

	}

	class_exists(__NAMESPACE__.'\ADM_Builder') || require __DIR__.'/class-adm-builder.php';

	ADM_Builder::main();

}

class_exists(__NAMESPACE__.'\ADM_Enqueue') || require __DIR__.'/class-adm-enqueue.php';

ADM_Enqueue::main();
