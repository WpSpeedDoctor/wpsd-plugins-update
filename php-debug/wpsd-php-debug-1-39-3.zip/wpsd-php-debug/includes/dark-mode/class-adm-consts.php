<?php

namespace WPSD\admin_darkmode;

class ADM_Consts {

	const SLUG = 'wpsd-darkmode';

	const ASSETS_DIR = 'wpsd-admin-darkmode';

	const REWRITE_CSS = false;

	const INLINE_DM_CSS = true;

	const WP_ADMIN_PATH = '/wp-admin/';

	const WP_INCLUDES_PATH = '/wp-includes/';

	const CSS_EXTENSION = '.css';

	const MIN_CSS_EXTENSION = '.min.css';

	const DARKMODE_CSS_EXTENSION = '.' . self::SLUG . self::CSS_EXTENSION;

	const LINK_TAG_PATTERN = '/<link\b[^>]*\bhref=(["\'])(.*?)\1[^>]*>/i';

	const ID_ATTRIBUTE_PATTERN = '/\bid=(["\'])(.*?)\1/i';

	public static function get_wp_version_slug() {

		global $wp_version;

		return str_replace( '.', '-', $wp_version );

	}

	public static function get_uploads() {

		static $uploads;

		if ( null === $uploads ) {

			$uploads = wp_upload_dir( null, false );

		}

		return $uploads;

	}

	public static function get_assets_dir() {

		static $assets_dir;

		if ( null !== $assets_dir ) {

			return $assets_dir;

		}

		$uploads = self::get_uploads();

		$assets_dir = rtrim( $uploads['basedir'], '/\\' ) . '/' . self::ASSETS_DIR . '/' . self::get_wp_version_slug();

		return $assets_dir;

	}

	public static function get_url() {

		static $url;

		if ( null !== $url ) {

			return $url;

		}

		$uploads = self::get_uploads();

		$url = rtrim( $uploads['baseurl'], '/' ) . '/' . self::ASSETS_DIR . '/' . self::get_wp_version_slug();

		return $url;

	}

}
