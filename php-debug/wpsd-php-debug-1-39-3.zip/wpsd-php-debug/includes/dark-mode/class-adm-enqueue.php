<?php

namespace WPSD\admin_darkmode;

defined( 'ABSPATH' ) || exit;

class ADM_Enqueue {

	public static function main() {

		add_filter('admin_body_class', [self::class, 'add_dark_mode_classes']);

		ob_start( [ self::class, 'process_load_styles_html' ] );

	}

	public static function add_dark_mode_classes($classes) {

		if(!str_contains($classes, ADM_Consts::SLUG)){
			
			return $classes .=  ' '.ADM_Consts::SLUG;
		}

		return $classes;

	}

	public static function process_load_styles_html( $html ) {

		$darkmode_tags = [];

		$html = preg_replace_callback(
			ADM_Consts::LINK_TAG_PATTERN,
			function( $matches ) use ( &$darkmode_tags ) {

				$tag = $matches[0];

				$url = $matches[2];

				$darkmode_tag = self::get_link_darkmode_tags( $tag, $url );

				if ( '' !== $darkmode_tag ) {

					$darkmode_tags[] = $darkmode_tag;

				}

				return $tag;

			},
			$html
		);

		if ( empty( $darkmode_tags ) ) {

			return $html;

		}

		$darkmode_tags = implode( "\n", array_unique( $darkmode_tags ) );

		if ( ADM_Consts::INLINE_DM_CSS ) {

			$darkmode_tags = '<style id="' . esc_attr( ADM_Consts::SLUG ) . '">' . $darkmode_tags . '</style>';

		}

		$head_position = stripos( $html, '</head>' );

		if ( false === $head_position ) {

			return $html . "\n" . $darkmode_tags;

		}

		return substr( $html, 0, $head_position ) . $darkmode_tags . "\n" . substr( $html, $head_position );

	}

	private static function get_link_darkmode_tags( $tag, $url ) {

		if ( str_contains( $url, '/wp-admin/load-styles.php' ) ) {

			return self::get_load_styles_darkmode_tags( $tag, $url );

		}

		return self::get_core_link_darkmode_tag( $tag, $url );

	}

	private static function get_core_link_darkmode_tag( $tag, $url ) {

		$path = wp_parse_url( html_entity_decode( $url, ENT_QUOTES ), PHP_URL_PATH );

		$darkmode_url = self::get_core_style_darkmode_url( $path );

		if ( false === $darkmode_url ) {

			return '';

		}

		return self::get_enqueue_darkmode_link_tag( $tag, $url, $darkmode_url );

	}

	private static function get_load_styles_darkmode_tags( $tag, $url ) {

		$handles = self::get_load_styles_handles( $url );

		if ( empty( $handles ) ) {

			return '';

		}

		$urls = self::get_load_styles_darkmode_urls( $handles, $url );

		if ( empty( $urls ) ) {

			return '';

		}

		$tags = [];

		foreach ( $urls as $darkmode_url ) {

			$tags[] = self::get_enqueue_darkmode_link_tag( $tag, $url, $darkmode_url );

		}

		return implode( "\n", $tags );

	}

	private static function get_load_styles_handles( $url ) {

		$decoded_url = html_entity_decode( $url, ENT_QUOTES );

		$query = wp_parse_url( $decoded_url, PHP_URL_QUERY );

		if ( false === $query || null === $query ) {

			return [];

		}

		parse_str( $query, $args );

		if ( false === isset( $args['load'] ) ) {

			return [];

		}

		$load = $args['load'];

		if ( is_array( $load ) ) {

			ksort( $load );

			$load = implode( '', $load );

		}

		if ( false === is_string( $load ) ) {

			return [];

		}

		$load = preg_replace( '/[^a-z0-9,_-]+/i', '', $load );

		if ( '' === $load ) {

			return [];

		}

		return array_unique( explode( ',', $load ) );

	}

	private static function get_load_styles_darkmode_urls( $handles, $url ) {

		$wp_styles = wp_styles();

		$rtl = str_contains( html_entity_decode( $url, ENT_QUOTES ), 'dir=rtl' );

		$urls = [];

		foreach ( $handles as $handle ) {

			if ( 'colors' === $handle ) {

				$darkmode_url = self::get_colors_darkmode_url();

				if ( false !== $darkmode_url ) {

					$urls[] = $darkmode_url;

				}

				continue;

			}

			if ( false === isset( $wp_styles->registered[ $handle ] ) ) {

				continue;

			}

			$style = $wp_styles->registered[ $handle ];

			if ( empty( $style->src ) ) {

				continue;

			}

			$darkmode_url = self::get_registered_style_darkmode_url( $style, $rtl );

			if ( false === $darkmode_url ) {

				continue;

			}

			$urls[] = $darkmode_url;

		}

		return $urls;

	}

	private static function get_registered_style_darkmode_url( $style, $rtl ) {

		$core_path = $style->src;

		if ( $rtl && false === empty( $style->extra['rtl'] ) ) {

			$core_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, '-rtl' . ADM_Consts::MIN_CSS_EXTENSION, $core_path );

		}

		return self::get_core_style_darkmode_url( $core_path );

	}

	private static function get_colors_darkmode_url() {

		$url = wp_style_loader_src( '', 'colors' );

		if ( false === $url ) {

			return false;

		}

		return self::get_core_style_darkmode_url( wp_parse_url( $url, PHP_URL_PATH ) );

	}

	private static function get_core_style_darkmode_url( $core_path ) {

		if ( false === is_string( $core_path ) ) {

			return false;

		}

		if ( false === str_starts_with( $core_path, ADM_Consts::WP_ADMIN_PATH ) && false === str_starts_with( $core_path, ADM_Consts::WP_INCLUDES_PATH ) ) {

			$core_admin_path = strstr( $core_path, ADM_Consts::WP_ADMIN_PATH );

			$core_includes_path = strstr( $core_path, ADM_Consts::WP_INCLUDES_PATH );

			if ( false === $core_admin_path && false === $core_includes_path ) {

				return false;

			}

			$core_path = false === $core_admin_path ? $core_includes_path : $core_admin_path;

		}

		if ( ADM_Consts::CSS_EXTENSION !== substr( $core_path, -4 ) ) {

			return false;

		}

		$relative_path = str_replace( ADM_Consts::MIN_CSS_EXTENSION, ADM_Consts::CSS_EXTENSION, $core_path );

		$relative_path = substr( $relative_path, 0, -4 ) . ADM_Consts::DARKMODE_CSS_EXTENSION;

		if ( false === file_exists( ADM_Consts::get_assets_dir() . $relative_path ) ) {

			return false;

		}

		return ADM_Consts::get_url() . $relative_path;

	}

	private static function get_enqueue_darkmode_link_tag( $tag, $url, $darkmode_url ) {

		if ( ADM_Consts::INLINE_DM_CSS ) {

			return self::get_darkmode_style_css( $darkmode_url );

		}

		$darkmode_tag = str_replace( $url, esc_url( $darkmode_url ), $tag );

		return preg_replace_callback(
			ADM_Consts::ID_ATTRIBUTE_PATTERN,
			function( $matches ) {

				return 'id=' . $matches[1] . $matches[2] . '-' . ADM_Consts::SLUG . $matches[1];

			},
			$darkmode_tag
		);

	}

	private static function get_darkmode_style_css( $darkmode_url ) {

		$path = self::get_darkmode_css_path( $darkmode_url );

		if ( false === $path ) {

			return '';

		}

		$css = file_get_contents( $path );

		if ( false === $css ) {

			return '';

		}

		static $url_length;

		if ( is_null( $url_length ) ) {

			$url_length = strlen( ADM_Consts::get_url() ) + 1;

		}

		$path = substr( $darkmode_url, $url_length );

		return "/* {$path} */\n{$css}";

	}

	private static function get_darkmode_css_path( $darkmode_url ) {

		$base_url = ADM_Consts::get_url();

		if ( false === str_starts_with( $darkmode_url, $base_url ) ) {

			return false;

		}

		$path = ADM_Consts::get_assets_dir() . substr( $darkmode_url, strlen( $base_url ) );

		if ( false === file_exists( $path ) ) {

			return false;

		}

		return $path;

	}

}
