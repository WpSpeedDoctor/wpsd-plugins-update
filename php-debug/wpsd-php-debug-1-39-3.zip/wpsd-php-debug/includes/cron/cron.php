<?php

namespace WPSD\debug\v2;

require_once Consts::DIR.'includes/universal-functions.php';

add_action( 'wp_loaded', __NAMESPACE__.'\setup_cron' );

add_action( Consts::CRON_CLEANUP, __NAMESPACE__.'\\'.Consts::CRON_CLEANUP );

add_action( Consts::CRON_REPORTING, __NAMESPACE__.'\\'.Consts::CRON_REPORTING );


function setup_cron() {

	if ( !wp_next_scheduled( Consts::CRON_CLEANUP ) ){
				
		wp_schedule_event( get_midnight_timestamp(), 'daily', Consts::CRON_CLEANUP );

	}

	if ( !empty(get_plugin_settings()['report_email']) && !wp_next_scheduled( Consts::CRON_REPORTING )){
		
		wp_schedule_event( time(), 'hourly', Consts::CRON_REPORTING );

	}
	
}

function get_midnight_timestamp(){

	/**
	 * strtotime('tomorrow') will schedule
	 * for next morning 0:00 AM and will first time execute
	 * strtotime('tomorrow') may fail,added fallback
	 *  
	 * time() will schedule and execute immediately after plugin activation
	 */

	
	$time = strtotime('tomorrow');

	$in_a_day = time() + DAY_IN_SECONDS;

	if(!is_numeric($time)){
		
		$date = new \DateTime('tomorrow');
		
		$time = $date->getTimestamp();
	}
		
	if(!is_numeric($time)){

		$time = strtotime(date('Y-m-d 00:00:00', $in_a_day));
	}

	return $time ?: $in_a_day;

}


/**
 * This function must be named as Consts::CRON_REPORTING value
 */
function wpsd_debug_reporting(){

	require_once Consts::DIR.'includes/cron/cron-private.php';

	run_debug_reporting();

}


/**
 * This function must be named as Consts::CRON_CLEANUP value
 */

function wpsd_debug_cleanup(){
	
	require_once Consts::DIR.'includes/cron/cron-private.php';
	
	run_ajax_move_old_logs();
	
}

