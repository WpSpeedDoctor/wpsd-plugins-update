<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function run_debug_reporting(){

	record_bulk_fragments_cron();

	$email = get_plugin_settings()['report_email']??'';

	if( empty($email) ) return;

	$errors = get_errors_for_email();

	if( has_php_fatal_errors($errors) ) {
		
		require_once Consts::DIR.'includes/cron/fatal-error-email.php';

		send_notification_email( $errors, $email );
	}

	run_integrity_db_check();

}

function has_php_fatal_errors($errors){
	
	return !empty($errors['counts'][1]);
}

function get_errors_for_email(){

	if( !class_exists('SQLite3') ){
		return [];
	}

	$db_filepath = get_db_filepath();

	if ( $db_filepath === '' || !file_exists($db_filepath) ) return [];

	$db = new \SQLite3($db_filepath);

	if (!$db) return [];

	$cutoff_time = date('Y-m-d H:i:s', strtotime('-1 hour'));
	
	//codes 99999,32768 are debl() and database errors

	$query = <<<SQL
SELECT code, COUNT(*) as count 
FROM error_log 
WHERE daytime >= :cutoff_time AND code NOT IN (99999,32768)
GROUP BY code
SQL;

	$stmt = $db->prepare($query);

	if (!$stmt) {

		$db->close();

		return [];
	}

	$stmt->bindValue(':cutoff_time', $cutoff_time, SQLITE3_TEXT);

	$result = $stmt->execute();

	if (!$result) return [];

	$codes_count = [];

	while ($row = $result->fetchArray(SQLITE3_ASSOC)){
		$codes_count[$row['code']] = $row['count'];
	}

	$last_fatal_error = '';

	$failed_emails = '';

	$query = <<<SQL
	SELECT error_log.error, error_meta.meta
	FROM error_log
	JOIN error_meta ON error_meta.meta_id = error_log.meta_id
	WHERE error_log.code = 1
	ORDER BY error_log.event_id DESC
	LIMIT 1
	SQL;

	$result_fatal = $db->query($query);

	if ($result_fatal && ($row = $result_fatal->fetchArray(SQLITE3_ASSOC))){
		$last_fatal_error = htmlentities($row['error']) . '<hr>' . htmlentities($row['meta']);
	}

	$query = <<<SQL
	SELECT error
	FROM error_log
	WHERE daytime >= :cutoff_time AND code = 65537
	ORDER BY event_id DESC
	SQL;

	$stmt = $db->prepare($query);

	if (!$stmt) {

		$db->close();

		return [];
	}

	$stmt->bindValue(':cutoff_time', $cutoff_time, SQLITE3_TEXT);

	$result_failed_emails = $stmt->execute();

	while( $result_failed_emails && ($row = $result_failed_emails->fetchArray(SQLITE3_ASSOC)) ){

		$failed_emails .= htmlentities($row['error']).'<hr>';

	}

	$db->close();

	return [
		'counts'		=> $codes_count,
		'last_fatal_error'	=> $last_fatal_error,
		'failed_emails'		=> $failed_emails
	];
}

function cleanup_main_private(){

	if( !class_exists('SQLite3') ) return false;
	
	$keep_days = get_plugin_settings()['keep']??30;

	remove_old_logs( $keep_days );
	
	remove_old_records_main( $keep_days );

	delete_matched_files( ['meta.log'] );

	record_bulk_fragments_cron();

}

function delete_matched_files($needles){

	$files = scandir(Consts::DB_DIR);
	
	foreach( $files as $file ){
		
		foreach ($needles as $needle){

			if( str_contains( $file, $needle ) ) unlink( Consts::DB_DIR.$file );
		}
	}	
}

function record_bulk_fragments_cron(){

	$ip = rtrim(get_ip_string(),'.');

	require_once Consts::DIR.'includes/class-fragments-recorder.php';

	$record = new Fragment_Recorder($ip);

	$record->record_fragments_files();

	remove_other_ips_fragments($ip);
}

/**
 * removed files made on a different server, copied by load balancer or migration. 
 */
function remove_other_ips_fragments($ip){

	$ip_extension = ".{$ip}";

	$directory = dir( Consts::FRAGMENTS_DIR );

	while( ($file = $directory->read()) !== false ){

		switch(true){

			case $file === '.':
			case $file === '..':
			case str_ends_with($file, $ip_extension):
			case str_ends_with($file, 'null'):
				break;

			default:
				unlink(Consts::FRAGMENTS_DIR.$file);
				break;
		}

	}
}

function run_integrity_db_check(){

	if( !class_exists('SQLite3') ) return false;
	
	$db_filepath = get_db_filepath();
	
	if( empty($db_filepath) || !file_exists($db_filepath) ) return true;

	$is_db_ok = has_db_integrity($db_filepath);

	if( $is_db_ok ) return true; 

	require_once Consts::DIR.'includes/cron/recovery-sqlite.php';
		
	return recover_broken_sqlite_db( $db_filepath );
}

function remove_old_records_main( $keep_days ){

	$db_filepath = get_db_filepath();

	if ( empty($db_filepath) || !file_exists($db_filepath) ) return;

	$is_db_ok = run_integrity_db_check();

	if( ! $is_db_ok ) return;

	remove_old_sqlite_records( $keep_days, $db_filepath );
	
}

function copy_recovery_file( $db_filepath ){

	$date = date('Y-m-d_H-i-s');

	$broken_db_filepath = str_replace( '.sqlite',"-broken-{$date}.sqlite", $db_filepath);

	rename($db_filepath, $broken_db_filepath );

	require_once Consts::DIR.'includes/create-sqlite-db.php';

	create_sqlite_db();
}

function remove_old_sqlite_records($keep_days, $db_filepath) {
	
	try {
			
		$db = new \SQLite3($db_filepath);
		
		$db->enableExceptions(true);
		
		$db->busyTimeout(5000);
		
		$temp_storage_markup = filesize($db_filepath) > 100 * MB_IN_BYTES ? 'FILE' : 'MEMORY';
		
		$db->exec('PRAGMA synchronous = OFF');
		$db->exec('PRAGMA journal_mode = WAL');
		$db->exec('PRAGMA temp_store = '.$temp_storage_markup);
		$db->exec('PRAGMA cache_size = 100000');
		$db->exec('PRAGMA foreign_keys = OFF');
		$db->exec('PRAGMA locking_mode = EXCLUSIVE');
		$db->exec('PRAGMA auto_vacuum = NONE');
		$db->exec('BEGIN EXCLUSIVE');

	} catch (\Exception $e) {

		switch ($e->getCode()?:0) {

			case 5: // SQLITE_BUSY
			case 6: // SQLITE_LOCKED

				// Another connection is holding the lock.
				// Safe to retry with backoff.
				break;

			case 11: // SQLITE_CORRUPT
			case 26: // SQLITE_NOTADB

				// File is not a valid SQLite database.
				// Don't retry — restore from backup.
				copy_recovery_file($db_filepath);
				break;

			case 10: // SQLITE_IOERR
			case 13: // SQLITE_FULL
			case 8:  // SQLITE_READONLY

				// Filesystem / permission issues. Worth logging
				// distinctly from real corruption.
				error_log('SQLite I/O error [' . $e->getCode() . ']: ' . $e->getMessage());

				break;

			default:

				trigger_error('SQLite init failed [' . $e->getCode() . ']: ' . $e->getMessage(), E_USER_NOTICE);

				break;
		}

		return;
	}

	if (!$db) {
		return;
	}
	
	$cutoff_date = date('Y-m-d H:i:s', strtotime("-{$keep_days} days"));
	
	$delete_log_query = <<<SQL
		DELETE FROM error_log 
		WHERE daytime < :cutoff_date
		SQL;
			
			$delete_orphaned_meta_query = <<<SQL
		DELETE FROM error_meta
		WHERE meta_id NOT IN (
			SELECT DISTINCT meta_id 
			FROM error_log
		)
		SQL;
	
	$stmt_log = $db->prepare($delete_log_query);
	
	$stmt_log->bindValue(':cutoff_date', $cutoff_date, SQLITE3_TEXT);
	
	$stmt_log->execute();
	
	$rows_deleted_log = $db->changes();
	
	$db->exec($delete_orphaned_meta_query);
	
	$rows_deleted_meta = $db->changes();
	
	$db->exec('COMMIT');
	
	if ($rows_deleted_log === 0 && $rows_deleted_meta === 0) {
		
		$db->close();
		
		return;
	}
	
	//vacuum on Monday morning
	if( date('N') === '1' ){

		$db->exec('VACUUM');
	}
	
	$db->close();
	
}


function has_db_integrity($db_filepath){

	$db = new \SQLite3($db_filepath);

	$integrity_result = $db->querySingle('PRAGMA integrity_check');
	
	$db->close();

	return $integrity_result === 'ok';
	
}

function remove_old_logs( $keep_days ){

	remove_old_files( Consts::DB_DIR, $extension = 'log', $keep_days );

}

function remove_old_files( $path, $extension = false, $keep_days = 30 ){
 
    $max_age_in_seconds = $keep_days * 24 * 60 * 60;
 
    $time = time();
 
    $files = new \DirectoryIterator($path);
 
    foreach($files as $file){
 
        if ( $file->isDot() || !$file->isFile() ) continue;
 
        if ( $extension && strtolower($file->getExtension()) != strtolower($extension) ) continue;
		
        $file_age = $time - $file->getMTime();
		
        if ($file_age <= ($max_age_in_seconds)) continue;

		$file_path = $file->getRealPath();
 
        unlink($file_path);
 
    }
 
}

/**
 * Move old error logs to the archive is not called directly as cron may run without webserver
 * in such a case server's IP will be missing.
 */
function run_ajax_move_old_logs(){

	$args = [
		'body' => [
			'cron-job-via-ajax' => 1,

			'nonce' => Consts::get_nonce(),

			'action' => 'htmx-php-debug-search',
		],
	];

	wp_remote_post(
		admin_url('admin-ajax.php?php-debug-search'),
		$args
	);
	
}
