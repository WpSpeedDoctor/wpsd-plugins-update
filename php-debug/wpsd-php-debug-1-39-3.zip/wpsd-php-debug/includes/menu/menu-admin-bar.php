<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$texts = get_admin_bar_texts();

$admin_menu_items = get_admin_menu_items();

save_admin_menu_items($admin_menu_items);

if(empty($admin_menu_items)){
	header("Refresh:0");
	die;
}

$admin_menu_tiles_markup = get_admin_menu_tiles_markup($admin_menu_items);

$admin_menu_nonce = wp_nonce_field('wpsd-admin-bar-menus-save', 'wpsd_admin_bar_menus_nonce', false, false);

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<form method="post" action="" id="admin-bar-menus">
		<h2>{$texts['admin_menu_title']}</h2>
		<div class="wpsd-admin-bar-menus-wrap">
			{$admin_menu_tiles_markup}
		</div>
		{$admin_menu_nonce}
		<input type="hidden" name="action" value="save_admin_bar_menus">
		<input type="submit" value="{$texts['save_admin_menus']}" class="button button-primary wpsd-button">
	</form>
</div>
HTML;

function get_admin_bar_texts(){

	return [
		'admin_menu_title'			=> __( 'Admin menus displayed under the site name', 'wpsd-debug' ),
		'save_admin_menus'			=> __( 'Save Admin Menus', 'wpsd-debug' ),
	];

}

function get_admin_menu_items(){

	$all_items = get_wpsd_transient(Consts::TRANSIENT_MENUS);

	if(is_array($all_items)){

		return $all_items;

	}

	$query_args = [
		'wpsd-debug' => '',
	];

	$cookies = [];

	foreach($_COOKIE as $name => $value){

		if( !str_contains($name, COOKIEHASH)){

			continue;

		}

		$cookies[] = new \WP_Http_Cookie([
			'name' => $name,
			'value' => $value,
		]);

	}

	/**
	 * The plugin is fetching the menu items from the Tools admin page as on this page
	 * the menu items could be filtered out.
	 */

	$response = wp_remote_get(add_query_arg($query_args, admin_url('tools.php')), [
		'timeout' => 10,
		'redirection' => 0,
		'cookies' => $cookies,
	]);

	if(!is_wp_error($response)){

		$all_items = get_wpsd_transient(Consts::TRANSIENT_MENUS);

		if(is_array($all_items)){

				return $all_items;

		}

	}

	return [];
}

function save_admin_menu_items($items){

	if(!isset($_POST['action']) || $_POST['action'] !== 'save_admin_bar_menus'){

		return false;

	}

	if(!isset($_POST['wpsd_admin_bar_menus_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpsd_admin_bar_menus_nonce'])), 'wpsd-admin-bar-menus-save') || !current_user_can('manage_options')){

		return false;

	}

	$selected_paths = array_keys(wp_unslash($_POST['admin_bar_menus'] ?? []));

	$selected_items = [];

	foreach($selected_paths as $path){

		if(!isset($items[$path])){

			continue;

		}

		$selected_items[] = [
			'name' => isset($items[$path]['compound']) ? $items[$path]['compound'] : $items[$path]['name'],
			'path' => $items[$path]['path'],
		];

	}

	update_user_meta(get_current_user_id(), Consts::USERMETA_ADMIN_BAR_MENUS, $selected_items);

}

function get_admin_menu_tiles_markup($items){

	$items_markup = get_admin_menu_items_markup($items);

	$markup = <<<HTML
	<div class="wpsd-admin-bar-menus-list">
		{$items_markup}
	</div>
	HTML;

	return $markup;

}

function get_admin_menu_items_markup($items){

	$selected_items = get_user_meta(get_current_user_id(), Consts::USERMETA_ADMIN_BAR_MENUS, true) ?: [];

	$selected_paths = array_flip(array_column($selected_items, 'path'));

	$menu_groups = get_admin_menu_groups($items);

	$markup = '';

	foreach($menu_groups as $menu_group){

		$menu_markup = get_admin_menu_checkbox_markup($menu_group['menu_key'], $menu_group['menu'], $selected_paths, 'wpsd-admin-bar-menu-tile-title');

		$submenu_markup = get_admin_submenu_items_markup($menu_group['submenus'], $selected_paths);

		$submenus_markup = '';

		if($submenu_markup){

			$submenus_markup = <<<HTML
			<div class="wpsd-admin-bar-menu-tile-submenus mt10">
				{$submenu_markup}
			</div>
			HTML;

		}

		$markup .= <<<HTML
		<div class="wpsd-admin-bar-menu-tile wpsd-admin-bar-menu-tile-color">
			{$menu_markup}
			{$submenus_markup}
		</div>
		HTML;

	}

	return $markup;

}

function get_admin_menu_groups($items){

	$menu_groups = [];

	$current_menu_key = '';

	foreach($items as $menu_key => $item){

		if(!isset($item['sub'])){

			$current_menu_key = $menu_key;

			$menu_groups[$current_menu_key] = [
				'menu_key' => $menu_key,
				'menu' => $item,
				'submenus' => [],
			];

			continue;

		}

		if(!$current_menu_key){

			$current_menu_key = $menu_key;

			$menu_groups[$current_menu_key] = [
				'menu_key' => $menu_key,
				'menu' => $item,
				'submenus' => [],
			];

			continue;

		}

		$menu_groups[$current_menu_key]['submenus'][$menu_key] = $item;

	}

	return $menu_groups;

}

function get_admin_submenu_items_markup($items, $selected_paths){

	$markup = '';

	foreach($items as $menu_key => $item){

		$markup .= get_admin_menu_checkbox_markup($menu_key, $item, $selected_paths, 'wpsd-is-submenu');

	}

	return $markup;

}

function get_admin_menu_checkbox_markup($menu_key, $item, $selected_paths, $class){

	$escaped_menu_key = esc_attr($menu_key);

	$escaped_name = esc_html($item['name']);

	$checked = checked(isset($selected_paths[$item['path']]), true, false);

	$class = esc_attr($class);

	$markup = <<<HTML
	<label class="{$class}">
		<input type="checkbox" name="admin_bar_menus[{$escaped_menu_key}]" value="1" {$checked}>
		<span>{$escaped_name}</span>
	</label>
	HTML;

	return $markup;

}
