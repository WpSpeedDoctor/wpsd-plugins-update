<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function admin_menu_main(){
	
	require_once Consts::DIR.'includes/universal-functions.php';
	
	enqueue_plugins_assets();

	the_menu();

}


function the_menu(){
	
	$active_tab = $_GET['tab']??'home';
	
	$tab_arr = get_tabs_arr();

	switch(true){

		case !class_exists('SQLite3'):
			
			echo '<p>'.__('The included PHP extension "SQLite3" is not installed. Please install it to use this plugin.', 'wpsd-debug'  ).'</p>';
			return;
			break;
		
		case !in_array( $active_tab, array_keys($tab_arr) ):

			echo '<p>'.__("Page doesn't exist.", 'wpsd-debug').'</p>';
			
			return;
	}

	the_old_sqlite_version_notice();

	the_missing_mu_plugin_notice();

	the_header();

	display_tab_links($active_tab);
	
	ob_start();
	
	@include Consts::DIR."includes/menu/{$tab_arr[$active_tab]['template']}";

	$output = ob_get_clean();

	$body_class= Consts::SLUG.'-body';

	echo <<<HTML
	</nav>
	<div class="{$body_class} clear">
	{$output}
	</div>
	HTML;

	the_footer();
}

function the_old_sqlite_version_notice(){

	if( ($_GET['tab'] ?? '') !=='info' || !is_old_sqlite() ){

		return;
	}

	$version = \SQLite3::version()['versionString'];

	$notice_text = sprintf(
		__("You're running older version of Sqlite3 extension %s, minimal recommended version is 3.38, error logging might not work as expected.", 'wpsd-debug'),
		$version
	);

	echo <<<HTML
	<div class="notice notice-warning is-dismissible">
		<p>{$notice_text}</p>
	</div>
	HTML;

}


function the_missing_mu_plugin_notice(){

	if( function_exists( __NAMESPACE__.'\set_php_error_reporting') ) return;

	?><div class="notice notice-error is-dismissible">
		<p>
			<?php echo __('The essential part of the debug plugin is missing. Deactivate and activate back <i>Advanced PHP Debug</i> plugin.', 'wpsd-debug'  );?>
		</p>
	</div><?php

}



function is_old_sqlite(){

	$version = \SQLite3::version()['versionString'];

	return version_compare($version, '3.38', '<');

}

function display_tab_links( $active_tab ){
	
	?><nav class="nav-tabs wpsd-border-tabs"><?php
	
	foreach (get_tabs_arr() as $slug => $tab_arr){
		
		$active_tab_class = ($slug === $active_tab) ? ' nav-tab-active' : '';
		
		$tab_qs = $slug == 'home' ? '':'&tab='.$slug;
		
		$url = 'admin.php?page='.Consts::PAGE_ADMIN.$tab_qs;

		echo <<<HTML
		<a href="{$url}" class="nav-tab{$active_tab_class}">
			{$tab_arr['title']}
		</a>
		HTML;
	}

}




function the_header() {

	$text = __('Advanced PHP and WordPress debug', 'wpsd-debug');

	echo <<<HTML
<div class="wrap wpsd-debug-wrap">
	<h1>{$text}</h1>
HTML;

}

function the_footer(){

	//</div>wpsd-php-debug-body
?>	</div>
</div><?php
}


function enqueue_plugins_assets(){

	// "q"is there just to make it though WP function, not a real path or file
	$plugin_url_dir = plugin_dir_url(Consts::DIR.'q'); 

	wp_register_style( 
		
		'wpsd-debug',

		"{$plugin_url_dir}assets/wpsd-php-debug.css",

		false,

		Consts::VER
	);

	
	wp_enqueue_style( 'wpsd-debug' );

	wp_register_script( 
		
		'htmx',
	
		"{$plugin_url_dir}assets/htmx.min.js",

		false,
		
		'1.9.12',
		
		['strategy' => 'defer', 'in_footer' => true]
	);

	wp_enqueue_script( 'htmx' );
	
	
}

function get_tabs_arr(){

	return [
		
		'home'		=> [ 
				
			'title' 	=> __('Home','wpsd-debug'),
			'template'	=> 'menu-home.php',
		],
		'error-log'		=> [ 
				
			'title' 	=> __('Error log','wpsd-debug'),
			'template'	=> 'menu-error-log.php',
		],
		'fetch'		=> [

			'title' 	=> __('Fetch','wpsd-debug'),
			'template'	=> 'menu-fetch.php',
		],
		'toggles'	=> [

			'title'		=> __('Toggles','wpsd-debug'),
			'template'	=> 'menu-toggles.php',
		],
		'admin-bar'	=> [

			'title'		=> __('Admin bar menu','wpsd-debug'),
			'template'	=> 'menu-admin-bar.php',
		],
		'settings'	=> [

			'title' 	=> __('Settings','wpsd-debug'),
			'template'	=> 'menu-settings.php',
		],
		'checklist'	=> [

			'title' 	=> __('Checklist','wpsd-debug'),
			'template'	=> 'menu-checklist.php',
		],
		'info'	=> [

			'title' 	=> __('Info','wpsd-debug'),
			'template'	=> 'menu-info.php',
		],
		'docs'		=> [

			'title' 	=> __('FAQs & Docs','wpsd-debug'),
			'template'	=> 'menu-faq-docs.php',
		]
		
	
	];

}

