<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require_once Consts::DIR.'includes/login/display-cookies.php';

save_toggle_states();

restore_saved_toggle_cookies();

$texts = get_toggle_texts();

echo <<<HTML
<div class="wpsd-php-debug-body clear">
	<br>
	<div class="tables-wrap">
		<form method="post">
			{$texts['nonce_field']}
		<table class="wpsd-toggles-table">
			<thead>
				<tr>
					<th class="table-title" colspan="2">{$texts['title']}</th>
				</tr>
				<tr>
					<th class="table-subtitle" colspan="2">{$texts['subtitle']}</th>
				</tr>
			</thead>
			<tr>
				<td>{$texts['text_errors']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugToggle" name="{$texts['display_errors']}" onchange="toggleCookie('{$texts['display_errors']}', this.checked)" {$texts['checked_display_errors']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td>{$texts['text_values']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugValuesToggle" name="{$texts['display_values']}" onchange="toggleCookie('{$texts['display_values']}', this.checked)" {$texts['checked_display_values']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td>{$texts['text_admin_bar']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugAdminBarToggle" name="{$texts['display_admin_bar']}" onchange="toggleCookie('{$texts['display_admin_bar']}', this.checked)" {$texts['checked_display_admin_bar']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td>{$texts['text_php_files']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugPhpFiles" name="{$texts['display_php_files']}" onchange="toggleCookie('{$texts['display_php_files']}', this.checked)" {$texts['checked_display_php_files']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td>{$texts['text_disable_plugins']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugDisablePlugins" name="{$texts['disable_plugins']}" onchange="toggleCookie('{$texts['disable_plugins']}', this.checked)" {$texts['checked_disable_plugins']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td>{$texts['text_dark_mode']}</td>
				<td>
					<label class="switch">
						<input type="checkbox" id="debugDarkMode" name="{$texts['dark_mode']}" onchange="toggleCookie('{$texts['dark_mode']}', this.checked)" {$texts['checked_dark_mode']}>
						<span class="slider wpsd-slider-color"></span>
					</label>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<button type="submit" name="wpsd_save_toggles" value="1" class="button button-primary wpsd-button mt10">{$texts['text_save']}</button>
				</td>
			</tr>
			</table>
		</form>
	</div>
</div>
{$texts['script']}
HTML;

function save_toggle_states(){
	
	switch (true) {
		case !isset($_POST['wpsd_save_toggles']):
		case !current_user_can('manage_options'):
		case !isset($_POST['wpsd_toggles_nonce']):
		case !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpsd_toggles_nonce'])), 'wpsd_save_toggles'):
			return false;
	}
	$saved_toggles = [];

	foreach( get_toggle_cookie_names() as $cookie_name ){

		$saved_toggles[$cookie_name] = isset($_POST[$cookie_name]) ? 1 : 0;

		switch(true){

			case !empty($saved_toggles[$cookie_name]):
				$_COOKIE[$cookie_name] = Consts::get_nonce();
				break;

			default:
				unset($_COOKIE[$cookie_name]);
				break;
		}
	}

	update_user_meta(get_current_user_id(), Consts::USERMETA_TOGGLES, $saved_toggles);

	return true;
}

function restore_saved_toggle_cookies(){

	$cookie_names = get_toggle_cookie_names();

	foreach( $cookie_names as $cookie_name ){

		if( ($_COOKIE[$cookie_name]??'') === Consts::get_nonce()  ){

			return false;

		}

	}

	$saved_toggles = get_saved_toggles();

	if( !is_array($saved_toggles) ){

		return false;

	}

	foreach( $cookie_names as $cookie_name ){

		if( empty($saved_toggles[$cookie_name]) ){

			continue;

		}

		set_toggle_cookie($cookie_name);

	}

	return true;
}

function get_toggle_texts(){

	$nonce = Consts::get_nonce();

	$checked_display_errors = checked($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] ?? '', $nonce, false);

	$checked_display_values = checked($_COOKIE[Consts::COOKIE_DISPLAY_VALUES] ?? '', $nonce, false);

	$checked_display_admin_bar = checked($_COOKIE[Consts::COOKIE_DISPLAY_ADMIN_BAR] ?? '', $nonce, false);

	$checked_display_php_files = checked($_COOKIE[Consts::COOKIE_DISPLAY_PHP_FILES] ?? '', $nonce, false);

	$checked_disable_plugins = checked($_COOKIE[Consts::COOKIE_DISABLE_PLUGINS] ?? '', $nonce, false);

	$checked_dark_mode = checked($_COOKIE[Consts::COOKIE_DARK_MODE] ?? '', $nonce, false);

	$script = <<<HTML
	<script>
	function toggleCookie(cookieName, isChecked) {
		const dirString = '{$nonce}';

		if (isChecked) {
			document.cookie = cookieName + "=" + dirString + "; path=/";
		} else {
			document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
		}
	}
	</script>
	HTML;

	return [
		'nonce_field'				=> wp_nonce_field('wpsd_save_toggles', 'wpsd_toggles_nonce', true, false),
		'checked_display_errors'	=> $checked_display_errors,
		'checked_display_values'	=> $checked_display_values,
		'checked_display_admin_bar'	=> $checked_display_admin_bar,
		'checked_display_php_files'	=> $checked_display_php_files,
		'checked_disable_plugins'	=> $checked_disable_plugins,
		'checked_dark_mode'			=> $checked_dark_mode,
		'display_errors'			=> Consts::COOKIE_DISPLAY_ERRORS,
		'display_values'			=> Consts::COOKIE_DISPLAY_VALUES,
		'display_admin_bar'			=> Consts::COOKIE_DISPLAY_ADMIN_BAR,
		'display_php_files'			=> Consts::COOKIE_DISPLAY_PHP_FILES,
		'disable_plugins'			=> Consts::COOKIE_DISABLE_PLUGINS,
		'dark_mode'					=> Consts::COOKIE_DARK_MODE,
		'title'						=> __( 'Toggles', 'wpsd-debug' ),
		'subtitle'					=> __( 'Settings related to browser session, if saved then applied to the current user after login.', 'wpsd-debug' ),
		'text_errors'				=> __( 'Display PHP Errors', 'wpsd-debug' ),
		'text_values'				=> __( 'Display Debug Values', 'wpsd-debug' ),
		'text_admin_bar'			=> __( 'Display menu in WP Admin bar', 'wpsd-debug' ),
		'text_php_files'			=> __( 'Display PHP files in WP Admin bar', 'wpsd-debug' ),
		'text_disable_plugins'		=> __( 'Disable plugins on debug pages', 'wpsd-debug' ),
		'text_dark_mode'			=> __( 'Dark mode', 'wpsd-debug' ),
		'text_save'					=> __( 'Save', 'wpsd-debug' ),
		'script'					=> $script,
	];

}
