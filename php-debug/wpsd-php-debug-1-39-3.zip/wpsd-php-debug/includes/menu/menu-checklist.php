<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

$checklist_data = get_checklist_data();

$table_content = '';

$sql_db_info_content = get_checklist_sql_db_info_content();

foreach($checklist_data as $data){

	$table_content .= <<<HTML
	<tr id="{$data['name']}">
		<td>{$data['text']}</td>
		<td>{$data['description']}</td>
		<td>{$data['value']}</td>
	</tr>
	HTML;

}

echo <<<HTML
<table class="wpsd-checklist-table">
	{$table_content}
</table>
{$sql_db_info_content}
HTML;

function get_checklist_data(){

	$opcache_status = function_exists('opcache_get_status') ? opcache_get_status(false) : false;

	return [
		[
			'name'	=> 'custom_filepath_allowed',
			'text'	=> __( 'Custom PHP error filepath allowed', 'wpsd-debug' ),
			'description'	=> 'boolval(OPTION_INI_STATUS) === true',
			'value'	=> get_checklist_icon( boolval(get_wpsd_option( Consts::OPTION_INI_STATUS )) ),
		],
		[
			'name'	=> 'opcache_enabled',
			'text'	=> __( 'Opcache enabled', 'wpsd-debug' ),
			'description'	=> "function_exists('opcache_get_status')",
			'value'	=> get_checklist_icon( function_exists('opcache_get_status') ),
		],
		[
			'name'	=> 'opcache_memory_used',
			'text'	=> __( 'Available OPcache memory', 'wpsd-debug' ),
			'description'	=> get_opcache_memory_description($opcache_status),
			'value'	=> get_checklist_icon( is_opcache_memory_available($opcache_status) ),
		],
		[
			'name'	=> 'interned_memory_free',
			'text'	=> __( 'Available interned strings memory', 'wpsd-debug' ),
			'description'	=> get_interned_memory_description($opcache_status),
			'value'	=> get_checklist_icon( has_free_interned_memory($opcache_status) ),
		],
		[
			'name'	=> 'jit_enabled',
			'text'	=> __( 'JIT enabled', 'wpsd-debug' ),
			'description'	=> "ini_get('opcache.jit') == '1' && buffer_size > 0",
			'value'	=> get_checklist_jit_icon(),
		],
		[
			'name'	=> 'pcre_jit_enabled',
			'text'	=> __( 'PCRE JIT enabled', 'wpsd-debug' ),
			'description'	=> "ini_get('pcre.jit') == '1'",
			'value'	=> get_checklist_icon( ini_get('pcre.jit') == '1' ),
		],
		[
			'name'	=> 'apcu_available',
			'text'	=> __( 'APCu available', 'wpsd-debug' ),
			'description'	=> "extension_loaded('apcu') && apcu_enabled()",
			'value'	=> get_checklist_icon( extension_loaded('apcu') && function_exists('apcu_enabled') && apcu_enabled() ),
		],
	];

}

function get_opcache_memory_description($status){

	if(!is_array($status)){

		return __('memory_usage unavailable','wpsd-debug');

	}

	$memory_usage = $status['memory_usage'] ?? [];

	$free_memory = $memory_usage['free_memory'] ?? 0;

	return size_format($free_memory).' > '.size_format(100 * KB_IN_BYTES);

}

function get_interned_memory_description($status){

	if(!is_array($status)){

		return __('interned_strings_usage unavailable','wpsd-debug');

	}

	$free_memory = $status['interned_strings_usage']['free_memory'] ?? 0;

	return size_format($free_memory).' > '.size_format(10 * KB_IN_BYTES);

}

function is_opcache_memory_available($status){

	if(!is_array($status)){

		return false;

	}

	return ($status['memory_usage']['free_memory'] ?? 0) > 100 * KB_IN_BYTES;

}

function has_free_interned_memory($status){

	if(!is_array($status)){

		return false;

	}

	return ($status['interned_strings_usage']['free_memory'] ?? 0) > 10 * KB_IN_BYTES;

}

function get_checklist_jit_icon(){

	switch(true){

		case ini_get('opcache.jit') != '1':

		case !is_string( ini_get('opcache.jit_buffer_size') ):

		case ($buffer_size = rtrim(strtolower( ini_get('opcache.jit_buffer_size')),'gmkb')) === null:

		case !is_numeric($buffer_size):

		case intval($buffer_size) === 0:

			return get_checklist_icon(false);

		default:

			return get_checklist_icon(true);

	}

}

function get_checklist_icon($bool){

	return $bool ? '<span class="wpsd-debug-icon icon-true">✔</span>' : '<span class="wpsd-debug-icon icon-false">✘</span>';

}

function get_checklist_sql_db_info_content(){

	$cpu_cores = 6;

	$results = get_checklist_sql_db_info_results($cpu_cores);

	if(!$results){

		return '';

	}

	$heading_text = __( 'SQL database recommendations', 'wpsd-debug' );

	$cpu_cores_text = __( 'CPU cores available', 'wpsd-debug' );

	$variable_name_text = __( 'Variable name', 'wpsd-debug' );

	$current_value_text = __( 'Current value', 'wpsd-debug' );

	$recommended_value_text = __( 'Recommended value', 'wpsd-debug' );

	$status_text = __( 'Status', 'wpsd-debug' );

	$rows = '';

	foreach($results as $row){

		$variable_name = esc_attr(strtolower($row['variable_name']));

		$variable_label = esc_html($row['variable_name']);

		$current_value = esc_attr($row['current_value']);

		$current_label = esc_html(get_checklist_sql_db_info_value_label($row['current_value']));

		$recommended_value = esc_attr($row['recommended_value']);

		$recommended_label = esc_html(get_checklist_sql_db_info_value_label($row['recommended_value']));

		$status = esc_html(get_checklist_sql_db_info_status($row['current_value'], $row['recommended_value']));

		$rows .= <<<HTML
		<tr data-sql-db-row="{$variable_name}" data-current-value="{$current_value}">
			<td>{$variable_label}</td>
			<td>{$current_label}</td>
			<td data-recommended-value="{$recommended_value}">{$recommended_label}</td>
			<td data-sql-db-status>{$status}</td>
		</tr>
		HTML;

	}

	return <<<HTML
	<br>
	<div class="wrap-sql-db-info">
		<h2>{$heading_text}</h2>
		<label>
			{$cpu_cores_text}
			<input type="number" id="wpsd-sql-cpu-cores" min="1" max="256" step="1" value="{$cpu_cores}">
		</label>
		<table class="wpsd-db-info-table">
			<thead>
				<tr>
					<th>{$variable_name_text}</th>
					<th>{$current_value_text}</th>
					<th>{$recommended_value_text}</th>
					<th>{$status_text}</th>
				</tr>
			</thead>
			<tbody>
				{$rows}
			</tbody>
		</table>
	</div>
	<script>
	(() => {
		const input = document.getElementById('wpsd-sql-cpu-cores');

		if(!input){
			return;
		}

		const formatValue = (value) => String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

		const getStatus = (currentValue, recommendedValue) => {
			if(String(currentValue) === String(recommendedValue)){
				return 'ok';
			}

			const currentNumber = Number(currentValue);
			const recommendedNumber = Number(recommendedValue);

			if(!Number.isFinite(currentNumber) || !Number.isFinite(recommendedNumber)){
				return '↓';
			}

			return currentNumber < recommendedNumber ? '↑' : '↓';
		};

		const getCpuValues = (cpuCores) => ({
			thread_pool_size: Math.min(cpuCores, 128),
			innodb_read_io_threads: Math.min(Math.max(cpuCores, 4), 64),
			innodb_write_io_threads: Math.min(Math.max(cpuCores, 4), 64),
			innodb_purge_threads: Math.min(Math.max(Math.ceil(cpuCores / 2), 1), 8),
		});

		const updateRows = () => {
			const cpuCores = Math.max(parseInt(input.value, 10) || 6, 1);
			const values = getCpuValues(cpuCores);

			Object.entries(values).forEach(([name, value]) => {
				const row = document.querySelector(`[data-sql-db-row="\${name}"]`);

				if(!row){
					return;
				}

				const recommended = row.querySelector('[data-recommended-value]');
				const status = row.querySelector('[data-sql-db-status]');

				recommended.dataset.recommendedValue = String(value);
				recommended.textContent = formatValue(value);
				status.textContent = getStatus(row.dataset.currentValue, value);
			});
		};

		input.addEventListener('input', updateRows);
	})();
	</script>
	HTML;

}

function get_checklist_sql_db_info_results($cpu_cores){

	global $wpdb;

	$query = get_checklist_sql_db_info_query();

	$results = $wpdb->get_results($query, ARRAY_A);

	if(!$results){

		return false;

	}

	$recommendations = get_checklist_sql_db_info_recommendations($cpu_cores);

	$data = [];

	foreach($results as $row){

		$variable_name = $row['variable_name'] ?? '';

		$recommendation_key = strtolower($variable_name);

		if(!isset($recommendations[$recommendation_key])){

			continue;

		}

		$data[] = [
			'variable_name' => $variable_name,
			'current_value' => $row['current_value'] ?? '',
			'recommended_value' => $recommendations[$recommendation_key],
		];

	}

	return $data;

}

function get_checklist_sql_db_info_recommendations($cpu_cores){

	global $wpdb;

	$database_size = (int) $wpdb->get_var('SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE table_schema = DATABASE()');

	$min_buffer_pool_size = 134217728;

	$buffer_pool_size = max($min_buffer_pool_size, (int) ceil(($database_size * 1.25) / 1048576) * 1048576);

	$chunk_size = 134217728;

	switch(true){

		case $buffer_pool_size >= 8589934592:

			$chunk_size = 536870912;

			break;

		case $buffer_pool_size >= 1073741824:

			$chunk_size = 268435456;

			break;

	}

	return [
		'innodb_buffer_pool_size' => $buffer_pool_size,
		'innodb_buffer_pool_chunk_size' => $chunk_size,
		'innodb_log_file_size' => 2147483648,
		'innodb_log_buffer_size' => 67108864,
		'innodb_flush_method' => 'O_DIRECT',
		'innodb_flush_log_at_trx_commit' => 1,
		'innodb_read_io_threads' => min(max($cpu_cores, 4), 64),
		'innodb_write_io_threads' => min(max($cpu_cores, 4), 64),
		'innodb_purge_threads' => min(max((int) ceil($cpu_cores / 2), 1), 8),
		'thread_handling' => 'pool-of-threads',
		'thread_pool_size' => min($cpu_cores, 128),
		'max_connections' => 100,
		'table_open_cache' => 2000,
		'table_definition_cache' => 2000,
		'thread_cache_size' => 32,
		'tmp_table_size' => 67108864,
		'max_heap_table_size' => 67108864,
		'wait_timeout' => 120,
		'query_cache_type' => 0,
		'query_cache_size' => 0,
		'key_buffer_size' => 33554432,
	];

}

function get_checklist_sql_db_info_query(){

	return <<<SQL
SELECT variable_name, variable_value AS current_value
FROM information_schema.GLOBAL_VARIABLES
WHERE variable_name IN (
    'innodb_buffer_pool_size', 'innodb_buffer_pool_chunk_size', 'innodb_log_file_size',
    'innodb_log_buffer_size', 'innodb_flush_method', 'innodb_flush_log_at_trx_commit',
    'innodb_read_io_threads', 'innodb_write_io_threads', 'innodb_purge_threads',
    'thread_handling', 'thread_pool_size', 'max_connections', 'table_open_cache',
    'table_definition_cache', 'thread_cache_size', 'tmp_table_size', 'max_heap_table_size',
    'wait_timeout', 'query_cache_type', 'query_cache_size', 'key_buffer_size'
)
SQL;

}

function get_checklist_sql_db_info_value_label($value){

	if(!is_numeric($value)){

		return $value;

	}

	return number_format((float) $value);

}

function get_checklist_sql_db_info_status($current_value, $recommended_value){

	if((string) $current_value === (string) $recommended_value){

		return 'ok';

	}

	if(!is_numeric($current_value)){

		return '↓';

	}

	if(!is_numeric($recommended_value)){

		return '↓';

	}

	return (float) $current_value < (float) $recommended_value ? '↑' : '↓';

}
