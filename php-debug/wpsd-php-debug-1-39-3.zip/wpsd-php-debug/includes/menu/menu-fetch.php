<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require Consts::DIR.'includes/menu/htmx-error-handler.php';

$t = get_fetch_texts();

$callable_options = get_fetch_callable_options();

echo <<<HTML
<div class="wpsd-fetch-wrap mt10">
	<button type="button" class="button wpsd-button"
		hx-post="{$t->ajax_url}"
		hx-vals='{"action": "{$t->action}","nonce": "{$t->nonce}"}'
		hx-include="#fetch-hook,#fetch-value,#fetch-callable"
		hx-indicator="#fetch-spinner"
		hx-target="#fetch-result">
		{$t->button_text}
	</button>
	<input type="text" id="fetch-value" name="fetch-value" value="">
	<select id="fetch-hook" name="hook">
		<option value="now">{$t->hook_now}</option>
		<option value="plugins_loaded">{$t->hook_plugins_loaded}</option>
		<option value="init">{$t->hook_init}</option>
		<option value="wp_ajax">{$t->hook_wp_ajax}</option>
	</select>
	<select id="fetch-callable" name="fetch-callable" aria-label="{$t->fetch_callable}">
		<option value="all">{$t->callable_all}</option>
		{$callable_options}
	</select>
	<img class="htmx-indicator" id="fetch-spinner" src="/wp-includes/images/spinner.gif" height="18" width="18">
	<div id="fetch-result" class="mt10">-</div>
</div>
HTML;

the_inlined_htmx_error_handler();


function get_fetch_texts(){

	return (object) [
		'ajax_url'				=> admin_url('/admin-ajax.php?'.Consts::AJAX_QS_FETCH),
		'button_text'			=> __( 'Fetch', 'wpsd-debug' ),
		'fetch_callable'			=> esc_attr__( 'Fetch callable', 'wpsd-debug' ),
		'callable_all'			=> __( 'All', 'wpsd-debug' ),
		'hook_now'				=> __( 'now', 'wpsd-debug' ),
		'hook_plugins_loaded'	=> __( 'plugins_loaded', 'wpsd-debug' ),
		'hook_init'				=> __( 'init', 'wpsd-debug' ),
		'hook_wp_ajax'			=> __( 'WP Ajax', 'wpsd-debug' ),
		'nonce'					=> Consts::get_nonce(),
		'action'				=> Consts::AJAX_QS_FETCH,
	];
}

function get_fetch_callable_options(){

	global $wp_filter;

	$options = '';

	foreach( $wp_filter[Consts::HOOK_FETCH]->callbacks ?? [] as $priority => $callbacks ){

		foreach( array_values($callbacks) as $index => $callback ){

			$label = get_fetch_callable_label($callback['function']);

			$value = esc_attr($priority.':'.$index);

			$label = esc_html($label);

			$options .= <<<HTML
<option value="{$value}">{$label}</option>
HTML;

		}

	}

	return $options;

}

function get_fetch_callable_label($callback){

	if( is_string($callback) ){

		return $callback;

	}

	if( is_array($callback) ){

		$class = is_object($callback[0]) ? get_class($callback[0]) : $callback[0];

		return $class.'::'.$callback[1];

	}

	if( $callback instanceof \Closure ){

		$reflection = new \ReflectionFunction($callback);

		return __('Closure', 'wpsd-debug').' ('.basename($reflection->getFileName()).':'.$reflection->getStartLine().')';

	}

	return get_class($callback).'::__invoke';

}
