<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function do_fetch_main($value){ 

	global $wp_filter;

	$selected = $_POST['fetch-callable'] ?? '';

	if( !is_string($selected) ){

		return false;

	}

	$original_hook = $wp_filter[Consts::HOOK_FETCH] ?? null;

	if( $selected !== '' && $selected !== 'all' ){

		$found = false;

		foreach( $original_hook->callbacks ?? [] as $priority => $callbacks ){

			foreach( array_values($callbacks) as $index => $callback ){

				if( $selected !== $priority.':'.$index ){

					continue;

				}

				$found = true;

			}

		}

		if( !$found ){

			return false;

		}

		foreach( $original_hook->callbacks as $priority => $callbacks ){

			foreach( array_values($callbacks) as $index => $callback ){

				if( $selected === $priority.':'.$index ){

					continue;

				}

				remove_action(Consts::HOOK_FETCH, $callback['function'], $priority);

			}

		}

	}
	
	$hrtime_start = hrtime(true);
	
	do_action(Consts::HOOK_FETCH, $value);

	$hrtime_end = hrtime(true);

	defined('WPSD_TM_START') || define('WPSD_TM_START',$hrtime_start);//can be defined in the hook

	defined('WPSD_TM_END') || define('WPSD_TM_END', $hrtime_end);//can be defined in the hook

}


if( $_POST['nonce'] !== Consts::get_nonce() || empty($_POST['hook']) ){

	http_response_code( 401 );

	die('Unauthorized Access');
}

switch( $_POST['hook'] ){
	case 'now':
		do_fetch_ajax();
		break;
	case 'plugins_loaded':
		add_action('plugins_loaded', __NAMESPACE__.'\\do_fetch_ajax');
		break;
	case 'init':
		add_action('init', __NAMESPACE__.'\\do_fetch_ajax');
		break;
	case 'wp_ajax':
		add_action('wp_ajax_'.Consts::AJAX_QS_FETCH, __NAMESPACE__.'\\do_fetch_ajax');
		break;
	default:
		http_response_code( 401 );
		die('Bad request');
		break;
}

function do_fetch_ajax(){
	
	$value = sanitize_text_field( wp_unslash( $_POST['fetch-value']??'' ) );

	$start_measure = hrtime(true);
	
	do_fetch_main($value);
	
	$end_measure = hrtime(true);
	
	$start = defined('WPSD_TM_START') ? WPSD_TM_START : $start_measure;
	
	$end = defined('WPSD_TM_END') ? WPSD_TM_END : $end_measure;
	

	$difference_measure = $end - $start;
	foreach(['s'=>1e9,'ms'=>1e6,'µs'=>1e3,'ns'=>1] as $unit=>$scale){
		if($difference_measure >= $scale){echo '<br><br>'.round($difference_measure/$scale,($unit==='s'?3:1)).' '.$unit;break;}
	}
	die;
}
