<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;


switch($_GET['act']){

	case 'email-test':
	
		require_once '/home/jaro/FlyEnv/sites/plugin-filter/wordpress/wp-includes/pluggable.php';
		\wp_mail('jaro@me.me', 'Test', 'Test-email '.md5(uniqid()).md5(uniqid()).md5(uniqid()).md5(uniqid()).md5(uniqid()).md5(uniqid()).md5(uniqid()).md5(uniqid()));
		break;
	case 'wp-remote-get':
				
		wp_remote_get('http://plugin-filter.local/test-404.php', [
			'timeout' => 1,

				'redirection' => 0,

				'httpversion' => '1.1',

		]);
		break;
	case 'wp-remote-post':
				
		wp_remote_post('http://plugin-filter.local/test-404.php', [
				'timeout' => 1,

				'redirection' => 0,

				'httpversion' => '1.1',

				'user-agent' => 'WPSD PHP Debug',

				'reject_unsafe_urls' => false,

				'blocking' => true,

				'headers' => [
					'Accept' => 'application/json',

					'Content-Type' => 'application/json',
				],

				'cookies' => [
					new \WP_Http_Cookie([
						'name' => 'wpsd-debug',

						'value' => 'failed-request',
					]),
					new \WP_Http_Cookie([
						'name' => 'wpsd-debug2',

						'value' => 'failed-request2',
					]),
				],

				'body' => wp_json_encode([
					'fetch_value' => uniqid(),
				]),

				'compress' => false,

				'decompress' => true,

				'sslverify' => false,

				'sslcertificates' => ABSPATH . WPINC . '/certificates/ca-bundle.crt',

				'stream' => false,

				'filename' => null,

				'limit_response_size' => 1024,
		]);

		break;
	case 'wpdb-error':

		//describe table abcd

		global $wpdb;

		$result = $wpdb->query("DESCRIBE {$wpdb->prefix}abcd");

		
		deb( $result , basename(__FILE__).' at '.__LINE__ );
		
		

		break;

	case 'wrong':

		$a = __('a','abc');

		break;

	case 'deprecated':

		_deprecated_function('test_old_function', '6.0.0', 'test_new_function');

		_deprecated_argument('test_function', '6.0.0', 'The $arg parameter is deprecated.');

		// _deprecated_file('test-old-file.php', '6.0.0', 'test-new-file.php');



		// add_action('test_old_action', '__return_null');

		// add_filter('test_old_filter', function($value){

		// 	return $value;

		// });

		// do_action_deprecated('test_old_action', array('value'), '6.0.0', 'test_new_action');

		// $value = apply_filters_deprecated('test_old_filter', array('value'), '6.0.0', 'test_new_filter');
		


		// _deprecated_class('Test_Old_Class', '6.0.0', 'Test_New_Class');
		// __('a');
		// _doing_it_wrong('test_function', 'This is not correct.', '6.0.0');
		// test_doing_it_wrong_function();

		break;

	case 'wp-remote':

		// add_action(
		// 	'http_api_curll',
		// 	function( $handle, $parsed_args, $url ) {

		// 		if ( !str_contains( $url, 'ec.europa.eu/taxation_customs/vies/' ) ) {
		// 				return;
		// 		}

		// 		// curl_setopt( $handle, CURLOPT_ENCODING, '' );

		// 		curl_setopt( $handle, CURLOPT_HTTPHEADER, array(
		// 			'Accept-Encoding: ',
		// 			// 'Connection: close',
		// 		) );
		// 	},
		// 	10,
		// 	3
		// );

		// add_filter('http_request_args', function($args, $url) {
	
		// 	if( str_contains( $url, 'ec.europa.eu/taxation_customs/vies/' ) ) {
				
		// 		$args['headers']['Accept-Encoding'] = '';
		// 	}
			
		// 	return $args;
			
		// }, 10, 2);

		// add_action( 'http_api_debug', function( $response, $context, $class, $parsed_args, $url ){

		// 	// if ( 'response' !== $context ) return false;

		// 	// if ( ! is_wp_error( $response ) ) return false;
		// 	$data = [
		// 		'url' => $url,
		// 		'response_code' => $response->get_response_code(),
		// 		'error_code' => $response->get_error_code(),
		// 		'error_message' => $response->get_error_message()
		// 	];

		// 	vd($data);
		// }, 10, 5 );

		$response = wp_safe_remote_get(
				"https://ec.europa.eu/taxation_customs/vies/rest-api/ms/sk/vat/SK2121889891",
				array(
					'timeout'    => 10,
					'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
					'sslverify'  => true,
					// 'httpversion' => '1.1',
					// 'reject_unsafe_urls' => false,
					// 'headers' => array(
					// 	'Accept-Encoding' => '',
					// ),
				)
				// array(
				// 	'timeout'    => 10,
				// 	// 'redirection' => 3,

				// 	// 'httpversion' => '1.1',
				// 	// 'reject_unsafe_urls' => false,
				// 	// 'headers' => array(
				// 	// 	'Accept-Encoding' => 'identity',
				// 	// 	'Connection' => 'close',
				// 	// ),

				// 	'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
				// 	'sslverify'  => true,
				// )
			);
			
	debu($response);
		break;

	case 'db-dir':
		
		$db_folder_content = scandir(WP_CONTENT_DIR.'/database/');

		$db_folder_content = array_diff($db_folder_content,['.','..','index.php']);

		deb( $db_folder_content , basename(__FILE__).' at '.__LINE__ );
		
		
		break;

	case 'rename-ht':
		require Consts::DIR.'admin/setup.php';
		append_string_to_filename(Consts::DIR.'play/', '.sqlite');
		die;

	case 'debl-marker':
		deb();
		break;
	case 'debl':
		// debl(date('Y-m-d H:i:s'));
		debl(1);
		break;

	case 'php-files':
		add_action ( (WPSD_REQUEST_TYPE === REQUEST_ADMIN) ? 'admin_footer' : 'shutdown' , 'the_wpsd_used_php' , 1000 );

		break;

	case 'hook-content':

		add_filter('the_content', function($content){

			// ini_set('display_errors', '1');
		
			// ini_set('display_startup_errors', 1);
		
			// error_reporting(E_ALL);
			$content .= $a.'qwe';
		
			return $content;
		
		});
		
		break;

	case 'used-php':
		 the_wpsd_used_php();
		 break;

	case 'recovery':

		require Consts::DIR.'includes/cron/recovery-sqlite.php';

		
		$microtime_int = floatval( time() );
		$start_time_measure = microtime(true)-$microtime_int;
		
		recover_broken_sqlite_db( get_db_filepath() );

		$end_time_measure = microtime(true)-$microtime_int;
		dtm( $start_time_measure, $end_time_measure );
		
		
		break;

	case 'is-file':
		
        
		deb( file_exists( Consts::DIR.'must-use-plugin/ajax/source-error-log.php') , basename(__FILE__).' at '.__LINE__ );
		
		break;
		
	case 'rmdir':

		$dir = __DIR__.'/a/';

		if(!is_dir($dir)){
			return;
		}
	
		$d = dir($dir);
	
		while(($file = $d->read()) !== false){

				if(  $file==='.' || $file==='..') continue;

				unlink($dir . DIRECTORY_SEPARATOR . $file);
		}
	
		$d->close();

		rmdir($dir);
		break;

	case 'fragment':
		
		
		deb( 'not active' , basename(__FILE__).' at '.__LINE__ );
		
		
		
		// $microtime_int = floatval( time() );
		// $start_time_measure = microtime(true)-$microtime_int;
		
		// // require Consts::DIR.'includes/fragments-recorder.php';

		// // record_bulk_fragments();

		// // record_fragments_into_db();
		
		// $end_time_measure = microtime(true)-$microtime_int;
		// dtm( $start_time_measure, $end_time_measure );
		
		
		
		
		
		break;
	case 'fatal':

		qwe();
		break;
	case 'tm':

		
		$microtime_int = floatval( time() );
		$start_time_measure = microtime(true)-$microtime_int;

		usleep(5000);
		// $j=0;

		// for($i=1;$i<10000;++$i){
		// 	++$j;

		// }
		$end_time_measure = microtime(true)-$microtime_int;

		deb( tm($start_time_measure,$end_time_measure) );
		
		break;
	
	case 'files':
		the_wpsd_used_php();
		break;
		
	case 'hook':
		add_action('wp', __NAMESPACE__.'\wp_hook_callable' );
		break;
	case 'blog-id':
		
		break;
	case 'vd-class':
		$test_vd = new Test_VD();

		$test_vd->exec_vd();

		die;
		break;
	case 'vd':
		
		vd('abc');
		die;
		break;

	case 'warning':
		
		echo $asdfghjk;

		break;

	case 'warnings':

		// for($i=1;$i<1000;++$i){
			
			warnings();
		// }


		// deb('warning');
		// echo $asd1;
		// echo $asd2;
		// echo $asd3;
		// echo $asd4;
		// echo $asd5;
		// echo $asd6;
		// echo $asd7;
		// echo $as8;
		// echo $asd9;
		// echo $asd10;
		// echo $asd11;
		break;

	case 'deb':
// vd('abc');
		// define('WPSD_DEBUG_TEST', uniqid() );

		// deb(WPSD_DEBUG_TEST);

		deb(microtime(true));
	
	// deb(time() , basename(__FILE__).' at '.__LINE__ );
	// deb(time() , basename(__FILE__).' at '.__LINE__ );
	
		break;

	case 'multi':
		
		for($i=1;$i<30;++$i){
		multi_curl();
		}
		break;

	case 'stw':

		stw();

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);

		for($i=1;$i<rand(800000,10000000);++$i){
			md5($i);
		}
		stw(true);
		
		break;
		
}



function warnings(){
	// 1. Undefined variable notice
echo $undefined_variable;

// 2. Array index undefined notice
$array = ['key' => 'value'];
echo $array['undefined_key'];

// 3. Division by zero warning
$non_object = 123;
echo $non_object->property;

// 4. Invalid argument supplied for foreach warning
foreach ($undefined_variable as $item) {
    echo $item;
}

// 5. Missing argument warning
$float = 123.45;
$array = [$float => 'value'];

// 6. Deprecated function warning (if applicable to your PHP version)
$string = '';
$string++;

// 7. Using a non-object warning
$non_object = null;
echo $non_object->property;

// 8. Invalid argument supplied for array_merge warning
array_key_exists(null, ['key' => 'value']);

// 9. Creating default object from empty value warning
$instance = new MyClass();

// Accessing the deprecated property
echo $instance->deprecated_property;

}

class MyClass {
    /** @deprecated Use $new_property instead */
    public $deprecated_property = "This is deprecated.";

    public $new_property = "Use this instead.";
}


function is_new_lock_set_(){
	global $wpdb;

	$result = $wpdb->query("UPDATE {$wpdb->options} SET option_value = '1' WHERE option_name = 'wpsd-php-debug-lock-x' AND option_value = '0'");

	
	deb( $result , basename(__FILE__).' at '.__LINE__ );
	
}


function wp_hook_callable(){

	// update_site_option('asd','qwe');
// deb( get_site_option('asd') , basename(__FILE__).' at '.__LINE__ );


// $microtime_int = floatval( time() );
// $start_time_measure = microtime(true)-$microtime_int;
// get_wpsd_option('wpsd-debug-values');
// $end_time_measure = microtime(true)-$microtime_int;
// dtm( $start_time_measure, $end_time_measure );



}

function multi_curl(){

	$home_url = get_home_url();

	$i=0;
	$urls = [
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		// "http://dev-plugins.local/?thread=".++$i,
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",
		"{$home_url}/?act=warning",

	// ];
	// $urls = [
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
	// 	"{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",
		// "{$home_url}/?empty-test",

	];

	$multi_handle = curl_multi_init();

	$curl_handles = [];

	foreach( $urls as $key => $url ){

		$parsed_url = parse_url($url);

		$full_base = "http://{$_SERVER['SERVER_ADDR']}{$parsed_url['path']}";

		$query_string = ($parsed_url['query'] ?? '') === '' 
			? "?thread={$key}" 
			: "?{$parsed_url['query']}&thread={$key}";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $full_base . $query_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, ['Host: ' . $parsed_url['host']]);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_multi_add_handle($multi_handle, $ch);
		$curl_handles[] = $ch;
	}

	do {
		curl_multi_exec($multi_handle, $running);
		curl_multi_select($multi_handle);
	} while( $running > 0 );

	$results = [];
	foreach( $curl_handles as $ch ){
		$response = curl_multi_getcontent($ch);
		$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$body = substr($response, $header_size);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$redirect_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
		$error = curl_error($ch);

		$results[] = [
			'content' => htmlentities( mb_substr($body, 0, 100)),
			'error' => $error,
			'response_code' => $http_code,
			'redirect_url' => $redirect_url,
		];

		curl_multi_remove_handle($multi_handle, $ch);

	}

	curl_multi_close($multi_handle);

}


class Test_VD{

	public function __construct(){
		vd( 'constructed' );
	}

	public function exec_vd(){
	
		vd( 'executed' );
		
	}
}

function test_doing_it_wrong_function(){
	_doing_it_wrong(__FUNCTION__, 'This is not correct.', '6.0.0');
}
