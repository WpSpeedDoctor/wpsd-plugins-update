<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function store_admin_bar_menu_items(){

	ob_start();

	add_action('adminmenu', __NAMESPACE__.'\store_captured_admin_menu_items', PHP_INT_MAX);

}

function store_captured_admin_menu_items(){

	$html = ob_get_clean();

	if($html === false){

		return false;

	}

	$items = get_all_admin_menu_items($html);

	if($items){

		set_wpsd_transient(Consts::TRANSIENT_MENUS, $items, HOUR_IN_SECONDS);

	}

	echo $html;

}

function get_all_admin_menu_items($html = ''){

	if(!$html){

		return [];

	}

	$document = get_admin_menu_document($html);

	if(!$document){

		return [];

	}

	$xpath = new \DOMXPath($document);

	$menus = $xpath->query('//ul[@id="adminmenu"]/li[not(contains(concat(" ", normalize-space(@class), " "), " wp-menu-separator ")) and @id!="collapse-menu"]');

	if(!$menus){

		return [];

	}

	$items = [];

	foreach($menus as $menu){

		$menu_link = get_admin_menu_link($xpath, $menu);

		if(!$menu_link){

			continue;

		}

		$menu_path = get_admin_menu_path($menu_link->getAttribute('href'));

		$menu_name = get_admin_menu_name($xpath, $menu);

		if(!$menu_path || !$menu_name){

			continue;

		}

		$items[$menu_path] = [
			'name' => $menu_name,
			'path' => $menu_path,
		];

		$submenus = $xpath->query('./ul[contains(concat(" ", normalize-space(@class), " "), " wp-submenu ")]/li[not(contains(concat(" ", normalize-space(@class), " "), " wp-submenu-head "))]', $menu);

		foreach($submenus as $submenu){

			$submenu_link = get_admin_menu_link($xpath, $submenu);

			if(!$submenu_link){

				continue;

			}

			$submenu_path = get_admin_menu_path($submenu_link->getAttribute('href'));

			$submenu_name = trim(wp_strip_all_tags($submenu_link->textContent));

			if(!$submenu_path || !$submenu_name){

				continue;

			}

			$submenu_key = isset($items[$submenu_path]) ? $menu_path.'|'.$submenu_path : $submenu_path;

			$items[$submenu_key] = [
				'name'		=> $submenu_name,
				'path'		=> $submenu_path,
				'compound'	=> $menu_name.' > '.$submenu_name,
				'sub'		=> true,
			];

		}

	}

	return $items;

}

function get_admin_menu_document($html){

	if(!class_exists('DOMDocument')){

		return false;

	}

	$document = new \DOMDocument();

	$previous_errors = libxml_use_internal_errors(true);

	$loaded = $document->loadHTML('<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$html);

	libxml_clear_errors();

	libxml_use_internal_errors($previous_errors);

	if(!$loaded){

		return false;

	}

	return $document;

}

function get_admin_menu_link($xpath, $node){

	$links = $xpath->query('./a', $node);

	if(!$links || !$links->length){

		return false;

	}

	return $links->item(0);

}

function get_admin_menu_name($xpath, $node){

	$names = $xpath->query('./a/div[contains(concat(" ", normalize-space(@class), " "), " wp-menu-name ")]', $node);

	if(!$names || !$names->length){

		return false;

	}

	return trim(wp_strip_all_tags($names->item(0)->textContent));

}

function get_admin_menu_path($path){

	$path = html_entity_decode((string) $path, ENT_QUOTES, get_bloginfo('charset') ?: 'UTF-8');

	$admin_url = admin_url();

	if(str_starts_with($path, $admin_url)){

		$path = substr($path, strlen($admin_url));

	}

	$path = ltrim($path, '/');

	if(!$path || str_starts_with($path, '#')){

		return false;

	}

	return $path;

}
