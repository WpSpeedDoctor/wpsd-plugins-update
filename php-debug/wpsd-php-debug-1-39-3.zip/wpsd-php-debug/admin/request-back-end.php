<?php

namespace WPSD\debug\v2;

use \WPSD\shared\Shared_Admin_Menu;

defined( 'ABSPATH' ) || exit;

global $pagenow;

$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

/**
 * Plugin setup
 */
if ( $page_now === 'plugins.php' ) {
	
	require_once Consts::DIR.'admin/setup.php';

	plugin_setup_main($file);

}	

/**
 * Admin menus
 */
add_action('init', __NAMESPACE__.'\wpsd_shared_menu');


if(isset($_GET[Consts::SLUG]) && $page_now === 'tools.php'){

	require_once Consts::DIR.'admin/admin-bar-menus.php';
	
	add_action('admin_menu', __NAMESPACE__.'\store_admin_bar_menu_items', PHP_INT_MAX);

}

function wpsd_shared_menu(){

	if( !class_exists('WPSD\shared\Shared_Admin_Menu') ){

		require Consts::DIR.'shared/class-admin-menu.php';
	}

	global $pagenow;

	$page_now = empty($pagenow) ? basename( WPSD_URI_PATH ) : $pagenow;

	Shared_Admin_Menu::set_title(__( 'WPSD Plugins', 'wpsd-debug' ));

	add_action('admin_menu', [Shared_Admin_Menu::class, 'add_shared_wpsd_menu']);

	add_filter(Shared_Admin_Menu::FILTER_SUBMENUS, __NAMESPACE__.'\add_wpsd_submenu');

	Shared_Admin_Menu::set_title(__( 'WPSD Plugins', 'ls-css-helper' ));

	if ( $page_now === 'admin.php' && ($_GET['page']??'') == Consts::PAGE_ADMIN ) {

		require Consts::DIR.'includes/menu/wp-admin-menu.php';
	}
}

function add_wpsd_submenu($submenus){

	$submenus[] = [
		__( 'Advanced PHP Debug', 'wpsd-debug' ),
		Consts::PAGE_ADMIN,
		__NAMESPACE__.'\admin_menu_main',
	];

	return $submenus;
}

/**
 * Other back-end parts
 */

require_once Consts::DIR.'admin/update.php';

require_once Consts::DIR.'includes/cron/cron.php';
