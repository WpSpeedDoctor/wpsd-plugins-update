<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

defined('QM_DISABLE_ERROR_HANDLER') || define('QM_DISABLE_ERROR_HANDLER',true);

defined('WP_DISABLE_FATAL_ERROR_HANDLER') || define('WP_DISABLE_FATAL_ERROR_HANDLER',true);

set_php_error_reporting();

set_error_handlers();

add_action('wp_mail_failed', __NAMESPACE__.'\log_failed_email');

add_action('plugins_loaded', __NAMESPACE__.'\set_error_handlers' );

add_action('http_api_debug', __NAMESPACE__.'\http_request_error_handler', 10, 5);

register_shutdown_function( __NAMESPACE__.'\shutdown_handler');

//TODO:Remove in future, it's here only to prevent PHP fatal error on rare occurrence
if( !function_exists( __NAMESPACE__.'\get_wpsd_option') ){
	function get_wpsd_option($name){

		return is_multisite() ? get_site_option( $name ) : get_option( $name );
	}
}

function set_error_handlers(){

	set_error_handler( __NAMESPACE__.'\error_handler');

	set_exception_handler( __NAMESPACE__.'\exception_handler');

}

function shutdown_handler(){

	require_error_handler_private();

	shutdown_handler_private();

}

function http_request_error_handler( $response, $context, $class, $args, $url ){

	require_error_handler_private();

	return http_request_error_handler_private( $response, $context, $class, $args, $url );

}

function exception_handler( \Throwable $e){

	require_error_handler_private();

	exception_handler_private($e);

}

function error_handler( $error_code, $error_string, $error_file, $error_line ){

	require_error_handler_private();

	return error_handler_private( $error_code, $error_string, $error_file, $error_line );

}

function set_php_error_reporting(){

	ini_set('log_errors', '1' );

	ini_set('ignore_repeated_errors', '1' );

	ini_set('ignore_repeated_source', '1' );

	$reporting_code = get_wpsd_option( Consts::OPTION_REPORTING) ?: E_ALL;

	error_reporting( $reporting_code );

	activate_display_errors();

	if( get_wpsd_option(Consts::OPTION_INI_STATUS) ){

		ini_set( 'error_log', get_error_log_filepath() );

	}

	// if( $reporting_code & E_USER_WARNING !== 0  ){

		// add_action('doing_it_wrong_run', __NAMESPACE__ . '\trigger_doing_it_wrong_warning', 10, 3);

	// }

}

function get_error_log_filepath(){

	if( defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG) && is_writable(WP_DEBUG_LOG) ){

		return WP_DEBUG_LOG;

	}

	return WP_CONTENT_DIR.'/debug'.get_multisite_and_ip_string().'.log';

}

function activate_display_errors(){

	$display_error = is_error_displayed();

	ini_set('display_errors', $display_error );

	ini_set('display_startup_errors', $display_error );

}

function is_error_displayed(){

	switch(true){

		case !isset($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS]):
		case !is_screen_output_allowed():
		case $_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] != Consts::get_nonce():
			return false;
		default:
			return true;

	}

}

function is_screen_output_allowed(){

	switch( WPSD_REQUEST_TYPE ){

		case REQUEST_FRONTEND:
		case REQUEST_ADMIN:
		case REQUEST_LOGIN:
		case REQUEST_DIRECT:
		case REQUEST_404:
			return true;
		default:
			return false;

	}

}

function log_failed_email($error){

	require_error_handler_private();

	return log_failed_email_private($error);

}


function require_error_handler_private(){
	require_once Consts::DIR.'must-use-plugin/errors/error-handler-private.php';
}

function trigger_doing_it_wrong_warning($function_name, $message, $version){
		
	$text_called = is_textdomain_loaded('wpsd-debug') ? __('was called incorrectly.', 'wpsd-debug') : 'was called incorrectly.';
	$text_added = is_textdomain_loaded('wpsd-debug') ? __('This message was added in version', 'wpsd-debug') : 'This message was added in version';

	trigger_error("{$function_name} {$text_called} {$message} {$text_added} {$version}.", E_USER_WARNING);

}