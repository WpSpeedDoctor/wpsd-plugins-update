<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

function shutdown_handler_private(){

	store_php_fatal_error();

	if( defined('WPSD_DEBUG_SHUTDOWN') ){

		debug_shutdown_main();

	}

	if( defined('WPSD_DEBL_SHUTDOWN') && !defined('WPSD_DEBUG_SHUTDOWN') && is_callable(__NAMESPACE__.'\add_deb_to_log_wpsd') ){

		add_deb_to_log_wpsd();

	}

	if( defined('WPSD_DEB_SHUTDOWN') && is_callable(__NAMESPACE__.'\store_deb_values_wpsd') ){

		store_deb_values_wpsd();

	}

	if( defined('WPSD_PHP_TIME_SHUTDOWN') && is_callable(__NAMESPACE__.'\add_php_time_script') ){

		add_php_time_script();

	}

}

function http_request_error_handler_private( $response, $context, $class, $args, $url ){

	if( $context !== 'response' ){

		return false;

	}

	$method = $args['method'] ?? 'GET';

	if( is_wp_error($response) ){

		$message = "WP HTTP {$method} request failed for {$url}: {$response->get_error_message()}";

		return error_handler(65536, $message, '', '');

	}

	$status_code = (int) ($response['response']['code'] ?? 0);

	if( $status_code < 400 ){

		return false;

	}

	$status_message = $response['response']['message'] ?? '';

	$message = "WP HTTP {$method} request failed for {$url}: {$status_code} {$status_message}";

	return error_handler(65536, trim($message), '', '');

}

function exception_handler_private( \Throwable $e){

	$type = E_ERROR;

	$file = $e->getFile();

	$line = $e->getLine();

	$trace = $e->getTraceAsString();

	$message = $e->getMessage();

	$error_message = $message ."\n\n{$file}:{$line}\n". PHP_EOL . 'Stack trace:' . PHP_EOL . $trace;

	error_handler($type, $error_message, $file, $line);

	$php_log_line = sprintf(
		'PHP Fatal error:  Uncaught %s: %s in %s:%d%sStack trace:%s%s',
		get_class($e),
		$e->getMessage(),
		$e->getFile(),
		$e->getLine(),
		PHP_EOL,
		PHP_EOL,
		$e->getTraceAsString()
	);

	if(error_reporting() & E_ERROR){

		error_log($php_log_line);

	}

	if(
		!isset($_COOKIE[Consts::COOKIE_DISPLAY_ERRORS]) ||
		$_COOKIE[Consts::COOKIE_DISPLAY_ERRORS] != Consts::get_nonce()
	){

		return;

	}

	echo <<<HTML
	<br><div style="white-space: break-spaces;line-height: 2;font-family: monospace;">
	$php_log_line
	</div><br>
	HTML;

}

function store_php_fatal_error(){

	global $EZSQL_ERROR;

	if( !empty($EZSQL_ERROR) ){

		foreach( $EZSQL_ERROR as $sql_errors ){

			error_handler( 32768 , "{$sql_errors['error_str']}\n\n{$sql_errors['query']}" , '', '' );

		}

	}

	if( !isset(error_get_last()['type']) ){

		return false;

	}

	switch( error_get_last()['type'] ){

		case E_ERROR:
		case E_PARSE:
		case E_CORE_ERROR:
		case E_COMPILE_ERROR:
		case E_USER_ERROR:

			$last_error = error_get_last();

			error_handler( $last_error['type'], $last_error['message'], $last_error['file'], $last_error['line'] );

			break;

	}

}

function error_handler_private( $error_code, $error_string, $error_file, $error_line ){

	$settings = get_plugin_settings();

	if( in_array( (int) $error_code , $settings['excluded_errors']??[] ) ){

		return true;

	}

	$stored_message = $error_string;

	if( !empty($error_file) && !str_contains($error_string, $error_file ) ){

		$stored_message .= "\n\n{$error_file}:{$error_line}";

	}

	//sometimes the stack trace is not in the error message
	if( !str_contains($error_string,'Stack trace:') && $error_code !== 32768 ){

		$stored_message .= "\n\n".get_stack($error_code);

	}

	foreach( $settings['excluded_logging_strings']??[] as $excluded_logging_string ){

		if( $excluded_logging_string !== '' && str_contains($stored_message, $excluded_logging_string) ){

			return true;

		}

	}

	errors_storage( [

		0 => $error_code,

		1 => remove_abspath( $stored_message ),

	]);

	if( !defined('WPSD_DEBUG_SHUTDOWN') ){

		define('WPSD_DEBUG_SHUTDOWN', true );

	}

	move_older_error_log_to_archive();

	return false;

}

function errors_storage( $data_input='', $retreive=false ){

	static $wpsd_debug_errors;

	static $fragment_file;

	static $fragment_filepath;

	if( $retreive ){

		return retrieve_stored_errors( $wpsd_debug_errors, $fragment_file, $fragment_filepath );

	}

	return store_error( $data_input, $wpsd_debug_errors, $fragment_file, $fragment_filepath );

}

function retrieve_stored_errors( &$wpsd_debug_errors, &$fragment_file, &$fragment_filepath ){

	if( !$fragment_file ){

		return $wpsd_debug_errors;

	}

	fflush($fragment_file);

	rewind($fragment_file);

	$wpsd_debug_errors = [];

	while( !feof($fragment_file) ){

		$length_data = fread($fragment_file, 4);

		if( strlen($length_data) !== 4 ){

			break;

		}

		$length = unpack('Nlength', $length_data)['length'];

		$serialized_error = '';

		while( strlen($serialized_error) < $length ){

			$serialized_error_part = @fread($fragment_file, $length - strlen($serialized_error));

			if( $serialized_error_part === false || $serialized_error_part === '' ){

				break 2;

			}

			$serialized_error .= $serialized_error_part;

		}

		$wpsd_debug_errors[] = unserialize($serialized_error, ['allowed_classes' => false]);

	}

	fclose($fragment_file);

	unlink($fragment_filepath);

	$fragment_file = null;

	$fragment_filepath = null;

	return $wpsd_debug_errors;

}

function store_error( $data_input, &$wpsd_debug_errors, &$fragment_file, &$fragment_filepath ){

	if( $fragment_file ){

		if( write_error_to_fragment( $fragment_file, $data_input ) ){

			return;

		}

		$wpsd_debug_errors = retrieve_stored_errors( $wpsd_debug_errors, $fragment_file, $fragment_filepath );

		$wpsd_debug_errors[] = $data_input;

		return false;

	}

	$wpsd_debug_errors[] = $data_input;

	if( count($wpsd_debug_errors) < Consts::MAX_ERRORS_IN_MEMORY ){

		return;

	}

	$fragment_filepath = Consts::DB_DIR.get_random_fragment_filename();

	$fragment_file = @fopen($fragment_filepath, 'x+b');

	if( !$fragment_file ){

		$fragment_filepath = null;

		return false;

	}

	foreach( $wpsd_debug_errors as $error_event ){

		if( write_error_to_fragment( $fragment_file, $error_event ) ){

			continue;

		}

		fclose($fragment_file);

		unlink($fragment_filepath);

		$fragment_file = null;

		$fragment_filepath = null;

		return false;

	}

	$wpsd_debug_errors = [];

}

function write_error_to_fragment( $fragment_file, $error_event ){

	$serialized_error = serialize($error_event);

	$fragment_data = pack('N', strlen($serialized_error)).$serialized_error;

	$fragment_data_length = strlen($fragment_data);

	$fragment_position = ftell($fragment_file);

	if( $fragment_position === false ){

		return false;

	}

	$written_length = 0;

	while( $written_length < $fragment_data_length ){

		$write_length = @fwrite($fragment_file, substr($fragment_data, $written_length));

		if( $write_length === false || $write_length === 0 ){

			ftruncate($fragment_file, $fragment_position);

			fseek($fragment_file, 0, SEEK_END);

			return false;

		}

		$written_length += $write_length;

	}

	return true;

}
//todo:remove in future when all error codes are covered
// $filepath = __DIR__ ."/{$error_code}.json";
// !file_exists($filepath) && file_put_contents( $filepath , json_encode( $exception->getTrace(), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE,JSON_UNESCAPED_SLASHES ) );

//todo: shorten stack when doing_it_wrong();
// _load_textdomain_just_in_time was called incorrectly.
function get_stack($error_code){

	$exception = new \Exception();

	$trace = array_reverse($exception->getTrace());

	$lines = [];

	$additional_data = false;

	switch($error_code){

		case 65536:

			$additional_data = get_failed_http_request_data_from_trace($trace);

			break;

	}

	foreach($trace as $index => $frame){

		$class = $frame['class'] ?? '';

		$function = $frame['function'] ?? '{main}';

		$frame_arguments = $frame['args'] ?? [];

		
		//MARK:FRAME DEB
		// if( str_contains( var_export($frame,true),'Test-email'  ) ) {
		// vd( $frame );
		// }
		//breaking here for function excluded from log
		switch(true){

			case $function === __NAMESPACE__.'\\error_handler_private':

			case 65536 === $error_code && 'WP_Http' === $class:

			case 65537 === $error_code && 'do_action' === $function && 'wp_mail_failed' === ($frame_arguments[0] ?? ''):

				break 2;

		}

		$file = $frame['file'] ?? '[internal function]';

		$line = $frame['line'] ?? 0;

		$type = $frame['type'] ?? '';

		$arguments = [];
		//MARK: ARGS
		foreach($frame_arguments as $argument){

			// $arguments[] = format_trace_argument($argument);
			$arguments[] = get_value_as_string($argument);

		}

		// if( str_starts_with($function, 'wp_remote_') ){

		// 	$arguments[1] = '$args';

		// }

		$arguments = implode(', ', $arguments);

		$lines[] = remove_abspath("#{$index} {$file}:{$line} {$class}{$type}{$function}({$arguments})");

		// breaking here for functions that do remain in log
		switch($function){
			case '_doing_it_wrong':
			case '_deprecated_class':
			case 'apply_filters_deprecated':
			case 'do_action_deprecated':
			case '_deprecated_file':
			case '_deprecated_argument':
			case '_deprecated_function':
				break 2;

		}
	}

	if ( false !== $additional_data ) {

		$lines[] = '';

		$lines[] = get_failed_request_data( $additional_data );

	}

	
	return implode("\n", array_reverse($lines) );

}

function get_failed_http_request_data_from_trace($trace){

	foreach($trace as $frame){

		$arguments = $frame['args'] ?? [];

		$class_index = array_search('WpOrg\\Requests\\Requests', $arguments, true);

		if( false === $class_index ){

			continue;

		}

		return get_failed_http_request_data($frame, $class_index);

	}

	return false;

}

function get_failed_request_data( $data ) {

	$result = '';

	foreach ( $data as $section => $values ) {

		$result .= "{$section}:\n";

		foreach ( $values as $key => $value ) {

			$label = ucfirst( str_replace( '_', ' ', $key ) );

			$value = get_value_as_string( $value );

			$value = str_replace( "\n", "\n  ", $value );

			$result .= "  {$label}: {$value}\n";

		}

	}

	return rtrim( $result );

}

function get_failed_http_request_data( $frame, $class_index ) {

	$arguments = $frame['args'] ?? [];

	$request = $arguments[$class_index + 1] ?? [];

	$response = $arguments[$class_index - 2] ?? [];

	$response_data = [

		'transport_class' => $arguments[$class_index] ?? null,

	];

	if( is_wp_error($response) ){

		$response_data = [

			'error_code' => $response->get_error_code(),

			'error_message' => $response->get_error_message(),

			'error_data' => $response->get_error_data(),

			'transport_class' => $arguments[$class_index] ?? null,

		];

	}

	if( is_array($response) ){

		$response_data = [

			'status_code' => $response['response']['code'] ?? null,

			'status_message' => $response['response']['message'] ?? null,

			'headers' => $response['headers'] ?? [],

			'body' => $response['body'] ?? null,

			'cookies' => $response['cookies'] ?? [],

			'filename' => $response['filename'] ?? null,

			'transport_class' => $arguments[$class_index] ?? null,

		];

	}

	$request_body = $request['body'] ?? null;

	$decoded_request_body = is_string( $request_body ) ? json_decode( $request_body, true ) : null;

	if ( is_string( $request_body ) && JSON_ERROR_NONE === json_last_error() ) {

		$request_body = $decoded_request_body;

	}

	return [

		'Response' => $response_data,
		
		'Request' => [

			'url' => $arguments[$class_index + 2] ?? null,

			'method' => $request['method'] ?? null,

			'timeout' => $request['timeout'] ?? null,

			'redirection' => $request['redirection'] ?? null,

			'http_version' => $request['httpversion'] ?? null,

			'user_agent' => $request['user-agent'] ?? null,

			'blocking' => $request['blocking'] ?? null,

			'headers' => $request['headers'] ?? [],

			// 'cookies' => $request['cookies'] ?? [],

			'body' => $request_body,

			'ssl_verify' => $request['sslverify'] ?? null,

			'compress' => $request['compress'] ?? null,

			'decompress' => $request['decompress'] ?? null,

			'stream' => $request['stream'] ?? null,

			'filename' => $request['filename'] ?? null,

			'limit_response_size' => $request['limit_response_size'] ?? null,

		],


	];

}

function format_failed_request_value( $value ) {

	$result = match(true){

		$value===null => 'null',

		$value === true => 'true',

		$value === false => 'false',

		is_array($value),
		is_object($value) => get_iterable_as_string($value),
			// json_encode( $value,
			// 	 JSON_PRETTY_PRINT |
			// 	 JSON_UNESCAPED_SLASHES |
			// 	 JSON_UNESCAPED_UNICODE |
			// 	 JSON_INVALID_UTF8_SUBSTITUTE
			// ),

		default => (string) $value
	};

	//250 max length of string
	return strlen($result) > 250 ? substr($result,0,250)."..." : $result;

}

function get_value_as_string($value){

	$result = match(true){

		$value === null => 'null',

		$value === true => 'true',

		$value === false => 'false',

		is_array($value),
		is_object($value) =>  get_iterable_as_string($value),
			// json_encode( $value,
			// 	 JSON_PRETTY_PRINT |
			// 	 JSON_UNESCAPED_SLASHES |
			// 	 JSON_UNESCAPED_UNICODE |
			// 	 JSON_INVALID_UTF8_SUBSTITUTE
			// ),

		is_string($value) => get_truncated_string($value),
		default => (string) $value
	};

	//250 max length of string
	return $result;
					
}

function get_truncated_string($value, $length = 100) {

	return strlen($value) > $length ? substr($value,0,$length)."..." : $value;
}

function get_iterable_as_string($value_arr, $depth = 0){

	if($depth > 15) return var_export($value_arr, true);

	$output = '';

	$padding = str_repeat("\t", $depth);

	$output .= "{$padding}[\n";

	foreach ($value_arr as $key => $value) {

		$child_padding = str_repeat("\t", $depth + 1);

		$show_key = ! is_int($key);

		$label = $show_key ? "{$key}: " : '';

		$next_depth = $depth + 1;

		switch (true) {

			case is_iterable($value):

				if ($show_key) {

					$output .= "{$child_padding}{$key}\n";

					$next_depth = $depth + 2;

				}

				$output .= get_iterable_as_string($value, $next_depth);

				break;

			case $value instanceof \WP_Http_Cookie:

				if ($show_key) {

					$output .= "{$child_padding}{$key}\n";

					$next_depth = $depth + 2;

				}

				$output .= get_iterable_as_string(
					get_object_vars($value),
					$next_depth
				);

				break;

			case is_object($value):

				$output .= "{$child_padding}{$label}"
					. get_class($value)
					. "\n";

				break;

			case is_bool($value):

				$output .= "{$child_padding}{$label}"
					. ($value ? 'true' : 'false')
					. "\n";

				break;

			case is_null($value):

				$output .= "{$child_padding}{$label}null\n";

				break;

			default:
				$value = get_truncated_string($value);
				$output .= "{$child_padding}{$label}{$value}\n";

				break;

		}

	}

	$output .= "{$padding}]\n";

	return $output;

}

function get_itterable_as_string($value,$level=0){
	$padding = str_repeat(" ", $level);
	if($level!==0){

	}
	$result = $padding."[";
	
	foreach($value as $key => $value){


		$result .= "{$padding}{$key}  => ";

		if(is_array($value) || is_object($value)){
			$result .= get_itterable_as_string($value,$level+1);
		}else{
			$result .= get_value_as_string($value);
		}

	}
	$padding=str_repeat(" ", ++$level);

	rtrim($result);
	return (string) $result.']';
}

function format_trace_argument( $argument ) {
	if ( is_string( $argument ) ) {
		return json_encode( $argument, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
	}

	if ( null === $argument ) {
		return 'null';
	}

	if ( is_bool( $argument ) ) {
		return $argument ? 'true' : 'false';
	}

	if ( is_array( $argument ) ) {
		return get_iterable_as_string( $argument );
	}

	if ( is_object( $argument ) ) {
		return get_class( $argument );
	}

	return (string) $argument;
}

function remove_abspath( $string ){

	if( PHP_OS !== 'WINNT' ){

		return str_replace( ABSPATH, '/', $string);

	}

	$string = str_replace('\\','/', $string );

	$abspath = str_replace('\\','/', ABSPATH );

	return str_replace( $abspath, '/', $string);

}

function debug_shutdown_main(){

	if( defined('WPSD_DEBUG_SHUTDOWN_MAIN') ){

		return false;

	}

	define( 'WPSD_DEBUG_SHUTDOWN_MAIN', true );

	record_php_errors();

	display_fatal_error_data();

}

function log_failed_email_private($error){

	if( !is_wp_error($error) ){

		return false;

	}

	$data = $error->get_error_data();

	$headers = $data['headers']??[];

	$from = get_failed_email_from($headers);

	$to = get_failed_email_recipients($data['to']??'');

	$subject = $data['subject']??'';

	$error_message = $error->get_error_message();

	$message = "From: {$from}\nTo: {$to}\nSubject: {$subject}";

	if( $error_message !== '' ){

		$message .= "\nError: {$error_message}";

	}

	return error_handler(65537, $message, '', '');

}

function get_failed_email_recipients($recipients){

	if( !is_array($recipients) ){

		$recipients = [$recipients];

	}

	$addresses = [];

	foreach( $recipients as $recipient ){

		if( is_object($recipient) ){

			try{

				switch( true ){

					case is_callable([$recipient, 'getEmail']):

						$recipient = $recipient->getEmail();

						break;

					case is_callable([$recipient, '__toString']):

						$recipient = (string) $recipient;

						break;

					default:

						$recipient = get_class($recipient);

				}

			}catch( \Throwable $exception ){

				$recipient = get_class($recipient);

			}

		}

		if( !is_string($recipient) || $recipient === '' ){

			continue;

		}

		$addresses[] = $recipient;

	}

	return implode(', ', $addresses);

}

function get_failed_email_from($headers){

	if( is_string($headers) ){

		$headers = explode("\n", str_replace("\r", '', $headers));

	}

	if( !is_array($headers) ){

		return '';

	}

	foreach( $headers as $name => $header ){

		if( is_array($header) ){

			$header = implode(', ', array_filter($header, 'is_string'));

		}

		if( !is_string($header) ){

			continue;

		}

		$header = trim($header);

		if( is_string($name) && strncasecmp($name, 'From', 4) === 0 ){

			return $header;

		}

		if( strncasecmp($header, 'From:', 5) !== 0 ){

			continue;

		}

		return trim(substr($header, 5));

	}

	return '';

}

// 0=> error code
// 1=> error string

function record_php_errors(){

	$wpsd_debug_errors = errors_storage('',true);

	if( !$wpsd_debug_errors ){

		return;
	}

	$wpsd_debug_errors = get_errors_for_logging($wpsd_debug_errors);

	if( !$wpsd_debug_errors ){

		return;
	}

	$timestamp = defined('WP_START_TIMESTAMP') ? WP_START_TIMESTAMP : microtime(true);

	$daytime = date('Y-m-d H:i:s', (int) $timestamp );

	$meta = get_php_error_metadata($timestamp);

	$sql_stored_success = record_event_to_db( get_db_filepath(), $daytime, $wpsd_debug_errors, $meta );

	if(!$sql_stored_success){

		store_fragment( get_this_site_db_filename(), $meta, $daytime, $wpsd_debug_errors );

	}
	
}

function get_errors_for_logging($wpsd_debug_errors){

	//todo:move excluded_logging_strings to store errors, errors containing strings won't be stored in memory or disk
	$excluded_logging_strings = get_plugin_settings()['excluded_logging_strings']??[];

	if( !$excluded_logging_strings ){

		return $wpsd_debug_errors;
	}

	foreach( $wpsd_debug_errors as $key => $error_event ){

		foreach( $excluded_logging_strings as $excluded_logging_string ){

			if( $excluded_logging_string !== '' && str_contains($error_event[1], $excluded_logging_string) ){

				unset($wpsd_debug_errors[$key]);

				break;
			}
		}
	}

	return $wpsd_debug_errors;
}

/**
 * @return boolean true if the data been successfully stored
 */
function record_event_to_db( $db_filepath, $daytime, $wpsd_debug_errors, $meta ){
	
	require_once Consts::DIR.'includes/create-sqlite-db.php';

	$db = null;

	$transaction_started = false;

	$transaction_completed = false;

	try {

		if( !create_sqlite_db($db_filepath) ) {

			return false;
		}
				
		$temp_storage_markup = filesize($db_filepath) > 100 * MB_IN_BYTES ? 'FILE' : 'MEMORY';

		$db = new \SQLite3( $db_filepath );

		$db->enableExceptions( true );

		$db->exec('PRAGMA synchronous = OFF');
		$db->exec('PRAGMA journal_mode = OFF');
		$db->exec('PRAGMA cache_size = 100000');
		$db->exec('PRAGMA foreign_keys = OFF');
		$db->exec('PRAGMA temp_store = '.$temp_storage_markup);
		$db->exec('PRAGMA locking_mode = EXCLUSIVE');
		$db->exec('PRAGMA auto_vacuum = NONE');
		$db->exec('BEGIN EXCLUSIVE');

		$transaction_started = true;

		$meta_id = record_event_meta( $db, $meta );

		if( $meta_id === false ) return false;

		$stmt = $db->prepare('INSERT INTO error_log (meta_id, daytime, code, error) VALUES (:meta_id, :daytime, :code, :error)');

		if( !$stmt ) return false;

		foreach( $wpsd_debug_errors as $error_event ){

			if( !$stmt->bindValue(':meta_id', $meta_id, SQLITE3_INTEGER) ) return false;
			
			if( !$stmt->bindValue(':daytime', $daytime, SQLITE3_TEXT) ) return false;
			
			if( !$stmt->bindValue(':code', $error_event[0], SQLITE3_INTEGER) ) return false;
			
			if( !$stmt->bindValue(':error', $error_event[1], SQLITE3_TEXT) ) return false;

			if( !$stmt->execute() ) return false;
		}

		if( !$db->exec('END TRANSACTION') ) return false;

		$transaction_completed = true;

		if( !$db->close() ) return false;

		$db = null;
		
		return true;

	} catch ( \Throwable $e) {
		
		return false;

	} finally {

		if( $db && $transaction_started && !$transaction_completed ){

			try {

				$db->exec('ROLLBACK');

			} catch ( \Throwable $e ) {

			}
		}

		if( $db ){

			try {

				$db->close();

			} catch ( \Throwable $e ) {

			}
		}
	}
		
}

function record_event_meta( $db, $meta ) {

	$query = <<<SQL
		INSERT INTO error_meta (meta)
		VALUES (:meta);
		SQL;

	$stmt = $db->prepare($query);

	if (!$stmt){

		log( "couldn't prepare SQLite statement for metadata table", basename(__FILE__).' at '.__LINE__);

		return false;
	}

	$stmt->bindValue(':meta', $meta, SQLITE3_TEXT);
		
	$result = $stmt->execute();
	
	if( !$result ){

		log( "couldn't write metadata into SQLite database", basename(__FILE__).' at '.__LINE__);
		
		return false;
	}

	$meta_id = $db->lastInsertRowID();
		
	return $meta_id;
}

function store_fragment( $db_filename, $meta,$daytime, $wpsd_debug_errors ){

	$fragment_filepath = Consts::FRAGMENTS_DIR.get_random_fragment_filename();

	$stored_array = [
		Consts::FRAGMENT_DB_FILENAME	=> $db_filename,
		Consts::FRAGMENT_DAYTIME		=> $daytime,
		Consts::FRAGMENT_ERRORS			=> $wpsd_debug_errors,
		Consts::FRAGMENT_META			=> $meta,
	];

	file_put_contents( $fragment_filepath, serialize($stored_array) );
	
}

function get_random_fragment_filename(){
	
	return '.ht.'.bin2hex( random_bytes(10) ).get_ip_string();
}

function the_line_with_error( $last_error ){

	if( !is_php_error_file_valid_filepath( $last_error ) ) return '';

	$php_error_line = get_file_line( $last_error['file'], (int) $last_error['line'] );

	$pieces = explode( 'Stack trace:', $last_error['message']);
	
	$message = $pieces[0];
	
	$stack_trace = $pieces[1]??'-';

	echo
<<<HTML

Line with error:


$php_error_line

Type: {$last_error['type']}

Message: {$message}

File: {$last_error['file']}

Line: {$last_error['line']}

Stack trace: $stack_trace



HTML;

}

function is_php_error_file_valid_filepath( $last_error ){

	return 
	
		file_exists( $last_error['file']??'' ) &&
			
		is_readable( $last_error['file']??'' ) &&
		
		is_numeric( $last_error['line']??false );
}

function get_file_line( $filename, $line_number ) {

	$handle = fopen( $filename, 'r' );
	
	if (!$handle ) return 'N/A';

	$current_line = 1;

	while (( $line = fgets( $handle ) ) !== false ) {

		if ( $current_line == $line_number ) {
		
			fclose( $handle );
		
			return $line;
		}
		
		$current_line++;
	}

	fclose( $handle );
	
	return 'N/A';
}

function get_sanitized_uri(){

	$uri = $_SERVER['REQUEST_URI']??$_SERVER['PHP_SELF']??'N/A';

	if( empty($_SERVER['QUERY_STRING']) || !str_contains( $_SERVER['QUERY_STRING'],'pass' ) ) return $uri;

	return preg_replace_callback('/(pass(?:word)?=)[^&]*/i', function ($matches) {
		return ($matches[1]??'') . '***removed***';
	}, $uri);
}

function get_php_error_metadata( $timestamp ){
	
	$request_type_names = [
		1 => 'Frontend',
		2 => 'AJAX',
		3 => 'Admin',
		4 => 'Cron',
		5 => 'Login',
		6 => 'Xmlrpc',
		7 => 'Empty',
		8 => 'REST',
		9 => 'Sitemap',
		10 => 'Direct',
		11 => '404',
		12 => 'Feed',
		13 => 'Cli'
	];

	$settings = get_plugin_settings();
	
	$result = get_logged_in_user_from_cookies();

	$result .= get_server_superglobal( $settings );
	
	$result .= get_sanitized_post_superglobal($settings);

	$result .= get_sanitized_cookies_superglobal( $settings );

	$result .= "\nTimestamp: {$timestamp}\n\n";
	
	$result .= 'RT:'.$request_type_names[WPSD_REQUEST_TYPE].PHP_EOL;

	return $result;
			
}

function get_logged_in_user_from_cookies( ){

	foreach( $_COOKIE??[] as $key => $value ) {

		if( str_starts_with( $key,'wordpress_logged_in_' ) ) {
			
			return 'Username: '.get_cookie_username($value).PHP_EOL.PHP_EOL;
			
		}
	}
		
	return '';
}

//call if Fatal PHP error doesn't show the message
function display_fatal_error_data( ){

	$last_error = error_get_last();

	if( !is_fatal_error($last_error) || !is_error_displayed() ) return;
	
	?>
	<style type="text/css">
	@media (prefers-color-scheme: dark ) {
		html {
			background: #222!important;
		}
		body#error-page {
			background: #333;
		}
		body#error-page {
			background: #333;
			color: #ccc;
			font-size: 20px;
		}
	}
	</style>
	<div style="white-space: break-spaces">
	<?php

	the_line_with_error( $last_error ).'<br>';

	?></div><?php
	

}


function is_fatal_error( $last_error ){
	
	switch( intval( $last_error['type']??0 ) ){

		case 1:
		case 4:
		case 16:
		case 64:
			
			return true;
			break;

		default:
			return false;
		break;
	}
	
}


function get_sanitized_post_superglobal( $settings ){

	if ( empty( $_POST ) || empty($settings['post']) ) return '';

	$result = '';

	foreach( array_keys( $_POST ) as $key ){

		switch(true){

			case $key === 'pwd':
			case str_contains($key, 'pass' ):
			case str_contains($key, 'nonce' ):
				$value = '***';
				break;
			default:
				$value = sanitize_text_field( $_POST[$key] );
				break;
		}

		$result .= "$key => {$value}\n";
	}

	return $result === '' ? '' : "\nPOST:\n$result"; 
}

function get_server_superglobal( $settings ){

	if( empty($settings['server']) ) return '';

	$result = '';

	foreach( $settings['server_keys'] as $key ){

		if( !isset( $_SERVER[$key] ) ) continue;

		$result .= $key === 'REQUEST_URI' ? 'REQUEST_URI => '.get_sanitized_uri()."\n" : "$key => {$_SERVER[$key]}\n";
			
	}

	return $result === '' ? '' : "SERVER:\n$result"; 
}

function get_sanitized_cookies_superglobal( $settings ){
	
	if( empty( $_COOKIE ) || empty($settings['cookies']) ) return '';

	$result = '';

	foreach( $_COOKIE as $key => $nonce ){

		if( is_cookie_key_excluded_string( $key ) ) continue;
		
		//multiple cookies with the same name is passed as an array, therefore value has to be iterated.
		foreach( (array) $nonce as $multi_key => $multi_value ){

			$stored_value = is_full_value_stored( $key,$settings ) ? $multi_value : get_truncated_value( $multi_value );
			
			$result_key = $multi_key === 0 ? $key : "{$key}_{$multi_key}";
			
			$result .= "$result_key => $stored_value\n";

		}

	}

	return $result === '' ? '' : "\nCookies:\n$result"; 
}

function get_truncated_value( $nonce ){

	if( strlen( $nonce ) < 6 ) return $nonce; 

	return substr( $nonce, 0, 5 )."...";
}

function is_full_value_stored( $key, $settings ){

	return !empty( $settings['cookies_keys_full_value'] ) && in_array( $key, $settings['cookies_keys_full_value'] );
}

function is_cookie_key_excluded_string( $key ){

	switch( true ){

		case str_contains( $key, 'wordpress_logged_in'):
		case str_contains( $key, 'nonce'):
			return true;
			break;
	
		default:
			return false;

	}
}

function get_cookie_username( $nonce ){

	return get_str_before( $nonce, '|' );

}

function get_str_before( $string, $before_char ){

	return str_contains( $string, $before_char ) ? substr( $string, 0, strpos( $string, $before_char ) ) : $string;
}

function move_older_error_log_to_archive(){
	
	$error_log_filepath = ini_get( 'error_log' );

	switch(true){

		case !str_starts_with( $error_log_filepath, ABSPATH ):
			return;

		case !file_exists($error_log_filepath):
			file_put_contents( $error_log_filepath, '');
			return;

		//size under 10 is practically empty
		case filesize($error_log_filepath) < 10:
		
		//fallthrough, never true
		case !($file_date = date('Y-m-d', filemtime($error_log_filepath) )):
		case $file_date === date('Y-m-d'): //same day
			return;

		//fallthrough
		case !($debug_archive_filepath = get_debug_archive_filepath($file_date)):

		case file_exists($debug_archive_filepath):
			append_log_to_archived_file( $error_log_filepath, $debug_archive_filepath );
			return;

		default:
			rename( $error_log_filepath, $debug_archive_filepath );
			file_put_contents( $error_log_filepath, '');
			return;
	}
	
}

function append_log_to_archived_file( $src_filepath, $dest_filepath ){

	if( !is_readable($src_filepath) || !is_writable($dest_filepath) ){

		return false;
	}

	$src_content = file_get_contents($src_filepath);

	if( $src_content === false ){

		return false;
	}

	$write = file_put_contents($dest_filepath, $src_content, FILE_APPEND);

	if( $write === false ){

		return false;
	}

	unlink($src_filepath);

	return true;
}


function get_debug_archive_filepath($file_date){
	
	static $debug_archive_dir;

	if(!$debug_archive_dir){

		$debug_archive_dir = Consts::DB_DIR.'debug-'.$file_date.get_multisite_and_ip_string().'.log';
	}

	return $debug_archive_dir;

}
