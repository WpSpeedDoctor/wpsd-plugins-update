<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

require_once WP_PLUGIN_DIR.'/wpsd-php-debug/constants.php';

require_once Consts::DIR.'includes/universal-functions.php';

if( get_wpsd_option( Consts::OPTION_VER ) !== Consts::VER ){

    require Consts::DIR.'admin/setup.php';

    set_autoload_settings([Consts::OPTION_MULTI_IP => '1']);
    
    update_settings_to_latest_version();
    
}

require Consts::DIR.'must-use-plugin/errors/error-handler.php';

require Consts::DIR.'must-use-plugin/debug/debug-public.php';

// serving ajax plugin's request
if( isset($_GET['php-debug-search']) && ($_POST['action']??'') === 'htmx-php-debug-search' ){

    require Consts::DIR.'must-use-plugin/ajax/ajax-handler.php';

    die;
}

switch(true){
    case !isset($_COOKIE[Consts::COOKIE_DISABLE_PLUGINS]):
    case WPSD_REQUEST_TYPE !== REQUEST_ADMIN:
    case !isset($_GET['page']):
    case $_GET['page'] !== Consts::PAGE_ADMIN:
        break;
    default:
        require Consts::DIR.'must-use-plugin/disable-plugins.php';
        break;
}