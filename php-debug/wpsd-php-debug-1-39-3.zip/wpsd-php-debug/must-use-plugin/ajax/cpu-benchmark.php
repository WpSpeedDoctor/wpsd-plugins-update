<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;


echo get_cpu_performance_test();

function get_cpu_performance_test(){

	$tStart = microtime(true);	//Init time

	$passes = 0;				//Init passes

	$sieveSize = 1000000;		//Set sieve size

	$runTime = 2;				//The amount of seconds the script should be running for

	while (getTimeDiffInMs($tStart) < $runTime * 1000) {

		$sieve = new PrimeSieve($sieveSize);
		
		$sieve->runSieve();
		
		$passes++;
	
	}
	
	return $passes;

}

/**
* Code credit https://github.com/PlummersSoftwareLLC/Primes/tree/drag-race/PrimePHP/solution_1 
*/

class PrimeSieve {

	 private string $rawbits;

	 private int $sieveSize;
	 private int $rawBitsSize;

	 public static array $primeCounts = [
		 10 => 4,
		 100 => 25,
		 1000 => 168,
		 10000 => 1229,
		 100000 => 9592,
		 1000000 => 78498,
		 10000000 => 664579,
		 100000000 => 5761455,
	 ];

	 public function __construct($sieveSize = 1000000)
	 {
		 $this->sieveSize = $sieveSize;
		 $this->rawBitsSize = (int)(($this->sieveSize + 1) * 0.5);
	 }

	 public function runSieve()
	 {
		 $factor = 3;
		 $sieveSize = $this->sieveSize;
		 $q = sqrt($sieveSize);
		 $rawBitsSize = $this->rawBitsSize;
		 $rb = str_repeat('0', $rawBitsSize);

		 while ($factor < $q) {
			 for ($i = $factor; $i <= $sieveSize; $i += 2) {
				 $rbi = (int)($i * 0.5);
				 if ($rb[$rbi] == '0') {
					 $factor = $i;
					 break;
				 }
			 }

			 $ft2 = $factor;
			 $start = (int)($factor * $factor * 0.5);
			 for ($i = $start; $i < $rawBitsSize; $i += $ft2) {
				 $rb[$i] = '1';
			 }

			 $factor += 2;
		 }
		 $this->rawbits = $rb;
	 }

	 public function printResults(): void
	 {
		 for ($i = 1; $i < $this->sieveSize; $i++) {
			 if ($i % 2 && $this->rawbits[(int)($i * 0.5)] == '0') {
				 echo $i . ", ";
			 }
		 }
	 }

	 public function getRawbitCount(): int
	 {
		 $sum = 0;
		 $sz = strlen($this->rawbits);
		 for ($i = 0; $i < $sz; $i++){
			 if ($this->rawbits[$i] == '0'){
				 $sum++;
			 }
		 }
		 return $sum;
	 }
}

function getTimeDiffInMs(float $tStart): float
{
	 return (microtime(true) - $tStart) * 1000;
}

function validateResult($sieveSize): ?int
{
	 return PrimeSieve::$primeCounts[$sieveSize];
}