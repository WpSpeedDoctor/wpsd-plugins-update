<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;

echo CPU_Model::get();

abstract class CPU_Model {

	private const EMPTY_OUTPUT = '-';

	public static function get(): string {

		switch ( true ) {

			case stripos( PHP_OS, 'linux' ) !== false:

				if ( !function_exists( 'shell_exec' ) ) return self::EMPTY_OUTPUT;

				$cpuinfo = shell_exec( 'cat /proc/cpuinfo' );

				if ( !is_string( $cpuinfo ) ) return self::EMPTY_OUTPUT;

				preg_match( '/model name\s+:\s+([^\n]+)/', $cpuinfo, $matches );

				return trim( $matches[1] ?? self::EMPTY_OUTPUT );

			case stripos( PHP_OS, 'win' ) !== false:

				if ( !function_exists( 'exec' ) ) return self::EMPTY_OUTPUT;

				exec( 'wmic cpu get name', $output );

				return trim( $output[1] ?? self::EMPTY_OUTPUT );

			default:

				return self::EMPTY_OUTPUT;

		}

	}

}
