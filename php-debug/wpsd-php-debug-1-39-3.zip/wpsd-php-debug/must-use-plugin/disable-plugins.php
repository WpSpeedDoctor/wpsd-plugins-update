<?php

namespace WPSD\debug\v2;

defined( 'ABSPATH' ) || exit;


add_filter( 'option_active_plugins', __NAMESPACE__ . '\filter_active_plugins_wpsd' );

add_filter( 'site_option_active_sitewide_plugins', __NAMESPACE__ . '\filter_active_sitewide_plugins_wpsd' );


function filter_active_plugins_wpsd( $plugins ){

	return array_filter( $plugins, fn( $plugin ) => str_contains( $plugin, 'wpsd' ) );

}

function filter_active_sitewide_plugins_wpsd( $plugins ){
	return array_filter( 
		$plugins,
		fn( $plugin ) => str_contains( $plugin, 'wpsd' ), ARRAY_FILTER_USE_KEY
	);
}

//disable theme
add_filter( 'template_directory', function(){return ABSPATH;} );

add_filter( 'stylesheet_directory', function(){return ABSPATH;} );