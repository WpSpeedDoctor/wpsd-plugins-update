<?php

namespace WPSD\shared;

defined( 'ABSPATH' ) || exit;

class Shared_Admin_Menu {

	public const FILTER_CONTENT = 'wpsd-main-page-content';

	public const CONTENT_URL = 'https://raw.githubusercontent.com/WpSpeedDoctor/wpsd-plugins-update/refs/heads/main/wpsd-shared-plugins-info.json';

	private const CONTENT_FILE = __DIR__.'/wpsd-shared-plugins-info.json';

	private const TEMPLATE_FILE = __DIR__.'/wpsd-plugins-template.html';

	private const FOOTER_ALLOWED_HTML = [
		'a' => [
			'href' => true,
			'title' => true,
		],
		'br' => [],
		'em' => [],
		'strong' => [],
	];

	public const FILTER_SUBMENUS = 'wpsd-plugins-submenus';

	public const KEY_SUBMENU_TITLE = 0;

	public const KEY_SUBMENU_SLUG = 1;

	public const KEY_SUBMENU_CALLABLE = 2;

	private static string $main_menu_title = '';

	static function add_shared_wpsd_menu(){

		global $menu;

		if( in_array('wpsd', array_column($menu, 2)) ){

			return;
		}

		add_menu_page(
			self::$main_menu_title,
			self::$main_menu_title,
			'manage_options',
			'wpsd',
			[self::class, 'wpsd_main_page'],
			'dashicons-code-standards',
			30
		);

		$plugins_submenus = apply_filters(self::FILTER_SUBMENUS, []);

		foreach( $plugins_submenus as $submenu ){

			add_submenu_page(
				'wpsd',
				$submenu[self::KEY_SUBMENU_TITLE],
				$submenu[self::KEY_SUBMENU_TITLE],
				'administrator',
				$submenu[self::KEY_SUBMENU_SLUG],
				$submenu[self::KEY_SUBMENU_CALLABLE]
			);
		}
	}

	static function wpsd_main_page(){

		$content_data = self::get_content_data();

		if( $content_data === false ){

			wp_die(__( 'Unable to load WPSD plugin information.', 'plugin-domain' ));
		}

		$locale_data = self::get_locale_data($content_data);

		if( $locale_data === false ){

			wp_die(__( 'Unable to load WPSD plugin information.', 'plugin-domain' ));
		}

		$page_content = self::render_page($locale_data);

		if( $page_content === false ){

			wp_die(__( 'Unable to load WPSD plugin information.', 'plugin-domain' ));
		}

		echo $page_content;
	}

	private static function get_content_data(){

		$content = self::get_content();

		$content_data = self::decode_content($content);

		if( $content_data !== false ){

			return $content_data;
		}

		return self::decode_content(self::get_local_content());
	}

	private static function decode_content($content){

		if( !is_string($content) || $content === '' ){

			return false;
		}

		$content_data = json_decode($content, true);

		if( !is_array($content_data) ){

			return false;
		}

		return $content_data;
	}

	private static function get_content(){

		if( wp_get_environment_type() === 'development' ){

			return self::get_local_content();
		}

		$response = wp_remote_get(self::CONTENT_URL);

		if( is_wp_error($response) ){

			return self::get_local_content();
		}

		if( wp_remote_retrieve_response_code($response) !== 200 ){

			return self::get_local_content();
		}

		return wp_remote_retrieve_body($response);
	}

	private static function get_local_content(){

		if( !is_readable(self::CONTENT_FILE) ){

			return false;
		}

		return file_get_contents(self::CONTENT_FILE);
	}

	private static function get_locale_data($content_data){

		if( !isset($content_data['locale']) || !is_array($content_data['locale']) ){

			return false;
		}

		$current_locale = strtolower(str_replace('_', '-', determine_locale()));

		$language = explode('-', $current_locale)[0];

		$locales = array_unique([$current_locale, $language, 'en']);

		foreach( $locales as $locale ){

			if( isset($content_data['locale'][$locale]) && is_array($content_data['locale'][$locale]) ){

				return $content_data['locale'][$locale];
			}
		}

		return false;
	}

	private static function render_page($locale_data){

		$required_keys = ['heading', 'tagline', 'section_title', 'footer'];

		foreach( $required_keys as $required_key ){

			if( !isset($locale_data[$required_key]) || !is_string($locale_data[$required_key]) ){

				return false;
			}
		}

		if( !isset($locale_data['plugins']) || !is_array($locale_data['plugins']) ){

			return false;
		}

		$plugins = self::render_plugins($locale_data['plugins']);

		if( $plugins === false ){

			return false;
		}

		$template = file_get_contents(self::TEMPLATE_FILE);

		if( $template === false ){

			return false;
		}

		$replacements = [
			'{{heading}}' => esc_html($locale_data['heading']),
			'{{tagline}}' => esc_html($locale_data['tagline']),
			'{{section_title}}' => esc_html($locale_data['section_title']),
			'{{plugins}}' => $plugins,
			'{{footer}}' => wp_kses($locale_data['footer'], self::FOOTER_ALLOWED_HTML),
		];

		return strtr($template, $replacements);
	}

	private static function render_plugins($plugins){

		$plugins_html = '';

		foreach( $plugins as $plugin ){

			if( !is_array($plugin) ){

				return false;
			}

			$plugin_html = self::render_plugin($plugin);

			if( $plugin_html === false ){

				return false;
			}

			$plugins_html .= $plugin_html;
		}

		return $plugins_html;
	}

	private static function render_plugin($plugin){

		$required_keys = ['name', 'description', 'url', 'image_url'];

		foreach( $required_keys as $required_key ){

			if( !isset($plugin[$required_key]) || !is_string($plugin[$required_key]) ){

				return false;
			}
		}

		$name = esc_html($plugin['name']);

		$description = esc_html($plugin['description']);

		$url = esc_url($plugin['url']);

		if( $url === '' ){

			return false;
		}

		$image = self::render_plugin_image($plugin['image_url'], $plugin['name']);

		return <<<HTML
		<li>
			<a href="{$url}" target="_blank" rel="noopener">
				{$image}
				{$name}
				<span>{$description}</span>
			</a>
		</li>
		HTML;
	}

	private static function render_plugin_image($image_url, $plugin_name){

		if( $image_url === '' ){

			return '';
		}

		$image_url = esc_url($image_url);

		if( $image_url === '' ){

			return '';
		}

		$image_alt = esc_attr($plugin_name);

		return <<<HTML
		<img class="wpsd-plugin-image" src="{$image_url}" alt="{$image_alt}" loading="lazy">
		HTML;
	}

	static function set_data($translated_title, $release_date){

		_deprecated_function(__METHOD__, '0.9.8', 'set_title');

		self::set_title($translated_title);
	}

	static function set_release_date($release_date){

		_deprecated_function(__METHOD__, '0.9.8');
	}

	static function set_title($translated_title){

		if( self::$main_menu_title !== '' ){

			return;
		}

		self::$main_menu_title = $translated_title;
	}

}
