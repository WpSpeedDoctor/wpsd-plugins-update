<?php

namespace advanced_plugin_filter_pro;

defined( 'ABSPATH' ) || exit;

$post_data =  get_request_post();


if( is_excluded_action($post_data) ) return;

store_post_data( $post_data );

// deb( $post_data , basename(__FILE__).' at '.__LINE__ );

// deb($_SERVER['REQUEST_URI'], $_SERVER['REQUEST_METHOD'].' '.$_SERVER['REQUEST_TIME_FLOAT']);

// deb( $_SERVER['REQUEST_METHOD']??'' , basename(__FILE__).' at '.__LINE__ );



/**
* @param array $post_data 
* @return array -
* - hash =>  (string) is hash of JSON
* - value => (string) data in JSON
*
*/

function get_event_data_to_store( $post_data ) {

	$event_data['uri_path'] = get_sanitized_uri_path();

	$event_data['qs_keys'] = get_sanitized_get_keys();

	$event_data['post_action'] = array( sanitize_text_field( $post_data['action']??'' ) );

	$event_data['post_keys'] = get_sanitized_post_keys( $post_data );

	$data_json = json_encode( $event_data );

	return [
		
		'hash' => crc32($data_json),
		
		'value' => $data_json
	];
}

function get_sanitized_uri_path(){

	$uri_path = @$_SERVER['QUERY_STRING'] ==='' ? $_SERVER['REQUEST_URI'] : strstr($_SERVER['REQUEST_URI'], '?', true);
	
	return array( sanitize_text_field( $uri_path ) );

}

function get_sanitized_get_keys(){

	foreach( ($_GET??[]) as $key => $value ){

		if( is_excluded_qs_key($key) ) continue;

		$truncated_value = get_truncated_value($value);

		$result[] = sanitize_text_field("$key=$truncated_value");
	}

	return $result??[];
}

function get_truncated_value($value){

	$max_allowed_value_length = 25;

	if( strlen($value) < $max_allowed_value_length ) return $value;

	return substr($value, 0, 25).'...';

}

function is_excluded_qs_key($key){

	//todo: add to settings
	$excluded_qs_keys = [ 'nonce','pass','fbclid','utm','gclid','_ga','_kx','gad_source','judgeme'];

	foreach( $excluded_qs_keys as $excluded_string ){

		if( str_contains($key,$excluded_string) ) return true;
	}

	return false;
}

function get_sanitized_post_keys( $post_data ){

	if( empty($post_data) ) return [];

	foreach( array_keys($post_data) as $key ){

		if( is_excluded_post_key($key) ) continue;

		$result[] = sanitize_text_field($key);
	}

	return $result??[];
}

function is_excluded_post_key($key){

	if( $key == 'action' ) return true;

	return str_contains($key,'nonce');
}




function store_post_data( $post_data ){
	
	$event_data = get_event_data_to_store( $post_data );
	
	if( empty($event_data) ) return;

	$post_id = get_option('adv_plugins_pro_id');

	if( is_already_in_db( $post_id, $event_data ) ) return;

	add_post_meta( $post_id, $event_data['hash'], $event_data['value'], true );
}

function get_request_post(){

	if( !empty($_POST) ) return $_POST;

	$post_data = json_decode( file_get_contents('php://input'), true);

	return empty($post_data) ? [] : $post_data;

}

function is_already_in_db( $post_id, $event_data ){

	$result = get_post_meta( $post_id, $event_data['hash'], true );

    return !empty($result);

}

//TODO add settings filter
function is_excluded_action($post_data){

	if(!isset($post_data['action'])) return false;

	return in_array( $post_data['action'], ['heartbeat']  );
}