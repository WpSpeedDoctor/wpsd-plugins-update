<?php

namespace apf_pro;

defined( 'ABSPATH' ) || exit;

// const NON_PRO_NAMESPACE = 'advanced_plugin_filter\\';



function apf_pro_add_meta_box() {

	add_meta_box(
		'apf_pro_meta_box',
		__('Advanced Plugin Filter PRO - Recorded events you might need', 'advanced-plugin-filter-pro'), 
		__NAMESPACE__.'\apf_pro_meta_box_callback',
		'adv_plugin_filter',
		'normal',
		'high'
	);

}
add_action('add_meta_boxes', __NAMESPACE__.'\apf_pro_add_meta_box',11);

function apf_pro_meta_box_callback(){
	
	$events = get_recorded_events();

	print_data_as_json($events);

}

function print_data_as_json($events){

	$events_json = json_encode($events);

	$converter = json_encode(get_action_converter());

?>
<div class="metabox_wrapper">
	<div class="metabox_header mb10">
		<div class="mb5">
			<input type="text" id="search_box" placeholder="Search..." />
			<button id="prev_button">&#8592;</button>
			<button id="next_button">&#8594;</button>
		</div>
		<div class="mb5">
			<span id="current_info"></span>
		</div>
			<!-- Suggested title: <span id="suggested_title"></span> -->
			<!-- <button id="copy_button">Copy</button> -->
	</div>
	<div class="metabox_body">
		<!-- Data will be displayed here -->
	</div>
</div>
<script>

const events_apf_pro = <?=$events_json?>

const converter = <?=$converter?>

let currentKey = 0;
let searchTimeout = null;
let keysWithMatch = [];
let isSearchActive = false;

document.getElementById('search_box').addEventListener('input', function() {
	clearTimeout(searchTimeout);
	searchTimeout = setTimeout(searchEvents, 1000);
});

document.getElementById('next_button').addEventListener('click', function(event){
	event.preventDefault();
	navigate(1);
});

document.getElementById('prev_button').addEventListener('click', function(event){
	event.preventDefault();
	navigate(-1);
});

function navigate(direction) {
	if (isSearchActive && keysWithMatch.length > 0) {
		let currentIndex = keysWithMatch.indexOf(currentKey);
		let nextIndex = (currentIndex + direction + keysWithMatch.length) % keysWithMatch.length;
		currentKey = keysWithMatch[nextIndex];
	} else if (!isSearchActive) {
		currentKey = (currentKey + direction + events_apf_pro.length) % events_apf_pro.length;
	}
	displayData();
}

function displayData() {
	let htmlContent = '';
	let infoText;

	if (isSearchActive && keysWithMatch.length > 0) {
		htmlContent = createDisplayData(events_apf_pro[keysWithMatch[currentKey]], converter);
		infoText = `Event: ${currentKey + 1} / ${keysWithMatch.length}`;
	} else if (!isSearchActive) {
		htmlContent = createDisplayData(events_apf_pro[currentKey], converter);
		infoText = `Event: ${currentKey + 1} / ${events_apf_pro.length}`;
	} else {
		htmlContent = 'No matches found';
		infoText = 'No matches';
	}

	document.querySelector('.metabox_body').innerHTML = `<table class='apf-pro-table'>${htmlContent}</table>`;
	document.getElementById('current_info').textContent = infoText;
}


function createDisplayData(data, converter) {
	return Object.entries(data).map(([key, value]) => {
		const displayKey = converter[key]?.display || key;
		const dataMatch = converter[key]?.match_type;
		const dataOperator = converter[key]?.operator;

		if (Array.isArray(value)) {
			return displayArrayItems(key, displayKey, value, dataMatch, dataOperator);
		} else {
			return createTableRow(displayKey, value, dataMatch, dataOperator);
		}
	}).join('');
}

function displayArrayItems(key, displayKey, array, dataMatch, dataOperator) {
	return array.map(item => createTableRow(displayKey, item, dataMatch, dataOperator)).join('');
}

function createTableRow(displayKey, value, dataMatch, dataOperator) {
	return `<tr>
		<td class='event-key apf-pro-cell'>${displayKey}</td>
		<td class='event-value apf-pro-cell' data-match='${dataMatch}' data-operator='${dataOperator}'>${value}</td>
		<td><button type="button" class='buttonL apf-pro-button'>Left</button></td>
		<td><button type="button" class='buttonR apf-pro-button'>Right</button></td>
	</tr>`;
}



document.addEventListener('click', function(event) {
	if (event.target.classList.contains('buttonL')) {
		handleButtonClick(event.target, 'match_type_1', 'operator_1', 'value_1');
	} else if (event.target.classList.contains('buttonR')) {
		handleButtonClick(event.target, 'match_type_2', 'operator_2', 'value_2');
	}
});

function handleButtonClick(button, matchTypeId, operatorId, valueInputName) {
	const row = button.closest('tr');
	const eventValueCell = row.querySelector('.event-value');
	const dataMatch = eventValueCell.getAttribute('data-match');
	const dataOperator = eventValueCell.getAttribute('data-operator');
	const valueContent = eventValueCell.textContent || eventValueCell.innerText;

	if (dataMatch) {
		document.getElementById(matchTypeId).value = dataMatch;
	}
	if (dataOperator) {
		document.getElementById(operatorId).value = dataOperator;
	}
	document.querySelector(`input[name="${valueInputName}"]`).value = valueContent;

	 // Call updateVisibility for the relevant group
	 const matchTypeSelect = document.getElementById(matchTypeId);
	const operatorSelect = document.getElementById(operatorId);
	const valueInput = document.querySelector(`input[name="${valueInputName}"]`);
	updateVisibility(matchTypeSelect, operatorSelect, valueInput);

	createSuggestedTitle(valueInputName, valueContent);
}

function createSuggestedTitle() {
	const value1 = document.querySelector('input[name="value_1"]').value;
	const value2 = document.querySelector('input[name="value_2"]').value;

	let title = value1;
	if (value2) {
		title += ' AND ' + value2;
	}

	document.getElementById('suggested_title').textContent = title;
}

function updateVisibility(matchTypeSelect, operatorSelect, valueInput) {
	const value = matchTypeSelect.value;
	if (value === 'post_key_exists') {
		operatorSelect.classList.add('ro-hidden');
		valueInput.classList.remove('ro-hidden'); // Ensure value field is visible
	} else if (value === 'admin' || value === 'frontend' ||
			  value === 'logged_in' || value === 'logged_in_not' ||
			  value === 'null') {
		operatorSelect.classList.add('ro-hidden');
		valueInput.classList.add('ro-hidden');
	} else {
		operatorSelect.classList.remove('ro-hidden');
		valueInput.classList.remove('ro-hidden');
	}
}

document.addEventListener('DOMContentLoaded', function() {
	// Get the elements for the first group
	var matchType1 = document.getElementById('match_type_1');
	var operator1 = document.getElementById('operator_1');
	var value1 = document.querySelector('input[name="value_1"]');

	// Get the elements for the second group
	var matchType2 = document.getElementById('match_type_2');
	var operator2 = document.getElementById('operator_2');
	var value2 = document.querySelector('input[name="value_2"]');

	// Set up the event listeners
	matchType1.addEventListener('change', () => updateVisibility(matchType1, operator1, value1));
	matchType2.addEventListener('change', () => updateVisibility(matchType2, operator2, value2));
});

//SEARCH
function searchEvents() {
	let searchText = document.getElementById('search_box').value.toLowerCase();
	keysWithMatch = [];
	isSearchActive = searchText.length > 0;

	events_apf_pro.forEach((event, index) => {
		for (let key in event) {
			if (Array.isArray(event[key])) {
				if (event[key].some(value => value.toLowerCase().includes(searchText))) {
					keysWithMatch.push(index);
					break;
				}
			} else if (typeof event[key] === 'string' && event[key].toLowerCase().includes(searchText)) {
				keysWithMatch.push(index);
				break;
			}
		}
	});

	currentKey = 0; // Reset currentKey for search results
	displayData();
}

displayData(); // Initial display





	</script>
	<?php
}


function get_action_converter(){

	return [
		'uri_path' =>[
			'display'		=> 'URI Path',
			'match_type'	=>'uri_path',
			'operator'		=>'equal'
		],
		
		'qs_keys'		=> [
			'display'		=> 'Query string',
			'match_type'	=>'query_string',
			'operator'		=>'contain'
		],
		
		'post_action'		=> [
			'display'		=> '$_POST action',
			'match_type'	=>'post_action',
			'operator'		=>'equal'
		],
		
		'post_keys'		=> [
			'display'		=> '$_POST[$key]',
			'match_type'	=>'post_key_exists',
			'operator'		=>'equal'
		],
	];

}



function get_recorded_events(){

	$page_id = get_option('adv_plugins_pro_id');

	$events = get_post_meta($page_id);


	foreach($events as $event){

		$result[] = json_decode( reset($event), true );

	}

	return $result??[];
}