<?php

namespace advanced_plugin_filter_pro;

defined( 'ABSPATH' ) || exit;

/**
 * Delete all data in wp_post, wp_comments and wp_options
 */


function plugin_uninstall_main(){
	
	$post_id = get_option('adv_plugins_pro_id');
	
	delete_option('adv_plugins_pro_id');
	
	if( get_post($post_id) ) {

		wp_delete_post($post_id, true);

	}

}