<?php

namespace advanced_plugin_filter_pro;

defined( 'ABSPATH' ) || exit;

function plugin_setup_main($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );

}

/**
 * Main setup functions
 */
function plugin_activation_main(){

	if ( get_option('adv_plugins_pro_id') )  return;

	$post_id = wp_insert_post( 
		[
		'post_title'  => 'Advanced Plugin Filter Pro Data',
		'post_type'   => 'adv_plugins_pro',
		'post_status' => 'publish'
		] 
	);

	add_option('adv_plugins_pro_id', $post_id );
	
}

function plugin_deactivation_main(){


}
