<?php

namespace advanced_plugin_filter_pro;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced Plugin Filter PRO by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/
* Description: PRO functionalities for Advanced Plugin Filter
* Version: 1.0.5
* Updated: 2023-01-10
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: advanced-plugin-filter-pro
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

/**
 * Constants
 */

define( 'WPSD_APF_PRO_DIR', __DIR__.'/' );

const WPSD_APF_PRO_VER = '1.0.0';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){
			
		// case wp_doing_cron():
				
			//your code for cron comes here
		// break;
			
		case wp_doing_ajax():
				
			if( ($_POST['action']??'') === 'delete-plugin' ) {

				require WPSD_APF_PRO_DIR.'admin/uninstall.php';
			}
			
			//your code for ajax comes here
		break;

		case is_admin():
			
			run_back_end();
			
		break;
		
		// default:
			
			//your code for font-end comes here		
			
		// break;
	}
		
	if( ($_SERVER['REQUEST_METHOD']??'') === 'POST' || str_contains($_SERVER['REQUEST_URI']??'', '/wp-json/')){


		require WPSD_APF_PRO_DIR.'includes/data-recorder.php';
	}

}

function run_back_end(){
	
	global $pagenow;

	//WP plugin page
	if ($pagenow === 'plugins.php') {
		
		require_once WPSD_APF_PRO_DIR.'admin/setup.php';

		plugin_setup_main(__FILE__);

	}

	require WPSD_APF_PRO_DIR.'includes/pro-metabox.php';

}

// 'advanced_plugin_filter_pro'

// 'advanced-plugin-filter'

// __( "", 'advanced-plugin-filter' );
