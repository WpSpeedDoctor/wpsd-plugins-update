<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	//Disabled as no menu is in use in this version
	//links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}


/**
 * Main setup functions
 */
function plugin_activation_main(){

	create_mu_plugin_wp_folder();

	activate_mu_plugin();
	
}


function plugin_deactivation_main(){

	remove_mu_plugin();

}

/*
 * Activation functions beginning
 */

function activate_mu_plugin($rewrite=false){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) && $rewrite === false ) return;

	$mu_loader_markup = get_mu_loader_markup();

	if( empty($mu_loader_markup) ) return;

	file_put_contents( $mu_loader_filepath, $mu_loader_markup );

}

function get_mu_loader_markup(){
	
	if ( empty( get_option('adv-plugin-filter-enabled') ) ) return '';

	require_once WPSD_APF_DIR.'includes/construct-mu-plugin.php';
	
	$conditions_markup = get_mu_conditions_markup();

	if( empty($conditions_markup) ) {

		remove_mu_plugin();

		return '';
	}

	return get_mu_plugin_markup( $conditions_markup );
}

function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR ) ) return;
	
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}

/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return WPMU_PLUGIN_DIR."/advanced-plugin-filter-mu.php";
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) unlink( $mu_loader_filepath );

}



/**
 * Deactivation functions end
 */

/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(WPSD_APF_DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ) {

	$page_link = admin_url( 'edit.php?post_type=advanced_plugin_filter&page=advanced_plugin_filter' );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">Menu</a>
		HTML;

	return array_merge([$menu_link], $actions );

}


