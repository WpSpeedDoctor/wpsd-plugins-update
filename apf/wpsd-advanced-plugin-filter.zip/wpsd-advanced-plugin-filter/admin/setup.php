<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}


/**
 * Main setup functions
 */
function plugin_activation_main(){

	create_mu_plugin_wp_folder();

	activate_mu_plugin();
	
	add_default_rules_to_db();

}

function add_default_rules_to_db(){
	
	if( is_settings_saved_once() || has_already_apf_post() ) return;

	global $wpdb;

	$translated_title = get_translated_title();
	
	$safe_title = $wpdb->_real_escape($translated_title);
	
	$post_content = '{"filter_mode":"allow","logic":"or","match_type_1":"query_string","value_1":"adv_plugin_filter","operator_1":"contain","match_type_2":"admin_post_type","value_2":"adv_plugin_filter","operator_2":"equal","plugins":["wpsd-advanced-plugin-filter/advanced-plugin-filter.php"],"note":"","version":"'.WPSD_APF_VER.'"}';

	$safe_post_content = $wpdb->_real_escape( $post_content );

	$post_data = array(
		'post_type'    => 'adv_plugin_filter',
		'post_status'  => 'draft',
		'post_title'   => $safe_title,
		'post_content' => $safe_post_content
	);

	wp_insert_post($post_data);
}


function get_translated_title(){
	
	return sprintf(
		'%s: %s %s "adv_plugin_filter" %s %s %s "adv_plugin_filter"',
		esc_html__("Allow only mode", 'advanced-plugin-filter'),
		esc_html__("Query string", 'advanced-plugin-filter'),
		esc_html__("contains", 'advanced-plugin-filter'),
		esc_html__("OR", 'advanced-plugin-filter'),
		esc_html__("Admin post type", 'advanced-plugin-filter'),
		esc_html__("equals", 'advanced-plugin-filter')
	);
}

function is_settings_saved_once(){

	return get_option('adv-plugin-filter-enabled') !== false;
}

function has_already_apf_post(){

	global $wpdb;

	return !empty( $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_type = 'adv_plugin_filter'"));

}


function plugin_deactivation_main(){

	remove_mu_plugin();

}

/*
 * Activation functions beginning
 */
//MARK: Activate MU
function activate_mu_plugin( $rewrite=false ){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if( file_exists( $mu_loader_filepath ) && $rewrite === false ) return;

	$mu_loader_markup = get_mu_loader_markup();

	if( empty($mu_loader_markup) ) return;

	if( is_code_valid( $mu_loader_markup ) ){
		
		$mu_loader_markup_correct_namespace = str_replace( 'WPSD\\apf\\mu_plugin\\test','WPSD\\apf\\mu_plugin', $mu_loader_markup );
	
		file_put_contents( $mu_loader_filepath, $mu_loader_markup_correct_namespace  );
		
		opcache_invalidate( $mu_loader_filepath, true);

		return;
	}

	change_post_status_to_pending();

}

function change_post_status_to_pending(){

	if( !is_filter_saving_process() || defined('APF_UNPUBLISHED') ) return;
	
	global $wpdb;

	$post_id = intval($_POST['post_ID']); // Ensure the ID is an integer to avoid SQL injection

	$sql = $wpdb->prepare("UPDATE {$wpdb->posts} SET post_status = %s WHERE ID = %d", 'pending', $post_id);

	$wpdb->query($sql);


	define('APF_UNPUBLISHED', true);
}

function is_filter_saving_process() {

    switch( true ){

        case ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST':
            return false;

        case ($_POST['post_type'] ?? '') !== 'adv_plugin_filter':
            return false;

        case ($_POST['post_status'] ?? '') !== 'publish':
            return false;

        case !is_numeric($_POST['post_ID']??false):
            return false;

        default:
            return true;
    }
}

//MARK: is_code_valid
function is_code_valid( $mu_loader_markup ){

	$is_created = create_validation_php_file( $mu_loader_markup );
	
	if( $is_created === false ) return false;
	
	$post_data=[

		'timeout'   =>'10',
		'body'  =>[
			
				'action'	=> 'afp-code-validation',

				'nonce'		=> get_nonce_hash()
	 
			]
		];
	 
		 
	$response = wp_remote_post( admin_url('/admin-ajax.php?adv_plugin_filter') , $post_data);

	$is_success = get_validation_result( $response );

    return $is_success; 
}

function get_validation_result( $response ){

	$body = wp_remote_retrieve_body($response);

	switch(true){

		case $body === '':

			$notice_data = [
				'text' => esc_html__('Received unclear response when creating MU plugin, filters might not work.', 'advanced-plugin-filter'),
				'type' => 'warning'
			];
			
			break;

		case $body === 'OK':

			$notice_data = [
				'text' => esc_html__('MU plugin created successfully, all published filters are in use.', 'advanced-plugin-filter'),
				'type' => 'success'
			];
			
			break;

		case is_wp_error($response):

			$notice_data = [
				'text' => esc_html__('MU plugin validation request failed, data from this filter are not in use. Send feedback to the developer please.', 'advanced-plugin-filter'),
				'type' => 'error'
			];

			break;
		default:
			
		$notice_data = [
				'text' => esc_html__('Code validation failed, current filter is not in use and status been changed to "Pending review". Send feedback to the developer please.', 'advanced-plugin-filter'),
				'type' => 'error'
			];

		    break;
	}

	set_transient('wpsd-apf-notice', $notice_data, 15 );
	
	return $notice_data['type'] === 'success';

}

function get_hash(){

	static $result = false;

	if( $result !== false ) return $result;

	return $result = hash('sha3-512', $_SERVER['SERVER_ADDR']);
}

function get_debug_hash(){

	return substr(get_hash(), 0, 32);
}

function get_nonce_hash(){

	return substr(get_hash(), 64, 64);
}

function try_validation_file(){

	if( ($_POST['nonce']??'') !== get_nonce_hash() ) {

		http_response_code( 401 );

		die('Not authorized');
	} 
	
	set_error_log();

	$filepath = WPSD_APF_DIR . 'code-validation/test.php';

	if( file_exists( $filepath ) ){

		@include $filepath;
	
		unlink($filepath);

		$message = 'OK';
	
	} else {

		error_log('Validation file not found');

		$message = 'No validation file';

	}

	die($message);
}

function set_error_log(){

	register_shutdown_function( __NAMESPACE__ . '\rename_validation_file');

	$ip_hash = get_debug_hash();

	error_reporting(E_ALL);

	ini_set('log_errors', true ); 

	ini_set('error_log', WPSD_APF_DIR."code-validation/debug-{$ip_hash}.log");

}


function rename_validation_file(){

	$filepath = WPSD_APF_DIR . '/code-validation/test.php';

	if( file_exists( $filepath ) ) rename( $filepath, WPSD_APF_DIR . '/code-validation/not-valid-mu-'.uniqid().'.php' );
	
}


function create_validation_php_file( $mu_loader_markup ){

	$mu_loader_markup_unique_constants = str_replace( 'APF_','APFTEST_', $mu_loader_markup );

	return false !== file_put_contents( WPSD_APF_DIR . '/code-validation/test.php', $mu_loader_markup_unique_constants );

}

function get_mu_loader_markup(){
	
	if ( empty( get_option('adv-plugin-filter-enabled') ) ) return '';

	require_once WPSD_APF_DIR.'includes/construct-mu-plugin.php';
	
	$conditions_markup = get_mu_conditions_markup();

	if( empty($conditions_markup) ) {

		remove_mu_plugin();

		return '';
	}

	return get_mu_plugin_markup( $conditions_markup );
}

function create_mu_plugin_wp_folder(){
	
	if ( file_exists( WPMU_PLUGIN_DIR ) ) return;
	
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}

/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return WPMU_PLUGIN_DIR."/advanced-plugin-filter-mu.php";
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if ( file_exists( $mu_loader_filepath ) ) unlink( $mu_loader_filepath );

}


/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(WPSD_APF_DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ) {

	$page_link = admin_url( 'edit.php?post_type=adv_plugin_filter&page=settings' );

	$text = esc_html__( "Settings", 'advanced-plugin-filter' );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">{$text}</a>
		HTML;

	return array_merge( $actions,[$menu_link] );

}


