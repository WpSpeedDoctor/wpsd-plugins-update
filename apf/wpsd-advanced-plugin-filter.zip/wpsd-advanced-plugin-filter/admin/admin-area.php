<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function run_back_end($file){
	
	$pagenow = get_pagenow();
	
	switch($pagenow){

		case 'edit.php':
        case 'post-new.php':
        case 'post.php':
            
			add_action( 'current_screen', __NAMESPACE__.'\run_admin_on_screen_area' );
		
            add_action('admin_notices', __NAMESPACE__.'\display_notice');
            
			break;

		case 'plugins.php':

			the_plugin_admin_area($file);
			
			add_action('activated_plugin', __NAMESPACE__.'\refresh_mu_plugin',10);
			add_action('deactivated_plugin', __NAMESPACE__.'\refresh_mu_plugin_after_other_plugin_deactivate',10,1);
            break;

	}
	
	//menu
	add_action('admin_menu', __NAMESPACE__.'\plugin_admin_menu');

	/* temporary disabled
	add_action('admin_menu', __NAMESPACE__.'\plugin_admin_pro');
	*/

	//language domain
	add_action('plugins_loaded', __NAMESPACE__.'\load_language_domain');

}

function run_admin_on_screen_area($screen){

	if( empty($screen->post_type) || $screen->post_type !== 'adv_plugin_filter' ){
		return;
	}
	
	require WPSD_APF_DIR.'includes/cpt-main.php';
	
	require WPSD_APF_DIR.'includes/cpt-admin.php';

	switch($_GET['page']??'settings'){

		case 'settings':

			require WPSD_APF_DIR.'includes/menu-settings.php';

			break;
		case 'bulk-edit':
			require WPSD_APF_DIR.'includes/menu-bulk-edit.php';
			break;
	}

	add_action('admin_enqueue_scripts', __NAMESPACE__.'\enqueue_plugin_assets');
}

function get_pagenow(){

	global $pagenow;

	if( !empty($pagenow) ) return $pagenow;

	defined('WPSD_URI_PATH') || define('WPSD_URI_PATH', strstr( $_SERVER['REQUEST_URI']??'', '?', true ) ?: $_SERVER['REQUEST_URI']??'');

	return basename( WPSD_URI_PATH );
}

function the_plugin_admin_area($file){

	require_once WPSD_APF_DIR.'admin/setup.php';

	plugin_setup_main($file);

	require_once WPSD_APF_DIR.'admin/update.php';

	the_mu_activation();
}

function the_mu_activation(){

		if( !is_apf_activation() || get_option('adv-plugin-filter-enabled') !== '1' ) return;

		register_shutdown_function( __NAMESPACE__ . '\remove_crushed_mu_plugin');

		activate_mu_plugin( $rewrite=true, $validate = false, $display_notice=false);

		update_option('adv-plugin-filter-enabled', '0', 'no');
		
		@include get_mu_plugin_loader_filepath();
		
		update_option('adv-plugin-filter-enabled', '1', 'no');

}

function is_apf_activation(){
	
	return ($_GET['action']??'') === 'activate' && ($_GET['plugin']??'') === 'wpsd-advanced-plugin-filter';
}

function display_notice(){

	$notice_data = get_transient('wpsd-apf-notice');

	if( empty($notice_data) ) return;

	$type = esc_attr($notice_data['type']);
	
	$text = esc_attr($notice_data['text']);

	echo <<<HTML
	<div class="notice notice-{$type} is-dismissible">
	<p>{$text}</p>
	</div>
	HTML;

	delete_transient('wpsd-apf-notice');
}

function enqueue_plugin_assets(){

	require_once WPSD_APF_DIR.'includes/enqueue-assets.php';

}

function plugin_admin_menu(){
	add_submenu_page(
		'edit.php?post_type=adv_plugin_filter',
		esc_html__( "Settings", 'advanced-plugin-filter' ),
		esc_html__( "Settings", 'advanced-plugin-filter' ),
		'administrator',
		'settings',
		__NAMESPACE__.'\admin_menu_main'
	);

	add_submenu_page(
		'edit.php?post_type=adv_plugin_filter',
		esc_html__( "Bulk Edit", 'advanced-plugin-filter' ),
		esc_html__( "Bulk Edit", 'advanced-plugin-filter' ),
		'administrator',
		'bulk-edit',
		__NAMESPACE__.'\admin_menu_bulk_edit'
	);
}

function admin_menu_bulk_edit(){
	// require_once WPSD_APF_DIR.'includes/menu-bulk-edit.php';
	bulk_edit_main();
}

function load_language_domain(){

	load_plugin_textdomain('advanced-plugin-filter', false, basename(WPSD_APF_DIR) . '/languages/');
}

/* temporarily disabled
function plugin_admin_pro(){
	add_submenu_page(
		'edit.php?post_type=adv_plugin_filter',
		esc_html__( "PRO bring ease of use", 'advanced-plugin-filter' ),
		esc_html__( "PRO bring ease of use", 'advanced-plugin-filter' ),
		'administrator',
		'pro',
		__NAMESPACE__.'\admin_menu_pro'
	);

}

function admin_menu_pro(){
	echo 'PRO';
}
*/