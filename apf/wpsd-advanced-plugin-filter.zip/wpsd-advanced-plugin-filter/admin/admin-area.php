<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function run_back_end($file){
	
	global $pagenow;
	
	//CPT
	require_once WPSD_APF_DIR.'includes/cpt.php';
	
	if( in_array( $pagenow, ['edit.php','post-new.php','post.php'])	){
		
		require WPSD_APF_DIR.'includes/cpt-main.php';

		add_action('admin_notices', __NAMESPACE__.'\display_notice');

	} 
	
	//WP plugin page
	if($pagenow === 'plugins.php'){
		
		require_once WPSD_APF_DIR.'admin/setup.php';

		plugin_setup_main($file);

	}
	
	//Activate mu-plugin
	if( str_contains( $_SERVER['REQUEST_URI'], '/wp-admin/plugins.php?action=activate&plugin=wpsd-advanced-plugin-filter' ) ){
		
		$is_active =  get_option('adv-plugin-filter-enabled');

		if( !$is_active ) return;

		register_shutdown_function( __NAMESPACE__ . '\remove_crushed_mu_plugin');

		activate_mu_plugin( $rewrite=true, $validate = false, $display_notice=false);

		update_option('adv-plugin-filter-enabled', '0', 'no');
		
		@include get_mu_plugin_loader_filepath();
		
		update_option('adv-plugin-filter-enabled', '1', 'no');
	}

	//assets
	add_action('admin_enqueue_scripts', __NAMESPACE__.'\enqueue_plugin_assets');
	
	add_action('wp', __NAMESPACE__.'\enqueue_plugin_assets');

	//menu
	add_action('admin_menu', __NAMESPACE__.'\plugin_admin_menu');

	/* temporary disabled
	add_action('admin_menu', __NAMESPACE__.'\plugin_admin_pro');
	*/

	if( ($_GET['post_type']??'') === 'adv_plugin_filter' ){

		require WPSD_APF_DIR.'includes/menu-settings.php';
	}

	//language domain
	add_action('plugins_loaded', __NAMESPACE__.'\load_language_domain');

}

function display_notice(){

	$notice_data = get_transient('wpsd-apf-notice');

	if( empty($notice_data) ) return;
	
	echo <<<HTML
	<div class="notice notice-{$notice_data['type']} is-dismissible">
	<p>{$notice_data['text']}</p>
	</div>
	HTML;

	delete_transient('wpsd-apf-notice');

}


function enqueue_plugin_assets(){

	global $post;

	if( ($_GET['post_type']??'') === 'adv_plugin_filter' || ($post->post_type??'') === 'adv_plugin_filter' ){
		
		require_once WPSD_APF_DIR.'includes/enqueue-assets.php';
		
	}

}

function plugin_admin_menu(){
	add_submenu_page(
		'edit.php?post_type=adv_plugin_filter',
		esc_html__( "Settings", 'advanced-plugin-filter' ),
		esc_html__( "Settings", 'advanced-plugin-filter' ),
		'administrator',
		'settings',
		__NAMESPACE__.'\admin_menu_main'
	);

}

function load_language_domain(){

	load_plugin_textdomain('advanced-plugin-filter', false, basename(WPSD_APF_DIR) . '/languages/');
}

/* temporarily disabled
function plugin_admin_pro(){
	add_submenu_page(
		'edit.php?post_type=adv_plugin_filter',
		esc_html__( "PRO bring ease of use", 'advanced-plugin-filter' ),
		esc_html__( "PRO bring ease of use", 'advanced-plugin-filter' ),
		'administrator',
		'pro',
		__NAMESPACE__.'\admin_menu_pro'
	);

}

function admin_menu_pro(){
	echo 'PRO';
}
*/