<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_auto_update_data(){

	$cached_update_data = get_transient( 'wpsd-apf-update' );

	if( !empty( $cached_update_data ) ) {
		
		return $cached_update_data;
	} 

	$update_data_url = 'http://po-fork.local/plugins-update/apf/update.json';
	
	$args = [

		'headers' => [
			'User-Agent' => "WordPress/{$wp_version};"
		],
		
		'sslverify' => true, 
	];

	$response = wp_remote_get( $update_data_url, $args );

	if ( is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200 ) {
		
		return false;
	}

	$response_body = wp_remote_retrieve_body( $response );

	$update_data = json_decode( $response_body, true );

	set_transient( 'wpsd-apf-update', $update_data, 60 * 5 ); //5 minutes

	return $update_data;
}

function enable_plugin_auto_update($transient) {

	if (empty($transient->checked)) {
		return $transient;
	}

	$plugin_path = 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php';

	if (!isset($transient->checked) || !isset($transient->checked[$plugin_path])) {
		return $transient;
	}

	$current_version = $transient->checked[$plugin_path];

	$update_data_url = get_public_update_url('apf/update.json');

	$response = wp_remote_get( $update_data_url );

	if ( is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200 ) {
		
		return $transient;
	}

	$update_data = json_decode( wp_remote_retrieve_body( $response ) );

	if (version_compare($current_version, $update_data->version, '<')) {

		$obj = new \stdClass();
		$obj->id = 0;
		$obj->slug = $plugin_path;
		$obj->plugin = $plugin_path;
		$obj->new_version = $update_data->version;
		$obj->package = $update_data->download_url;
		$obj->requires = $update_data->requires;
		$obj->tested = $update_data->tested;
		$obj->requires_php = $update_data->requires_php;
		$obj->last_updated = $update_data->last_updated;
		// $obj->sections = (array) $update_data->sections;

		$transient->response[$plugin_path] = $obj;
	}

	return $transient;
}

add_filter('pre_set_site_transient_update_plugins', __NAMESPACE__.'\enable_plugin_auto_update');


function custom_plugin_api_handler($false, $action, $args) {
	
	$plugin_slug = 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php';

	if ($action !== 'plugin_information' || isset($args->slug) && $args->slug !== $plugin_slug) return $false;
	
	
	$update_data = get_auto_update_data();

	$response = new \stdClass();
	$response->slug = $plugin_slug;
	
	$response->version = $update_data['version']; 
	$response->download_link = $update_data['download_url'];
	
	
	$response->requires =  $update_data['requires'];// Minimum WordPress version
	$response->tested = $update_data['tested']; // Tested up to WordPress version
	$response->requires_php = $update_data['requires_php']; // Minimum PHP version
	
	$response->name = esc_html__('Advanced Plugin Filter by WP Speed Doctor','advanced-plugin-filter');

	$response->sections = [
				// 'description' => 'The latest version of the plugin.', // Main description
				'changelog' => 'List of changes in this version.', // Changelog section
				// Add other sections as needed
			];

	// $update_data[''];
	
	// $response->banners = array(
		//     'low' => 'URL to a 772x250px banner image', // Optional: Banner image
		//     'high' => 'URL to a 1544x500px banner image' // Optional: High-resolution banner image
		// );

	
	


	return $response; // Return the custom response


	 // Return default response for other plugins
}

add_filter('plugins_api', __NAMESPACE__.'\custom_plugin_api_handler', 10, 3);


function get_public_update_url($slug){

	return "http://po-fork.local/plugins-update/{$slug}";
}

	// 	$response = new \stdClass();
	// 	$response->slug = $plugin_slug;
	// 	$response->name = esc_html__('Advanced Plugin Filter by WP Speed Doctor','advanced-plugin-filter');
	// 	$response->version = '1.0.29'; 
	// 	$response->download_link = get_public_update_url('/apf/latest-version.zip');

	// 	// Mimic the structure of a response from the WordPress Plugin Directory
	// 	$response->sections = [
	// 		// 'description' => 'The latest version of the plugin.', // Main description
	// 		'changelog' => 'List of changes in this version.', // Changelog section
	// 		// Add other sections as needed
	// 	];

	// 	// $response->banners = array(
	// 	//     'low' => 'URL to a 772x250px banner image', // Optional: Banner image
	// 	//     'high' => 'URL to a 1544x500px banner image' // Optional: High-resolution banner image
	// 	// );

	// 	// Optional: Compatibility with WordPress and PHP versions
	// 	$response->requires = '5.9'; // Minimum WordPress version
	// 	$response->tested = '6.5'; // Tested up to WordPress version
	// 	$response->requires_php = '7.4'; // Minimum PHP version

	// 	file_put_contents( __DIR__ .'/'.date('m-d').'.log',json_encode($response));

	// 	return $response; // Return the custom response
	// }

if( isset($_GET['wpsd-apf-json'])) {

	add_action('plugins_loaded', __NAMESPACE__.'\the_plugin_update_json_generator');
}
function the_plugin_update_json_generator() {
	if ( !current_user_can('administrator')) return;

	$basic_data = [
		'version' => '1.0.29',
		'download_link' => get_public_update_url('/apf/latest-version.zip'),

		'requires' => '5.9', // Minimum WordPress version
		'tested' => '6.5', // Tested up to WordPress version
		'requires_php' => '7.4', // Minimum PHP version
	];

	echo htmlentities(str_replace( "'","\'", json_encode( $basic_data )));
	
	die;
}

// if( isset($_GET['wpsd-apf-json'])) {



// // 	$data_
// // echo str_replace( "'","\'", json_encode( ));
// 	die;
// }