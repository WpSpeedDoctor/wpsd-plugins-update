<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){
	
	delete_adv_plugin_filter_posts();

	delete_option('adv-plugin-filter-enabled');

	delete_option('adv-plugin-filter-debug');

}

function delete_adv_plugin_filter_posts(){

	global $wpdb;
	
	$wpdb->query(
		
		"DELETE pm FROM {$wpdb->postmeta} pm
		INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
		WHERE p.post_type = 'adv_plugin_filter'"
	
	);

	$wpdb->query(
		
		"DELETE FROM {$wpdb->posts} WHERE post_type = 'adv_plugin_filter'"
	
	);

}


