<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;


function plugin_uninstall_main(){
	
	delete_adv_plugin_filter_posts();

	delete_option('adv-plugin-filter-enabled');

	delete_option('adv-plugin-filter-debug');

}

function delete_adv_plugin_filter_posts(){

	$args = array(
		'post_type'      => 'adv_plugin_filter',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	);

	$posts_to_delete = get_posts($args);

	if ( empty($posts_to_delete) ) return;

	foreach ($posts_to_delete as $post_id) {

		$meta_keys = get_post_meta($post_id);

		foreach (array_keys($meta_keys) as $meta_key) {

			delete_post_meta($post_id, $meta_key);

		}

		wp_delete_post($post_id, true);

	}

}


