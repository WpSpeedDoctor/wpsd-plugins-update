<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

/**
 * Automatically update mu plugin via shutdown function on cron or update ajax.
 * Hook `upgrader_process_complete` is unreliable for update mu-plugins
 */

if( get_option('adv-plugin-filter-enabled') === '1' ){

	register_shutdown_function( __NAMESPACE__.'\update_mu_plugin');
}

function update_mu_plugin(){

	if( is_mu_current_version() ) return;

	require_once WPSD_APF_DIR.'admin/setup.php';

	activate_mu_plugin( $rewrite=true );

}

function is_mu_current_version(){

	return defined('WPSD_APF_MU_VER') && WPSD_APF_MU_VER === WPSD_APF_VER;
}