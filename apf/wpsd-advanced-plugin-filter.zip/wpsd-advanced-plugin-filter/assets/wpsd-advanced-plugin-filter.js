//Check all|none|invert

document.addEventListener('DOMContentLoaded', function(){
	function checkAll(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = true;
		});
	}

	function uncheckAll(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = false;
		});
	}

	function invertSelection(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = !checkbox.checked;
		});
	}

	document.querySelectorAll('.check-all').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			checkAll(this.getAttribute('data-column'));
		});
	});

	document.querySelectorAll('.uncheck-all').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			uncheckAll(this.getAttribute('data-column'));
		});
	});

	document.querySelectorAll('.invert-selection').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			invertSelection(this.getAttribute('data-column'));
		});
	});
});



//hide unused elements in when certain matched are selected
document.addEventListener('DOMContentLoaded', function(){
	// Function to update operator and value field visibility
	function updateVisibility(matchTypeSelect, operatorSelect, valueInput){
		matchTypeSelect.addEventListener('change', function(){
			const hideBoth = ['admin', 'frontend', 'ajax', 'cron', 'rest', 'logged_in', 'logged_in_not', 'null'];
	
			// Hide operator for post_key_exists, keep value visible
			if(this.value === 'post_key_exists'){
				operatorSelect.classList.add('ro-hidden');
				valueInput.classList.remove('ro-hidden'); // Ensure value field is visible
			} else if(hideBoth.includes(this.value)){
				// Hide both operator and value for these options
				operatorSelect.classList.add('ro-hidden');
				valueInput.classList.add('ro-hidden');
			} else {
				// Make both fields visible for all other options
				operatorSelect.classList.remove('ro-hidden');
				valueInput.classList.remove('ro-hidden');
			}
		});
	}
	

	// Get the elements for the first group
	var matchType1 = document.getElementById('match_type_1');
	var operator1 = document.getElementById('operator_1');
	var value1 = document.querySelector('input[name="value_1"]');

	// Get the elements for the second group
	var matchType2 = document.getElementById('match_type_2');
	var operator2 = document.getElementById('operator_2');
	var value2 = document.querySelector('input[name="value_2"]');

	// Set up the event listeners
	updateVisibility(matchType1, operator1, value1);
	updateVisibility(matchType2, operator2, value2);
});

//populate title
document.addEventListener('DOMContentLoaded', function(){
	document.getElementById('populateTitle').addEventListener('click', function(event){
		event.preventDefault();
		var filterMode = document.getElementById('filter_mode');
		var filterModeText = filterMode.options[filterMode.selectedIndex].text + ': ';
		var title = filterModeText;

		var matchType1 = document.getElementById('match_type_1');
		var matchType1Text = matchType1.options[matchType1.selectedIndex].text;
		title += matchType1Text;

		var operator1 = document.getElementById('operator_1');
		var value1Input = document.querySelector('input[name="value_1"]');
		if(!operator1.classList.contains('ro-hidden') && !value1Input.classList.contains('ro-hidden')){
			var operator1Text = operator1.options[operator1.selectedIndex].text;
			var value1 = value1Input.value;
			title += ' ' + operator1Text + ' "' + value1 + '"';
		}

		var logic = document.getElementById('logic');
		var logicText = logic.options[logic.selectedIndex].text;

		var matchType2 = document.getElementById('match_type_2');
		if(matchType2.value !== 'null'){
			var matchType2Text = matchType2.options[matchType2.selectedIndex].text;
			var operator2 = document.getElementById('operator_2');
			var value2Input = document.querySelector('input[name="value_2"]');
			if(!operator2.classList.contains('ro-hidden') && !value2Input.classList.contains('ro-hidden')){
				var operator2Text = operator2.options[operator2.selectedIndex].text;
				var value2 = value2Input.value;
				title += ' ' + logicText + ' ' + matchType2Text + ' ' + operator2Text + ' "' + value2 + '"';
			} else {
				title += ' ' + logicText + ' ' + matchType2Text;
			}
		}
		
		document.getElementById('title').value = title;
		document.getElementById('title-prompt-text').style.display = 'none';
	});
});


/**
 * Alert of unsaved changes
 */

jQuery(document).ready(function($) {

	var formChanged = false;

	$('form :input').change(function() {
		formChanged = true;
	});

	$(window).on('beforeunload', function() {
		if (formChanged) {
			return true;
		}
	});

	$('#publish').click(function() {
		formChanged = false;
	});

	$('form').submit(function() {
		$(window).off('beforeunload');
	});
	
});