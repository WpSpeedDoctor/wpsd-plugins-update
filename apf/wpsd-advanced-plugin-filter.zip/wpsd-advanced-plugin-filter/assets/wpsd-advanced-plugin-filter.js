//Check all|none|invert

document.addEventListener('DOMContentLoaded', function(){
	function checkAll(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = true;
		});
	}

	function uncheckAll(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = false;
		});
	}

	function invertSelection(columnClass){
		var checkboxes = document.querySelectorAll('.plugins-column.' + columnClass + ' input[type="checkbox"]');
		checkboxes.forEach(function(checkbox){
			checkbox.checked = !checkbox.checked;
		});
	}

	document.querySelectorAll('.check-all').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			checkAll(this.getAttribute('data-column'));
		});
	});

	document.querySelectorAll('.uncheck-all').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			uncheckAll(this.getAttribute('data-column'));
		});
	});

	document.querySelectorAll('.invert-selection').forEach(function(button){
		button.addEventListener('click', function(event){
			event.preventDefault();
			invertSelection(this.getAttribute('data-column'));
		});
	});
});

document.addEventListener('change', function(e){
	const isRt = e.target.matches('input[name="request_type[]"]'); if(!isRt) return;

	const inputs = Array.from(document.querySelectorAll('input[name="request_type[]"]'));
	const all = inputs.find(i => i.value === 'all');
	const specifics = inputs.filter(i => i.value !== 'all');

	if(e.target === all){
		if(all.checked){
			specifics.forEach(i => i.checked = false);
		} else {
			all.checked = true;
		}
		return;
	}

	if(e.target.checked){
		all.checked = false;
	}

	const checkedSpecifics = specifics.filter(i => i.checked).length;

	if(checkedSpecifics === 0){
		all.checked = true;
	}

	if(checkedSpecifics === specifics.length){
		specifics.forEach(i => i.checked = false);
		all.checked = true;
	}
});


//continue here, show/hide fields doesn't work
//hide unused elements in when certain matched are selected
document.addEventListener('DOMContentLoaded', function(){
	function updateVisibility(matchTypeSelect, operatorSelect, valueInput){
		function applyVisibility(){
			const hideBoth = ['logged_in', 'logged_in_not', 'null'];

			if (matchTypeSelect.value === 'post_key_exists'){
				operatorSelect.classList.add('ro-hidden');
				valueInput.classList.remove('ro-hidden');
			} else if (hideBoth.includes(matchTypeSelect.value)){
				operatorSelect.classList.add('ro-hidden');
				valueInput.classList.add('ro-hidden');
			} else {
				operatorSelect.classList.remove('ro-hidden');
				valueInput.classList.remove('ro-hidden');
			}
		}

		matchTypeSelect.addEventListener('change', applyVisibility);
		applyVisibility();
	}

	var matchType1 = document.getElementById('match_type_1');
	var operator1 = document.getElementById('operator_1');
	var value1 = document.querySelector('input[name="value_1"]');

	var matchType2 = document.getElementById('match_type_2');
	var operator2 = document.getElementById('operator_2');
	var value2 = document.querySelector('input[name="value_2"]');

	updateVisibility(matchType1, operator1, value1);
	updateVisibility(matchType2, operator2, value2);
});


//request type checkboxes
(function(){
	function init_wrap(wrap){
		var list = wrap.querySelector('.wpsd-apf-list');
		var toggle = wrap.querySelector('.wpsd-apf-toggle-btn');
		var field = wrap.querySelector('.wpsd-apf-selected');
		var inputs = Array.prototype.slice.call(wrap.querySelectorAll('input[name="request_type[]"]'));
		if(!list || !toggle || !field || inputs.length === 0) return;

		var all = inputs.find(function(i){ return i.value === 'all'; });
		var specifics = inputs.filter(function(i){ return i.value !== 'all'; });

		function set_field_width(){
			var len = field.value.length;
			field.style.width = Math.max(20, len) + 'ch';
		}

		function sync_field(){
			var chk = inputs.filter(function(i){ return i.checked; }).map(function(i){
				var t = i.closest('label')?.querySelector('.wpsd-apf-text');
				return t ? t.textContent : i.value;
			});
			field.value = chk.join(', ');
			set_field_width();
		}

		function enforce_rules(e){
			if(e && e.target === all){
				if(all.checked){
					specifics.forEach(function(i){ i.checked = false; });
				} else {
					all.checked = true;
				}
				sync_field();
				return;
			}

			if(e && e.target && e.target.checked) all.checked = false;

			var checked_specifics = specifics.filter(function(i){ return i.checked; }).length;

			if(checked_specifics === 0) all.checked = true;

			if(checked_specifics === specifics.length){
				specifics.forEach(function(i){ i.checked = false; });
				all.checked = true;
			}

			sync_field();
		}

		toggle.addEventListener('click', function(){
			var isHidden = list.classList.contains('ro-hidden');
			if(isHidden){
				list.classList.remove('ro-hidden');
				toggle.setAttribute('aria-expanded', 'true');
			} else {
				list.classList.add('ro-hidden');
				toggle.setAttribute('aria-expanded', 'false');
			}
		});

		wrap.addEventListener('change', function(e){
			if(!e.target.matches('input[name="request_type[]"]')) return;
			enforce_rules(e);
		});

		enforce_rules();
	}

	Array.prototype.forEach.call(document.querySelectorAll('.wpsd-apf-wrap'), init_wrap);
})();

//copy post type buttons
(function(){

	if( !window.WPSD_PT ) return;

	const sel = window.WPSD_PT.selector || '.wpsd-pt-copy';

	const copiedLabel = window.WPSD_PT.copied || 'Copied';

	function copy_text(text){

		if( typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function' ){

			return navigator.clipboard.writeText(text);

		}

		const ta = document.createElement('textarea');

		ta.value = text;

		ta.setAttribute('readonly','');

		ta.style.position = 'fixed';

		ta.style.top = '-9999px';

		document.body.appendChild(ta);

		ta.focus();

		ta.select();

		document.execCommand('copy');

		document.body.removeChild(ta);

		return Promise.resolve();

	}

	function on_click(e){

		const btn = e.target.closest(sel);

		if( !btn ) return;

		const v = btn.dataset.copy || '';

		copy_text(v).then(function(){

			btn.setAttribute('aria-label', copiedLabel);

			btn.classList.add('wpsd-pt-copied');

			setTimeout(function(){

				btn.removeAttribute('aria-label');

				btn.classList.remove('wpsd-pt-copied');

			}, 1200);

		});

	}

	document.addEventListener('click', on_click, false);

})();


//populate title
document.addEventListener('DOMContentLoaded', function(){
	document.getElementById('populateTitle').addEventListener('click', function(event){
		event.preventDefault();
		var filterMode = document.getElementById('filter_mode');
		var filterModeText = filterMode.options[filterMode.selectedIndex].text + ': ';
		var title = filterModeText;

		var matchType1 = document.getElementById('match_type_1');
		var matchType1Text = matchType1.options[matchType1.selectedIndex].text;
		title += matchType1Text;

		var operator1 = document.getElementById('operator_1');
		var value1Input = document.querySelector('input[name="value_1"]');
		if(!operator1.classList.contains('ro-hidden') && !value1Input.classList.contains('ro-hidden')){
			var operator1Text = operator1.options[operator1.selectedIndex].text;
			var value1 = value1Input.value;
			title += ' ' + operator1Text + ' "' + value1 + '"';
		}

		var logic = document.getElementById('logic');
		var logicText = logic.options[logic.selectedIndex].text;

		var matchType2 = document.getElementById('match_type_2');
		if(matchType2.value !== 'null'){
			var matchType2Text = matchType2.options[matchType2.selectedIndex].text;
			var operator2 = document.getElementById('operator_2');
			var value2Input = document.querySelector('input[name="value_2"]');
			if(!operator2.classList.contains('ro-hidden') && !value2Input.classList.contains('ro-hidden')){
				var operator2Text = operator2.options[operator2.selectedIndex].text;
				var value2 = value2Input.value;
				title += ' ' + logicText + ' ' + matchType2Text + ' ' + operator2Text + ' "' + value2 + '"';
			} else {
				title += ' ' + logicText + ' ' + matchType2Text;
			}
		}
		
		document.getElementById('title').value = title;
		document.getElementById('title-prompt-text').style.display = 'none';
	});
});


/**
 * Alert of unsaved changes
 */

jQuery(document).ready(function($) {

	var formChanged = false;

	$('form :input').change(function() {
		formChanged = true;
	});

	$(window).on('beforeunload', function() {
		if (formChanged) {
			return true;
		}
	});

	$('#publish').click(function() {
		formChanged = false;
	});

	$('form').submit(function() {
		$(window).off('beforeunload');
	});
	
});