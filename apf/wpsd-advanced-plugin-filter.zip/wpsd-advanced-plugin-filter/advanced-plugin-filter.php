<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced Plugin Filter by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
* Description: Reduce initial server response time (TTFB) with this essential tool. It allows admins to selectively deactivate non-essential plugins based on a variety of conditions like URL, $_POST, thus making the website faster and reducing CPU utilization.
* Version: 1.0.47
* Updated: 2024-09-08
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-advanced-plugin-filter
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

/**
 * Constants
 */

define( 'WPSD_APF_DIR', __DIR__.'/' );

const WPSD_APF_VER = '1.0.47';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){

		case wp_doing_ajax():
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'update-plugin' ){
				
				require_once WPSD_APF_DIR.'admin/update.php';

				require_once WPSD_APF_DIR.'admin/mu-update.php';
			}

			if( $post_action === 'delete-plugin' ){
				
				require WPSD_APF_DIR.'admin/uninstall.php';
			}
			
			if( is_apf_plugin_ajax_area( $post_action ) ){
				
				require_once WPSD_APF_DIR.'includes/cpt.php';
			}

			if( $post_action === 'afp-code-validation'){

				require WPSD_APF_DIR.'admin/setup.php';

				try_validation_file();
			}
		break;

		case is_admin():
			
			require WPSD_APF_DIR.'admin/admin-area.php';

			run_back_end(__FILE__);

		break;

		case wp_doing_cron():
	
			require_once WPSD_APF_DIR.'admin/update.php';

			require_once WPSD_APF_DIR.'admin/mu-update.php';
		
		break;

		// default:
			
			

			// your code for font-end comes here		
			
		// break;
	}
		
		
}

function is_apf_plugin_ajax_area( $post_action ){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return false;

	return	($_POST['post_type']??'') === 'adv_plugin_filter' ||
		
			($_POST['taxonomy']??'') === 'apf_group' ||

			str_contains( $post_action, 'apf_group');

}