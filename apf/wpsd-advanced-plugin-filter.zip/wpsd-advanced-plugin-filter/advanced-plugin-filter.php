<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced Plugin Filter by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
* Description: Reduce initial server response time (TTFB) with this essential tool. It allows admins to selectively deactivate non-essential plugins based on a variety of conditions like URL, $_POST, thus making the website faster and reducing CPU utilization.
* Version: 1.0.49
* Updated: 2024-12-09
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: advanced-plugin-filter
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

/**
 * Constants
 */

define( 'WPSD_APF_DIR', __DIR__.'/' );

// change version in setup.php where `version_compare`
define( 'WPSD_APF_VER', '1.0.49' );

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){

		case wp_doing_ajax():
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'update-plugin' ){
				
				require_once WPSD_APF_DIR.'admin/update.php';

			}

			if( $post_action === 'delete-plugin' ){
				
				require WPSD_APF_DIR.'admin/uninstall.php';
			}
			
			if( is_apf_plugin_ajax_area( $post_action ) ){
				
				require_once WPSD_APF_DIR.'includes/cpt.php';
			}

			if( $post_action === 'afp-code-validation'){

				require WPSD_APF_DIR.'admin/setup.php';

				try_validation_file();
			}
		break;

		case is_admin():
			
			require WPSD_APF_DIR.'admin/admin-area.php';

			run_back_end(__FILE__);

			assure_latest_mu_plugin_version();
			
		break;

		case wp_doing_cron():
	
			require_once WPSD_APF_DIR.'admin/update.php';
			
		break;

		default:
			assure_latest_mu_plugin_version();
		break;
	}
		

}

/**
 * Automatically update mu plugin via shutdown function on cron or update ajax.
 * Hook `upgrader_process_complete` is unreliable for update mu-plugins
 */

function assure_latest_mu_plugin_version(){
	
	switch(true){

		case !defined('WPSD_APF_MU_VER'):
		case WPSD_APF_MU_VER === WPSD_APF_VER:
		case defined( 'WPSD_APF_CREATED'):
		case empty( get_option('adv-plugin-filter-enabled') ):
		case is_network_admin():
		case is_admin() && str_ends_with( $_SERVER['REQUEST_URI']??'', '/wp-admin/plugins.php' ):
		case !empty($_SERVER['HTTP_REFERER']) && wp_doing_ajax() && str_contains( $_SERVER['HTTP_REFERER'], '/wp-admin/plugins.php' ):
			
			return false;
	}
	
	require_once WPSD_APF_DIR.'admin/setup.php';

	add_action('init', __NAMESPACE__.'\refresh_mu_plugin');


}

function is_apf_plugin_ajax_area( $post_action ){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return false;

	return	($_POST['post_type']??'') === 'adv_plugin_filter' ||
		
			($_POST['taxonomy']??'') === 'apf_group' ||

			str_contains( $post_action, 'apf_group');

}
