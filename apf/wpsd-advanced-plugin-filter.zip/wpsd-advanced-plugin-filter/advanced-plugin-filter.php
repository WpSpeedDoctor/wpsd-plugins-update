<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: Advanced Plugin Filter by WP Speed Doctor
* Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
* Description: Reduce initial server response time (TTFB) with this essential tool. It allows admins to selectively deactivate non-essential plugins based on a variety of conditions like URL, $_POST, thus making the website faster and reducing CPU utilization.
* Version: 1.0.36
* Updated: 2024-05-07
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: advanced-plugin-filter
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

/**
 * Constants
 */

define( 'WPSD_APF_DIR', __DIR__.'/' );

const WPSD_APF_VER = '1.0.36';

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	switch(true){

		case wp_doing_ajax():
				
			if( ($_POST['action']??'') === 'update-plugin' ) {
				
				require_once WPSD_APF_DIR.'admin/update.php';
			}

			if( ($_POST['action']??'') === 'delete-plugin' ) {
				
				require WPSD_APF_DIR.'admin/uninstall.php';
			}
			
			if( is_apf_plugin_ajax_area() ){
				
				require_once WPSD_APF_DIR.'includes/cpt.php';
			}

		break;

		case is_admin():
			
			require WPSD_APF_DIR.'admin/admin-area.php';

			run_back_end(__FILE__);

			require_once WPSD_APF_DIR.'admin/update.php';

		break;

		// case wp_doing_cron():
	
			// your code for cron comes here
		
		// break;

		// default:
			
			

			// your code for font-end comes here		
			
		// break;
	}
		
		
}

function is_apf_plugin_ajax_area(){

	if($_SERVER['REQUEST_METHOD'] !== 'POST') return false;

	return	($_POST['post_type']??'') === 'adv_plugin_filter' ||
		
			($_POST['taxonomy']??'') === 'apf_group' ||

			str_contains( $_POST['action']??'', 'apf_group');

}