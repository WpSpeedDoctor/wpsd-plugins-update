<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

add_action( (is_admin() ? 'admin_footer' : 'wp_footer'), __NAMESPACE__.'\main_debug');


function main_debug(){

    $output = '';

    if( defined('APF_DISABLED_PLUGINS') ){

        $output .= esc_html__('Disabled plugins on the current page:','advanced-plugin-filter').PHP_EOL.PHP_EOL;

        $output .= implode( PHP_EOL, APF_DISABLED_PLUGINS ).PHP_EOL.PHP_EOL;
    } 

    if( defined('APF_ALLOWED_PLUGINS') ){
        
        if( $output !== '') $output .="***********\n";

        $output .= esc_html__('Allowed plugins on the current page:','advanced-plugin-filter').PHP_EOL.PHP_EOL;

        $output .= implode( PHP_EOL, APF_ALLOWED_PLUGINS ).PHP_EOL.PHP_EOL;

    }

    if( $output === '' ) return;

    $title =  esc_html__('Advanced Plugin Filter debug','advanced-plugin-filter').PHP_EOL.PHP_EOL;

    echo
<<<HTML

<!-- $title

$output

-->
HTML;

}

function display_debug_allowed(){

    $comment_text =  esc_html__('Advanced Plugin Filter allowed only these plugins the current page:','advanced-plugin-filter');

    the_apf_debug( APF_ALLOWED_PLUGINS, $comment_text );
    
}

function display_debug_disabled(){
    
    $comment_text =  esc_html__('Advanced Plugin Filter disabled these plugins on the current page:','advanced-plugin-filter');
    
    the_apf_debug( APF_DISABLED_PLUGINS, $comment_text );

}

function the_apf_debug( $value_array,$comment_text ){

    echo "<!-- \n\n{$comment_text} \n\n";

    echo implode("\n",$value_array);


    echo "\n-->\n\n";

}
