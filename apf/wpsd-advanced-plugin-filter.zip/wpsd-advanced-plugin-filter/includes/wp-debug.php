<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

// TODO: Display theme been disabled
// add sticky footer to display debug

switch( WPSD_REQUEST_TYPE ){

	case REQUEST_ADMIN:
		
		$display_hook = 'admin_footer';
		break;
	
	case REQUEST_FRONTEND:
	case REQUEST_404:
		

		
		
		$display_hook = 'wp_footer';
		break;

	default:
		return;
}


add_action( $display_hook, __NAMESPACE__.'\main_debug');

switch(true){

	case isset($td):
		$debug['theme'] = 1;//disabled
		break;
	case isset($ta):
		$debug['theme'] = 2;//allowed
		break;
	default:
		$debug['theme']	= 3;//unchanged
		break;
}

//this constant passes  debug information to later hook where is displayed.
define('APF_DEBUG', $debug??null );

function main_debug(){

	$output = '';

	$output .= get_disabled_plugins_output();

	$output .= get_allowed_plugins_output();

	$output .= get_executed_plugins_output();

	$output .= get_debug_output();

	if($output === ''){
		$output = esc_html__('No plugins have been filtered here.', 'advanced-plugin-filter') . PHP_EOL;
	}

	$output .= get_theme_status();
	
	$title = esc_html__('Advanced Plugin Filter debug', 'advanced-plugin-filter');

	echo
<<<HTML

<!-- $title

$output
-->
HTML;

}

function get_theme_status(){

	switch(APF_DEBUG['theme']){

		case 1:
			$output = __('Disabled', 'advanced-plugin-filter');
			break;

		case 2:
			$output = __('Allowed', 'advanced-plugin-filter');
			break;

		case 3:
			$output = __('Unchanged', 'advanced-plugin-filter');
			break;

	}

	return "\nTheme: {$output}\n\n";

}

function get_disabled_plugins_output(){

	$output = '';

	if(defined('APF_DISABLED_PLUGINS') && !empty(APF_DISABLED_PLUGINS)){

		$output .= "***********\n";

		$output .= esc_html__('Disabled plugins on the current page:', 'advanced-plugin-filter');

		$output .= get_plugin_list_debug_markup( array_keys( APF_DISABLED_PLUGINS)).PHP_EOL;

	}

	return $output;

}

function get_plugin_list_debug_markup( $plugins ){

	return "\n ● ".implode( "\n ● ", $plugins) ."\n\n";
}

function get_allowed_plugins_output(){

	$output = '';

	if(defined('APF_ALLOWED_PLUGINS')){

		if($output !== ''){
			$output .= "***********\n";
		}

		if(empty(APF_ALLOWED_PLUGINS)){

			$output .= esc_html__('No plugins allowed on this page.', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

		} else {

			$output .= esc_html__('Allowed plugins on the current page:', 'advanced-plugin-filter');

			$output .= get_plugin_list_debug_markup( array_keys(APF_ALLOWED_PLUGINS) );

		}

	}

	return $output;

}

function get_executed_plugins_output(){

	defined( 'WPSD_APF_DIR' ) || define( 'WPSD_APF_DIR' , WP_PLUGIN_DIR.'/wpsd-advanced-plugin-filter/');

	require_once WPSD_APF_DIR.'admin/setup.php';


	switch(true){

		case !defined('APF_DISABLED_PLUGINS') && !defined('APF_ALLOWED_PLUGINS' ):
		case !is_callable( get_mu_plugin_namespace().'\filter_active_plugins'):
			return '';
	}

	$output = '';
	
	$mu_plugin_namespace = get_mu_plugin_namespace();

	$executed_plugins = call_user_func( $mu_plugin_namespace.'\filter_active_plugins',false);

	if( is_multisite() ){

		$executed_sitewide_plugins = call_user_func( $mu_plugin_namespace.'\filter_active_sitewide_plugins',false);

		$executed_plugins = array_unique( array_merge( $executed_plugins, array_flip($executed_sitewide_plugins)) );
	}

	$output .= "***********\n";

	if(empty($executed_plugins)){

		$output .= esc_html__('No plugins have been executed on this page', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

	} else {

		$output .= esc_html__('Plugins executed on this page:', 'advanced-plugin-filter');

		$output .= get_plugin_list_debug_markup( $executed_plugins );

	}

	return $output;

}

function get_debug_output(){
	
	$output = '';
	
	if(!empty(APF_DEBUG['d'])){
		
		$text = esc_html__('Disabled plugins by filter ID', 'advanced-plugin-filter');

		$output .= get_debug_data_output( APF_DEBUG, 'd', $text );

	}

	if(!empty(APF_DEBUG['a'])){
		
		$text = esc_html__('Allowed plugins by filter ID', 'advanced-plugin-filter');

		$output .= get_debug_data_output( APF_DEBUG, 'a', $text );
	}

	return $output;

}

function get_debug_data_output( $debug, $type, $text ){
		
	$output = "\n**********\n";

	$output .= $text;

	foreach( $debug[$type] as $post_id => $plugin_list ){

		$output .= "\n\n{$post_id}\n";

		$output .= get_plugin_list_debug_markup( $plugin_list );

	}
	
	return $output;
}

function display_debug_allowed(){

	$comment_text =  esc_html__('Advanced Plugin Filter allowed only these plugins the current page:','advanced-plugin-filter');

	the_apf_debug( APF_ALLOWED_PLUGINS, $comment_text );
	
}

function display_debug_disabled(){
	die;
	$comment_text =  esc_html__('Advanced Plugin Filter disabled these plugins on the current page:','advanced-plugin-filter');
	
	the_apf_debug( APF_DISABLED_PLUGINS, $comment_text );

}

function the_apf_debug( $value_array,$comment_text ){
return;
	$values = implode("\n",$value_array);

	echo <<<HTML
	<!--
	{$comment_text}
	{$values}
	-->
	HTML;

}
