<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

add_action( (is_admin() ? 'admin_footer' : 'wp_footer'), __NAMESPACE__.'\main_debug');

define('APF_DEBUG', $debug??null );

function main_debug(){

	$output = '';

	$output .= get_disabled_plugins_output();

	$output .= get_allowed_plugins_output();

	$output .= get_executed_plugins_output();

	$output .= get_debug_output();

	if($output === ''){
		$output = esc_html__('No plugins have been filtered here.', 'advanced-plugin-filter') . PHP_EOL;
	}

	$title = esc_html__('Advanced Plugin Filter debug', 'advanced-plugin-filter');

	echo
<<<HTML

<!-- $title

$output
-->
HTML;

}

function get_disabled_plugins_output(){

	$output = '';

	if(defined('APF_DISABLED_PLUGINS') && !empty(APF_DISABLED_PLUGINS)){

		$output .= "***********\n";

		$output .= esc_html__('Disabled plugins on the current page:', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

		$output .= get_plugin_list( APF_DISABLED_PLUGINS);

	}

	return $output;

}

function get_plugin_list( $plugins ){

	return "\n ● ".implode( "\n ● ", $plugins) ."\n\n";
}

function get_allowed_plugins_output(){

	$output = '';

	if(defined('APF_ALLOWED_PLUGINS')){

		if($output !== ''){
			$output .= "***********\n";
		}

		if(empty(APF_ALLOWED_PLUGINS)){

			$output .= esc_html__('No plugins allowed on this page.', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

		} else {

			$output .= esc_html__('Allowed plugins on the current page:', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

			$output .= get_plugin_list( APF_ALLOWED_PLUGINS );

		}

	}

	return $output;

}

function get_executed_plugins_output(){

	$output = '';

	if(
		(defined('APF_DISABLED_PLUGINS') || defined('APF_ALLOWED_PLUGINS')) &&
		is_callable('\WPSD\apf\mu_plugin\filter_active_plugins')
	){

		$executed_plugins = \WPSD\apf\mu_plugin\filter_active_plugins(false);

		$output .= "***********\n";

		if(empty($executed_plugins)){

			$output .= esc_html__('No plugins have been executed on this page', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

		} else {

			$output .= esc_html__('Plugins executed on this page:', 'advanced-plugin-filter') . PHP_EOL . PHP_EOL;

			$output .= get_plugin_list( $executed_plugins );

		}

	}

	return $output;

}

function get_debug_output(){
	
	$output = '';
	
	if(!empty(APF_DEBUG['d'])){
		
		$text = esc_html__('Disabled plugins by filter ID', 'advanced-plugin-filter');

		$output .= get_debug_data_output( APF_DEBUG, 'd', $text );

	}

	if(!empty(APF_DEBUG['a'])){
		
		$text = esc_html__('Allowed plugins by filter ID', 'advanced-plugin-filter');

		$output .= get_debug_data_output( APF_DEBUG, 'a', $text );
	}

	return $output;

}

function get_debug_data_output( $debug, $type, $text ){
		
	$output = "\n**********\n";

	$output .= $text;

	foreach( $debug[$type] as $post_id => $plugin_list ){

		$output .= "\n\n{$post_id}\n";

		$output .= get_plugin_list( $plugin_list );

	}
	
	$output .= "\n";

	return $output;
}

function display_debug_allowed(){

	$comment_text =  esc_html__('Advanced Plugin Filter allowed only these plugins the current page:','advanced-plugin-filter');

	the_apf_debug( APF_ALLOWED_PLUGINS, $comment_text );
	
}

function display_debug_disabled(){
	
	$comment_text =  esc_html__('Advanced Plugin Filter disabled these plugins on the current page:','advanced-plugin-filter');
	
	the_apf_debug( APF_DISABLED_PLUGINS, $comment_text );

}

function the_apf_debug( $value_array,$comment_text ){

	echo "<!-- \n\n{$comment_text} \n\n";

	echo implode("\n",$value_array);


	echo "\n-->\n\n";

}
