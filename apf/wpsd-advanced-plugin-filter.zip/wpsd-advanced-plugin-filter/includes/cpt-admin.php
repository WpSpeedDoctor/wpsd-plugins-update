<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function remove_quick_edit_for_cpt( $actions, $post ){

	if( $post->post_type === 'adv_plugin_filter' && !empty($actions['edit']) ){

		unset( $actions['inline hide-if-no-js'] );

		$actions['edit'] = str_replace( 'action=edit', 'action=edit&adv_plugin_filter', $actions['edit']);
	}

	return $actions;
}

function add_adv_filter_query_string( $actions, $post ){

	if( $post->post_type === 'adv_plugin_filter' && !empty($actions['edit']) ){

		$actions['edit'] = str_replace( 'action=edit', 'action=edit&adv_plugin_filter', $actions['edit']);
	}

	return $actions;
}

if( ($_GET['post_type']??'') === 'adv_plugin_filter' ){

	add_filter( 'post_row_actions', __NAMESPACE__.'\remove_quick_edit_for_cpt', 10, 2 );

	add_filter( 'post_row_actions', __NAMESPACE__.'\add_adv_filter_query_string', 10, 2 );
}


/**
 * Author in column
 */
function add_author_column($columns){
    $result = [];
    foreach($columns as $key => $value){
        $result[$key] = $value;
        if($key === 'title') $result['author_name'] = 'Author';
    }
    return $result;
}
add_filter('manage_adv_plugin_filter_posts_columns', __NAMESPACE__.'\add_author_column');

function display_author_column($column_key, $post_id){
    if($column_key == 'author_name'){
        $post_author_id = get_post_field('post_author', $post_id);
        $author_name = esc_html( get_the_author_meta('display_name', $post_author_id) );
        echo $author_name;
    }
}
add_action('manage_adv_plugin_filter_posts_custom_column', __NAMESPACE__.'\display_author_column', 10, 2);

function make_author_column_sortable($columns){
    $columns['author_name'] = 'author';
    return $columns;
}

add_filter('manage_edit-adv_plugin_filter_sortable_columns', __NAMESPACE__.'\make_author_column_sortable');

