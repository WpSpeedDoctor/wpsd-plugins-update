<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;


function bulk_edit_main(){

	$header = __('Bulk add or remove plugins from rules.', 'advanced-plugin-filter');
	
	echo <<<HTML
	<div class="wrap mb10 ">
		<h1>{$header}</h1>
	</div>
	HTML;


	switch($_SERVER['REQUEST_METHOD']??''){

		case 'POST':
			current_user_can('administrator') && save_bulk_edit();
		break;

		case 'GET':
			display_bulk_edit_form();
		break;

		default:
			display_invalid_request();
			return;
	}


}

function display_invalid_request(){

	wp_die( __('Invalid request', 'advanced-plugin-filter') );
}

function save_bulk_edit(){

	$update_count = 0;

	$form_data = get_form_data($_POST);

	$posts = get_posts(
		[	'post_type' => 'adv_plugin_filter',
			'post_status' => 'any',
			'posts_per_page' => -1
		]
	);

	foreach($posts as $post){

		$post_data = json_decode($post->post_content);

		if( !empty($post_data->plugins) && !is_array($post_data->plugins) ){
		
			$post_data->plugins = (array) $post_data->plugins;
		}

		if(
			empty($post_data) ||
			 $post_data->filter_mode === 'disable' && $form_data->is_allowed ||
			 $post_data->filter_mode === 'allow' && !$form_data->is_allowed
		){
			continue;
		}

		if( $form_data->is_add ){
			
			$has_changed = add_plugins_to_post($post_data,$form_data);

		} else {
			
			$has_changed = remove_plugins_from_post($post_data,$form_data);
		}

		$change_markup = $has_changed ? '<span style="color:green">✔</span>' : '<span style="color:brown">✘</span>';
		
		$url = admin_url("post.php?post=$post->ID&action=edit&adv_plugin_filter");
		echo <<<HTML
		{$change_markup} {$post->post_title} <a href="$url">ID: $post->ID</a>
		<br>
		HTML;


		if( !$has_changed ){
			continue;
		}

		$post_data->plugins = (array) array_unique($post_data->plugins);
		$post_data->last_updated = time();
		$post->post_content = json_encode($post_data);
		wp_update_post($post);

		$update_count++;
	}
	
	if( $update_count === 0){
		return;
	}

	require_once WPSD_APF_DIR.'admin/setup.php';
	
	refresh_mu_plugin();

	$action_text  = $form_data->is_add ? __('added', 'advanced-plugin-filter') : __('removed', 'advanced-plugin-filter');

	$type_text = $form_data->is_allowed ? __('allowed', 'advanced-plugin-filter') : __('disabled', 'advanced-plugin-filter');

	$preposition_text = $form_data->is_add ? __('to', 'advanced-plugin-filter') : __('from', 'advanced-plugin-filter');

	$text = sprintf( 
		__('%s filters updated with plugins or theme %s %s %s mode filters', 'advanced-plugin-filter'),
		$update_count,
		$action_text,
		$preposition_text,
		$type_text,
	);
	


	echo <<<HTML
	<h3>{$text}</h3>
	HTML;
}

function remove_plugins_from_post( &$post_data, $form_data){

	$original_count = count($post_data->plugins);

	$post_data->plugins = array_diff(  (array) $post_data->plugins, (array) $form_data->plugins);

	return count($post_data->plugins) < $original_count;
}

function add_plugins_to_post( &$post_data,$form_data){

	$original_count = count($post_data->plugins);

	$post_data->plugins = array_unique(array_merge( (array) $post_data->plugins, (array) $form_data->plugins));

	return count($post_data->plugins) > $original_count;
}

function get_form_data($form_data){
	
	$plugins_sanitized = [];

	foreach($form_data['plugins'] as $value){
	
		if( str_contains($value,'../') ){
			continue;
		}

		$plugins_sanitized[] = sanitize_text_field($value);
	}

	return (object)[

		'is_add'	=> $form_data['bulk-edit-action'] === 'bulk-edit-add',
		'is_allowed' => $form_data['bulk-edit-rule'] === 'allowed',
		'plugins'	=> $plugins_sanitized
	];
}

function display_bulk_edit_form(){

	$plugins = get_plugins_data_for_checkbox_form();

	$data = (object)[

		'nonce'				=> wp_create_nonce('bulk_edit_nonce'),
		'bulk_edit_add'		=> __( 'Add these plugins to', 'advanced-plugin-filter' ),
		'bulk_edit_remove'	=> __( 'Remove these plugins from', 'advanced-plugin-filter' ),
		'allowed'			=> __( 'Allow mode rules', 'advanced-plugin-filter' ),
		'disabled'			=> __( 'Disable mode rules', 'advanced-plugin-filter' ),
		'button_text'		=> __( 'Apply', 'advanced-plugin-filter' ),
	];

	echo <<<HTML
	<form action="" method="post" class="apf-bulk-edit">
		<input type="hidden" name="nonce" value="{$data->nonce}">
		<p>
			<select name="bulk-edit-action">
				<option value="bulk-edit-add">{$data->bulk_edit_add}</option>
				<option value="bulk-edit-remove">{$data->bulk_edit_remove}</option>
			</select>
			<select name="bulk-edit-rule">
				<option value="allowed">{$data->allowed}</option>
				<option value="disabled">{$data->disabled}</option>
			</select>
		</p>
		
	HTML;


	the_all_installed_plugins_checkbox_markup($plugins, $display_post_types = false);

	echo <<<HTML
	<button type="submit" class="button-primary">{$data->button_text}</button>
	</form>
	HTML;


}

function get_plugin_column( $plugins_group ){
	
	$output = '';

	foreach($plugins_group as $plugin_data){
	
		$output .= <<<HTML
		<label class="ro-plugin-inactive">
			<input type="checkbox" name="plugins[]" value="{$plugin_data['path']}">{$plugin_data['name']}
		</label>
		HTML;
	}
}
