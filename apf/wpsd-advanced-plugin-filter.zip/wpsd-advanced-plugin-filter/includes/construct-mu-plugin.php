<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;


function get_mu_plugin_markup( $conditions_markup ){
	
	$markup_data = get_markup_data( $conditions_markup );

	$template = file_get_contents( WPSD_APF_DIR.'/includes/parts/template-mu-plugin.php' );

	foreach( $markup_data as $variable => $value ){

		$template = str_replace( '{$'.$variable.'}', $value, $template );
	}
	
	return str_replace( "\n\n","\n", $template);
	
}

function get_markup_data( $conditions_markup ){


	require_once WPSD_APF_DIR.'includes/recovery-functions.php';

	return [

		'match_type_variables_markup' => get_match_type_variables_markup($conditions_markup),

		'debug_enabled_markup' => get_option('adv-plugin-filter-debug', '0') ? '' : 'if( WP_DEBUG ) ',
		
		'recovery_query_string' => get_recovery_query_string(),
		
		'mu_plugin_name' => esc_html__("WPSD Advanced Plugin Filter", 'advanced-plugin-filter'),
		
		'mu_plugin_description' => esc_html__("Run less code, run faster website", 'advanced-plugin-filter'),
		
		'mu_plugin_author' => "WP Speed Doctor",
		
		'addon_functions_markup' => get_addon_functions_markup($conditions_markup),
		
		'mu_plugin_url' => "https://wpspeeddoctor.com/",

		'version'		=> WPSD_APF_VER, 
		
		'text_domain' => 'advanced-plugin-filter',
		
		'namespace' => 'WPSD\\apf\\mu_plugin\\test',

		'plugin_dir' => basename(WPSD_APF_DIR),
		
		'conditions_markup' => $conditions_markup,

		'all_plugins' => "\$p = [\n	'".implode("',\n	'",get_plugins_list( $add_theme = false ))."'\n];",

		'blackout_protection' => get_blackout_protection()

	];

}

function get_blackout_protection(){

	$apf_position = array_search( 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php' , get_plugins_list() );

	return <<<HTML
			if( isset(\$d) ) unset(\$d[{$apf_position}]);

			if( isset(\$a) ) \$a[{$apf_position}]=null;
	
	HTML;
}

function get_plugins_list( $add_theme = true ){

	if( !function_exists('get_plugins') ){
		
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$result = array_keys( get_plugins() );

	if( $add_theme ){

		$result[] = 'theme';
	}
	
	return $result;
}

function get_mu_conditions_markup(){

	$args = array(
		'post_type' => 'adv_plugin_filter', 
		'post_status' => 'publish',
		'posts_per_page' => -1,
	);

	$active_apf_rules = get_posts($args);

	$conditions_data = get_conditions( $active_apf_rules );

	if( empty($conditions_data) ) return '';

	$ifs_markup = get_ifs_markup( $conditions_data );

	return $ifs_markup;

}

//MARK:var markup
function get_match_type_variables_markup( $conditions_markup ){

	$dependency_string = get_dependency_string( $conditions_markup);

	$result= "\n";

	$used_match_markups = [

		'uri'				=> "\$uri = \$_SERVER['REQUEST_URI'] ?? \$_SERVER['SCRIPT_NAME'];",

		'qs'				=> "\$qs = \$_SERVER['QUERY_STRING']??'';",

		'cookie'			=> "\$cookie = \$_SERVER['HTTP_COOKIE']??'';",
		
		'is_logged_in'		=> "\$is_logged_in = isset(\$_COOKIE['".LOGGED_IN_COOKIE."']);",

		'admin_post_type'	=> "\$admin_post_type = get_admin_post_type(\$is_logged_in);",
		
		'post_type'			=> "\$post_type = get_front_end_post_type();",

	];

	foreach( $used_match_markups as $variable => $variable_markup ){

		if( !str_contains( $dependency_string.$conditions_markup , "\${$variable}" ) ) continue;

		$result .="	{$variable_markup}\n\n";
	}

	return $result;

}


function get_dependency_string($conditions_markup){

    $dependencies = [

        '$admin_post_type'	=> [ '$is_logged_in'],

    ];

    $dependency_strings = '';

    foreach($dependencies as $variable_with_dependency => $variables_to_be_depending_on){

        if(str_contains($conditions_markup, $variable_with_dependency)) $dependency_strings .=implode('',$variables_to_be_depending_on);
    }

    return $dependency_strings;
}

function get_addon_functions_markup($conditions_markup){

	$addon_functions_markup = $result = '';

	$addon_functions_markup .= get_post_type_front_end_function_markup( $conditions_markup );

	$addon_functions_markup .= get_post_type_back_end_function_markup( $conditions_markup );

	$code_lines = explode( "\n", $addon_functions_markup );

	$filtered_words = [ 'php', 'define', 'namespace', '//'];

	foreach( $code_lines as $line ){

		if(  is_filtered_line( $line, $filtered_words ) ) continue;

		$result .= $line;
	}

	return "$result\n";

}

function is_filtered_line( $line, $filtered_words ){

	foreach( $filtered_words as $filtered_word ){

        if( str_contains($line, $filtered_word) ) return true;
    }

	return false;
}

function get_post_type_back_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$admin_post_type') ) return '';

	return file_get_contents(WPSD_APF_DIR.'includes/post-type-be-functions.php').PHP_EOL;

}

function get_post_type_front_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$post_type') ) return '';

	$uri_roots_markup = get_uri_roots_markup();

	$template_markup = file_get_contents(WPSD_APF_DIR.'includes/post-type-fe-functions.php').PHP_EOL;
	
	$template_with_lang_roots = str_replace('{$uri_language_root_replacement}', $uri_roots_markup, $template_markup );

	return $template_with_lang_roots;

}

function get_uri_roots_markup(){

	$uri_roots = get_language_uri_roots();

	if( empty($uri_roots) ) return "if( WPSD_URI_PATH === '/' ) return get_front_page_type();";

	$uri_roots_case_markup = "	case '/".implode("/':\n\r		case '/",$uri_roots)."/':";

	return <<<HTML
	switch( trailingslashit( WPSD_URI_PATH ) ){

		{$uri_roots_case_markup}

				return get_front_page_type();

				break;
		}
	HTML;
}

function get_language_uri_roots(){
	
	$active_plugins = get_active_plugins_from_db();
	
	switch(true){
		
		//WPML
		case in_array('sitepress-multilingual-cms/sitepress.php', $active_plugins);

			$wpml_languages = apply_filters('wpml_active_languages', NULL, 'orderby=id&order=desc');

			if( !empty($wpml_languages) ){

				foreach ($wpml_languages as $language) {

					//parse_url() from 7.4 that this plugin is supported is reliable enough not to use wp_parse_url()
					$languages[] = trim(parse_url($language['url'])['path'], '/');
					
				}
			}

		break;

		//Polylang
		case in_array('polylang/polylang.php', $active_plugins) || in_array('polylang-pro/polylang.php', $active_plugins):

			global $wpdb;
			
			$languages = $wpdb->get_col(
				"SELECT slug 
				FROM {$wpdb->terms} AS t
				INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
				WHERE tt.taxonomy = 'language'"
			);

		break;
		
		//TranslatePress
		case in_array('translatepress-multilingual/index.php',$active_plugins) || in_array('translatepress-developer/index.php',$active_plugins):
		
			$trp_langs = get_option('trp_settings');
			
			if( !empty( $trp_langs ) ){

				foreach ($trp_langs['publish-languages'] as $code) {
					
					if ($code !== $trp_langs['default-language']) {
						
						$languages[] =  $trp_langs['url-slugs'][$code];
					}
				}
			}
		break;
	
		default:
		
            $languages = false;

		break;
	}

	return $languages??false;

}

function get_active_plugins_from_db(){

	global $wpdb;

	$active_plugins = $wpdb->get_var("
		SELECT option_value 
		FROM {$wpdb->options} 
		WHERE option_name = 'active_plugins'
	");

	return unserialize($active_plugins);

}

function get_ifs_markup($conditions_data){

	$result = '';
	
	$all_plugins = get_plugins_list();

	foreach($conditions_data as $data){
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'disable' ) continue;
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'allow' ) $data['plugins'] = ['all'];

		$result .= "\n	//Post ID: {$data['post_id']}\n";

		$result .="	if( {$data['condition']} ){\n\n";
		
		$result .= get_variable_markup( $data, $all_plugins );

		$result .= "	}\n";
	
	}
	
	return $result;
}

function get_variable_markup( $data, $all_plugins ){

	$result ='';
	
	$filter_type_variable_name = $data['filter_mode'] === 'disable' ? 'd' : 'a';

	if( 
		empty( $data['plugins'] ) ||
		
		$data['filter_mode'] !== 'disable' &&
		
		count($data['plugins']) === 1 &&
		
		$data['plugins'][0]==='theme'
	) {
			
			$data['plugins'][]='all';
	}

	foreach( $data['plugins'] as $key ){
	
		if( $key === 'theme' ){

			
			$result .= "    		\$t{$filter_type_variable_name} = true;\n";

		} else {

			$p_key = $key==='all' ? "'all'" : array_search($key, $all_plugins);
			
			$debug_text =  get_debug_plugin_text(  $key, $data, $filter_type_variable_name );
	
			if( $p_key === false ) continue;
	
			$result .= "    		\${$filter_type_variable_name}[{$p_key}] = null;{$debug_text}\n";
		}
		
	}

	return $result;
}

function get_debug_plugin_text( $key, $data, $filter_type_variable_name){

	if( empty( get_option('adv-plugin-filter-debug', '0') ) ) return '';

	return " \$debug['{$filter_type_variable_name}'][{$data['post_id']}][]='{$key}';";
	
}


/**
* @param object $active_apf_rules get_post()
* @return array -
* - condition =>  (string)condition markup for if statement
* - plugins => (array) allowed plugins list
* -
*/
//MARK: Get condition
function get_conditions($active_apf_rules){
	
	foreach( $active_apf_rules as $rule ){
		
		$condition_markup = '';

		$rule_data = json_decode($rule->post_content,true);

		foreach(['1','2'] as $count){
			
			if(empty($rule_data["match_type_{$count}"])) continue;
			
			if( $count === '2' && $rule_data['match_type_2'] !=='null' ){

				$condition_markup .= ($rule_data['logic']??'') === 'or' ? ' || ' : ' && ';
			} 

			if( $count === '2' && $rule_data["match_type_$count"] === 'null' ) continue;

			$condition_markup .= get_condition_php_markup(
				$rule_data["match_type_{$count}"],
				$rule_data["operator_{$count}"],
				$rule_data["value_{$count}"]
			);
		}

		$result[] = [

			'filter_mode' => $rule_data['filter_mode']??'allow',
			
			'condition' => $condition_markup,
			
			'plugins'=>$rule_data['plugins'],

			'post_id'=>$rule->ID //passed for debugging purposes
		];
		
	}

	return $result??'';
}

function is_condition_a_function($match_type){

	$condition_is_function = [
		'post_key_exists',
		'frontend',
		'admin',
		'ajax',
		'cron',
		'rest',
		'logged_in',
		'logged_in_not',
		'null'
	];

	return in_array( $match_type, $condition_is_function );
}
	
function get_condition_php_markup($match_type,$operator,$value){

	$match_value_markup = get_match_value_markup($match_type,$operator,$value);

	if( is_condition_a_function( $match_type ) ) return $match_value_markup;

	switch($operator){

		case 'equal':
			
				$condition_markup = "{$match_value_markup} === '{$value}'";
		break;

		case 'not_equal':
			
				$condition_markup = "{$match_value_markup} !== '{$value}'";
		break;
			
		case 'contain':
				
				$condition_markup = "str_contains( {$match_value_markup},'{$value}')";
		break;
			
		case 'not_contain':
				
				$condition_markup = "!str_contains( {$match_value_markup},'{$value}')";
		break;
				
		case 'start':
					
					$condition_markup = "str_starts_with({$match_value_markup}, '{$value}')";
		break;
				
		case 'not_start':
					
					$condition_markup = "!str_starts_with({$match_value_markup}, '{$value}')";
		break;
					
		case 'regex':
						
					$condition_markup = "!empty(@preg_match('~{$value}~', {$match_value_markup}))";
		break;
					
		case 'not_regex':
						
					$condition_markup = "empty(@preg_match('~{$value}~', {$match_value_markup}))";
		break;

		
	}

	return $condition_markup??[];
}

function get_match_value_markup($match_type,$operator,$value){

	switch($match_type){
		case 'uri':
			$result = "\$uri";
		break;
			
		case 'uri_path':

			$result='WPSD_URI_PATH';
		break;
		
		case 'query_string':
			$result = "\$qs";
		break;
		
		case 'post_action':
			$result = "isset(\$_POST['action']) && \$_POST['action']";
		break;
		
		case 'post_key_exists':
			
			$operator_markup = ($operator === 'not_equal') ? '!':'';

			$result = "{$operator_markup}isset( \$_POST['{$value}'] )";
		break;

		case 'cookies':

			$result = "\$cookie";
		break;
		
		case 'frontend':

			$result = "WP_REQUEST_TYPE === 'frontend'";
		break;
			
		case 'admin':
			
			$result = "WP_REQUEST_TYPE === 'admin'";
		break;
			
		case 'ajax':
			
			$result = "WP_REQUEST_TYPE === 'ajax'";
		break;
			
		case 'cron':
			
			$result = "WP_REQUEST_TYPE === 'cron'";
		break;
			
		case 'rest':
			
			$result = "WP_REQUEST_TYPE === 'rest'";
		break;
		
		case 'logged_in':

			$result = "\$is_logged_in";
		break;
			
		case 'logged_in_not':

			$result = "!\$is_logged_in";
		break;
		
		case 'host':
			$result = "(\$_SERVER['HTTP_HOST']??'')";
		break;
		
		case 'locale':
			$result = "get_locale()";
		break;
		
		case 'user_agent':
			$result = "(\$_SERVER['HTTP_USER_AGENT']??'')";
		break;
		
		case 'referer':
			$result = "(\$_SERVER['HTTP_REFERER']??'')";
		break;
		
		case 'null':
			$result = '';
		break;

		default:

		$result = "\${$match_type}";
		break;
	}

	return $result;
}
