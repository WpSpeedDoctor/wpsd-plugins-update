<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;


function get_mu_plugin_markup( $conditions_markup ){
	
	$markup_data = get_markup_data( $conditions_markup );

	$template = file_get_contents( WPSD_APF_DIR.'/includes/parts/template-mu-plugin.php' );

	foreach( $markup_data as $variable => $value ){

		$template = str_replace( '{$'.$variable.'}', $value, $template );
	}

	
	// deb( $template , basename(__FILE__).' at '.__LINE__ );
	
	return $template;
	
}

function get_markup_data( $conditions_markup ) {


	require_once WPSD_APF_DIR.'includes/recovery-functions.php';

	return [

		'match_type_variables_markup' => get_match_type_variables_markup($conditions_markup),

		'debug_enabled_markup' => get_option('adv-plugin-filter-debug', '0') ? '' : 'if( WP_DEBUG ) ',
		
		'recovery_query_string' => get_recovery_query_string(),
		
		'mu_plugin_name' => esc_html__("WPSD Advanced Plugin Filter", 'advanced-plugin-filter'),
		
		'mu_plugin_description' => esc_html__("Run less code, run faster website", 'advanced-plugin-filter'),
		
		'mu_plugin_author' => "WP Speed Doctor",
		
		'addon_functions_markup' => get_addon_functions_markup($conditions_markup),
		
		'mu_plugin_url' => "https://wpspeeddoctor.com/",

		'version'		=> WPSD_APF_VER,
		
		'text_domain' => 'advanced-plugin-filter',
		
		'namespace' => 'WPSD\\apf\\mu_plugin\\test',

		'plugin_dir' => basename(WPSD_APF_DIR),
		
		'conditions_markup' => $conditions_markup,

		'all_plugins' => '$p = '.var_export(get_plugins_list(),true).';',

		'blackout_allowed_protection' => get_blackout_allowed_protection( $conditions_markup ),

		'blackout_disabled_protection' => get_blackout_disabled_protection( $conditions_markup )
	];

}

function get_blackout_disabled_protection( $conditions_markup ){

	$is_admin_markup = str_contains( $conditions_markup, '$request_type') ? "\$request_type === 'back-end'" : 'is_admin()';

	$apf_position = array_search( 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php' , get_plugins_list() );

	return 
<<<HTML
//this makes always to load plugin filter on the back end to avoid menu blackout
		if( {$is_admin_markup} ) unset(\$d[{$apf_position}]);
HTML;

}

function get_blackout_allowed_protection( $conditions_markup ){

	$is_admin_markup = str_contains( $conditions_markup, '$request_type') ? "\$request_type === 'back-end'" : 'is_admin()';

	$apf_position = array_search( 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php' , get_plugins_list() );

	return 
<<<HTML
//this makes always to load plugin filter on the back end to avoid menu blackout
		if( {$is_admin_markup} ) \$a[{$apf_position}]=null;
HTML;

}

function get_plugins_list(){

	static $result = false;

	if( $result !== false ) return $result;

	$result = array_keys( get_plugins() );

	$result[] = 'theme';
	
	return $result;
}

function get_mu_conditions_markup(){

	$args = array(
		'post_type' => 'adv_plugin_filter', 
		'post_status' => 'publish',
		'posts_per_page' => -1,
	);

	$active_apf_rules = get_posts($args);

	$conditions_data = get_conditions( $active_apf_rules );

	if( empty($conditions_data) ) return '';

	$ifs_markup = get_ifs_markup( $conditions_data );

	return $ifs_markup;

}

//MARK:var markup
function get_match_type_variables_markup( $conditions_markup ){

	$dependency_string = get_dependency_string( $conditions_markup);

	$result= "\n";

	$used_match_markups = [

		'uri_path' 			=> "\$uri_path = \$_SERVER['QUERY_STRING'] === '' ? \$_SERVER['REQUEST_URI'] : strstr(\$_SERVER['REQUEST_URI'], '?', true);",
		
		'request_type'		=>	get_variable_request_type_markup(),
		
		'is_logged_in'		=> "\$is_logged_in = isset(\$_COOKIE['".LOGGED_IN_COOKIE."']);",

		'admin_post_type'	=> "\$admin_post_type = get_admin_post_type(\$request_type, \$is_logged_in);",
		
		'post_type'			=> "\$post_type = get_post_type_from_uri( \$uri_path, \$request_type );",

	];

	foreach( $used_match_markups as $variable => $variable_markup ){

		if( !str_contains( $dependency_string.$conditions_markup , "\${$variable}" ) ) continue;

		$result .="	{$variable_markup}\n\n";
	}

	return $result;

}


function get_dependency_string($conditions_markup) {

    $dependencies = [
        ['$post_type', '$uri_path'],
        ['$post_type', '$request_type'],
        ['$admin_post_type', '$uri_path'],
        ['$admin_post_type', '$request_type'],
        ['$admin_post_type', '$is_logged_in'],
        ['$request_type', '$uri_path'],
    ];

    $dependency_strings = '';

    foreach ($dependencies as $dependency_pair) {

        [$variable_with_dependency, $dependency_name] = $dependency_pair;

        if (str_contains($conditions_markup, $variable_with_dependency)) $dependency_strings .= $dependency_name;
    }

    return $dependency_strings;
}


function get_variable_request_type_markup(){

	return
"switch(true){

		case defined( 'DOING_AJAX' ) || isset(\$_GET['wc-ajax']):

			\$request_type = 'ajax';
			break;
			
		case is_admin():

			\$request_type = 'admin';
			break;
		
		case defined( 'DOING_CRON' ):
			
			\$request_type = 'cron';
			break;
		
		case str_contains( \$uri_path,'/wp-json/'):

			\$request_type = 'rest';
			break;
		
		case str_contains( \$uri_path,'/wp-content/'):

			\$request_type = 'content';
			break;

		default:

			\$request_type = 'frontend';
			break;

	}";

}





function get_addon_functions_markup($conditions_markup){

	$addon_functions_markup = $result = '';

	$addon_functions_markup .= get_post_type_front_end_function_markup( $conditions_markup );

	$addon_functions_markup .= get_post_type_back_end_function_markup( $conditions_markup );

	$code_lines = explode( "\n", $addon_functions_markup );

	$filtered_words = [ 'php', 'define', 'namespace', '//'];

	foreach( $code_lines as $line ){

		if(  is_filtered_line( $line, $filtered_words ) ) continue;

		$result .= $line;
	}

	return "$result\n";

}

function is_filtered_line( $line, $filtered_words ){

	foreach( $filtered_words as $filtered_word ){

        if( str_contains($line, $filtered_word) ) return true;
    }

	return false;
}

function get_post_type_back_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$admin_post_type') ) return '';

	return file_get_contents(WPSD_APF_DIR.'includes/post-type-be-functions.php').PHP_EOL;

}

function get_post_type_front_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$post_type') ) return '';

	return file_get_contents(WPSD_APF_DIR.'includes/post-type-fe-functions.php').PHP_EOL;

}

function get_parsed_uri_markup(){

	return "\$uri_path = \$_SERVER['QUERY_STRING'] === '' ? \$_SERVER['REQUEST_URI'] : strstr(\$_SERVER['REQUEST_URI'], '?', true);\n";

}

function get_ifs_markup($conditions_data){

	$result = '';
	
	$all_plugins = get_plugins_list();

	foreach($conditions_data as $data){
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'disable' ) continue;
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'allow' ) $data['plugins'] = ['all'];

		$result .= "\n	//Post ID: {$data['post_id']}\n";

		$result .="	if( {$data['condition']} ){\n\n";
		
		$result .= get_variable_markup( $data, $all_plugins );

		$result .= "	}\n";
	
	}
	
	return $result;
}

function get_variable_markup( $data, $all_plugins ){

	$is_debug = (bool) get_option('adv-plugin-filter-debug', '0');

	$result ='';
	
	$filter_type_variable_name = $data['filter_mode'] === 'disable' ? 'd' : 'a';

	if( empty( $data['plugins'] ) || count($data['plugins']) === 1 && $data['plugins'][0]==='theme') $data['plugins'][]='all';

	foreach( $data['plugins'] as $key ){
	
		if( $key === 'theme' ){

			
			$result .= "    		\$t{$filter_type_variable_name} = true;\n";

		} else {

			$debug_text = $is_debug ? " //$key" : '';

			$p_key = $key==='all' ? 'all' : array_search($key, $all_plugins);
	
			if( $p_key === false ) continue;
	
			$result .= "    		\${$filter_type_variable_name}[{$p_key}] = null;{$debug_text}\n";
		}
		
	}

	return $result;
}



/**
* @param object $active_apf_rules get_post()
* @return array -
* - condition =>  (string)condition markup for if statement
* - plugins => (array) allowed plugins list
* -
*/
//MARK: Get condition
function get_conditions($active_apf_rules){
	
	foreach( $active_apf_rules as $rule ){
		
		$condition_markup = '';

		$rule_data = json_decode($rule->post_content,true);

		foreach(['1','2'] as $count){
			
			if(empty($rule_data["match_type_{$count}"])) continue;
			
			if( $count === '2' && $rule_data['match_type_2'] !=='null' ) {

				$condition_markup .= ($rule_data['logic']??'') === 'or' ? ' || ' : ' && ';
			} 

			if(  $count === '2' && $rule_data["match_type_$count"] === 'null' ) continue;

			$condition_markup .= get_condition_php_markup(
				$rule_data["match_type_{$count}"],
				$rule_data["operator_{$count}"],
				$rule_data["value_{$count}"]
			);
		}

		$result[] = [

			'filter_mode' => $rule_data['filter_mode']??'allow',
			
			'condition' => $condition_markup,
			
			'plugins'=>$rule_data['plugins'],

			'post_id'=>$rule->ID //passed for debugging purposes
		];
		
	}

	return $result??'';
}

function is_condition_a_function($match_type){

	$condition_is_function = [
		'post_key_exists',
		'frontend',
		'admin',
		'ajax',
		'cron',
		'rest',
		'logged_in',
		'logged_in_not',
		'null'
	];

	return in_array( $match_type, $condition_is_function );
}
	
function get_condition_php_markup($match_type,$operator,$value){

	$match_value_markup = get_match_value_markup($match_type,$operator,$value);

	if( is_condition_a_function( $match_type ) ) return $match_value_markup;

	switch($operator){

		case 'equal':
			
				$condition_markup = "{$match_value_markup} === '{$value}'";
		break;

		case 'not_equal':
			
				$condition_markup = "{$match_value_markup} !== '{$value}'";
		break;
			
		case 'contain':
				
				$condition_markup = "str_contains( {$match_value_markup},'{$value}')";
		break;
			
		case 'not_contain':
				
				$condition_markup = "!str_contains( {$match_value_markup},'{$value}')";
		break;
				
		case 'start':
					
					$condition_markup = "str_starts_with({$match_value_markup}, '{$value}')";
		break;
				
		case 'not_start':
					
					$condition_markup = "!str_starts_with({$match_value_markup}, '{$value}')";
		break;
					
		case 'regex':
						
					$condition_markup = "!empty(@preg_match('~{$value}~', {$match_value_markup}))";
		break;
					
		case 'not_regex':
						
					$condition_markup = "empty(@preg_match('~{$value}~', {$match_value_markup}))";
		break;

		
	}

	return $condition_markup??[];
}

function get_match_value_markup($match_type,$operator,$value){

	switch($match_type){
		case 'uri':
			$result = "\$_SERVER['REQUEST_URI']";
		break;
		
		// case 'uri_path':
		
		// break;
		
		case 'query_string':
			$result = "\$_SERVER['QUERY_STRING']";
		break;
		
		case 'post_action':
			$result = "(\$_POST['action']??'')";
		break;
		
		case 'post_key_exists':
			
			$operator_markup = ($operator === 'not_equal') ? '!':'';

			$result = "{$operator_markup}isset( \$_POST['{$value}'] )";
		break;

		case 'cookies':

			$result = "\$_SERVER['HTTP_COOKIE']";
		break;
		
		case 'frontend':

			$result = "\$request_type === 'frontend'";
			break;
			
		case 'admin':
			
			$result = "\$request_type === 'admin'";
		break;
			
		case 'ajax':
			
			$result = "\$request_type === 'ajax'";
		break;
			
		case 'cron':
			
			$result = "\$request_type === 'cron'";
		break;
			
		case 'rest':
			
			$result = "\$request_type === 'rest'";
		break;
		
		case 'logged_in':

			$result = "\$is_logged_in";
		break;
			
		case 'logged_in_not':

			$result = "!\$is_logged_in";
		break;
		
		case 'user_agent':
			$result = "(\$_SERVER['HTTP_USER_AGENT']??'')";
		break;
		
		case 'referer':
			$result = "(\$_SERVER['HTTP_REFERER']??'')";
		break;
		
		case 'null':
			$result = '';
		break;

		default:

		$result = "\${$match_type}";
		break;
	}

	return $result;
}
