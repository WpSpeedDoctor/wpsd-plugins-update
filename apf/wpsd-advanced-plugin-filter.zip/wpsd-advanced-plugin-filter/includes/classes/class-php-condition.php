<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

class PHP_Condition{

	const REQUEST_TYPE_CONSTANTS = [
		'frontend'	=> 'REQUEST_FRONTEND',
		'ajax'		=> 'REQUEST_AJAX',
		'admin'		=> 'REQUEST_ADMIN',
		'cron'		=> 'REQUEST_CRON',
		'login'		=> 'REQUEST_LOGIN',
		'xmlrpc'	=> 'REQUEST_XMLRPC',
		'empty'		=> 'REQUEST_EMPTY',
		'rest'		=> 'REQUEST_REST',
		'sitemap'	=> 'REQUEST_SITEMAP',
		'direct'	=> 'REQUEST_DIRECT',
		'404'		=> 'REQUEST_404',
		'feed'		=> 'REQUEST_FEED',
		'cli'		=> 'REQUEST_CLI'
	];

	private APF_Rule $rule;

	private object $condition;

	private const SIMPLE_MATCH_TYPES = ['post_key_exists','logged_in','logged_in_not','null'];
	
	private const DEPRECATED_REQUEST_MATCH_TYPES = ['frontend','admin','ajax','cron','rest'];
	
	public function get_complete_conditions_markup($rule){

		$this->rule = $rule;

		$condition_1 = $this->get_condition_markup(1);

		$condition_2 = $this->get_condition_markup(2);

		return $this->wrap_conditions_with_request_type($condition_1,$condition_2);
	}

	private function wrap_conditions_with_request_type($condition_1,$condition_2){
		
		$request_type_condition_markup = $this->get_request_type_condition_markup();

		if( empty($condition_1) && empty($condition_2) ){
			return $request_type_condition_markup;
		}

		$operator = (!empty($condition_1) && !empty($condition_2) ) ? $this->get_operator_markup() : '';

		if( !$request_type_condition_markup ){
			return $condition_1.$operator.$condition_2;
		}

		return $operator ? "{$request_type_condition_markup} && ( {$condition_1}{$operator}{$condition_2} )" : "{$request_type_condition_markup} && {$condition_1}{$condition_2}";

	}

	/**
	 * Return request type markup
	 * 
	 * @return string `WPSD_REQUEST_TYPE === REQUEST_ADMIN'`
	 * @return string `in_array(WPSD_REQUEST_TYPE,[REQUEST_FRONTEND,REQUEST_LOGIN])`
	 */

	private function get_request_type_condition_markup(){
		
		if( $this->rule->request_type === APF_Rule::DEFAULT_REQUEST_TYPE ){
			return '';
		}

		if( count($this->rule->request_type) === 1 ){

			return 'WPSD_REQUEST_TYPE === '.self::REQUEST_TYPE_CONSTANTS[$this->rule->request_type[0]];
		}
		
		$array = '[';

		foreach( $this->rule->request_type as $request_type ){
			$array .= self::REQUEST_TYPE_CONSTANTS[$request_type].",";
		}

		$array = rtrim($array,',').']';

		return "in_array(WPSD_REQUEST_TYPE,{$array})";
	}

	private function get_condition_markup($number){
		
		$this->condition = $this->rule->get_condition($number);

		if( $this->migrate_legacy_rules($number) ){
			return '';
		}
		
		$match_markup = $this->get_match_value_markup();

		if( in_array( $this->condition->match_type, self::SIMPLE_MATCH_TYPES) ){
			return $match_markup;
		}

		return $this->get_compound_condition($match_markup);
		
	}

	private function migrate_legacy_rules($number){
	
		if( !in_array($this->condition->match_type, self::DEPRECATED_REQUEST_MATCH_TYPES ) ){
			return false;
		}

		$this->rule->set_number_rule(APF_Rule::MATCH_TYPE,'null');

		$this->add_deprecated_match_type_to_request_type($this->condition,$number);
		
		return true;

	}

	/**
	 * part of migration to new matching algorithm,
	 * from match type the condition is moved to request_type
	 */
	private function add_deprecated_match_type_to_request_type($condition){
	
		switch(true){

			case $this->rule->request_type === APF_Rule::DEFAULT_REQUEST_TYPE:

				$this->rule->request_type = [$condition->match_type];
				break;

			case !in_array($condition->match_type, $this->rule->request_type):
				
				$this->rule->request_type[] = $condition->match_type;
				break;
		}
		
	}

	private function get_compound_condition($match_value_markup){

		$switch_operator = ltrim($this->condition->operator,'not_');

		$is_negative = $this->condition->operator !== $switch_operator;

		$esc_needle = $this->esc_needle($this->condition->value);

		switch($switch_operator){

			case 'equal':
				
				$haystack = $match_value_markup;
				$arg = $esc_needle;
				$needle = $is_negative ? '!==' : '===';
				$template =  "%s %s '%s'";
				break;
				
			case 'contain':

				$haystack = $match_value_markup;
				$needle = $esc_needle;
				$arg = $is_negative ? '=== false':'';
				$template =  "str_contains(%s, '%s') %s";
				break;
					
			case 'start':
				
				$haystack = $match_value_markup;
				$needle = $esc_needle;
				$arg = $is_negative ? '=== false':'';
				$template =  "str_starts_with(%s, '%s') %s";
				break;

			case 'end':
				
				$haystack = $match_value_markup;
				$needle = $esc_needle;
				$arg = $is_negative ? '=== false':'';
				$template =  "str_ends_with(%s, '%s') %s";
				break;
						
			case 'regex':
				$needle = $match_value_markup;
				$haystack = $esc_needle;
				$arg = $is_negative ? '!== 1' : '=== 1';
				$template =  "@preg_match('~%s~', %s) %s";
				break;
			
		}
		
		$output = sprintf($template, $haystack??'', $needle??'', $arg??'' );
		
		if($this->condition->match_type === 'post_action'){

			$output = "isset({$match_value_markup}) && {$output}";

		}

		return $output;
	}

	private function esc_needle($needle){

		return str_replace("'", "\\'", $needle);
	}

	private function get_operator_markup(){
	
		return $this->rule->logic === 'or' ? ' || ' : ' && ';
	}

	private function get_match_value_markup(){

		switch($this->condition->match_type){
			case 'uri':
				$result = "\$uri";
			break;
				
			case 'uri_path':

				$result='WPSD_URI_PATH';
			break;
			
			case 'query_string':
				$result = "\$qs";
			break;
			
			case 'post_action':
				$result = "\$_POST['action']";
			break;
			
			case 'post_key_exists':
				
				$operator_markup = ($this->condition->operator === 'not_equal') ? '!':'';

				$result = "{$operator_markup}isset( \$_POST['{$this->condition->value}'] )";
			break;

			case 'cookies':

				$result = "\$cookie";
			break;
			
			case 'logged_in':

				$result = "\$is_logged_in";
			break;
				
			case 'logged_in_not':

				$result = "!\$is_logged_in";
			break;
			
			case 'host':
				$result = "(\$_SERVER['HTTP_HOST']??'')";
			break;
			
			case 'locale':
				$result = "get_locale()";
			break;
			
			case 'user_agent':
				$result = "(\$_SERVER['HTTP_USER_AGENT']??'')";
			break;
			
			case 'referer':
				$result = "(\$_SERVER['HTTP_REFERER']??'')";
			break;
			
			case 'null':
				$result = '';
			break;

			default:

			$result = "\${$this->condition->match_type}";
			break;
		}

		return $result;
	}

	static function display_if_conditions(){
		
		require WPSD_APF_DIR.'/includes/classes/class-apf-rule.php';

		$posts= get_posts(
				
			[	'post_type' => 'adv_plugin_filter', 
				'post_status' => 'publish',
				'posts_per_page' => -1,
		]);
		
		$conditions = '';

		$constructor = new PHP_Condition();

		$rule = new APF_Rule();

		$original_error_reporting = error_reporting();

		error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR);
		
		foreach($posts as $post){

			$rule->set_rule($post);

			if($rule->id == 31 || 1){

				$condition =  $constructor->get_complete_conditions_markup($rule);
				
				error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR);
				
				$conditions .= "Post ID:{$rule->id}<br>if( {$condition} )<br>";

				$error_message = '';

				try{
					eval($condition.';');
				} catch (\ParseError $e) {
					$error_message = "Parse Error caught: " . $e->getMessage();
				} catch (\Error $e) {
					$error_message = "Fatal Error caught: " . $e->getMessage();
				}
				
				error_reporting($original_error_reporting);

				if($error_message){
					$conditions .=  <<<HTML
					<span style="color:red">{$error_message}</span><br>
					HTML;
				}
				$conditions .='<br>';
			}
		}
		
	
		echo '<br><div style="white-space: break-spaces;line-height: 2;font-family: monospace;">'
		.$conditions.'</div>';
		
		


	}
}

