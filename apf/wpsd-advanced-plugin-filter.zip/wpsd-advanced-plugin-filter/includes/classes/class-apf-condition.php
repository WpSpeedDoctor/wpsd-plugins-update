<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

class APF_Condition{

	
}