<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

class APF_Rule{

	const DEFAULT_REQUEST_TYPE = ['all'];

	const MATCH_TYPE = 'match_type';

	const OPERATOR = 'operator';

	const VALUE = 'value';

	public string $id;

	public string $filter_mode;

	public array $request_type;
	
	public string $logic;

	public string $match_type_1;

	public string $operator_1;

	public string $value_1;

	public string $match_type_2;

	public string $operator_2;

	public string $value_2;

	public array $plugins;

	public string $note;

	public string $version;

	private $rule_number;

	public function set_rule($post){

		$this->id = (string) $post->ID;
		
		$rule = json_decode($post->post_content);
		
		$this->filter_mode = $rule->filter_mode ?? 'allow';

		$this->request_type = $rule->request_type ?? self::DEFAULT_REQUEST_TYPE;

		$this->logic = ($rule->logic??'and') === 'and' ? 'and' : 'or';

		$this->match_type_1 = $rule->match_type_1 ?? '';

		$this->operator_1 = $rule->operator_1 ?? '';

		$this->value_1 = $rule->value_1 ?? '';

		$this->match_type_2 = $rule->match_type_2 ?? '';

		$this->operator_2 = $rule->operator_2 ?? '';

		$this->value_2 = $rule->value_2 ?? '';

		$this->plugins = (array) ($rule->plugins ?? []);

		$this->note = $rule->note ?? '';

		$this->version = $rule->version ?? '';

	}

	public function get_condition($number){
		
		$this->rule_number = $number;

		$number = $number == '1' ? '1': '2';

		return (object)[
			
			self::MATCH_TYPE => $this->{"match_type_{$number}"},
			self::OPERATOR => $this->{"operator_{$number}"},
			self::VALUE => $this->{"value_{$number}"}

		];
		
	}

	public function set_number_rule($rule, $value){
	
		$this->{"{$rule}_{$this->rule_number}"} = $value;
		
	}
}