<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_recovery_url(){

    return trailingslashit( get_home_url() ).'?'.get_recovery_query_string();
}

function get_recovery_query_string(){

    return hash( 'fnv164', LOGGED_IN_COOKIE );
}