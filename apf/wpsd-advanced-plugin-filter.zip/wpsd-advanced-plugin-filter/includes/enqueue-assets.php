<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

$plugin_url_dir = plugin_dir_url(WPSD_APF_DIR.'f');

wp_register_style( 
	
	'advanced-plugin-filter',

	"{$plugin_url_dir}assets/wpsd-advanced-plugin-filter.css",

	false,

	WPSD_APF_VER
);


wp_enqueue_style( 'advanced-plugin-filter' );


wp_register_script( 
	
	'advanced-plugin-filter',

	"{$plugin_url_dir}assets/wpsd-advanced-plugin-filter.js",

	false,
	
	WPSD_APF_VER,
	
	['strategy' => 'defer', 'in_footer' => true]
);

wp_enqueue_script( 'advanced-plugin-filter' );

