<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

add_action( 'admin_enqueue_scripts', function(){

	wp_dequeue_script( 'autosave' );
});



function advanced_plugin_filter_add_meta_box(){
	add_meta_box(
		'advanced_plugin_filter_meta_box',
		esc_html__('Plugin Filter', 'advanced-plugin-filter'), 
		__NAMESPACE__.'\display_apf_meta_box',
		'adv_plugin_filter',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', __NAMESPACE__.'\advanced_plugin_filter_add_meta_box');

function get_available_options(){

	static $options;

	if(!$options){

		$options = [
			'null'				=> '',
			'uri' 				=> __("URI", 'advanced-plugin-filter'),
			'uri_path' 			=> __("URI Path", 'advanced-plugin-filter'),
			'query_string' 		=> __("Query string", 'advanced-plugin-filter'),
			'post_action' 		=> __("\$_POST['action']", 'advanced-plugin-filter'),
			'post_key_exists'	=> __("\$_POST[ \$KEY ] exists", 'advanced-plugin-filter'),
			'cookies' 			=> __("Cookies", 'advanced-plugin-filter'),
			'post_type' 		=> __("Front-end post type", 'advanced-plugin-filter'),
			'admin_post_type'	=> __("Admin post type", 'advanced-plugin-filter'),
			'user_agent' 		=> __("User agent", 'advanced-plugin-filter'),
			'referer' 			=> __("Referer", 'advanced-plugin-filter'),
			'logged_in' 		=> __("Logged in user", 'advanced-plugin-filter'),
			'logged_in_not' 	=> __("Not logged in user", 'advanced-plugin-filter'),
			'host'			 	=> __("Domain (HTTP Host)", 'advanced-plugin-filter'),
			'locale'		 	=> __("Language (locale)", 'advanced-plugin-filter'),
		];

	}

	return $options;
}


//TODO: refactor to match() when dropped PHP 7.4 compatibility

function get_converted_name_of_deprecated_key($key){

	switch($key){

		case 'frontend': return 'request_frontend';
		case 'admin': return 'request_admin';
		case 'ajax': return 'request_ajax';
		case 'cron': return 'request_cron';
		case 'rest': return 'request_rest';

		default: return $key;
	}

}

function get_dropdown_match_type($id, $selected_type){

	$options = get_available_options();

	// Remove empty option for match_type_1
	// if($id === 'match_type_1'){
	// 	unset($options['null']);
	// }

	$options_html = '';

	foreach ($options as $name => $display) {
		
		$selected = selected($name,get_converted_name_of_deprecated_key( $selected_type), false);
		
		$options_html .= <<<HTML
	<option value="{$name}" {$selected}>{$display}</option>
	HTML;

	}

	return <<<HTML
	<select id="{$id}" name="{$id}">
		{$options_html}
	</select>
	HTML;

}

function get_dropdown_filter_mode($filter_mode){
	
	$allow = [
	'text'		=> esc_html__("Allow only mode", 'advanced-plugin-filter'),
	'selected'	=> selected( 'allow', $filter_mode, false)
	];

	$disable = [
		'text'		=> esc_html__("Disable mode", 'advanced-plugin-filter'),
		'selected'	=> selected( 'disable', $filter_mode, false)
	];

	return
<<<HTML
<select id="filter_mode" name="filter_mode">
	<option value="allow"{$allow['selected']}>{$allow['text']}</option>
	<option value="disable"{$disable['selected']}>{$disable['text']}</option>
</select>
HTML;
	
}

function get_dropdown_logic_operator($filter_mode){
	
	$allow = [
	'text'	 	=> esc_html__('AND', 'advanced-plugin-filter'),
	'selected'	=> selected( 'and', $filter_mode, false)
	];

	$disable = [
		'text'		=> esc_html__("OR", 'advanced-plugin-filter'),
		'selected'	=> selected( 'or', $filter_mode, false)
	];

	return
<<<HTML
<select id="logic" name="logic" class="logic-operator">
	<option value="and"{$allow['selected']}>{$allow['text']}</option>
	<option value="or"{$disable['selected']}>{$disable['text']}</option>
</select>
HTML;
	
}

function get_dropdown_operator($id, $selected_operator,$match_type){

	static $operators = false;

	if( !$operators ){

		$operators = [
			'equal'			=> esc_html__("equals", 'advanced-plugin-filter'),
			'not_equal'		=> esc_html__("not equal", 'advanced-plugin-filter'),
			'contain'		=> esc_html__("contains", 'advanced-plugin-filter'),
			'not_contain'	=> esc_html__("doesn't contain", 'advanced-plugin-filter'),
			'start' 		=> esc_html__("starts with", 'advanced-plugin-filter'),
			'not_start'		=> esc_html__("doesn't start with", 'advanced-plugin-filter'),
			'end' 			=> esc_html__("ends with", 'advanced-plugin-filter'),
			'not_end'		=> esc_html__("doesn't end with", 'advanced-plugin-filter'),
			'regex' 		=> esc_html__("regex", 'advanced-plugin-filter'),
			'not_regex' 	=> esc_html__("not regex", 'advanced-plugin-filter'),
		];
	}
	
	$hidden_on_match_type = [
		'null',
		'post_key_exists',
		'logged_in',
		'logged_in_not',
	];
	
	$select_class= in_array( $match_type, $hidden_on_match_type ) ? 'ro-hidden' : '';	

	$options_html = '';

	foreach ($operators as $name => $display) {
		$selected = selected($name, $selected_operator, false);
		$options_html .= <<<HTML
	<option value="{$name}" {$selected}>{$display}</option>

	HTML;
	}

	$select_html = <<<HTML
	<select id="{$id}" name="{$id}" class="{$select_class}">
		{$options_html}
	</select>
	HTML;

	return $select_html;

}

function display_apf_meta_box($post){
	
	if( !get_option('adv-plugin-filter-enabled', '0') ) display_notice_not_filters_enabled();
	
	$data = json_decode($post->post_content, true);
	adjust_legacy_data($data);
	$filter_mode = esc_attr($data['filter_mode']??'allow');
	$logic_operator = esc_attr($data['logic']??'and');
	$match_type_1 = esc_attr($data['match_type_1'] ?? 'uri');
	$value_1 = esc_attr($data['value_1'] ?? '');
	$operator_1 = esc_attr($data['operator_1'] ?? '');
	$match_type_2 = esc_attr($data['match_type_2'] ?? 'null');
	$value_2 = esc_attr($data['value_2'] ?? '');
	$operator_2 = esc_attr($data['operator_2'] ?? '');
	$note = empty($data['note'] ) ? '' : trim(esc_textarea($data['note']));
	$note_placeholder = esc_html__( "Don't be lazy, write a note.", 'advanced-plugin-filter' );
	$note_label= esc_html__( "Note:", 'advanced-plugin-filter' );
	$suggest_the_title_text = esc_html__( 'Suggest the title', 'advanced-plugin-filter' );
	$class_match_1 = get_text_input_class($match_type_1);
	$class_match_2 = get_text_input_class($match_type_2);
	$dropdown_markup = get_dropdown_filter_mode($filter_mode);
	$request_type_check = get_request_type_checkboxes($data);
	$match_type_2_markup = get_dropdown_match_type('match_type_2', $match_type_2);
	$match_type_1_markup = get_dropdown_match_type('match_type_1', $match_type_1);
	$operator_1_markup = get_dropdown_operator('operator_1', $operator_1,$match_type_1);
	$operator_2_markup = get_dropdown_operator('operator_2', $operator_2,$match_type_2);
	$logic_operator_markup = get_dropdown_logic_operator($logic_operator);
	wp_nonce_field('advanced_plugin_filter_save_meta_box_data', 'advanced_plugin_filter_meta_box_nonce');

	echo 

<<<HTML
<button id="populateTitle" class="button button-primary" >{$suggest_the_title_text}</button><hr>
{$dropdown_markup}{$request_type_check}
<div class="conditions-wrap mb20">
	<div class="condition-wrap mb10">
		{$match_type_1_markup}
		{$operator_1_markup}
		<input type="text" name="value_1" value="{$value_1}" class="{$class_match_1}">
		{$logic_operator_markup}
	</div>
	<div class="condition-wrap">
		{$match_type_2_markup}
		{$operator_2_markup}
		<input type="text" name="value_2" value="{$value_2}" class="{$class_match_2}">
	</div>
</div>
<div id="plugins_lists">
HTML;

	the_all_installed_plugins_checkbox_markup($data['plugins'] ?? []);

	echo <<<HTML
	</div>
	<div class="adv-plugin-filter-note-wrap">
		<label for="note" class="adv-plugin-filter-note mb5">
			{$note_label}
		</label>
		<textarea id="note" name="note" cols="68" rows="5" placeholder="{$note_placeholder}">{$note}</textarea>
	</div>
	HTML;

	if(isset($_GET['rules'])){
		
		require WPSD_APF_DIR.'includes/classes/class-php-condition.php';

		PHP_Condition::display_if_conditions();
	
	}
}

function adjust_legacy_data(&$data){

	switch(true){

		case is_deprecated_request_type($data['match_type_1']??'') && is_deprecated_request_type($data['match_type_2']??''):
			
			$data['request_type'] = [$data['match_type_1'], $data['match_type_2']];
		
			$data['match_type_1'] = 'null';
			$data['match_type_2'] = 'null';
			break;
		
		case is_deprecated_request_type($data['match_type_2']??''):
			
			$data['request_type'] = [$data['match_type_2']];
			$data['match_type_2'] = 'null';
			break;
		
		case is_deprecated_request_type($data['match_type_1']??''):
			
			$data['request_type'] = [$data['match_type_1']];
			$data['match_type_1'] = $data['match_type_2'];
			$data['operator_1'] = $data['operator_2'];
			$data['value_1'] = $data['value_2'];
			$data['match_type_2'] = 'null';
			$data['operator_2'] = 'equals';
			$data['value_2'] = '';
			break;
	}

}

function is_deprecated_request_type($request_type){
	
	switch($request_type){
		
		case 'frontend':
		case 'admin':
		case 'ajax':
		case 'cron':
		case 'rest':

			return true;
		
		default:

			return false;
	}
}

function get_request_type_checkboxes($data){

	$selected_types = $data['request_type']??['all'];

	$options = get_request_type_options();

	$texts = [
		'applies' => __('Request type:', 'advanced-plugin-filter'),
		'change' => __('Change selection', 'advanced-plugin-filter'),
	];

	$uid = uniqid('wpsd-apf-', false);

	$valid_selected = array_values(array_intersect($selected_types, array_keys($options)));

	if( empty($valid_selected) ) $valid_selected = ['all'];

	if( in_array('all', $valid_selected, true) ) $valid_selected = ['all'];

	$specifics = array_diff(array_keys($options), ['all']);

	if( empty(array_diff($valid_selected, ['all'])) && !in_array('all', $valid_selected, true) ) $valid_selected = ['all'];

	$selected_labels = [];

	foreach( $valid_selected as $k ){
		
		$selected_labels[] = $options[$k] ?? '';
		
	}

	$selected_value = implode(', ', $selected_labels);

	$checkboxes_html = '';

	foreach($options as $key => $label){
		
		$checked = in_array($key, $valid_selected, true) ? ' checked' : '';
		
		$checkboxes_html .= <<<HTML
		<label class="wpsd-apf-option wpsd-pointer mr10">
			<input type="checkbox" name="request_type[]" value="{$key}"{$checked}>
			<span class="wpsd-apf-text">{$label}</span>
		</label>
		HTML;
		
	}

	$output = <<<HTML
	<div class="wpsd-apf-wrap mb10" id="{$uid}">
		
		<div class="wpsd-apf-row">
			
			
			<div class="wpsd-apf-field">
				<span class="wpsd-apf-label">{$texts['applies']}</span>
				
				<input id="wpsd-request-types-summary" type="text" class="wpsd-apf-selected" value="{$selected_value}" readonly>
				
				<button type="button" class="wpsd-apf-toggle-btn" aria-controls="{$uid}-list" aria-expanded="false" aria-label="{$texts['change']}">&#9662;</button>
				
			</div>
			
		</div>
		
		<div class="wpsd-apf-list ro-hidden" id="{$uid}-list">
			
			{$checkboxes_html}
			
		</div>
		
	</div>
	HTML;

	return $output;

}


function get_request_type_options(){

	return [
		'all'		=> __('All', 'advanced-plugin-filter'),
		'frontend'	=> __('Front-end', 'advanced-plugin-filter'),
		'ajax'		=> __('AJAX', 'advanced-plugin-filter'),
		'admin'		=> __('Admin', 'advanced-plugin-filter'),
		'cron'		=> __('Cron', 'advanced-plugin-filter'),
		'login'		=> __('Login', 'advanced-plugin-filter'),
		'xmlrpc'	=> __('XML-RPC', 'advanced-plugin-filter'),
		'empty'		=> __('Empty', 'advanced-plugin-filter'),
		'rest'		=> __('REST', 'advanced-plugin-filter'),
		'sitemap'	=> __('Sitemap', 'advanced-plugin-filter'),
		'direct'	=> __('Direct', 'advanced-plugin-filter'),
		'404'		=> __('404', 'advanced-plugin-filter'),
		'feed'		=> __('Feed', 'advanced-plugin-filter'),
		'cli'		=> __('CLI', 'advanced-plugin-filter')
	];

}

function get_text_input_class($match_type) {

	switch ($match_type) {
		case 'null':
		case 'request_type':
		case 'logged_in':
		case 'logged_in_not':

			return 'ro-hidden';
		default:
		
			return '';
	}
}


function the_all_installed_plugins_checkbox_markup($selected_plugins){

	$plugins = get_plugins_data_for_checkbox_form();
	
	$markup = '';

	foreach($plugins as $column => $plugins_group){
	
		$column_name = get_column_name($column);
	
		$selectors_markup = get_selectors_markup($column);
	
		$column_markup = 
<<<HTML
<div class="plugins-column {$column}">
	<div class="title-column mb5">
		{$column_name}
	</div>
	{$selectors_markup}
HTML;

		foreach($plugins_group as $plugin_data){
			$checked = is_checked($plugin_data, $selected_plugins) ? ' checked' : '';
			$plugin_name = get_truncated_plugin_name($plugin_data['name']);
			$plugin_checkbox_class = get_plugin_checkbox_class($plugin_data['path']);
			$plugin_path = esc_attr($plugin_data['path']);
			$plugin_name_html = esc_html($plugin_name);

			$column_markup .= 
<<<HTML
	<label class="{$plugin_checkbox_class}">
		<input type="checkbox" name="plugins[]" value="{$plugin_path}"{$checked}>{$plugin_name_html}
	</label><br>
HTML;
		}

		if($column === 'theme'){

			$column_markup .= '<br><hr>'.get_post_types_markup();
		}
		// Close column div
		$column_markup .=
<<<HTML
	</div>
HTML;

		$markup .= $column_markup;
	}

	echo <<<HTML
<div class="plugins-wrap mb20">
	{$markup}
</div>
HTML;
}

function get_post_types_markup(){

	global $wpdb;

	$post_types = $wpdb->get_col("SELECT DISTINCT post_type FROM {$wpdb->posts} ORDER BY post_type ASC");

	if( empty($post_types) ) return false;

	$texts = [
		'heading'		=> __('Post types', 'plugin-domain'),

		'subheading'	=> __('(click to copy into clipboard)', 'plugin-domain'),
		
		'copied'		=> __('Copied', 'plugin-domain'),
		
	];

	$list_items = '';

	foreach($post_types as $pt){
		
		$value = esc_html($pt);
		
		$list_items .= <<<HTML
		<li class="wpsd-pt-item">
			<button type="button" class="wpsd-pt-copy wpsd-pointer" data-copy="{$value}">{$value}</button>
		</li>
		
		HTML;
		
	}

	$markup = <<<HTML
	<br>
	<div class="wpsd-post-types">
		<div class="title-column mb5">{$texts['heading']}</div>
		<div class="subheading-column mb20">{$texts['subheading']}</div>
		<ul class="wpsd-pt-list">
			{$list_items}
		</ul>
	</div>
	<script>
		window.WPSD_PT = {
		selector: '.wpsd-pt-copy',
		copied: "{$texts['copied']}",
	};
	</script>
	HTML;

	return $markup;

}

function get_truncated_plugin_name($plugin_name){

	if( strlen($plugin_name)<= 45 ) return $plugin_name;

	return substr( $plugin_name, 0, 43).'...';

}

function get_selectors_markup($column){

	if($column === 'theme') return '<br>';

	$text_check_all 	= esc_html__( 'Check all', 'advanced-plugin-filter' );
	$text_uncheck_all 	= esc_html__( 'Uncheck all', 'advanced-plugin-filter' );
	$text_check_invert 	= esc_html__( 'Invert', 'advanced-plugin-filter' );

	return <<<HTML
	<div class="selectors-{$column} mb5">
		<a href="#" class="check-all" data-column="{$column}">{$text_check_all}</a> |
		<a href="#" class="uncheck-all" data-column="{$column}">{$text_uncheck_all}</a> |
		<a href="#" class="invert-selection" data-column="{$column}">{$text_check_invert}</a>
	</div>
	HTML;
}


function get_column_name($column){

	switch($column){

		case 'active':
			$result = esc_html__( 'Active plugins', 'advanced-plugin-filter' );
		break;

		case 'inactive':
			$result = esc_html__( 'Inactive plugins', 'advanced-plugin-filter' );
		break;

		case 'theme':
			$result = esc_html__( 'Active theme', 'advanced-plugin-filter' );
		break;
	}

	return $result??'';
}

function is_checked($plugin_data,$selected_plugins){

	global $pagenow;

	if($pagenow === 'post-new.php' && $plugin_data['path'] === 'theme'){
		
		// make by default theme active on a new filter
		return ' checked';
	}

	return	in_array($plugin_data['path'], $selected_plugins) ? ' checked' : '';

}

/**
* @param string 
* @return array -
* - 'active'[] => ['path'=>$path,'name'=>$plugin_name]
* - 'inactive'[] => ['path'=>$path,'name'=>$plugin_name]
*/

function get_plugins_data_for_checkbox_form(){

	$plugins = get_actual_plugin_lists();
	
	return [

		'active' => $plugins['active']??[],

		'inactive' => $plugins['inactive']??[],
		
		'theme' => [ 
			
			0=> [
				'path'=>'theme',
				
				'name'=> esc_html__(
					
					wp_get_theme()->get('Name'),
					
					wp_get_theme()->get('TextDomain')
					
					)
				]
		],
	];
}


function get_actual_plugin_lists(){

	if( !function_exists('is_plugin_active') ) include_once ABSPATH . 'wp-admin/includes/plugin.php';

	require_once WPSD_APF_DIR.'admin/setup.php';

	$active_plugins = get_active_plugins_from_db();

	$all_plugins = get_plugins();

	foreach($all_plugins as $path => $plugin_data){

		$plugin_group = in_array($path, $active_plugins) ? 'active' : 'inactive';
		
		$result[$plugin_group][] = [
			'path' => $path,
			'name' => esc_html__($plugin_data['Name'], $plugin_data['TextDomain'])
		];
	}

	return $result;
}

function get_plugin_checkbox_class($path){

	if( $path === 'theme' ) return 'ro-theme-checkbox';

	return is_plugin_active($path) ? 'ro-plugin-active' : 'ro-plugin-inactive';

}

//MARK:SAVE Settings
function filter_save_post_data($post_id, $post, $update){
	
	if( !is_apf_save_point($post, $post_id) || !current_user_can('activate_plugins', $post_id) ) return;

	$data = [];

	$data['filter_mode'] = ($_POST['filter_mode'] ?? 'allow') === 'allow' ? 'allow' : 'disable';
	
	$data['request_type'] = !empty($_POST['request_type'])&&is_array($_POST['request_type']) ? $_POST['request_type'] : ['all'];
	
	$data['logic'] = ($_POST['logic'] ?? 'or') === 'or' ? 'or' : 'and';
	
	$data['match_type_1'] = sanitize_text_field($_POST['match_type_1'] ?? '');
	
	$data['operator_1'] = sanitize_text_field($_POST['operator_1'] ?? '');
	
	// $data['value_1'] = sanitize_for_valid_uri(sanitize_text_field($_POST['value_1'] ?? ''), $data['operator_1'] );
	$data['value_1'] = get_value_by_match_type( '1', $data['match_type_1'], $data['operator_1'] );
	
	$data['match_type_2'] = sanitize_text_field($_POST['match_type_2'] ?? '');
	
	$data['operator_2'] = sanitize_text_field($_POST['operator_2'] ?? '');
	
	$data['value_2'] = get_value_by_match_type( '2', $data['match_type_2'], $data['operator_2'] );
	// $data['value_2'] = sanitize_for_valid_uri(sanitize_text_field($_POST['value_2'] ?? ''), $data['operator_2'] );
	
	$data['plugins'] = isset($_POST['plugins']) ? array_map('sanitize_text_field', $_POST['plugins']) : array();
	
	$data['note'] = sanitize_textarea_field($_POST['note'] ?? '');
	
	$data['version'] = WPSD_APF_VER;
	
	$json_data = wp_json_encode($data);

	remove_action('save_post', __NAMESPACE__.'\filter_save_post_data');

	wp_update_post( [
		
		'ID'           => $post_id,
		'post_content' => $json_data
	]);

	add_action('save_post', __NAMESPACE__.'\filter_save_post_data', 10, 3);

	rewrite_mu_plugin_after_save_post();
	
}

add_action('save_post', __NAMESPACE__.'\filter_save_post_data', 10, 3);

function get_value_by_match_type( $value_key_number, $match_type, $operator ){

	$value_key = 'value_'.$value_key_number;

	switch(true){
		
		case !isset($_POST[$value_key]) || $_POST[$value_key]==='' || $_POST[$value_key] === ' ':
			return '';

		//fall though
		case ($value_without_domain = str_replace( get_home_url(),'',sanitize_text_field($_POST[$value_key]) ))=== null:	

		case str_ends_with($operator,'regex'):
			 return str_replace( ["'",'~'],'',$value_without_domain );

		default:
			return preg_replace('/[^A-Za-z0-9\-\/._=\?\&]/', '', $value_without_domain);
	}

}

function rewrite_mu_plugin_after_save_post(){

	if( !get_option('adv-plugin-filter-enabled') ) return;

	require_once WPSD_APF_DIR.'admin/setup.php';

	activate_mu_plugin( $rewrite=true );

}

function sanitize_for_valid_uri( $value, $operator ){

	$value_without_domain = str_replace( get_home_url(),'',$value);

	if( $operator === 'not_regex' || $operator === 'regex' ) return str_replace( ["'",'~'],'',$value_without_domain );
	
	return preg_replace('/[^A-Za-z0-9\-\/._=\?\&]/', '', $value_without_domain);

}

function add_author_column_header($columns){
	
	foreach($columns as $key => $value){

		if( $key==='date' ) $result['author'] = esc_html__('Author');

		$result[$key]= $value;
	}

	return $result;

}

add_filter('manage_advanced_plugin_filter_posts_columns', __NAMESPACE__ . '\add_author_column_header');


function is_apf_save_point($post){

	return (
	
		$post->post_type === 'adv_plugin_filter' &&
	
		!defined('DOING_AUTOSAVE') &&
	
		isset($_POST['advanced_plugin_filter_meta_box_nonce']) &&
	
		wp_verify_nonce(
			
			$_POST['advanced_plugin_filter_meta_box_nonce'],
			
			'advanced_plugin_filter_save_meta_box_data'
			
		)
	);
}

function display_notice_not_filters_enabled(){

	$text = esc_html__('Filters are not enabled.', 'advanced-plugin-filter');

	echo <<<HTML
	<div class="notice notice-warning is-dismissible">
	<p>{$text}</p>
	</div>
	HTML;


}

function refresh_mu_plugin_after_filter_update( $post_id ){

	$post = get_post( $post_id );

	if( !$post->post_type === 'adv_plugin_filter' ) return;

	require_once WPSD_APF_DIR.'admin/setup.php';

	activate_mu_plugin( $rewrite=true );
	
}

add_action( 'publish_to_trash', __NAMESPACE__.'\refresh_mu_plugin_after_filter_update' );
add_action( 'draft_to_publish', __NAMESPACE__.'\refresh_mu_plugin_after_filter_update' );
add_action( 'trash_to_publish', __NAMESPACE__.'\refresh_mu_plugin_after_filter_update' );
add_action( 'bulk_edit_posts', __NAMESPACE__.'\refresh_mu_plugin_after_filter_update' );
