<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

add_action( 'admin_enqueue_scripts', function(){

	wp_dequeue_script( 'autosave' );
});



function advanced_plugin_filter_add_meta_box() {
	add_meta_box(
		'advanced_plugin_filter_meta_box',
		esc_html__('Plugin Filter', 'advanced-plugin-filter'), 
		__NAMESPACE__.'\advanced_plugin_filter_meta_box_callback',
		'adv_plugin_filter',
		'normal',
		'high'
	);
}
add_action('add_meta_boxes', __NAMESPACE__.'\advanced_plugin_filter_add_meta_box');

function the_dropdown_match_type($id, $selected_type) {

	$options = [
		'null'				=> '',
		'uri' 				=> esc_html__("URI", 'advanced-plugin-filter'),
		'uri_path' 			=> esc_html__("URI Path", 'advanced-plugin-filter'),
		'query_string' 		=> esc_html__("Query string", 'advanced-plugin-filter'),
		'post_action' 		=> esc_html__("\$_POST['action']", 'advanced-plugin-filter'),
		'post_key_exists'	=> esc_html__("\$_POST[ \$KEY ] exists", 'advanced-plugin-filter'),
		'cookies' 			=> esc_html__("Cookies", 'advanced-plugin-filter'),
		'post_type' 		=> esc_html__("Post type", 'advanced-plugin-filter'),
		'admin_post_type'	=> esc_html__("Admin post type", 'advanced-plugin-filter'),
		'user_agent' 		=> esc_html__("User agent", 'advanced-plugin-filter'),
		'frontend' 			=> esc_html__("Front-end", 'advanced-plugin-filter'),
		'admin' 			=> esc_html__("Back-end", 'advanced-plugin-filter'),
		'ajax' 				=> esc_html__("Ajax", 'advanced-plugin-filter'),
		'cron' 				=> esc_html__("Cron", 'advanced-plugin-filter'),
		'rest' 				=> esc_html__("REST API", 'advanced-plugin-filter'),
		'logged_in' 		=> esc_html__("Logged in user", 'advanced-plugin-filter'),
		'logged_in_not' 	=> esc_html__("Not logged in user", 'advanced-plugin-filter'),
	];

	// Remove empty option for match_type_1
	if ($id === 'match_type_1') {
		unset($options['null']);
	}

	?>
	<select id="<?php echo $id;?>" name="<?php echo $id;?>">
		<?php foreach ($options as $name => $display){ ?>
			<option value="<?php echo $name;?>"<?php selected($name, $selected_type);?>><?php echo $display;?></option>
		<?php } ?>
	</select>
	<?php
}

function the_dropdown_filter_mode($filter_mode){
	
	$allow = [
	'text' 	=> esc_html__("Allow only mode", 'advanced-plugin-filter'),
	'selected'	=> selected( 'allow', $filter_mode, false)
	];

	$disable = [
		'text'		=> esc_html__("Disable mode", 'advanced-plugin-filter'),
		'selected'	=> selected( 'disable', $filter_mode, false)
	];

	echo
<<<HTML
<select id="filter_mode" name="filter_mode">
	<option value="allow"{$allow['selected']}>{$allow['text']}</option>
	<option value="disable"{$disable['selected']}>{$disable['text']}</option>
</select>
HTML;
	
}

function the_dropdown_logic_operator($filter_mode){
	
	$allow = [
	'text' 	=> esc_html__('AND', 'advanced-plugin-filter'),
	'selected'	=> selected( 'and', $filter_mode, false)
	];

	$disable = [
		'text'		=> esc_html__("OR", 'advanced-plugin-filter'),
		'selected'	=> selected( 'or', $filter_mode, false)
	];

	echo
<<<HTML
<select id="logic" name="logic" class="logic-operator">
	<option value="and"{$allow['selected']}>{$allow['text']}</option>
	<option value="or"{$disable['selected']}>{$disable['text']}</option>
</select>
HTML;
	
}

function the_dropdown_operator($id, $selected_operator,$match_type) {

	static $operators = false;

	if( !$operators ){

		$operators = [
			'equal'			=> esc_html__("equals", 'advanced-plugin-filter'),
			'not_equal'		=> esc_html__("not equal", 'advanced-plugin-filter'),
			'contain'		=> esc_html__("contains", 'advanced-plugin-filter'),
			'not_contain'	=> esc_html__("doesn't contain", 'advanced-plugin-filter'),
			'start' 		=> esc_html__("starts with", 'advanced-plugin-filter'),
			'not_start'		=> esc_html__("doesn't start with", 'advanced-plugin-filter'),
			'regex' 		=> esc_html__("regex", 'advanced-plugin-filter'),
			'not_regex' 	=> esc_html__("not regex", 'advanced-plugin-filter'),
		];
	}
	
	static $hidden_on_match_type = false;

	if(!$hidden_on_match_type ){
		$hidden_on_match_type = [
			'null',
			'admin',
			'frontend',
			'ajax',
			'cron',
			'rest',
			'post_key_exists',
			'logged_in',
			'logged_in_not',
		];
	}
	
	$select_class= in_array( $match_type, $hidden_on_match_type ) ? 'ro-hidden' : '';	

	?>
	<select id="<?php echo $id;?>" name="<?php echo $id;?>" class="<?php echo $select_class;?>">
		<?php foreach ($operators as $name => $display): ?>
			<option value="<?php echo $name;?>"<?php selected($name, $selected_operator);?> ><?php echo $display;?></option>
		<?php endforeach; ?>
	</select>
	<?php
}

function advanced_plugin_filter_meta_box_callback($post) {

	if( !get_option('adv-plugin-filter-enabled', '0') ) display_notice_not_filters_enabled();

	$data = json_decode($post->post_content, true);
	$filter_mode = $data['filter_mode']??'allow';
	$logic_operator = $data['logic']??'and';
	$match_type_1 = $data['match_type_1'] ?? '';
	$value_1 = $data['value_1'] ?? '';
	$operator_1 = $data['operator_1'] ?? '';
	$match_type_2 = $data['match_type_2'] ?? 'null';
	$value_2 = $data['value_2'] ?? '';
	$operator_2 = $data['operator_2'] ?? '';
	$note = esc_textarea($data['note'] ?? '');
	wp_nonce_field('advanced_plugin_filter_save_meta_box_data', 'advanced_plugin_filter_meta_box_nonce');
	$note_placeholder= esc_html__( "Don't be lazy, write a note.", 'advanced-plugin-filter' );
	$suggest_the_title_text =  esc_html__( 'Suggest the title', 'advanced-plugin-filter' );

	?>
	<button id="populateTitle" class="button button-primary" ><?php echo $suggest_the_title_text;?></button><hr>
	<?php the_dropdown_filter_mode($filter_mode) ?>
	<div class="conditions-wrap mb20">
		<div class="condition-wrap mb10">
			<?php the_dropdown_match_type('match_type_1', $match_type_1); ?>
			<?php the_dropdown_operator('operator_1', $operator_1,$match_type_1); ?>
			<input type="text" name="<?php echo esc_attr('value_1');?>" value="<?php echo esc_attr($value_1);?>" class="<?php echo get_text_input_class($match_type_1,$value_1);?>">
			<?php the_dropdown_logic_operator($logic_operator) ?>
		</div>
		<div class="condition-wrap">
			<?php the_dropdown_match_type('match_type_2', $match_type_2, $value_2); ?>
			<?php the_dropdown_operator('operator_2', $operator_2,$match_type_2); ?>
			<input type="text" name="<?php echo esc_attr('value_2');?>" value="<?php echo esc_attr($value_2);?>" class="<?php echo get_text_input_class($match_type_2,$value_2);?>">
		</div>
		
	</div>
	<div>
		<?php the_all_installed_plugins_checkbox_markup($data['plugins'] ?? []); ?>
	</div>
	<div class="adv-plugin-filter-note-wrap">
		<label for="note" class="adv-plugin-filter-note mb5">Note:</label>
		<textarea id="note" name="note" cols="68" rows="5" placeholder="<?php echo $note_placeholder;?>"><?php echo $note;?></textarea>
	</div>
	<?php
}

function get_text_input_class($match_type,$value){

	static $hidden_on_match_type = false;

	if(!$hidden_on_match_type ){
			
		$hidden_on_match_type = [
			'null',
			'admin',
			'frontend',
			'ajax',
			'cron',
			'rest',
			'logged_in',
			'logged_in_not',
		];
	}
	
	return in_array( $match_type, $hidden_on_match_type ) ? 'ro-hidden' : '';	

}

function the_all_installed_plugins_checkbox_markup($selected_plugins) {

	$plugins = get_plugins_data_for_checkbox_form();
	
	$markup = '';

	foreach ($plugins as $column => $plugins_group) {
	
		$column_name = get_column_name($column);
	
		$selectors_markup = get_selectors_markup($column);
	
		$column_markup = 
<<<HTML
<div class="plugins-column {$column}">
	<div class="title-column mb5">
		{$column_name}
	</div>
	{$selectors_markup}
HTML;

		foreach ($plugins_group as $plugin_data) {
			$checked = is_checked($plugin_data, $selected_plugins) ? ' checked' : '';
			$plugin_name = get_truncated_plugin_name($plugin_data['name']);
			$plugin_checkbox_class = get_plugin_checkbox_class($plugin_data['path']);
			$plugin_path = esc_attr($plugin_data['path']);
			$plugin_name_html = esc_html($plugin_name);

			$column_markup .= 
<<<HTML
	<label class="{$plugin_checkbox_class}">
		<input type="checkbox" name="plugins[]" value="{$plugin_path}"{$checked}>{$plugin_name_html}
	</label><br>
HTML;
		}

		// Close column div
		$column_markup .=
<<<HTML
	</div>
HTML;

		$markup .= $column_markup;
	}

	echo <<<HTML
<div class="plugins-wrap mb20">
	{$markup}
</div>
HTML;
}


function get_truncated_plugin_name($plugin_name){

	if( strlen($plugin_name)<= 45 ) return $plugin_name;

	return substr( $plugin_name, 0, 43).'...';

}

function get_selectors_markup($column) {

	if ($column === 'theme') return '';

	$text_check_all =	esc_html__( 'Check all', 'advanced-plugin-filter' );
	$text_uncheck_all =	esc_html__( 'Uncheck all', 'advanced-plugin-filter' );
	$text_check_invert =	esc_html__( 'Invert', 'advanced-plugin-filter' );

	return <<<HTML
	<div class="selectors-{$column} mb5">
		<a href="#" class="check-all" data-column="{$column}">{$text_check_all}</a> |
		<a href="#" class="uncheck-all" data-column="{$column}">{$text_uncheck_all}</a> |
		<a href="#" class="invert-selection" data-column="{$column}">{$text_check_invert}</a>
	</div>
	HTML;
}


function get_column_name($column){

	switch($column){

		case 'active':
			$result =  esc_html__( 'Active plugins', 'advanced-plugin-filter' );
		break;

		case 'inactive':
			$result =  esc_html__( 'Inactive plugins', 'advanced-plugin-filter' );
		break;

		case 'theme':
			$result =  esc_html__( 'Active theme', 'advanced-plugin-filter' );
		break;
	}

	return $result??'';
}

function is_checked($plugin_data,$selected_plugins){

	global $pagenow;

	if($pagenow === 'post-new.php' && $plugin_data['path'] === 'theme'){
		
		// make by default theme active on a new filter
		return ' checked';
	}

	return	in_array($plugin_data['path'], $selected_plugins) ? ' checked' : '';

}

/**
* @param string 
* @return array -
* - 'active'[] => ['path'=>$path,'name'=>$plugin_name]
* - 'inactive'[] => ['path'=>$path,'name'=>$plugin_name]
*/

function get_plugins_data_for_checkbox_form(){

	$plugins = get_actual_plugin_lists();
	
	return [

		'active' => $plugins['active']??[],

		'inactive' => $plugins['inactive']??[],
		
		'theme' => [ 
			
			0=> [
				'path'=>'theme',
				
				'name'=> esc_html__(
					
					wp_get_theme()->get('Name'),
					
					wp_get_theme()->get('TextDomain')
					
					)
				]
		],
	];
}

function get_actual_plugin_lists() {

	if(!function_exists( 'is_plugin_active' )) include_once ABSPATH . 'wp-admin/includes/plugin.php';

	$active_plugin_paths = get_active_plugin_paths();

	$all_plugins = get_plugins();

	foreach ($all_plugins as $path => $plugin_data) {

		$plugin_group_name = in_array($path, $active_plugin_paths) ? 'active' : 'inactive';

		$result[$plugin_group_name][] =[
			
			'path'=> $path,
			
			'name' => esc_html__(
				
				$plugin_data['Name'],
			
				$plugin_data['TextDomain']
				)
			];
			
	}

	return $result;
}

function get_active_plugin_paths(){
	
	global $wpdb;

	//get_options won't get current state of DB, has to be accessed directly
	$active_plugins_serialized = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'");
	
	return maybe_unserialize($active_plugins_serialized);

}

function get_plugin_checkbox_class($path){

	if( $path === 'theme' ) return 'ro-theme-checkbox';

	return is_plugin_active($path) ? 'ro-plugin-active' : 'ro-plugin-inactive';

}

function advanced_plugin_filter_save_post_data($post_id, $post, $update) {
	
	if( !is_apf_save_point($post, $post_id) || !current_user_can('activate_plugins', $post_id) ) return;
	
	$data = array(	
		'filter_mode' => ($_POST['filter_mode']??'allow') ==='allow' ? 'allow' : 'disable',
		'logic' => ($_POST['logic']??'or') ==='or' ? 'or' : 'and',
		'match_type_1' => sanitize_text_field($_POST['match_type_1'] ?? ''),
		'value_1' => sanitize_text_field($_POST['value_1'] ?? ''),
		'operator_1' => sanitize_text_field($_POST['operator_1'] ?? ''),
		'match_type_2' => sanitize_text_field($_POST['match_type_2'] ?? ''),
		'value_2' => sanitize_text_field($_POST['value_2'] ?? ''),
		'operator_2' => sanitize_text_field($_POST['operator_2'] ?? ''),
		'plugins' => isset($_POST['plugins']) ? array_map('sanitize_text_field', $_POST['plugins']) : array(),
		'note' => sanitize_textarea_field($_POST['note'] ?? ''),
		'version' => WPSD_APF_VER
	);

	$json_data = wp_json_encode($data);

	remove_action('save_post', __NAMESPACE__.'\advanced_plugin_filter_save_post_data');

	wp_update_post(array(
		'ID'           => $post_id,
		'post_content' => $json_data
	));

	add_action('save_post', __NAMESPACE__.'\advanced_plugin_filter_save_post_data', 10, 3);

	require_once WPSD_APF_DIR.'admin/setup.php';

	activate_mu_plugin( $rewrite=true );

}

add_action('save_post', __NAMESPACE__.'\advanced_plugin_filter_save_post_data', 10, 3);

function add_author_column_header($columns) {
	
	foreach($columns as $key => $value){

		if( $key==='date' ) $result['author'] = esc_html__('Author');

		$result[$key]= $value;
	}

	return $result;

}

add_filter('manage_advanced_plugin_filter_posts_columns', __NAMESPACE__ . '\add_author_column_header');


function is_apf_save_point($post) {

	return (
	
		$post->post_type === 'adv_plugin_filter' &&
	
		!defined('DOING_AUTOSAVE') &&
	
		isset($_POST['advanced_plugin_filter_meta_box_nonce']) &&
	
		wp_verify_nonce(
			
			$_POST['advanced_plugin_filter_meta_box_nonce'],
			
			'advanced_plugin_filter_save_meta_box_data'
			
		)
	);
}

function display_notice_not_filters_enabled(){

	$text = esc_html__('Filters are not enabled.', 'advanced-plugin-filter');

	echo <<<HTML
	<div class="notice notice-warning is-dismissible">
	<p>{$text}</p>
	</div>
	HTML;


}

function refresh_mu_plugin_after_update( $post_id ) {

	$post = get_post( $post_id );

	if ( !$post->post_type === 'adv_plugin_filter' ) return;

	require_once WPSD_APF_DIR.'admin/setup.php';

	activate_mu_plugin( $rewrite=true );
	
}

add_action( 'publish_to_trash', __NAMESPACE__.'\refresh_mu_plugin_after_update' );
add_action( 'draft_to_publish', __NAMESPACE__.'\refresh_mu_plugin_after_update' );
add_action( 'trash_to_publish', __NAMESPACE__.'\refresh_mu_plugin_after_update' );
add_action( 'bulk_edit_posts', __NAMESPACE__.'\refresh_mu_plugin_after_update' );
