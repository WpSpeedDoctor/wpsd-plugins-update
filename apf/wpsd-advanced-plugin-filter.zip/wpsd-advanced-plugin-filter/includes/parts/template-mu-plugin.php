<?php

namespace {$namespace};

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
Description: {$mu_plugin_description}
Version: {$version}
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

defined( 'ABSPATH' ) || exit;



//Recovery link
if( isset( $_GET['{$recovery_query_string}'] ) ){

	unlink(__FILE__);

	update_option('adv-plugin-filter-enabled', '0', 'no');

	return;
}

@include_once WP_PLUGIN_DIR.'/{$plugin_dir}/wp-request-type.php';

//disable filters on the plugin page to avoid automatic disabling of plugins
switch(true){

	case !defined('WPSD_REQUEST_TYPE'):
	case !defined('WPSD_URI_PATH'):
	{$blog_id_case}
	case WPSD_REQUEST_TYPE === REQUEST_ADMIN && str_ends_with( WPSD_URI_PATH, '/wp-admin/plugins.php' ):
	case !empty($_SERVER['HTTP_REFERER']) && WPSD_REQUEST_TYPE === REQUEST_AJAX && str_contains( $_SERVER['HTTP_REFERER'], '/wp-admin/plugins.php' ):
		return;
}

define( 'WPSD_APF_MU_VER', '{$version}');

run_plugin_filter();

function run_plugin_filter(){

{$match_type_variables_markup}

{$conditions_markup}

	{$debug_enabled_markup}@include_once WP_PLUGIN_DIR.'/{$plugin_dir}/includes/wp-debug.php';

	//disable theme
	if( isset( $td ) || isset($a) && !isset($ta) ){

		add_filter( 'template_directory', function(){return ABSPATH;} );
		
		add_filter( 'stylesheet_directory', function(){return ABSPATH;} );
	}

	if( !isset($a) && !isset($d) ) return;
	
//$a -> allowed plugins
//$d -> disabled plugins
//$td -> theme is disabled
//$ta -> theme is allowed
//$p -> all currently active plugins

{$all_plugins}

//blackout protection
	if( WPSD_REQUEST_TYPE ===REQUEST_ADMIN || WPSD_REQUEST_TYPE === REQUEST_AJAX ){

{$blackout_protection}
	
	}

    if( isset($d) ){

		define('APF_DISABLED_PLUGINS', array_flip(array_intersect_key($p,$d)) );

	}


	if( isset($a) ){

		define('APF_ALLOWED_PLUGINS', array_flip(array_intersect_key($p,$a)) );
		
	}

	add_filter('option_active_plugins', '{$namespace}\filter_active_plugins',1,1);
	
	{$multisite_hook}
}


{$multisite_hook_function}


function filter_active_plugins($active_plugins){

	static $filtered_plugin_list;

	if( $filtered_plugin_list !== null ) return $filtered_plugin_list;

	$filtered_plugin_list = array_flip(filter_plugins(array_flip($active_plugins)));

	return $filtered_plugin_list;

}

function filter_plugins($active_plugins){

	if( empty($active_plugins) ) return [];

	$filtered_plugin_list = $active_plugins;

	if(defined('APF_DISABLED_PLUGINS')){
		$filtered_plugin_list = array_diff_key($filtered_plugin_list, APF_DISABLED_PLUGINS);
	}

	if(defined('APF_ALLOWED_PLUGINS')){
		$filtered_plugin_list = array_intersect_key($filtered_plugin_list, APF_ALLOWED_PLUGINS);
	}

	return $filtered_plugin_list;

}

{$addon_functions_markup}