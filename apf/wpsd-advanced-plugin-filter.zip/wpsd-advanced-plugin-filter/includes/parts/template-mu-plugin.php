<?php

namespace {$namespace};

/*
Plugin Name: {$mu_plugin_name}
Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
Description: {$mu_plugin_description}
Version: {$version}
Author: {$mu_plugin_author}
Author URI: {$mu_plugin_url}
License: GPL2
Text Domain: {$text_domain}
Domain Path: /languages/
*/

defined( 'ABSPATH' ) || exit;

//disable filters on the plugin page to avoid automatic disabling of plugins
if( defined('WP_ADMIN') && str_contains($_SERVER['REQUEST_URI'], '/wp-admin/plugins.php') ) return;

//Recovery link
if( isset($_GET['{$recovery_query_string}']) ){

	unlink(__FILE__);

	update_option('adv-plugin-filter-enabled', '0', 'no');

	return;
}

run_plugin_filter();

function run_plugin_filter(){

	{$match_type_variables_markup}

    {$conditions_markup}

	{$debug_enabled_markup}@include_once WP_PLUGIN_DIR.'/{$plugin_dir}/includes/wp-debug.php';

	//disable theme
	if( isset( $td ) || isset($a) && !isset($ta) ){

		add_filter( 'template_directory', '__return_empty_string' );
		
		add_filter( 'stylesheet_directory', '__return_empty_string' );
	}

	if( !isset($a) && !isset($d) ) return;
	
//$a -> allowed plugins
//$d -> disabled plugins
//$td -> theme is disabled
//$ta -> theme is allowed
//$p -> all currently active plugins

{$all_plugins}

    if( isset($d) ){

		{$blackout_disabled_protection}

		define('APF_DISABLED_PLUGINS', array_intersect_key($p,$d) );

	}


	if( isset($a) ){

		{$blackout_allowed_protection}

		define('APF_ALLOWED_PLUGINS', array_intersect_key( $p,$a ) );
		
	}

	add_filter('option_active_plugins', '{$namespace}\\filter_active_plugins',1,1);


}

function filter_active_plugins($active_plugins){

	static $filtered_plugin_list = false;

	switch(true){

		case $filtered_plugin_list !== false :

			return $filtered_plugin_list;
		break;

		case defined('APF_DISABLED_PLUGINS') && defined('APF_ALLOWED_PLUGINS' ):

			$filtered_plugin_list = array_filter(array_diff($active_plugins, APF_DISABLED_PLUGINS), '{$namespace}\is_allowed_plugin');
		break;

		case defined('APF_DISABLED_PLUGINS') && !defined('APF_ALLOWED_PLUGINS' ):
			
			$filtered_plugin_list = array_diff($active_plugins, APF_DISABLED_PLUGINS);
		break;

		default:

			$filtered_plugin_list = array_filter($active_plugins, '{$namespace}\is_allowed_plugin');
		break;
	}

	return $filtered_plugin_list;
}

function is_allowed_plugin($plugin){

	return in_array($plugin, APF_ALLOWED_PLUGINS);
}

{$addon_functions_markup}