<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function admin_menu_main(){
	
	the_header();

	save_plugin_settings();
	
	plugin_settings();
	
	the_recovery_link();

	the_footer();
}

function save_plugin_settings(){

	if ( !isset($_POST['adv_plugin_settings_nonce']) || !is_valid_settings_nonce() ) return;

	$enabled = isset($_POST['adv_plugin_filter_enabled']) ? '1' : '0';

	update_option('adv-plugin-filter-enabled', $enabled, 'no');

	?><div class="notice notice-success is-dismissible"><p><?php echo esc_html__( "Settings saved successfully.", 'advanced-plugin-filter' );?></p></div><?php

	require_once WPSD_APF_DIR.'admin/setup.php';

	if($enabled) {

		activate_mu_plugin( $rewrite=true );
	
	} else {

		remove_mu_plugin();

	}

}

function is_valid_settings_nonce(){

    return wp_verify_nonce($_POST['adv_plugin_settings_nonce']??'', 'update_settings');
}

function plugin_settings(){

	$enabled_setting = get_option('adv-plugin-filter-enabled', '0');

?><form method="post" action="" class="mb20">
    <?php wp_nonce_field('update_settings', 'adv_plugin_settings_nonce'); ?>
	
    <h3><?php echo esc_html__( "Settings", 'advanced-plugin-filter' );?> </h3>
    <p>
        <input type="checkbox" id="adv_plugin_filter_enabled" name="adv_plugin_filter_enabled" <?php checked($enabled_setting, '1'); ?>>
        <label for="adv_plugin_filter_enabled"><?php echo esc_html__( "Plugin filters enabled", 'advanced-plugin-filter' );?></label>
    </p>    
    <input type="submit" value="Save Settings" class="button-primary">
</form>
<hr class="mb20">
<?php
}

function the_recovery_link(){

    require_once WPSD_APF_DIR.'includes/recovery-functions.php';

?>
<h3><?php echo esc_html__( "Recovery link", 'advanced-plugin-filter' );?></h3>
<p><?php echo esc_html__( "When you cannot access the admin area because of this plugin, use this link. It will completely disable any filters.", 'advanced-plugin-filter' );?></p>
<p><?php echo esc_html__( "In order to make work plugin again, you need to enable it in this menu.", 'advanced-plugin-filter' );?></p>
<p><?php echo esc_html__( "We recommend to bookmark this link.", 'advanced-plugin-filter' );?></p>
<script>
function copyURL() {
    // Get the URL text field
    var urlField = document.getElementById("recoveryUrl");

    // Select the content
    urlField.select();
    urlField.setSelectionRange(0, 99999); // For mobile devices

    // Copy the text inside the text field
    try {
        var successful = document.execCommand('copy');
    } catch (err) {
        console.log('Oops, unable to copy');
    }
}
</script>

<div class="url-copy-container" style="margin-bottom: 10px;">
    <input type="text" id="recoveryUrl" value="<?php echo get_recovery_url();?>" readonly style="min-width: 400px;">
    <button onclick="copyURL()" class="button-primary">Copy URL</button>
</div>
<br><hr><br>
<?php
}


function the_header(){

	?><div class="wrap apf-plugin-menu-wrap">
<h1><?php esc_html_e( "Advanced Plugin Filter by WP Speed Doctor", 'advanced-plugin-filter' );?></h1>
<?php
}

function the_footer(){

	//</div> of advanced-plugin-filter-body
?>	</div>
</div><?php
}