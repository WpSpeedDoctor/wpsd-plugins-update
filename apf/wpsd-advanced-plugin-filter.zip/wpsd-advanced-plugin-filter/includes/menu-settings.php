<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function admin_menu_main(){
	
	the_header();

	save_plugin_settings();
	
	plugin_settings();
	
	the_recovery_link();

	display_mu_for_debug();

	the_footer();
}

function display_mu_for_debug(){

	$title = esc_html__( "Debug info", 'advanced-plugin-filter' );

	$description =  esc_html__( "The code below serves as the engine for the filtration process and is displayed for debugging purposes.", 'advanced-plugin-filter' );
	
	$developer_debug_link =  esc_html__( "Send debug info", 'advanced-plugin-filter' );
	

	echo

<<<HTML
<h3>$title</h3>
<p>
	$description<br>
	<a href="https://wpspeeddoctor.com/plugins/advanced-plugin-filter/" target="_blank">$developer_debug_link</a>
</p>
HTML;
	
	$debug_text = trim( get_debug_text() );
	
	$lines_count = min( 15, count( explode ( "\n", $debug_text) ));

	$button_text = esc_html__( "Copy", 'advanced-plugin-filter' );
	

		echo 
<<<HTML
<button onclick="copyDebug()" class="button-primary">{$button_text}</button>
<br><br>
<textarea id="debugWindow" rows="{$lines_count}" readonly style="width: 100%;">$debug_text</textarea>
<script>
function copyDebug(){
	// Get the URL text field
	var urlField = document.getElementById("debugWindow");

	// Select the content
	urlField.select();
	urlField.setSelectionRange(0, 99999); // For mobile devices

	// Copy the text inside the text field
	try {
		var successful = document.execCommand('copy');
	} catch (err){
		console.log('Oops, unable to copy');
	}
}
</script>
HTML;

}

function get_debug_text(){

	$filter_data = get_content_adv_plugin_filter();
	
	if( empty($filter_data) ){

		return esc_html__( "No filters found. Create at least one plugin filter.", 'advanced-plugin-filter' );
	
	}
	
	require_once WPSD_APF_DIR.'admin/setup.php';
	
	$mu_loader_filepath = get_mu_plugin_loader_filepath();
	
	if( file_exists( $mu_loader_filepath ) ){

		$mu_plugin_markup = file_get_contents( $mu_loader_filepath );

		$mu_plugin_markup = str_replace( get_recovery_query_string(), '***reset-query-string***', $mu_plugin_markup );
		
		$mu_plugin_markup = htmlentities(str_replace( LOGGED_IN_COOKIE, 'wordpress_logged_in', $mu_plugin_markup ));
		
	} else {

		$mu_plugin_markup = esc_html__( "No filters in use because as there are no published filters or not globally enabled.", 'advanced-plugin-filter' );

	}

	return "$mu_plugin_markup\n\n$filter_data";

}

function get_content_adv_plugin_filter(){

	global $wpdb;
	
	$query = "SELECT post_content FROM {$wpdb->posts} WHERE post_type = 'adv_plugin_filter'";
	
	$results = $wpdb->get_results($query);
	
	$combined_content = '';
	
	foreach($results as $post){

		$combined_content .= "{$post->post_content}\n";
	
	}
	
	return $combined_content;
}


//MARK:Save settings
function save_plugin_settings(){

	if( !isset($_POST['adv_plugin_settings_nonce']) || !is_valid_settings_nonce() ) return;

	$enabled = isset($_POST['adv_plugin_filter_enabled']) ? '1' : '0';
	
	$debug = isset($_POST['adv_plugin_filter_debug']) ? '1' : '0';

	update_option('adv-plugin-filter-debug', $debug, 'no');

	require_once WPSD_APF_DIR.'admin/setup.php';

	$is_success = true;

	if($enabled){

		$is_success = activate_mu_plugin( $rewrite=true, $validate=true, $display_notice=false );
				
	} else {

		remove_mu_plugin();
		
		$enabled = '0';
	}

	if( !$is_success) {
	
		$enabled = '0';
	}
	
	update_option('adv-plugin-filter-enabled', $enabled, 'no');

	if( $is_success ) {

		$text = esc_html__( "Settings saved successfully.", 'advanced-plugin-filter' );
		
		$class = 'success';
		
	} else {
		
		$text = esc_html__( "Creating mu-plugin failed. Send debug information to the developer", 'advanced-plugin-filter' );
		
		$class = 'error';
	}

	echo <<<HTML
<div class="notice notice-{$class} is-dismissible">
	<p>
		{$text}
	</p>
</div>
HTML;

}

function is_valid_settings_nonce(){

	return wp_verify_nonce($_POST['adv_plugin_settings_nonce']??'', 'update_settings');
}

function plugin_settings(){

	$setting_enabled = get_option('adv-plugin-filter-enabled', '0');

	$debug_enabled = get_option('adv-plugin-filter-debug', '0');

?><form method="post" action="" class="mb20">
	<?php wp_nonce_field('update_settings', 'adv_plugin_settings_nonce'); ?>
	
	<h3><?php echo esc_html__( "Settings", 'advanced-plugin-filter' );?></h3>
	<p>
		<input type="checkbox" id="adv_plugin_filter_enabled" name="adv_plugin_filter_enabled" <?php checked($setting_enabled, '1'); ?>>
		<label for="adv_plugin_filter_enabled"><?php echo esc_html__( "Plugin filters enabled", 'advanced-plugin-filter' );?></label>
	</p>    
	<p>
		<input type="checkbox" id="adv_plugin_filter_debug" name="adv_plugin_filter_debug" <?php checked($debug_enabled, '1'); ?>>
		<label for="adv_plugin_filter_debug"><?php echo esc_html__( "Print debug info in the footer", 'advanced-plugin-filter' );?></label>
	</p>    
	<input type="submit" value="Save Settings" class="button-primary">
</form>
<hr class="mb20">
<?php
}

function the_recovery_link(){

	require_once WPSD_APF_DIR.'includes/recovery-functions.php';

?>
<h3><?php echo esc_html__( "Recovery link", 'advanced-plugin-filter' );?></h3>
<p><?php echo esc_html__( "When you cannot access the admin area because of this plugin, use this link. It will completely disable any filters.", 'advanced-plugin-filter' );?></p>
<p><?php echo esc_html__( "In order to make work plugin again, you need to enable it in this menu.", 'advanced-plugin-filter' );?></p>
<p><?php echo esc_html__( "We recommend to bookmark this link.", 'advanced-plugin-filter' );?></p>
<script>
function copyURL(){
	// Get the URL text field
	var urlField = document.getElementById("recoveryUrl");

	// Select the content
	urlField.select();
	urlField.setSelectionRange(0, 99999); // For mobile devices

	// Copy the text inside the text field
	try {
		var successful = document.execCommand('copy');
	} catch (err){
		console.log('Oops, unable to copy');
	}
}
</script>

<div class="url-copy-container" style="margin-bottom: 10px;">
	<input type="text" id="recoveryUrl" value="<?php echo get_recovery_url();?>" readonly style="min-width: 400px;">
	<button onclick="copyURL()" class="button-primary"><?php echo esc_html__( 'Copy', 'advanced-plugin-filter' );?></button>
</div>
<br><hr><br>
<?php
}


function the_header(){

	?><div class="wrap apf-plugin-menu-wrap">
<h1><?php esc_html_e( "Advanced Plugin Filter by WP Speed Doctor", 'advanced-plugin-filter' );?></h1>
<?php
}

function the_footer(){

	
?>	</div> <!-- end apf-plugin-menu-wrap -->
<?php
}