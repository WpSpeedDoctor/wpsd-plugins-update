<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_admin_post_type($request_type, $is_logged_in){
	
	if( $request_type !== 'admin' || !$is_logged_in ) return '';

	//sanitized input
	if( !empty( $_GET['post_type'] ) ) return preg_replace('/[^a-zA-Z0-9\-_]/', '', $_GET['post_type']);
		
	//ensured only numeric value allowed
	if(!isset($_GET['post']) || !is_numeric($_GET['post']) ) return '';

	$cache_key = "apf-admin-{$_GET['post']}";

	$cached_data = wp_cache_get( $cache_key );
	
	if( $cached_data !== false ) return $cached_data;

	global $wpdb;

	$result = $wpdb->get_var(

					$wpdb->prepare(
				
						"SELECT post_type FROM {$wpdb->posts} WHERE ID = %s LIMIT 1", $_GET['post']
					)
				);
	
	wp_cache_set( $cache_key, $result );

	return $result;
}