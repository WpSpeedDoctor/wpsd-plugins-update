<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_admin_post_type(){
	
	if( !empty( $_GET['post_type'] ) ) {
		//$post_type_max_length is a placeholder and is dynamically created based on post types in DB
		//no need for sanitization
		return isset( $_GET['post_type'][$post_type_max_length] ) ? '' : $_GET['post_type'];
	}

	$post_id = intval( $_GET['post']??0);

	if( $post_id < 1 ) {
		return '';
	}
	
	$cached_data = wp_cache_get( $post_id, 'apf-be' );
	
	if( $cached_data !== false ) return $cached_data;

	global $wpdb;

	$result = $wpdb->get_var(

		$wpdb->prepare(
	
			"SELECT post_type FROM {$wpdb->posts} WHERE ID = %d", $post_id
		)
	);
	
	wp_cache_set( $post_id, (string) $result, 'apf-be' );

	return $result;
}