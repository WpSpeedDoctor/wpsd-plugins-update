<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_front_end_post_type(){
	
	$uri_path = WPSD_URI_PATH === '/' ? '/' : untrailingslashit(WPSD_URI_PATH);

	//front page with language roots of URI when available,
	//undeclared variable will be replaced upon mu-plugin creation process
	{$uri_language_root_replacement}

	$slug = ltrim(strrchr($uri_path,'/'),'/');

	// 'fnv164' is fastest hash producing 16 characters and available from 7.4 till 8.3
	// when PHP 8.1 compatibility is minimum version, the hash algorithm may be replaced by 'murmur3f' producing 32 characters
	$cache_key = hash( 'fnv164', $slug );

	$cached_data = wp_cache_get( $cache_key, 'apf-fe' );
	
	if( $cached_data !== false ) return $cached_data;

	global $wpdb;

	{$table_posts_replacement}
	
	$result = $wpdb->get_var(

				$wpdb->prepare(
			
					"SELECT post_type FROM {$table_posts} WHERE post_name = %s LIMIT 1", $slug
				)
	);

	wp_cache_set( $cache_key, (string) $result, 'apf-fe' );

	return $result;
}

//Depends on settings of what's the front page, it returns post type.
//If it's post it means it's a blog archive therefore empty/undetermined post type. 

function get_front_page_type(){

	$show_on_front = get_option('show_on_front');

	return $show_on_front === 'posts' ? '' : $show_on_front;

}