<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_post_type_from_uri( $uri_path, $request_type ){
	
	if( $request_type !=='frontend') return '';

	//front page with language roots of URI when available
	if( $uri_language_root_replacement ) return get_front_page_type();
	
	$segments = explode('/', trim($uri_path, '/'));

	$slug = array_pop($segments);

	// 'fnv164' is fastest hash producing 16 characters and available from 7.4 till 8.3
	// when PHP 8.1 compatibility is minimum version, the hash algorithm may be replaced by 'murmur3f' producing 32 characters
	$cache_key = 'apf-fe-'.hash('fnv164', $slug);

	$cached_data = wp_cache_get( $cache_key );
	
	if( $cached_data !== false ) return $cached_data;

	global $wpdb;

	$result = $wpdb->get_var(

				$wpdb->prepare(
			
					"SELECT post_type FROM {$wpdb->posts} WHERE post_name = %s LIMIT 1", $slug
				)
	);

	wp_cache_set( $cache_key, $result );

	return $result;
}

function get_front_page_type(){

	$show_on_front = $GLOBALS['wp_object_cache']->cache['options']['alloptions']['show_on_front'];

	return $show_on_front === 'posts' ? '' : $show_on_front;

}