<?php

namespace advanced_plugin_filter;

defined( 'ABSPATH' ) || exit;

function get_front_end_post_type(){
	
	if( WP_REQUEST_TYPE !== 'frontend' ) return '';

	//front page with language roots of URI when available,
	//undeclared variable will be replaced upon mu-plugin creation process
	{$uri_language_root_replacement}
	
	$segments = explode( '/', trim(WPSD_URI_PATH, '/') );

	$slug = array_pop( $segments );

	// 'fnv164' is fastest hash producing 16 characters and available from 7.4 till 8.3
	// when PHP 8.1 compatibility is minimum version, the hash algorithm may be replaced by 'murmur3f' producing 32 characters
	$cache_key = 'apf-fe-'.hash( 'fnv164', $slug );

	$cached_data = wp_cache_get( $cache_key );
	
	if( $cached_data !== false ) return $cached_data;

	global $wpdb;

	$result = $wpdb->get_var(

				$wpdb->prepare(
			
					"SELECT post_type FROM {$wpdb->posts} WHERE post_name = %s LIMIT 1", $slug
				)
	);

	wp_cache_set( $cache_key, $result );

	return $result;
}

//Depends on settings of what's the front page, it returns post type.
//If it's post it means it's a blog archive therefore empty/undetermined post type. 

function get_front_page_type(){

	$show_on_front = $GLOBALS['wp_object_cache']->cache['options']['alloptions']['show_on_front'];

	return $show_on_front === 'posts' ? '' : $show_on_front;

}