<?php

namespace WPSD\apf;

defined( 'ABSPATH' ) || exit;

/*
* Plugin Name: WPSD Plugin filter
* Plugin URI: https://wpspeeddoctor.com/plugins/advanced-plugin-filter/
* Description: Reduce initial server response time (TTFB) with this essential tool. It allows admins to selectively deactivate non-essential plugins based on a variety of conditions like URL, $_POST, thus making the website faster and reducing CPU utilization.
* Version: 1.6
* Updated: 2026-10-06
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: advanced-plugin-filter
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 7.4.0
*/	

/**
 * Constants
 */

define( 'WPSD_APF_DIR', __DIR__.'/' );

// change version in setup.php where `version_compare`
define( 'WPSD_APF_VER', '1.6' );

if(	!defined( 'REQUEST_FRONTEND' ) || !defined('WPSD_URI_PATH') || !defined( 'WPSD_REQUEST_TYPE' )){
	require_once WPSD_APF_DIR.'wp-request-type.php';
}

/**
 * Runtime code
 */

main();

/**
 * functions only beyond this point
 */

function main(){

	require WPSD_APF_DIR.'includes/cpt.php';

	switch(WPSD_REQUEST_TYPE){

		case REQUEST_AJAX:
			
			$post_action = $_POST['action']??'';

			if( $post_action === 'update-plugin' ){
				
				require_once WPSD_APF_DIR.'admin/update.php';

			}

			if( $post_action === 'delete-plugin' ){
				
				require WPSD_APF_DIR.'admin/uninstall.php';
			}

			if( $post_action === 'afp-code-validation'){

				require WPSD_APF_DIR.'admin/setup.php';

				try_validation_file();
			}
		break;

		case REQUEST_ADMIN:

			require WPSD_APF_DIR.'admin/admin-area.php';

			run_back_end(__FILE__);

			assure_latest_mu_plugin_version();
			
			if(isset($_GET['tab']) && $_GET['tab'] === 'plugin-information'){
				
				require_once WPSD_APF_DIR.'admin/update.php';
			}


		break;

		case REQUEST_CRON:
	
			require_once WPSD_APF_DIR.'admin/update.php';
			
		break;

		default:
			assure_latest_mu_plugin_version();
		break;
	}
		

}


/**
 * Automatically update mu plugin via shutdown function on cron or update ajax.
 * Hook `upgrader_process_complete` is unreliable for update mu-plugins
 */

function assure_latest_mu_plugin_version(){
	
	switch(true){

		case !defined('WPSD_APF_MU_VER'):
		case WPSD_APF_MU_VER === WPSD_APF_VER:
		case defined( 'WPSD_APF_CREATED'):
		case empty( get_option('adv-plugin-filter-enabled') ):
		case is_network_admin():
		case is_admin() && str_ends_with( $_SERVER['REQUEST_URI']??'', '/wp-admin/plugins.php' ):
		case !empty($_SERVER['HTTP_REFERER']) && wp_doing_ajax() && str_contains( $_SERVER['HTTP_REFERER'], '/wp-admin/plugins.php' ):
			
			return;
	}
	
	require_once WPSD_APF_DIR.'admin/setup.php';

	add_action('init', __NAMESPACE__.'\refresh_mu_plugin');


}

