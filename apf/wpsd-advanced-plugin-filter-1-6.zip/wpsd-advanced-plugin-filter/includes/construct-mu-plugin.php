<?php

namespace WPSD\apf;

defined( 'ABSPATH' ) || exit;

require WPSD_APF_DIR.'includes/classes/class-php-condition.php';

require WPSD_APF_DIR.'/includes/classes/class-apf-rule.php';

function get_mu_plugin_markup( $conditions_markup ){
	
	$markup_data = get_markup_data( $conditions_markup );
	
	if( empty($markup_data) ) return false;
	
	$template = file_get_contents( WPSD_APF_DIR.'/includes/parts/template-mu-plugin.php' );

	foreach( $markup_data as $variable => $value ){

		$template = str_replace( '{$'.$variable.'}', $value, $template );
	}
	
	return str_replace( "\n\n","\n", $template);
	
}

function get_markup_data( $conditions_markup ){

	require_once WPSD_APF_DIR.'includes/recovery-functions.php';

	$active_plugins = get_active_plugins_from_db();

	$apf_position = array_search( 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php' , $active_plugins );

	if( $apf_position === false ){
		
		return false;
    }

	return [

		'match_type_variables_markup' => get_match_type_variables_markup($conditions_markup),

		'debug_enabled_markup'		=> get_option('adv-plugin-filter-debug', '0') ? '' : 'if( defined("WP_DEBUG") && WP_DEBUG ) ',
		
		'recovery_query_string'		=> get_recovery_query_string(),

		'blog_id_case'				=> get_blog_id_case_markup(),
		
		'mu_plugin_name'			=> esc_html__("WPSD Advanced Plugin Filter", 'advanced-plugin-filter'),
		
		'mu_plugin_description'		=> esc_html__("Run less code, run faster website", 'advanced-plugin-filter'),
		
		'mu_plugin_author'			=> "WP Speed Doctor",
		
		'addon_functions_markup'	=> get_addon_functions_markup($conditions_markup),
		
		'mu_plugin_url'				=> "https://wpspeeddoctor.com/",

		'version'					=> WPSD_APF_VER, 
		
		'text_domain'				=> 'advanced-plugin-filter',

		'plugin_dir'				=> basename(WPSD_APF_DIR),
		
		'conditions_markup'			=> $conditions_markup,

		'all_plugins'				=> '$p = '.var_export($active_plugins,true).';'.PHP_EOL,

		'blackout_protection'		=> get_blackout_protection($apf_position),

		'multisite_hook'			=> get_multisite_hook(),

		'multisite_hook_function'	=> get_multisite_hook_function(),

		'namespace'					=> 'WPSD\\apf\\mu_plugin\\test',

	];

}

function get_multisite_hook(){

	if( !is_multisite() ) return '';

	
	return

"if(is_multisite()) {
			
		add_filter('site_option_active_sitewide_plugins', '{\$namespace}\\filter_active_sitewide_plugins',1,1);
	}";

}

function get_multisite_hook_function(){

	if( !is_multisite() ) return '';

	return
'function filter_active_sitewide_plugins($active_plugins){

	static $filtered_plugin_list;

	if( $filtered_plugin_list !== null ) return $filtered_plugin_list;

	$filtered_plugin_list = filter_plugins($active_plugins);

	return $filtered_plugin_list;
}';

}

function get_blog_id_case_markup(){

	if( !is_multisite() ) return '';

	$blog_id = get_current_blog_id();

	return 

	"case is_network_admin():
	case get_current_blog_id() !== {$blog_id}:";

}

function get_blackout_protection( $apf_position ){

	return <<<HTML
			if( isset(\$d) ) unset(\$d[{$apf_position}]);

			if( isset(\$a) ) \$a[{$apf_position}]=null;
	HTML;
}

function get_plugins_list( $add_theme = true ){

	$result = get_active_plugins_from_db();

	if( $add_theme ){

		$result[] = 'theme';
	}
	
	return $result;
}

function get_mu_conditions_markup(){

	$active_apf_rules = get_filter_posts();

	$conditions_data = get_conditions( $active_apf_rules );

	if( empty($conditions_data) ) return '';

	$ifs_markup = get_ifs_markup( $conditions_data );

	return $ifs_markup;

}

function get_filter_posts(){

	return get_posts(
			
		[	'post_type' => 'adv_plugin_filter', 
			'post_status' => 'publish',
			'posts_per_page' => -1,
		]
	);

}

//MARK:var markup
function get_match_type_variables_markup( $conditions_markup ){

	$dependency_string = get_dependency_string( $conditions_markup);

	$result= "\n";

	$used_match_markups = [

		'uri'				=> "\$uri = \$_SERVER['REQUEST_URI'] ?? \$_SERVER['SCRIPT_NAME'];",

		'qs'				=> "\$qs = \$_SERVER['QUERY_STRING']??'';",

		'cookie'			=> "\$cookie = \$_SERVER['HTTP_COOKIE']??'';",
		
		//hardcoded cookie key as constant LOGGED_IN_COOKIE is not defined in mu-plugin yet
		'is_logged_in'		=> '$is_logged_in = isset($_COOKIE["'.LOGGED_IN_COOKIE.'"]);',

		'admin_post_type'	=> "\$admin_post_type = \$is_logged_in && WPSD_REQUEST_TYPE === REQUEST_ADMIN ? get_admin_post_type() : '';",
		
		'post_type'			=> "\$post_type = WPSD_REQUEST_TYPE === REQUEST_FRONTEND ? get_front_end_post_type() : '';",

	];

	foreach( $used_match_markups as $variable => $variable_markup ){

		if( !str_contains( $dependency_string.$conditions_markup , "\${$variable}" ) ) continue;

		$result .="	{$variable_markup}\n\n";
	}

	return $result;

}


function get_dependency_string($conditions_markup){

    $dependencies = [

        '$admin_post_type'	=> [ '$is_logged_in'],

    ];

    $dependency_strings = '';

    foreach($dependencies as $variable_with_dependency => $variables_to_be_depending_on){

        if(str_contains($conditions_markup, $variable_with_dependency)) $dependency_strings .=implode('',$variables_to_be_depending_on);
    }

    return $dependency_strings;
}

function get_addon_functions_markup( $conditions_markup ){
	
	$addon_functions_markup = $result = '';
	
	$addon_functions_markup .= get_post_type_front_end_function_markup( $conditions_markup );
	
	$addon_functions_markup .= get_post_type_back_end_function_markup( $conditions_markup );
	
	$code_lines = explode( "\n", $addon_functions_markup );
	
	$filtered_words = [ 'php', 'define', 'namespace', '//'];
	
	foreach( $code_lines as $line ){
		
		if(  is_filtered_line( $line, $filtered_words ) ) continue;
		
		$result .= $line;
	}
	
	$post_type_max_length = get_post_type_max_length();

	$result = str_replace( '$post_type_max_length', $post_type_max_length, $result );

	return "$result\n";

}

function get_post_type_max_length(){

	global $wpdb;

	$query = 
"SELECT MAX(LENGTH(post_type)) AS longest_length
FROM (
	
	SELECT DISTINCT post_type
	FROM {$wpdb->posts}
)
AS distinct_post_types;";

	return (string )$wpdb->get_var( $query );
}

function is_filtered_line( $line, $filtered_words ){

	foreach( $filtered_words as $filtered_word ){

        if( str_contains($line, $filtered_word) ) return true;
    }

	return false;
}

function get_post_type_back_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$admin_post_type') ) return '';

	return file_get_contents(WPSD_APF_DIR.'includes/post-type-be-functions.php').PHP_EOL;

}

function get_post_type_front_end_function_markup($conditions_markup){

	if( !str_contains($conditions_markup,'$post_type') ) return '';

	$uri_roots_markup = get_uri_roots_markup();

	$template_markup = file_get_contents(WPSD_APF_DIR.'includes/post-type-fe-functions.php').PHP_EOL;
	
	$template_markup = str_replace('{$uri_language_root_replacement}', $uri_roots_markup, $template_markup );

	$table_posts_markup = get_table_posts_markup();

	$template_markup = str_replace( '{$table_posts_replacement}', $table_posts_markup, $template_markup );

	return $template_markup;

}

function get_table_posts_markup(){
	
	return is_multisite() ? '$table_posts = $wpdb->get_blog_prefix( get_current_blog_id() )."posts";' : '$table_posts = $wpdb->posts;';
}

function get_uri_roots_markup(){

	$uri_roots = get_language_uri_roots();

	$parsed_path = parse_url( home_url('/'), PHP_URL_PATH);

	$home_url = $parsed_path === '/' ? '/' : untrailingslashit($parsed_path);
	
	if($home_url === '/') {
		
		$homepage_condition_markup = "\$uri_path === '/'";

	} else {
		
		$homepage_condition_markup = "\$uri_path === '/' || \$uri_path === '{$home_url}'";
	}

	if( empty($uri_roots) ) {

		return <<<HTML
		if( {$homepage_condition_markup} ){
				return get_front_page_type();
			}
		HTML;

	} 

	$uri_roots_case_markup = "	case '/".implode("/':\n\r		case '/",$uri_roots)."/':";

	return <<<HTML
	switch( trailingslashit( WPSD_URI_PATH ) ){

		{$uri_roots_case_markup}

				return get_front_page_type();

				break;
		}
	HTML;
}

function get_language_uri_roots(){

	$active_plugins = get_active_plugins_from_db();
	
	switch(true){
		
		//WPML
		case in_array('sitepress-multilingual-cms/sitepress.php', $active_plugins):

			$wpml_languages = apply_filters('wpml_active_languages', NULL, 'orderby=id&order=desc');

			if( !empty($wpml_languages) ){

				foreach ($wpml_languages as $language) {

					$languages[] = trim(parse_url($language['url'],PHP_URL_PATH), '/');
					
				}
			}

		break;

		//Polylang
		case in_array('polylang/polylang.php', $active_plugins) || in_array('polylang-pro/polylang.php', $active_plugins):

			//TODO: use polylang functions pll_home_url($args) to get home urls 
			global $wpdb;
			
			$languages = $wpdb->get_col(
				"SELECT slug 
				FROM {$wpdb->terms} AS t
				INNER JOIN {$wpdb->term_taxonomy} AS tt ON t.term_id = tt.term_id
				WHERE tt.taxonomy = 'language'"
			);

		break;
		
		//TranslatePress
		case in_array('translatepress-multilingual/index.php',$active_plugins) || in_array('translatepress-developer/index.php',$active_plugins):
		
			$trp_langs = get_option('trp_settings');
			
			if( !empty( $trp_langs ) ){

				foreach ($trp_langs['publish-languages'] as $code) {
					
					if ($code !== $trp_langs['default-language']) {
						
						$languages[] =  $trp_langs['url-slugs'][$code];
					}
				}
			}
		break;
	
		default:
		
            $languages = false;

		break;
	}

	return $languages??false;

}

function get_active_plugins_from_db_(){

	global $wpdb;

	$active_plugins = $wpdb->get_var("
		SELECT option_value 
		FROM {$wpdb->options} 
		WHERE option_name = 'active_plugins'
	");

	return unserialize($active_plugins);

}

function get_ifs_markup($conditions_data){

	$result = "\n";
	
	$all_plugins = get_plugins_list();

	foreach($conditions_data as $data){
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'disable' ) continue;
		
		if( empty($data['plugins']) && $data['filter_mode'] === 'allow' ) $data['plugins'] = ['all'];

		$variable_markup = get_variable_markup( $data, $all_plugins );
		
		if( empty($variable_markup) ) continue;

		$result .= "	//Post ID: {$data['post_id']}\n";

		if( empty($data['condition']) ){

			$result .= "{$variable_markup}\n";

		} else {

			$result .= <<<HTML
				if( {$data['condition']} ){
			{$variable_markup}
				}


			HTML;
		}
	
	}
	
	return $result;
}

function get_variable_markup( $data, $all_plugins ){

	$result ='';
	
	$filter_type_variable_name = $data['filter_mode'] === 'disable' ? 'd' : 'a';

	if( 
		empty( $data['plugins'] ) ||
		
		$data['filter_mode'] !== 'disable' &&
		
		count($data['plugins']) === 1 &&
		
		$data['plugins'][0]==='theme'
	) {
			
			$data['plugins'][]='all';
	}

	foreach( $data['plugins'] as $key ){
	
		if( $key === 'theme' ){

			
			$result .= "    		\$t{$filter_type_variable_name} = true;\n";

		} else {

			$p_key = $key==='all' ? "'all'" : array_search($key, $all_plugins);
			
			if( $p_key === false ) continue;
			
			$debug_text =  get_debug_plugin_text(  $key, $data, $filter_type_variable_name );
	
	
			$result .= "    		\${$filter_type_variable_name}[{$p_key}] = null;{$debug_text}\n";
		}
		
	}

	return rtrim($result);
}

function get_debug_plugin_text( $key, $data, $filter_type_variable_name){

	if( empty( get_option('adv-plugin-filter-debug', '0') ) ) return '';

	return " \$debug['{$filter_type_variable_name}'][{$data['post_id']}][]='{$key}';";
	
}


/**
* @param object $active_apf_rules get_post()
* @return array -
* - condition =>  (string)condition markup for if statement
* - plugins => (array) allowed plugins list
* -
*/
//MARK: Get condition
function get_conditions($active_apf_rules){
	
	$constructor = new PHP_Condition();

	$rule = new APF_Rule();

	foreach($active_apf_rules as $post){

		$rule->set_rule($post);

		$result[]=[
			
			'condition'		=> $constructor->get_complete_conditions_markup($rule),

			'filter_mode'	=> $rule->filter_mode,
			
			'plugins'		=>$rule->plugins,

			'post_id'		=>$rule->id //passed for debugging purposes
		];
	}
	
	return $result??[];

}
	

