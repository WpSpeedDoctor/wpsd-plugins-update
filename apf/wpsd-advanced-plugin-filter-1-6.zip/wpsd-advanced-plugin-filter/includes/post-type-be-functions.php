<?php

namespace WPSD\apf;

defined( 'ABSPATH' ) || exit;

function get_admin_post_type(){
	
	if( !empty( $_GET['post_type'] ) && is_string($_GET['post_type']) ) {
		//$post_type_max_length is a placeholder and is dynamically created based on post types in DB
		//no need for sanitization
		return isset( $_GET['post_type'][$post_type_max_length] ) ? '' : $_GET['post_type'];
	}

	
	if( !isset( $_GET['post'] ) || !is_numeric($_GET['post']) ) {
		return '';
	}

	$post_id = intval( $_GET['post'] );
	
	if( wp_using_ext_object_cache() ) {
		
		$cached_data = wp_cache_get( $post_id, __NAMESPACE__.'apf-be' );
		
		if( $cached_data !== false ) return $cached_data;
	}

	global $wpdb;

	$result = $wpdb->get_var(

		$wpdb->prepare(
	
			"SELECT post_type FROM {$wpdb->posts} WHERE ID = %d", $post_id
		)
	);
	
	if( wp_using_ext_object_cache() ){
		wp_cache_set( $post_id, (string) __NAMESPACE__.'apf-be' );
	}

	return $result;
}