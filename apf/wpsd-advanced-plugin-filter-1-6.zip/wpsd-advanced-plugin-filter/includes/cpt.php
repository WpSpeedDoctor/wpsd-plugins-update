<?php

namespace WPSD\apf;

defined( 'ABSPATH' ) || exit;

function create_advanced_plugin_filter_cpt(){
	
	$labels = array(
		'name'               => esc_html_x( 'Advanced Plugin Filters', 'post type general name', 'advanced-plugin-filter' ),
		'singular_name'      => esc_html_x( 'Advanced Plugin Filter', 'post type singular name', 'advanced-plugin-filter' ),
		'menu_name'          => esc_html_x( 'Advanced Plugin Filters', 'admin menu', 'advanced-plugin-filter' ),
		'name_admin_bar'     => esc_html_x( 'Advanced Plugin Filter', 'add new on admin bar', 'advanced-plugin-filter' ),
		'add_new'            => esc_html_x( 'Add New', 'Plugin Filter', 'advanced-plugin-filter' ),
		'add_new_item'       => esc_html__( 'Add New Plugin Filter', 'advanced-plugin-filter' ),
		'new_item'           => esc_html__( 'New Plugin Filter', 'advanced-plugin-filter' ),
		'edit_item'          => esc_html__( 'Edit Plugin Filter', 'advanced-plugin-filter' ),
		'view_item'          => esc_html__( 'View Plugin Filter', 'advanced-plugin-filter' ),
		'all_items'          => esc_html__( 'All Plugin Filters', 'advanced-plugin-filter' ),
		'search_items'       => esc_html__( 'Search Plugin Filters', 'advanced-plugin-filter' ),
		'parent_item_colon'  => esc_html__( 'Parent Plugin Filters:', 'advanced-plugin-filter' ),
		'not_found'          => esc_html__( 'No Plugin Filter found.', 'advanced-plugin-filter' ),
		'not_found_in_trash' => esc_html__( 'No Plugin Filters in Trash.', 'advanced-plugin-filter' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => esc_html__( 'Description.', 'advanced-plugin-filter' ),
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => false,
		'rewrite'            => false,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => ['title'],
		'show_in_rest'       => false,
		'menu_icon'			 => 'dashicons-plugins-checked',
	);

	register_post_type( 'adv_plugin_filter', $args );
}

add_action( 'init', __NAMESPACE__.'\create_advanced_plugin_filter_cpt' );


function create_adv_plugin_filter_taxonomy(){
	$labels = array(
		'name'              => esc_html_x( 'Filter Groups', 'taxonomy general name', 'advanced-plugin-filter' ),
		'singular_name'     => esc_html_x( 'Filter Group', 'taxonomy singular name', 'advanced-plugin-filter' ),
		'search_items'      => esc_html__( 'Search Filter Groups', 'advanced-plugin-filter' ),
		'all_items'         => esc_html__( 'All Filter Groups', 'advanced-plugin-filter' ),
		'parent_item'       => esc_html__( 'Parent Filter Group', 'advanced-plugin-filter' ),
		'parent_item_colon' => esc_html__( 'Parent Filter Group:', 'advanced-plugin-filter' ),
		'edit_item'         => esc_html__( 'Edit Filter Group', 'advanced-plugin-filter' ),
		'update_item'       => esc_html__( 'Update Filter Group', 'advanced-plugin-filter' ),
		'add_new_item'      => esc_html__( 'Add New Filter Group', 'advanced-plugin-filter' ),
		'new_item_name'     => esc_html__( 'New Filter Group Name', 'advanced-plugin-filter' ),
		'menu_name'         => esc_html__( 'Filter Group', 'advanced-plugin-filter' ),
	);

	$capabilities = array(
		'manage_terms' => 'manage_categories',
		'edit_terms'   => 'manage_categories',
		'delete_terms' => 'manage_categories',
		'assign_terms' => 'edit_posts',
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => false,
		'rewrite'           => false,
		'capabilities'      => $capabilities,
	);

	register_taxonomy( 'apf_group', array( 'adv_plugin_filter' ), $args );
}

add_action( 'init', __NAMESPACE__ . '\create_advanced_plugin_filter_cpt' );
add_action( 'init', __NAMESPACE__ . '\create_adv_plugin_filter_taxonomy', 0 );