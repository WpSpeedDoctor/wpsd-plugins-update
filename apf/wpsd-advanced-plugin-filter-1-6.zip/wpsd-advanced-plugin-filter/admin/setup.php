<?php

namespace WPSD\apf;

defined( 'ABSPATH' ) || exit;

function plugin_setup_main($parent_filepath){

	plugin_setup_hooks($parent_filepath);

	links_in_wp_plugin_page($parent_filepath);
}

function plugin_setup_hooks($parent_filepath){

	register_deactivation_hook( $parent_filepath, __NAMESPACE__.'\plugin_deactivation_main' );
	
	register_activation_hook( $parent_filepath, __NAMESPACE__.'\plugin_activation_main' );
	
	register_uninstall_hook( $parent_filepath, __NAMESPACE__.'\plugin_uninstall_main' );
	
}


/**
 * Main setup functions
 */
function plugin_activation_main(){

	create_mu_plugin_wp_folder();

	//mu activation is moved to hook, cannot serve ajax before is activated in multisite setup
	// activate_mu_plugin();
	
	add_action('activated_plugin', __NAMESPACE__.'\activate_mu_from_plugin_admin', 10, 2);

	add_default_rules_to_db();

}

function add_default_rules_to_db(){
	
	if( is_settings_saved_once() || has_already_apf_post() ) return;

	global $wpdb;

	$post_content = '{"filter_mode":"allow","request_type":["admin"],"logic":"or","match_type_1":"post_key_exists","operator_1":"contain","value_1":"wpsd_apf_metabox_nonce","match_type_2":"admin_post_type","operator_2":"equal","value_2":"adv_plugin_filter","plugins":["wpsd-advanced-plugin-filter/advanced-plugin-filter.php"],"note":"","version":"'.WPSD_APF_VER.'"}';
	
	$safe_title = get_translated_title( $post_content );

	$safe_post_content = $wpdb->_real_escape( $post_content );

	$post_data = array(
		'post_type'    => 'adv_plugin_filter',
		'post_status'  => 'draft',
		'post_title'   => $safe_title,
		'post_content' => $safe_post_content
	);

	wp_insert_post($post_data);
}



function get_translated_title( $post_content ){

	global $wpdb;

	$post_data = json_decode( $post_content, true );

	if( !is_array( $post_data ) ) return false;

	$translated_title = sprintf(
		'%s: %s %s %s %s %s "%s"',
		__( "Allow only mode", 'advanced-plugin-filter' ),
		__( "POST", 'advanced-plugin-filter' ),
		__( "key", 'advanced-plugin-filter' ),
		__( "exists", 'advanced-plugin-filter' ),
		__( "OR", 'advanced-plugin-filter' ),
		__( "Admin post type", 'advanced-plugin-filter' ),
		__( "equals", 'advanced-plugin-filter' ),
		$post_data['value_2']
	);

	return $wpdb->_real_escape( $translated_title );
}

function is_settings_saved_once(){

	return get_option('adv-plugin-filter-enabled') !== false;
}

function has_already_apf_post(){

	global $wpdb;

	return !empty( $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_type = 'adv_plugin_filter'"));

}


function plugin_deactivation_main(){

	if( is_network_admin() ){

		remove_all_apf_mu_plugins();

	} else {

		remove_mu_plugin();
	}

}

/*
 * Activation functions beginning
 */

function activate_mu_plugin( $rewrite=false, $validate=true, $display_notice=true ){

	if( defined( 'WPSD_APF_CREATED') ) return false;

	remove_previous_version_mu_plugin();
	
	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if( $rewrite === false && file_exists( $mu_loader_filepath ) ) return true;

	$mu_loader_markup = get_mu_loader_markup();

	if( empty($mu_loader_markup) ) return false;

	if( !$validate || is_code_valid( $mu_loader_markup, $display_notice ) ){
		
		$mu_loader_markup_correct_namespace = str_replace( 'WPSD\\apf\\mu_plugin\\test',get_mu_plugin_namespace(), $mu_loader_markup );
		
		//not using $wp_filesystem for performance reasons
		$is_success = file_put_contents( $mu_loader_filepath, $mu_loader_markup_correct_namespace  ) !== false;
		
		if( is_callable('opcache_invalidate') ) {

			opcache_invalidate( $mu_loader_filepath, true);
		}

	} else {

		$is_success = change_post_status_to_pending();

	}

	define( 'WPSD_APF_CREATED', true );

	return $is_success;

}

function remove_previous_version_mu_plugin(){
	
	if( file_exists( WPMU_PLUGIN_DIR.'/advanced-plugin-filter-mu.php') ){

		//previous mu-plugin file.
		unlink(WPMU_PLUGIN_DIR.'/advanced-plugin-filter-mu.php');
	}

}

function get_mu_plugin_namespace(){

	$multisite_string = is_multisite() ? '_site'.get_current_blog_id() : '';

	return 'WPSD\\apf\\mu_plugin'.$multisite_string ;
}

function activate_mu_from_plugin_admin($plugin, $network_wide){
  
	if( $network_wide || $plugin !== 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php' ) return;

	activate_mu_plugin();
	
}

function refresh_mu_plugin($plugin=''){

	if( is_network_admin() ) return;

	$success  = activate_mu_plugin( $rewrite=true );

}

function refresh_mu_plugin_after_other_plugin_deactivate($plugin=''){

	switch(true){

		case $plugin === 'wpsd-advanced-plugin-filter/advanced-plugin-filter.php':
		case empty($plugin):
		case is_network_admin():
	
			return;
	}

	defined('WPSD_DEACTIVATED_PLUGIN') || define('WPSD_DEACTIVATED_PLUGIN', $plugin);
	
	$success  = activate_mu_plugin( $rewrite=true );
	
}

function change_post_status_to_pending(){

	if( !is_filter_saving_process() || defined('APF_UNPUBLISHED') ) return false;
	
	global $wpdb;

	$post_id = intval($_POST['post_ID']);

	$wpdb->query( $wpdb->prepare("UPDATE {$wpdb->posts} SET post_status = %s WHERE ID = %d", 'pending', $post_id) );

	define('APF_UNPUBLISHED', true);

	return false;
}

function is_filter_saving_process(){

    switch( true ){

        case ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST':
        case ($_POST['post_type'] ?? '') !== 'adv_plugin_filter':
        case ($_POST['post_status'] ?? '') !== 'publish':
        case !is_numeric($_POST['post_ID']??false):
            return false;

        default:
            return true;
    }
}

function is_code_valid( $mu_loader_markup , $display_notice=true ){

	$is_created = create_validation_php_file( $mu_loader_markup );
	
	if( $is_created === false ){
	
		error_log('APF validation file could not be created '.WP_START_TIMESTAMP );

		$notice_data = [
			'text' => __('Validation file could not be created, active filters are not changed', 'advanced-plugin-filter'),
			'type' => 'error'
		];

		set_transient('wpsd-apf-notice', $notice_data, 15 );

		return false;
	}

	$post_data=[

		'timeout'   =>'10',

		'body'  =>[
			
				'action'	=> 'afp-code-validation',

				'nonce'		=> get_nonce_hash()
	 
			]
		];
	 
	$ajax_url = admin_url('/admin-ajax.php').'?adv_plugin_filter';

	$response = wp_remote_post( $ajax_url , $post_data);

	$is_success = get_validation_result( $response, $display_notice );
	
    return $is_success; 
}

function get_validation_result( $response, $display_notice ){

	$body = wp_remote_retrieve_body($response);

	$response_code = wp_remote_retrieve_response_code($response);

	switch(true){

		case $response_code !== 200:
			
            $notice_data = [
                'text' => sprintf(
					__('Ajax call to validate MU plugin failed, response code is %s not 200.', 'advanced-plugin-filter'),
					$response_code
				),
                'type' => 'error'
            ];
            
            break;

		case $body === '':

			$notice_data = [
				'text' => __('Received unclear response when creating MU plugin, filters might not work.', 'advanced-plugin-filter'),
				'type' => 'warning'
			];
			
			break;

		case $body === 'OK':

			$notice_data = [
				'text' => __('MU plugin created successfully, all published filters are in use.', 'advanced-plugin-filter'),
				'type' => 'success'
			];
			
			break;

		case is_wp_error($response):

			$notice_data = [
				'text' => __('MU plugin validation request failed, data from this filter are not in use. Send feedback to the developer please.', 'advanced-plugin-filter'),
				'type' => 'error'
			];

			break;
		default:
			
		$notice_data = [
				'text' => __('Code validation failed, current filter is not in use and status been changed to "Pending review". Send feedback to the developer please.', 'advanced-plugin-filter'),
				'type' => 'error'
			];

		    break;
	}

	if($display_notice){

		set_transient('wpsd-apf-notice', $notice_data, 15 );
		
	}
	
	if(  $notice_data['type'] === 'error' ){

		error_log( "APF: {$notice_data['text']}");

		error_log( var_export($response,true) );
	}

	return $notice_data['type'] === 'success';

}

function get_hash(){

	static $result = false;

	if( $result !== false ) return $result;

	return $result = hash('sha3-512', $_SERVER['SERVER_ADDR']);
}

function get_debug_hash(){

	return substr(get_hash(), 0, 32);
}

function get_nonce_hash(){

	return substr(get_hash(), 64, 64);
}

function try_validation_file(){

	if( ($_POST['nonce']??'') !== get_nonce_hash() ){

		http_response_code( 401 );

		die('Not authorized');
	} 
	
	set_error_log();

	$filepath = WPSD_APF_DIR . 'code-validation/test.php';

	if( file_exists( $filepath ) ){

		@include $filepath;
		//not using $wp_filesystem for performance reasons
		unlink($filepath);

		$message = 'OK';
	
	} else {

		$message = 'No validation file';

	}

	die($message);
}

function remove_crushed_mu_plugin(){

	$error = error_get_last();

	$mu_filename = basename(get_mu_plugin_loader_filepath());

	if( !str_contains($error['file']??'', $mu_filename) ) return;

	remove_mu_plugin();

}

function set_error_log(){

	register_shutdown_function( __NAMESPACE__ . '\rename_validation_file');

	$ip_hash = get_debug_hash();

	error_reporting(E_ALL);

	ini_set('log_errors', true ); 

	ini_set('error_log', WPSD_APF_DIR."code-validation/debug-{$ip_hash}.log");

}


function rename_validation_file(){

	$filepath = WPSD_APF_DIR . '/code-validation/test.php';
	
	//not using $wp_filesystem for performance reasons
	if( file_exists( $filepath ) ) rename( $filepath, WPSD_APF_DIR . '/code-validation/not-valid-mu-'.uniqid().'.php' );
	
}


function create_validation_php_file( $mu_loader_markup ){

	$mu_loader_markup_unique_constants = str_replace( 'APF_','APFTEST_', $mu_loader_markup );
	
	//not using $wp_filesystem for performance reasons
	return false !== file_put_contents( WPSD_APF_DIR . '/code-validation/test.php', $mu_loader_markup_unique_constants );

}

function get_mu_loader_markup(){

	require_once WPSD_APF_DIR.'includes/construct-mu-plugin.php';
	
	$conditions_markup = get_mu_conditions_markup();

	if( empty($conditions_markup) ){

		remove_mu_plugin();

		return '';
	}

	return get_mu_plugin_markup( $conditions_markup );
}

function get_active_plugins_from_db(){
	
	static $active_plugins = false;

	if( $active_plugins !== false ) return $active_plugins;
	
	global $wpdb;
	
	//get_options won't get current state of DB as plugins my be filtered here, has to be accessed directly
	$active_plugins_serialized = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'");
	
	$active_plugins = maybe_unserialize($active_plugins_serialized);

	if( defined('WPSD_DEACTIVATED_PLUGIN') ){

		$plugin_slug_location = array_search( WPSD_DEACTIVATED_PLUGIN, $active_plugins);

		if( $plugin_slug_location !== false && isset( $active_plugins[ $plugin_slug_location ] ) ){

			unset( $active_plugins[ $plugin_slug_location ] );
		}
	}

	if( is_multisite() ) {
		
		add_multisite_plugins( $active_plugins );

	}
	
	sort($active_plugins);

	return $active_plugins;
		
}

function add_multisite_plugins( &$active_plugins ){
	
	global $wpdb;

	$query = "SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key = 'active_sitewide_plugins';";

	$active_network_plugins_serialized = $wpdb->get_var( $query );
	
	$active_network_plugins = maybe_unserialize($active_network_plugins_serialized);

	if( defined('WPSD_DEACTIVATED_PLUGIN') && isset( $active_plugins[ WPSD_DEACTIVATED_PLUGIN ]) ){

		unset( $active_plugins[ WPSD_DEACTIVATED_PLUGIN ] );
	}

	if( !is_array( $active_network_plugins ) ){
	
		return $active_plugins;
	}

	$active_plugins = array_values( array_unique( array_merge( $active_plugins, array_keys($active_network_plugins) ) ) );

}


function create_mu_plugin_wp_folder(){
	
	if( file_exists( WPMU_PLUGIN_DIR ) ) return;

	//not using $wp_filesystem for performance reasons
	mkdir( WPMU_PLUGIN_DIR, 0755 );

}

/**
 * The filename for must-use plugin loader is based on namespace, that way should stay unique
 * when used by more plugins in the same WP installation
 */

function get_mu_plugin_loader_filepath(){

	return is_multisite() ?  WPMU_PLUGIN_DIR.'/adv-plugin-filter-id'.get_current_blog_id().'.php' : WPMU_PLUGIN_DIR."/adv-plugin-filter.php" ;
}

/*
 * Activation functions end
 */


/**
 * Deactivation functions beginning
 */

 function remove_mu_plugin(){

	$mu_loader_filepath = get_mu_plugin_loader_filepath();

	if( file_exists( $mu_loader_filepath ) ) unlink( $mu_loader_filepath );

}

function remove_all_apf_mu_plugins(){

	$files = glob( ABSPATH.MUPLUGINDIR.'/adv-plugin-filter*.php');
	
	foreach( $files as $file ){
		
		unlink( $file );
    }
}

/**
 * Links in WP plugins page
 */

function links_in_wp_plugin_page($parent_filepath){

	add_filter( 'plugin_action_links_'.basename(WPSD_APF_DIR).'/'.basename($parent_filepath), __NAMESPACE__.'\add_action_links_plugin_page' );
}

function add_action_links_plugin_page ( $actions ){

	$page_link = admin_url( 'edit.php?post_type=adv_plugin_filter&page=settings' );

	$text = __( "Settings", 'advanced-plugin-filter' );

	$menu_link =
		<<<HTML
		<a href="{$page_link}">{$text}</a>
		HTML;

	return array_merge( $actions,[$menu_link] );

}


