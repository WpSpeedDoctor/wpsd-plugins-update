<?php

namespace WPSD\cf_helper;

/**
 * Remove settings
 */

require_once __DIR__.'/class-consts.php';

require_once Consts::LOADER_FILEPATH;

Settings::uninstall_settings();

unlink( Early_Return::get_cached_404_filepath() );

Htaccess::remove_insert();