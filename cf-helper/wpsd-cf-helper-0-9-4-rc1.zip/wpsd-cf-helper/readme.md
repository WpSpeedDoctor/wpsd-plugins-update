Overall goals of this plugin is to:
reinforce security
save server's CPU resources
rise alarm when security breach is detected

How is achived each point?
Increased security:
Blocking requests bypassing Cloudflare edge layer
Detecting false authentication attempts
Detecting IP change from differenet locations that can mean stolen login cookies

Server resources:
Early rising 403/404 for missing files in .htaccess
Early rising 403/404 for missing and pages right after query hook when 404 can be determined.

Alarm system:
Logging and enabling REST API point to rise alarm via uptime bot for specific logged event.


This plugin reinforces on WP level security suplementing Cloudflare firewall
helping prevent unwanted requests, security breach and brings alarm system for early detection.
Main weakness that CF cannot solve by its own:
Bypassing of Cloudflare edge layer by detecting server IP and not using public DNS
Probing login cookies to bypass Cloudflare edge layer or old login cookies tokens
Logging out users from Cloudflare edge layer by IP address change
Detecting request of non existing file or WP page and handling it before it becomes expensive full WordPress request.
Logging and enabling REST API point to rise alarm via uptime bot for specific logged event.
