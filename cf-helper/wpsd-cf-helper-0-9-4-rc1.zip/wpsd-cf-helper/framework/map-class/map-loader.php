<?php

namespace WPSD\cf_helper;

defined( 'ABSPATH' ) || exit;

spl_autoload_register( __NAMESPACE__.'\\autoload_class' );

function autoload_class($classname){
	
	$classname = str_replace('/', '\\', $classname);

	if( class_exists($classname)  ){
		return;
	}

	static $map;

	if(!$map){

		$map = require Consts::MAP_CLASSES;
		
	}
	
	if( !isset( $map[$classname] ) ){
		return;
	}

	require_once Consts::DIR.$map[$classname];

}
