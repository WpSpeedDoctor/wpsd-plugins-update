<?php

namespace WPSD\cf_helper;

defined( 'ABSPATH' ) || exit;

function update_class_map(){

	$iterator = new \RecursiveIteratorIterator(
		new \RecursiveDirectoryIterator(Consts::DIR, \FilesystemIterator::SKIP_DOTS)
	);

	$class_map = [];

	foreach($iterator as $file){

		if( !$file->isFile() ){
			continue;
		}

		$filename  = $file->getFilename();
		
		if( str_starts_with($filename, 'class-') || str_starts_with($filename, 'interface-')){

			$content = file_get_contents($file->getPathname());

			$namespace = '';

			if(preg_match('~^namespace\s+([^;]+);~m', $content, $m)){
				$namespace = trim($m[1]);
			}

			if(preg_match('~^(?:abstract\s+|final\s+)?(?:class|interface)\s+([a-zA-Z0-9_]+)~m', $content, $m)){
				$class = $m[1];
				$key = ltrim($namespace.'\\'.$class,'\\');

				$relative = str_replace(Consts::DIR, '', $file->getPathname());

				$class_map[$key] = str_replace('\\','/',$relative);
			}
		}
	}

	$export = var_export($class_map, true);

	$data = <<<PHP
<?php

return {$export};

PHP;

	file_put_contents( Consts::MAP_CLASSES , $data);
}
