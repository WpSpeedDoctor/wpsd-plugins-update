<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Trace_Controller{

	public const TIMESCALE = 5 * MINUTE_IN_SECONDS;

	public const TRACE_PATH = WP_CONTENT_DIR.Log::DB_BUFFER_PATH;

	public const STATUS_OK = 'ok';

	public const STATUS_BREACH = 'breach';

	/**
	 * REST API output for monitoring.
	 */
	public static function get_breach_status( $timescale=self::TIMESCALE ){
	
		$traces_filenames = self::get_traces_filenames();

		foreach($traces_filenames as $filename){
			
			if( !self::is_monitored_trace($filename) ){
				continue;
			}

			$events = file(self::TRACE_PATH.$filename);

			$last_event = json_decode( end($events), true );
			
			if( intval($last_event[Log::KEY_TIMESTAMP]) + $timescale > time()){

				return self::STATUS_BREACH;
			}
			
		}

		return self::STATUS_OK;
	}

	public static function is_monitored_trace($filename){

		static $trace_monitoring_settings;

		if(is_null($trace_monitoring_settings)){

			$trace_monitoring_settings = S::get()[S::SECTION_LOGGING][S::KEY_MONITORING_TRACES];

		}

		$trace_slug = self::get_trace_name_from_filename($filename);

		$trace_key = Settings_Mapper::get_trace_key($trace_slug);

		if($trace_key === false)return false;

		return ($trace_monitoring_settings[$trace_key] ?? '') === '1';

	}

	public static function get_trace_name_from_filename($filename){
	
		static $prefix_length, $ip_length;

		if(is_null($prefix_length)){
			
			$prefix_length = strlen(Log::TRACE_PREFIX);
			
			$ip_length = 0-strlen(Log::get_server_last_ip_number());
		}

		return substr( $filename, $prefix_length, $ip_length );
		
	}

	/**
	 * function return breach events happened from $from to $to both unix timestamps time() equivalent
	 */
	public static function get_breach_events($from,$to,$limit=10){

		$result = [];

		$traces_filenames = self::get_traces_filenames();

		foreach($traces_filenames as $filename){

			$filepath = self::TRACE_PATH.$filename;

			if(!file_exists($filepath)) continue;

			$trace_events = self::get_breach_events_from_file($filepath,$from,$to,$limit);

			if(!$trace_events){

				continue;

			}

			$result[self::get_trace_name_from_filename($filename)] = $trace_events;

		}

		return $result;

	}

	private static function get_breach_events_from_file($filepath,$from,$to,$limit=10){

		if(!$filepath) return false;

		$lines = file($filepath,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);

		if(!$lines) return false;

		$trace_events = [];

		foreach($lines as $line){

			$event = self::get_breach_event_from_line($line,$from,$to);

			if(!$event){

				continue;

			}

			$trace_events[] = $event;

		}

		if(!$trace_events) return false;

		usort($trace_events,[__CLASS__,'sort_breach_events_newest_first']);

		return array_slice($trace_events,0,$limit);

	}

	private static function get_breach_event_from_line($line,$from,$to){

		if(!$line) return false;

		$event = json_decode($line,true);

		if(json_last_error()!==JSON_ERROR_NONE) return false;

		if(!isset($event[Log::KEY_TIMESTAMP])) return false;

		$timestamp = intval($event[Log::KEY_TIMESTAMP]);

		if($timestamp < $from || $timestamp > $to) return false;

		return $event;

	}

	private static function sort_breach_events_newest_first($event_a,$event_b){

		$timestamp_a = intval($event_a[Log::KEY_TIMESTAMP]??0);

		$timestamp_b = intval($event_b[Log::KEY_TIMESTAMP]??0);

		return $timestamp_b <=> $timestamp_a;

	}

	public static function get_traces_filenames(){
		
		if(!is_dir(self::TRACE_PATH)){
			return [];
		}
	
		$server_ip = Log::get_server_last_ip_number();

		$traces_filenames = [];

		foreach(scandir(self::TRACE_PATH) as $filename){
			if(	str_starts_with($filename, log::TRACE_PREFIX) && str_ends_with($filename, $server_ip) ){
				$traces_filenames[] = $filename;
			}
		}		
	
		return $traces_filenames;
	}

	public static function clean_traces_cron(){
	
		$traces_filenames = self::get_traces_filenames();
		
		foreach($traces_filenames as $filename){
			
			self::clean_trace_log(self::TRACE_PATH.$filename);
		}
	
	}

	public static function clean_trace_log($filepath){

		$days_to_keep = S::get()[S::SECTION_LOGGING][S::KEY_DAYS_TO_KEEP];

		$seconds_to_keep = $days_to_keep * DAY_IN_SECONDS;

		if(!file_exists($filepath)){

			return;

		}

		$handle = fopen($filepath, 'r+');

		if(!$handle){

			trigger_error('Failed to open trace log file: ' .basename($filepath), E_USER_NOTICE );
			return;

		}

		if(!flock($handle, LOCK_EX)){

			fclose($handle);

			trigger_error('Failed to lock trace log file: ' .basename($filepath), E_USER_NOTICE );
			return;

		}

		$tempfile = $filepath . '.tmp';

		$temp_handle = fopen($tempfile, 'w');

		if(!$temp_handle){

			flock($handle, LOCK_UN);

			fclose($handle);

			trigger_error('Failed to open temp trace log file: ' .basename($tempfile), E_USER_NOTICE );
			return;

		}

		while(($line = fgets($handle)) !== false){

			$trimmed = trim($line);

			if($trimmed === ''){

				fwrite($temp_handle, $line);

				continue;

			}

			$json = json_decode($trimmed, true);

			if(json_last_error() !== JSON_ERROR_NONE || !isset($json[Log::KEY_TIMESTAMP])){

				fwrite($temp_handle, $line);

				continue;

			}

			if( intval($json[Log::KEY_TIMESTAMP]) < time() - $seconds_to_keep){

				continue;

			}

			fwrite($temp_handle, $line);

		}

		fclose($temp_handle);

		flock($handle, LOCK_UN);

		fclose($handle);

		unlink($filepath);

		rename($tempfile, $filepath);

	}

}