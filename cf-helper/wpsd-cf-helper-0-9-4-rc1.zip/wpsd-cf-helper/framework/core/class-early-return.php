<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Early_Return{

	public static function direct_request(){

		$script_path = substr( $_SERVER['SCRIPT_FILENAME']??'',defined('ABSPATH') ? strlen(ABSPATH)-1 : 0);
		
		if( $script_path !== '/index.php' ){
			return;
		}

		self::no_file();
	}

	/**
	 * @param int $selected_option Handle early 403 or 404 page based on settings.
	 */
	
	public static function early_403_404_final($selected_option){
	
		switch($selected_option){

			case S::KEY_OPTION_403:
				self::set_header_and_die(403);
				break;

			case S::KEY_OPTION_SIMPLE_404:
				self::set_header_and_die(404);
				break;

			case S::KEY_OPTION_CACHED:
				self::display_cached();
				break;
		}
	}

	public static function no_file(){

		$settings = S::get();
		
		if($settings[S::SECTION_EARLY_403_404][S::KEY_LOG] === '1'){
			Log::store(Log::TRACE_NO_FILE);
		}
		
		self::early_403_404_final($settings[S::SECTION_EARLY_403_404][S::KEY_SELECT_NO_FILE]);
	
	}

	public static function no_page(){
		
		require_plugin_files();

		if(http_response_code() !== 404) return;
		
		$settings = S::get();

		if($settings[S::SECTION_EARLY_403_404][S::KEY_LOG] === '1'){
			Log::store(Log::TRACE_NO_PAGE);
		}
		
		self::early_403_404_final($settings[S::SECTION_EARLY_403_404][S::KEY_SELECT_NO_PAGE]);
	}

	public static function display_cached(){
			
		$cached_404_filepath = self::get_cached_404_filepath();
		
		if( !file_exists($cached_404_filepath) ){
			return;
		}
			
		http_response_code(404);

		echo file_get_contents($cached_404_filepath);

		die;
	}

	public static function create_cached_404(){
		
		$cached_404_filepath = self::get_cached_404_filepath();

		$response = wp_remote_get( self::get_404_url() );

		if ( is_wp_error( $response ) ) {
			trigger_error( 'Failed to download cached 404 page: ' . $response->get_error_message(), E_USER_NOTICE );
			return;
		
		}

		$content_404 = wp_remote_retrieve_body( $response ).'<!-- cached 404 page -->';

		file_put_contents($cached_404_filepath,$content_404);
		
	}

	public static function get_cached_404_filepath(){
	
		$dir = wp_upload_dir()['basedir'];
		
		return $dir.'/.ht-cf-helper-cached-404.html';
	}

	public static function get_404_url(){
	
		return home_url( apply_filters('cf-helper-404','404'));
		
	}

	public static function set_header_and_die(int $http_response_code){
	
		switch($http_response_code){
			case 403:
				http_response_code(403);
				break;
				
			default:
				http_response_code(404);
				break;
		}

		die;

	}

	/**
	 * @param string $false_login_key Auth cookie key that is not valid
	 */
	public static function false_auth($false_login_key){
	
		$settings = S::get();

		if($settings[S::SECTION_FALSE_AUTH][S::KEY_LOG]){
			
			$custom_meta = substr($false_login_key,0,100);

			Log::store(Log::TRACE_FALSE_AUTH,$custom_meta);
		}
		
		
		if($settings[S::SECTION_FALSE_AUTH][S::KEY_BLOCK_ATTEMPT]){
			
			self::set_header_and_die(403);
		}
		
	}

	//MARK:Verify Auth
	public static function log_bad_auth(){
		
		add_action( 'auth_cookie_malformed', __NAMESPACE__.'\Early_Return::log_malformed_cookie',10,2 );

		add_action( 'auth_cookie_bad_username', __NAMESPACE__.'\Early_Return::log_bad_username' );

		add_action( 'auth_cookie_bad_hash', __NAMESPACE__.'\Early_Return::log_bad_hash' );

		add_action( 'auth_cookie_bad_session_token', __NAMESPACE__.'\Early_Return::log_bad_session_token' );

	}

	/**
	 * Log malformed auth cookie
	 */
	public static function log_malformed_cookie($cookie, $scheme){

		// when $cookie === false && $scheme === '' it's auth user on 404 request, false positive
		if( $cookie === false && $scheme === '' ){
				return;
		}

		static $done;

		if($done) return;
		
		$done = true;

		Log::store(Log::TRACE_MALFORMED_COOKIE);

	}

	/**
	 * Log bad username in auth cookie
	 */
	public static function log_bad_username(){

		static $done;

		if($done) return;
			
		$done = true;

		Log::store(Log::TRACE_BAD_USERNAME);

	}

	/**
	 * Log bad hash in auth cookie
	 */
	public static function log_bad_hash(){
		
		static $done;

		if($done) return;
			
		$done = true;

		Log::store(Log::TRACE_BAD_HASH);
	}

	/**
	 * Log bad session token in auth cookie
	 */
	public static function log_bad_session_token(){
		
		static $done;

		if($done || defined( Auth_Control::CONSTANT_LOGGED_OUT ) ) return;

		$done = true;
		
		Log::store(Log::TRACE_BAD_SESSION_TOKEN);
	}
	
}