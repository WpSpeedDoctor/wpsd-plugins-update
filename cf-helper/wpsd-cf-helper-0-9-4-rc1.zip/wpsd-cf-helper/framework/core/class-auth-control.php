<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Auth_Control{

	public const USER_IP = 'ip';
	
	public const USER_ASN = 'asn';

	public const USER_COUNTRY = 'country';
	
	// public const USER_UA = 'ua'; //postponed

	public const SERVER_KEY_IP = 'REMOTE_ADDR';
	
	public const SERVER_KEY_ASN = 'HTTP_'.Consts::CF_HEADER_ASN;

	public const SERVER_KEY_COUNTRY = 'HTTP_CF_IPCOUNTRY';

	public const SERVER_KEY_UA = 'HTTP_USER_AGENT';

	public const CONSTANT_LOGGED_OUT = 'CFH_LOGGED_OUT';


	public static function logout_user_from_forbidden_location(){

		global $current_user;

		if( empty($current_user->ID) || self::is_current_ip_whitelisted() ){
			return;
		}

		$settings = S::get()[S::SECTION_IP_CHANGE];

		$stored_user_data = self::get_stored_user_data();
		
		$remote_user_data = self::get_user_remote_data();
		
		switch(true){
			case $remote_user_data[self::USER_IP] === $stored_user_data[self::USER_IP]:
			case $settings[S::KEY_ALLOW_IP_CHANGE_ASN] && $stored_user_data[self::USER_ASN] === $remote_user_data[self::USER_ASN]:
			case $settings[S::KEY_ALLOW_IP_CHANGE_COUNTRY] && $stored_user_data[self::USER_COUNTRY] === $remote_user_data[self::USER_COUNTRY]:
				return;

			default:
				$trace = Log::TRACE_IP_CHANGED;
				break;
		}

		define( self::CONSTANT_LOGGED_OUT, true );

		add_action('init', 'wp_logout');

		if(!$settings[S::KEY_LOG]) {
			return;
		}
		
		Log::store($trace,"Stored:{$stored_user_data[self::USER_IP]}");
	}

	public static function is_current_ip_whitelisted(){
	
		$allowed_ips = S::get()[S::SECTION_CF_HEADER][S::KEY_ALLOWED_IPS]??[];
	
		return in_array($_SERVER[self::SERVER_KEY_IP], $allowed_ips);
	}


	public static function get_stored_user_data(){
	
		global $current_user;

		$token = wp_get_session_token();

		if(!$token) return false;

		$session_manager = \WP_Session_Tokens::get_instance($current_user->ID);

		$session = $session_manager->get($token);

		return [

			self::USER_IP		=> $session[self::USER_IP],
			self::USER_ASN		=> $session[self::USER_ASN]??0,
			self::USER_COUNTRY	=> $session[self::USER_COUNTRY]??'',
			// self::USER_UA		=> $session[self::USER_UA],

		];
	}


	/**
	 * Adds remote user data to session tokens usermeta data
	 */
	public static function set_login_data($user){

		if(empty($user->ID)){
			return;
		}

		$sessions = get_user_meta( $user->ID, 'session_tokens', true );

		$current_key = self::get_current_session_key($sessions);

		$user_remote_data = self::get_user_remote_data();
		
		$sessions[$current_key][self::USER_ASN] = $user_remote_data[self::USER_ASN];

		$sessions[$current_key][self::USER_COUNTRY] = $user_remote_data[self::USER_COUNTRY];

		update_user_meta( $user->ID, 'session_tokens', $sessions );
		
	}

	static function get_current_session_key($sessions){
	
		$key = '';
		
		$time = 0;

		foreach( array_reverse($sessions) as $key => $session){
			if($session['login'] === time()){
				return $key;
			}

			if($session['login'] > $time){
				$key = $key;
				$time = $session['login'];
			}

		}
		
		return $key;
		
	}
	
	/**
	 * @return array -
	 * - self::USER_IP
	 * - self::USER_ASN
	 * - self::USER_COUNTRY
	 * - self::USER_UA
	 */
	public static function get_user_remote_data(){

		return [
			self::USER_IP			=> $_SERVER[self::SERVER_KEY_IP]??'',
			self::USER_ASN			=> $_SERVER[self::SERVER_KEY_ASN]??'',
			self::USER_COUNTRY		=> $_SERVER[self::SERVER_KEY_COUNTRY]??'',
			// self::USER_UA			=> $_SERVER[self::SERVER_KEY_UA]??'',
		];
	}
	
}
