<?php

namespace WPSD\cf_helper;

use WPSD\shared\Admin_Menu as Shared_Admin_Menu;

defined( 'ABSPATH' ) || exit;

require_plugin_files();

/**
 * Plugin menu added on plugin page
 */
global $pagenow;

if( $pagenow === 'plugins.php' ){

	add_filter( 
		'plugin_action_links_'.basename(dirname($plugin_filepath)).DIRECTORY_SEPARATOR.basename($plugin_filepath),
		[Plugin_Setup::class, 'add_action_links_plugin_page']
	);

}

add_action('init', __NAMESPACE__.'\wpsd_shared_menu');

function wpsd_shared_menu(){

	Shared_Admin_Menu::set_title(__( 'WPSD Plugins', 'wpsd-cf-helper' ));

	Shared_Admin_Menu::set_data(__( 'WPSD Plugins', 'wpsd-cf-helper' ), '2026-06-30');

	add_action('admin_menu', [Shared_Admin_Menu::class, 'add_shared_wpsd_menu']);

	add_filter(Shared_Admin_Menu::FILTER_SUBMENUS, __NAMESPACE__.'\add_wpsd_submenu');

	add_filter(Shared_Admin_Menu::FILTER_CONTENT, __NAMESPACE__.'\wpsd_main_page_content');
}

function wpsd_main_page_content($release_date){

	if($release_date !== '2026-06-30'){

		return $release_date;
	}

	return file_get_contents(Consts::DIR.'shared/wpsd-main-content.html');
}

function add_wpsd_submenu($submenus){

	$submenus[] = [
		__( "Cloudflare helper", 'wpsd-cf-helper' ),
		Consts::ADMIN_SUBPAGE,
		__NAMESPACE__.'\admin_menu_init',
	];

	return $submenus;
}

function admin_menu_init(){

	Admin_Menu::render();
}

if(isset($_POST[Consts::NONCE])){

	add_action('admin_init', [__NAMESPACE__ . '\Settings_Save_Controller', 'save_post']);
}
