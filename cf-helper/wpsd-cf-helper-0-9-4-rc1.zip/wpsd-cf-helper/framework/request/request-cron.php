<?php

namespace WPSD\cf_helper;

function register_cfh_log_cleaner_cron(){

	if(wp_next_scheduled('cfh_log_cleaner')) return false;

	wp_schedule_event(time(), 'daily', 'cfh_log_cleaner');

}

add_action('init', __NAMESPACE__ . '\\register_cfh_log_cleaner_cron');



function cfh_log_cleaner_handler(){

	Trace_Controller::clean_traces_cron();

}

add_action('cfh_log_cleaner', __NAMESPACE__ . '\\cfh_log_cleaner_handler');