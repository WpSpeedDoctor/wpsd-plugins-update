<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

defined( 'ABSPATH' ) || exit;

function register_monitor_endpoint(){

	register_rest_route(
		'cf-helper/v1',
		'/monitor/(?P<token>[^/]+)',
		array(
			'methods'             => 'GET',
			'callback'            => __NAMESPACE__ . '\\monitor_handler',
			'permission_callback' => '__return_true',
		)
	);

}

add_action( 'rest_api_init', __NAMESPACE__ . '\\register_monitor_endpoint' );

function monitor_handler(object $request ){

	require_plugin_files();
	
	$secret_token = S::get()[S::SECTION_LOGGING][S::KEY_SECRET_TOKEN] ?? 'secret-token';

	$token = $request->get_param( 'token' );

	if( $token !== $secret_token ){

		return new \WP_Error( 'invalid_token', 'Invalid token', array( 'status' => 403 ) );

	}

	return Trace_Controller::get_breach_status();

}