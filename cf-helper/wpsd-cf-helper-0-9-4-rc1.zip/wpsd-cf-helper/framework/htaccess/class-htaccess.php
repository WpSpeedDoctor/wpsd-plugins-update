<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Htaccess {

	private string $insert_start = '###WPSD-CF-HELPER-START';
	
	private string $insert_end = '###WPSD-CF-HELPER-END';
	
	public const FILEPATH = ABSPATH . '.htaccess';

	/**
	 * `s` is abbrevation of Settings
	 */
	private array $s;

	public string $insert_content='';

	public string $ht_content;

	private string $cf_header_markup='';

	private string $early_403_404_markup='';

	public function __construct(){

		$this->s = S::get();
	
		$this->ht_content = $this->get_ht_content();
	}

	public static function place_insert(){
	
		$htaccess = new Htaccess();
		
		$htaccess->built_insert_markup();
		
		$htaccess->store_insert();
		
	}

	public static function remove_insert(){
	
		$htaccess = new Htaccess();
		
		$htaccess->store_insert();
		
	}
	
	//MARK: Build insert
	public function built_insert_markup(){

		$this->insert_content = '';

		if($this->s[S::SECTION_CF_HEADER][S::KEY_ENABLED] === '1'){
			$this->add_cf_header();
		}

		
		$this->set_early_403_404();
		

		if(empty($this->cf_header_markup) && empty($this->early_403_404_markup)){
			return;
		}

		$cf_header_name=Consts::CF_HEADER_NAME;
		 
		$this->insert_content = <<<HTML
		<IfModule mod_rewrite.c>
		RewriteEngine On

		{$this->cf_header_markup}

		{$this->early_403_404_markup}
		
		</IfModule>
		RequestHeader unset $cf_header_name
		HTML;
		
		//remove double new line
		$this->insert_content = str_replace(["\n\n\n\n","\n\n\n"], "\n\n", $this->insert_content);
	}

	private function has_path_and_ext_header_from_cf(){

		return	str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_URI_PATH ) &&
				str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_FILE_EXT );
	}

	//MARK:Early 403
	/**
	 * in order this to work, CF has to add header of X-File-Ext and X-Uri-Path
	 */
	private function set_early_403_404(){
	
		$s = $this->s[S::SECTION_EARLY_403_404];
		
		if($s[S::KEY_ENABLED] !== '1' || $s[S::KEY_SELECT_NO_FILE] === S::KEY_OPTION_DEFAULT){
			return;
		}
		
		$this->early_403_404_markup = '';

		$this->add_missing_cf_headers_markup();
		
		$file_ext_header = Consts::CF_HEADER_FILE_EXT;
		$uri_path_header = Consts::CF_HEADER_URI_PATH;

		$this->early_403_404_markup .= <<<HTML


		#File doesn't exist
		RewriteCond %{ENV:HTTP_{$file_ext_header}} -z
		RewriteCond %{REQUEST_FILENAME} !-f
		RewriteCond %{ENV:HTTP_{$file_ext_header}} !=xml [NC,OR]
		RewriteCond %{ENV:HTTP_{$uri_path_header}} !sitemap [NC]
		HTML;

		$response_code = $this->s[S::SECTION_EARLY_403_404][S::KEY_SELECT_NO_FILE] === S::KEY_OPTION_403 ? '403' : '404';

		if($this->s[S::SECTION_EARLY_403_404][S::KEY_LOG] === '1'){
			
			$args=[
				Log::HTACCESS_KEY_RESPONSE_CODE => $response_code,
				Log::HTACCESS_KEY_TRACE => Log::TRACE_NO_FILE
			];

			$this->early_403_404_markup .= $this->get_logger_rule_line($args);

		} else {

			$this->early_403_404_markup .= "\nRewriteRule ^ - [R={$response_code},L]";
		}
	}

	private function add_missing_cf_headers_markup(){
	
	if(isset($_SERVER['HTTP_CF_RAY'])){//site goes through cloudflare
		return;
	}

	$file_ext_header = Consts::CF_HEADER_FILE_EXT;
	$uri_path_header = Consts::CF_HEADER_URI_PATH;

	// return	str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_URI_PATH ) &&
	// 			str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_FILE_EXT );

	if( !str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_URI_PATH )){

		$this->early_403_404_markup .= <<<HTML
			# Set HTTP_URI_PATH from original request path (before query/space)
			RewriteCond %{THE_REQUEST} ^[A-Z]{3,9}\s+([^?\s]+) [NC]
			RewriteRule ^ - [E=HTTP_{$uri_path_header}:%1]
			

			HTML;
	}

	if(!str_contains($this->ht_content, 'Set HTTP_'.Consts::CF_HEADER_FILE_EXT )){

		$this->early_403_404_markup .= <<<HTML
			# Set HTTP_FILE_EXT ONLY if original path ends with .ext (ignores query!)
			RewriteCond %{THE_REQUEST} ^[A-Z]{3,9}\s+([^?\s]+) [NC]
			RewriteCond %1 \.([a-zA-Z0-9]+)$ [NC]
			RewriteRule ^ - [E=HTTP_{$file_ext_header}:%1]
			HTML;
			
		}
	}

	public function store_insert(){
	
		$ht_content = $this->get_ht_content();

		$current_insert = $this->get_current_insert($ht_content);
		
		$insert = "###WPSD-CF-HELPER-START\n{$this->insert_content}\n###WPSD-CF-HELPER-END";

		switch(true){

			case $this->insert_content === '' && $current_insert === '':
			case $this->insert_content === $current_insert:
				return;
			
			case $current_insert === '':
				$ht_content = $insert.PHP_EOL.PHP_EOL.$ht_content;
				break;

			case $this->insert_content === '':
				$ht_content = str_replace( $current_insert, '', $ht_content );
				break;
			default:
				$ht_content = str_replace( $current_insert, $insert, $ht_content );
				break;
		
		}
		
		file_put_contents( self::FILEPATH, trim($ht_content) );
		
	}

	private function get_ht_content(){
		
		return file_exists( self::FILEPATH ) ? file_get_contents( self::FILEPATH ) : '';
	}
	
	private function get_current_insert($ht_content){
	
		switch(true){

			case empty($ht_content):
			case !str_contains( $ht_content, $this->insert_start ):
			case !str_contains( $ht_content, $this->insert_end ):
				return '';
				break;
	
			default:

				$pattern = "~{$this->insert_start}.*{$this->insert_end}~s";
				
				preg_match($pattern, $ht_content, $m);
				
				return $m[0]??'';
		}
		
	}
	
	//MARK: CF Header
	private function add_cf_header(){
		
		$this->get_cf_header_cond_markup();

		if( $this->cf_header_markup === '' ){
			return;
		}

		$this->add_allowed_ips();

		$this->add_allowed_user_agent();

		$this->cf_header_markup .= <<<HTML

		RewriteRule ^ - [E=CFH_ALLOWED:1]

		RewriteCond %{ENV:CFH_ALLOWED} !=1
		HTML;
		
		if($this->s[S::SECTION_CF_HEADER][S::KEY_LOG] === '1'){
			
			$this->cf_header_markup .= $this->get_logger_rule_line();

		} else {

			$this->cf_header_markup .= <<<HTML
			
			RewriteRule ^ - [F,L]
			HTML;
		}
		
	}

	private function get_logger_rule_line($args=[]){
			
		// $http_code = 403,$trace=Log::TRACE_CF_BYPASS

		$d = $this->get_logger_rule_line_values();
		
		// $headers_markup = "[E={$d->key_cookie_hash}:{$d->cookiehash},E={$d->key_response_code}:{$http_code},L]";
		$headers_markup = $this->get_headers_markup($args);
		
		$php_logger_filepath = "{$d->wp_content_dir}/{$d->wp_plugin_dir}/{$d->plugin_dir}/framework/log/htaccess-logger.php";

		return <<<HTML

		RewriteRule ^.* {$php_logger_filepath} {$headers_markup}
		HTML;
	
	}

	private function get_headers_markup($args){
	
		$args[Log::HTACCESS_KEY_HASH] 			= COOKIEHASH;
		$args[Log::HTACCESS_KEY_RESPONSE_CODE]	??= '403';
		$args[Log::HTACCESS_KEY_TRACE] 			??= Log::TRACE_CF_BYPASS;


		$result = '[';

		foreach($args as $key => $value){
			$result .= "E={$key}:{$value},";
		}
		
		return $result.'L]';
	}

	private function get_logger_rule_line_values(){
		
		return (object)[

			'cookiehash' => COOKIEHASH,
			
			'key_cookie_hash' => Log::HTACCESS_KEY_HASH,

			'key_response_code' => Log::HTACCESS_KEY_RESPONSE_CODE,
			
			'wp_content_dir' => basename(basename(WP_CONTENT_DIR)),

			'wp_plugin_dir' => basename(basename(WP_PLUGIN_DIR)),

			'plugin_dir' => basename(Consts::DIR),

		];
	}

	private function add_allowed_ips(){
	
		$ips = $this->s[S::SECTION_CF_HEADER][S::KEY_ALLOWED_IPS] ?? [];

		if( empty($ips) ){
			return;
		}

		foreach($ips as $ip){
			$this->cf_header_markup .= <<<HTML
		RewriteCond %{REMOTE_ADDR} ={$ip} [OR]

		HTML;
		}
	
		$user_agents = $this->s[S::SECTION_CF_HEADER][S::KEY_ALLOWED_USER_AGENT] ?? [];

		if(!empty($user_agents)){
			return;
		}

		$this->cf_header_markup = rtrim($this->cf_header_markup, "[OR] \n");
	}

	private function get_regex_value_markup($array){
	
		$array = array_map( [$this, 'escape_regex'], $array );

		return count($array) === 1 ? reset( $array ) : implode( '|', $array );
		
	}
	
	private function add_allowed_user_agent(){
	
		$user_agents = $this->s[S::SECTION_CF_HEADER][S::KEY_ALLOWED_USER_AGENT] ?? [];

		if( empty($user_agents) ){
			return;
		}
		
		$user_agents_markup = $this->get_regex_value_markup( $user_agents );
		
		$this->cf_header_markup .= <<<HTML
		RewriteCond %{HTTP_USER_AGENT} {$user_agents_markup} [NC]
		HTML;

	}

	private function get_cf_header_cond_markup(){

		$header_key = Consts::CF_HEADER_NAME;

		$header_value = $this->s[S::SECTION_CF_HEADER][S::KEY_HEADER_VALUE ]??false;

		if( $this->has_empty_cf_header_value( $header_key, $header_value ) ){
			return;
		}

		$this->cf_header_markup = <<<HTML
		RewriteCond %{HTTP:{$header_key}} ={$header_value} [NC
		HTML;

		if( empty($this->s[S::SECTION_CF_HEADER][S::KEY_ALLOWED_IPS]) && empty($this->s[S::SECTION_CF_HEADER][S::KEY_ALLOWED_USER_AGENT]) ){
			$this->cf_header_markup .= "]\n";
		} else {
			$this->cf_header_markup .= ",OR]\n";
		}
	}

	private function escape_regex($string){
	
		return addcslashes( $string, '\\|^$()[]{}?+*. ' );
	}

	private function has_empty_cf_header_value($header_key, $header_value){

		switch(true){

			case empty($header_key):
			case empty($header_value):
			case !is_string($header_key):
			case !is_string($header_value):
				return true;

			default:
				return false;
		}
		
	}

	public function get_insert_content(){
	
		return $this->insert_content;
	}
}
