<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;
/**
 * Setup for must use plugin (MU) in /wp-content/mu-plugins or WPMU_PLUGIN_URL
 * 
 */
class MU_Setup{

	public const FILENAME = 'cf-helper.php';

	public const FILEPATH = WPMU_PLUGIN_DIR.DIRECTORY_SEPARATOR.self::FILENAME;

	private array $settings;

	private  array $setting_auth;

	private array $settings_early_403_404;

	private string $mu_content='';

	private object $data;

	private bool $has_cookie_const = false;

	private function __construct(){

		$this->settings = S::get();

		$this->setting_auth = $this->settings[S::SECTION_FALSE_AUTH];

		$this->settings_early_403_404 = $this->settings[S::SECTION_EARLY_403_404];

		$this->data = (object)[
			'plugin_name'		=> __('Cloudflare Helper','wpsd-cf-helper'),
			'plugin_uri'		=> 'https://wpspeeddoctor.com/',
			'description'		=> __('Early check for superior security','wpsd-cf-helper'),
			'version'			=> Consts::VER,
			'author'			=> __('WP Speed Doctor','wpsd-cf-helper'),
			'author_uri'		=> 'https://wpspeeddoctor.com/',
			'license'			=> 'GPL2',
			'text_domain'		=> 'wpsd-cf-helper',
			'domain_path'		=> '/languages/',
			'plugin_dirname'	=> basename( Consts::DIR ),
			'namespace'			=> __NAMESPACE__,
			'auth_cookie'		=> AUTH_COOKIE,
			'logged_in_cookie'	=> LOGGED_IN_COOKIE,
			'sec_cookie'		=> COOKIEHASH

		];

		
	}

	public static function create_mu_plugin( $forced=false ){
		
		if( !file_exists( WPMU_PLUGIN_DIR ) ){
			mkdir( WPMU_PLUGIN_DIR, 0755, true );
		}

		if( file_exists( self::FILEPATH ) && !$forced ){
			return;
		}

		if( $forced && file_exists( self::FILEPATH ) ){
			unlink( self::FILEPATH );
		}
		
		$mu = new self();

		$mu->set_mu_plugin_markup();
		
		$mu_plugin_markup = $mu->get_mu_content();

		if(empty($mu_plugin_markup)){
			return;
		}

		file_put_contents( self::FILEPATH, $mu_plugin_markup );
	}

	private function set_mu_plugin_markup(){
		
		$this->get_early_403_404_markup();
		
		$this->get_mu_false_auth_content();
			
		if( $this->mu_content===''){
			return '';
		}

		if($this->has_cookie_const){
			$this->prepend_cookie_consts();
		}

		$this->mu_content = <<<PHP
		<?php

		namespace {$this->data->namespace};

		/*
		* Plugin Name: {$this->data->plugin_name}
		* Plugin URI: {$this->data->plugin_uri}
		* Description: {$this->data->description}
		* Version: {$this->data->version}
		* Author: {$this->data->author}
		* Author URI: {$this->data->author_uri}
		* License: {$this->data->license}
		* Text Domain: {$this->data->text_domain}
		* Domain Path: {$this->data->domain_path}
		*/

		{$this->mu_content}
		
		function require_plugin_files(){
			static \$loaded;
			if(is_null(\$loaded)){
				@include_once WP_PLUGIN_DIR.'/{$this->data->plugin_dirname}/class-consts.php';
				class_exists( __NAMESPACE__ . '\\Consts') && @include_once Consts::LOADER_FILEPATH;
				\$loaded = is_callable('{$this->data->namespace}\\autoload_class');
			}
			return \$loaded;
		}
		PHP;

	}

	private function prepend_cookie_consts(){
	
		$consts_markup =  <<<PHP
		const AUTH_COOKIE = '{$this->data->auth_cookie}';
		const LOGGED_IN_COOKIE = '{$this->data->logged_in_cookie}';
		const SEC_COOKIE = 'wordpress_sec_{$this->data->sec_cookie}';
		PHP;

		$this->mu_content = $consts_markup.$this->mu_content;
	}

	private function get_early_403_404_markup(){

		$s = $this->settings_early_403_404;
		
		if($s[S::KEY_ENABLED] !== '1'){
			return;
		}

		$has_log = $s[S::KEY_LOG] !== '';

		//enabled but doing nothing
		if(	!$has_log
			&& $s[S::KEY_SELECT_NO_PAGE] === S::KEY_OPTION_DEFAULT
			&& $s[S::KEY_SELECT_NO_FILE] === S::KEY_OPTION_DEFAULT
		){
			return;
		}

		if($has_log || $s[S::KEY_SELECT_NO_PAGE] !== S::KEY_OPTION_DEFAULT){
			
			$no_page_content = <<<PHP
			case REQUEST_FRONTEND:
						require_plugin_files() && add_action('send_headers', __NAMESPACE__ . '\\Early_Return::no_page');
						break;
			PHP;

		} else {
			$no_page_content ='';
		}

		if($has_log || $s[S::KEY_SELECT_NO_FILE] !== S::KEY_OPTION_DEFAULT){
			$no_file_content = <<<PHP
			case REQUEST_DIRECT:
						require_plugin_files() && Early_Return::direct_request();
						break;
					case REQUEST_404:
						require_plugin_files() && Early_Return::no_file();
						break;
			PHP;
		} else {
			$no_file_content = '';
		}

		$this->mu_content .= <<<PHP
		

		//early 403/404
		defined('WPSD_REQUEST_TYPE') || @include_once WP_PLUGIN_DIR.'/{$this->data->plugin_dirname}/framework/request/wp-request-type.php'; 
		
		if(defined('WPSD_REQUEST_TYPE')){
				
			switch(WPSD_REQUEST_TYPE){
				{$no_file_content}
				{$no_page_content}
			}
		}
		PHP;

		
	}

	private function get_mu_false_auth_content(){
		
		if( $this->setting_auth[S::KEY_ENABLED] !== '1' ){
			return;
		}
		
		$this->has_cookie_const = true;

		if($this->mu_content !== '') $this->mu_content .= "\n";

		//if log is enabled, check for false auth
		$log_wp_hooks_markup = $this->get_log_wp_hooks_markup();

		$this->mu_content .= <<<PHP

		//false auth attempt
		if( !empty( \$_COOKIE )){
			foreach(\$_COOKIE as \$key => \$value){

				if( !str_starts_with(\$key, 'wordpress_') ){
					continue;
				}

				switch(\$key){
					case AUTH_COOKIE:
					case LOGGED_IN_COOKIE:
					case SEC_COOKIE:
					case 'wordpress_test_cookie':
						continue 2;
				}
				require_plugin_files() && Early_Return::false_auth(\$key);
				break;
			}
		}
		
		{$log_wp_hooks_markup}
		PHP;
		
	}

	public function get_mu_content(){
		
		return $this->mu_content;
		
	}

	private function get_log_wp_hooks_markup(){
		
		if( $this->setting_auth[S::KEY_LOG] !== '1' ){
			return '';
		}

		return <<<'PHP'
		if( isset( $_COOKIE[LOGGED_IN_COOKIE] ) || isset( $_COOKIE[AUTH_COOKIE] ) ){
			require_plugin_files() && Early_Return::log_bad_auth();
		}
		PHP;
	}
		
	public static function remove_mu_plugin(){
	
		if( file_exists( self::FILEPATH ) ){
			unlink( self::FILEPATH );
		}
	}

}