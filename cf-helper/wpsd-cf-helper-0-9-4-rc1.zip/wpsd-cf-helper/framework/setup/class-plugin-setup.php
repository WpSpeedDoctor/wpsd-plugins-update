<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Plugin_Setup{

	static function activation(){

		require_plugin_files();

		Early_Return::create_cached_404();
		
		self::create_db_dir();

		MU_Setup::create_mu_plugin();

		Htaccess::place_insert();
	}

	static function deactivation(){

		MU_Setup::remove_mu_plugin();

		Htaccess::remove_insert();
	}

	static function add_action_links_plugin_page ( $actions ) {

		$page_link = admin_url( Consts::ADMIN_PAGE.'?page='.Consts::ADMIN_SUBPAGE );

		$text  = esc_html__( 'Menu', 'wpsd-cf-helper' );

		$menu_link =
			<<<HTML
			<a href="{$page_link}">{$text}</a>
			HTML;

		return array_merge( $actions,[$menu_link] );

	}

	static function create_db_dir(){
		
		wp_mkdir_p( WP_CONTENT_DIR.Log::DB_BUFFER_PATH );
	}
}