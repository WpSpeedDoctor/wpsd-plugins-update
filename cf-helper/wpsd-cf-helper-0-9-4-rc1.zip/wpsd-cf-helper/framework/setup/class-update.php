<?php

namespace WPSD\cf_helper;

class Update{

	public static function get_remote_json_data( $url, $transient_name ){
		
		$cached_update_data = get_transient( $transient_name );

		if( !empty( $cached_update_data ) ){

			return $cached_update_data;
		}
		
		global $wp_version;

		$args = [
			'headers' => ['User-Agent' => "WordPress/{$wp_version};"],
			'sslverify' => true, 
		];

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200 ) {
			
			return false;
		}

		$response_body = wp_remote_retrieve_body( $response );

		$result = json_decode( $response_body , true );

		if( empty($result) ) $result = $response_body;

		set_transient( $transient_name, $result, 12*HOUR_IN_SECONDS );
	
		return $result;

	}

	/**
	 * @return array -
	 * - version
	 * - download_link
	 * - requires
	 * - tested
	 * - requires_php
	 * - last_updated
	 * - sections
	 */

	public static function get_auto_update_data(){

		return self::get_remote_json_data( 'https://raw.githubusercontent.com/WpSpeedDoctor/wpsd-plugins-update/refs/heads/main/cf-helper/update.json', Consts::SLUG );

	}

	public static function enable_plugin_auto_update($transient, $plugin_file){ 

		if (empty($transient->checked)) {
			return $transient;
		}

		$plugin_slug = self::get_plugin_slug($plugin_file);

		if (!isset($transient->checked) || !isset($transient->checked[$plugin_slug])) {
			return $transient;
		}

		$current_version = $transient->checked[$plugin_slug];

		$update_data = self::get_auto_update_data();

		if(empty($update_data) || version_compare($current_version, $update_data['version'], '>=')) {
			return $transient;
		}

		$obj = (object) [
			'id'			=> 0,
			'slug'			=> $plugin_slug,
			'plugin'		=> $plugin_slug,
			'new_version'	=> $update_data['version'],
			'package'		=> $update_data['download_link'],
			'requires'		=> $update_data['requires'],
			'tested'		=> $update_data['tested'],
			'requires_php'	=> $update_data['requires_php'],
			'last_updated'	=> $update_data['last_updated'],
		];

		$transient->response[$plugin_slug] = $obj;

		return $transient;
	}

	public static function get_plugin_slug($plugin_file){
		return basename(dirname($plugin_file)).DIRECTORY_SEPARATOR.basename($plugin_file);
	}

	public static function custom_plugin_api_handler($false, $action, $args,$plugin_file) {
				
		$plugin_slug = self::get_plugin_slug($plugin_file);

		if ($action !== 'plugin_information' || isset($args->slug) && $args->slug !== $plugin_slug) return $false;
		
		$update_data = self::get_auto_update_data();

		$changelog_text = self::get_remote_json_data( 'https://raw.githubusercontent.com/WpSpeedDoctor/wpsd-plugins-update/refs/heads/main/cf-helper/changelog.log', Consts::SLUG.'-changelog' );

		if ( empty($changelog_text)) $changelog_text = __('Unable to fetch the changelog.','wpsd-cf-helper');

		$response = new \stdClass();

		$response->slug = $plugin_slug;
		
		$response->version = 		$update_data['version']; 
		$response->download_link =	$update_data['download_url']??$update_data['download_link'];
		
		
		$response->requires =		$update_data['requires'];// Minimum WordPress version
		$response->tested =			$update_data['tested']; // Tested up to WordPress version
		$response->requires_php =	$update_data['requires_php']; // Minimum PHP version
		
		$response->name = __('WPSD Cloudflare Helper','wpsd-cf-helper');

		$response->sections = [
					// 'description' => 'The latest version of the plugin.', // Main description
					
					'changelog' => str_replace( "\n",'<br>', esc_html( $changelog_text)), 
					
					// Add other sections as needed
				];

		// $response->banners = array(
			//     'low' => 'URL to a 772x250px banner image', // Optional: Banner image
			//     'high' => 'URL to a 1544x500px banner image' // Optional: High-resolution banner image
			// );

		return $response; // Return the custom response

	}


}