<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Settings_Defaults{

	public static function get(){

		return [

			S::SECTION_CF_HEADER => self::get_cf_header(),

			S::SECTION_FALSE_AUTH => self::get_false_auth(),

			S::SECTION_IP_CHANGE => self::get_ip_change(),

			S::SECTION_EARLY_403_404 => self::get_early_403_404(),

			S::SECTION_LOGGING => self::get_logging(),

		];

	}

	private static function get_cf_header(){

		return [

			S::KEY_ENABLED => '',

			S::KEY_HEADER_VALUE => $_SERVER['HTTP_ID_CF'] ?? '',

			S::KEY_ALLOWED_IPS => [],

			S::KEY_ALLOWED_USER_AGENT => [],

			S::KEY_LOG => '',

		];

	}

	private static function get_false_auth(){

		return [

			S::KEY_ENABLED => '',

			S::KEY_BLOCK_ATTEMPT => '',

			S::KEY_LOG => '',

		];

	}

	private static function get_ip_change(){

		return [

			S::KEY_ENABLED => '',

			S::KEY_LOG => '',

			S::KEY_ALLOW_IP_CHANGE_COUNTRY => '',

			S::KEY_ALLOW_IP_CHANGE_ASN => '',

		];

	}

	private static function get_early_403_404(){

		return [

			S::KEY_ENABLED => '0',

			S::KEY_LOG => '',

			S::KEY_SELECT_NO_FILE => S::KEY_OPTION_DEFAULT,

			S::KEY_SELECT_NO_PAGE => S::KEY_OPTION_DEFAULT,

		];

	}

	private static function get_logging(){

		return [

			S::KEY_DAYS_TO_KEEP => 30,

			S::KEY_SECRET_TOKEN => bin2hex(random_bytes(10)),

			S::KEY_MONITORING_TRACES => self::get_monitoring_traces(),

		];

	}

	public static function get_monitoring_traces(){

		return [

			S::TRACE_CF_BYPASS => '0',

			S::TRACE_FALSE_AUTH => '0',

			S::TRACE_IP_CHANGED => '0',

			S::TRACE_NO_FILE => '0',

			S::TRACE_NO_PAGE => '0',

			S::TRACE_MALFORMED_COOKIE => '0',

			S::TRACE_BAD_USERNAME => '0',

			S::TRACE_BAD_HASH => '0',

			S::TRACE_BAD_SESSION_TOKEN => '0',

		];

	}

}
