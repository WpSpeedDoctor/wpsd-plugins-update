<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Settings_Sanitizer{

	public static function sanitize($posted_settings){

		if( !is_array($posted_settings))return Settings_Defaults::get();

		return [

			S::SECTION_CF_HEADER => self::sanitize_cf_header($posted_settings),

			S::SECTION_FALSE_AUTH => self::sanitize_false_auth($posted_settings),

			S::SECTION_IP_CHANGE => self::sanitize_ip_change($posted_settings),

			S::SECTION_EARLY_403_404 => self::sanitize_early_403_404($posted_settings),

			S::SECTION_LOGGING => self::sanitize_logging($posted_settings),

		];

	}

	private static function sanitize_cf_header($posted_settings){

		return [

			S::KEY_ENABLED => self::get_bool_value($posted_settings, [S::SECTION_CF_HEADER, S::KEY_ENABLED]),

			S::KEY_HEADER_VALUE => self::get_text_value($posted_settings, [S::SECTION_CF_HEADER, S::KEY_HEADER_VALUE]),

			S::KEY_ALLOWED_IPS => self::get_allowed_ips($posted_settings),

			S::KEY_ALLOWED_USER_AGENT => self::get_allowed_user_agents($posted_settings),

			S::KEY_LOG => self::get_bool_value($posted_settings, [S::SECTION_CF_HEADER, S::KEY_LOG]),

		];

	}

	private static function sanitize_false_auth($posted_settings){

		return [

			S::KEY_ENABLED => self::get_bool_value($posted_settings, [S::SECTION_FALSE_AUTH, S::KEY_ENABLED]),

			S::KEY_BLOCK_ATTEMPT => self::get_bool_value($posted_settings, [S::SECTION_FALSE_AUTH, S::KEY_BLOCK_ATTEMPT]),

			S::KEY_LOG => self::get_bool_value($posted_settings, [S::SECTION_FALSE_AUTH, S::KEY_LOG]),

		];

	}

	private static function sanitize_ip_change($posted_settings){

		return [

			S::KEY_ENABLED => self::get_bool_value($posted_settings, [S::SECTION_IP_CHANGE, S::KEY_ENABLED]),

			S::KEY_LOG => self::get_bool_value($posted_settings, [S::SECTION_IP_CHANGE, S::KEY_LOG]),

			S::KEY_ALLOW_IP_CHANGE_COUNTRY => self::get_bool_value($posted_settings, [S::SECTION_IP_CHANGE, S::KEY_ALLOW_IP_CHANGE_COUNTRY]),

			S::KEY_ALLOW_IP_CHANGE_ASN => self::get_bool_value($posted_settings, [S::SECTION_IP_CHANGE, S::KEY_ALLOW_IP_CHANGE_ASN]),

		];

	}

	private static function sanitize_early_403_404($posted_settings){

		return [

			S::KEY_ENABLED => self::get_bool_value($posted_settings, [S::SECTION_EARLY_403_404, S::KEY_ENABLED], '0'),

			S::KEY_LOG => self::get_bool_value($posted_settings, [S::SECTION_EARLY_403_404, S::KEY_LOG]),

			S::KEY_SELECT_NO_FILE => self::get_early_option($posted_settings, S::KEY_SELECT_NO_FILE),

			S::KEY_SELECT_NO_PAGE => self::get_early_option($posted_settings, S::KEY_SELECT_NO_PAGE),

		];

	}

	private static function sanitize_logging($posted_settings){

		return [

			S::KEY_DAYS_TO_KEEP => self::get_days_to_keep($posted_settings),

			S::KEY_SECRET_TOKEN => self::get_secret_token($posted_settings),

			S::KEY_MONITORING_TRACES => self::get_monitoring_traces($posted_settings),

		];

	}

	private static function get_secret_token($posted_settings){

		$value = self::get_text_value($posted_settings, [S::SECTION_LOGGING, S::KEY_SECRET_TOKEN], '');

		if($value !== '')return $value;

		return bin2hex(random_bytes(10));

	}

	private static function get_early_option($posted_settings, $key){

		if( !is_array($posted_settings))return S::KEY_OPTION_DEFAULT;

		if(! is_int($key))return S::KEY_OPTION_DEFAULT;

		$value = self::get_text_value($posted_settings, [S::SECTION_EARLY_403_404, $key], S::KEY_OPTION_DEFAULT);

		return match($value){

			S::KEY_OPTION_403 => S::KEY_OPTION_403,

			S::KEY_OPTION_SIMPLE_404 => S::KEY_OPTION_SIMPLE_404,

			S::KEY_OPTION_CACHED => S::KEY_OPTION_CACHED,

			S::KEY_OPTION_DEFAULT => S::KEY_OPTION_DEFAULT,

			default => S::KEY_OPTION_DEFAULT,

		};

	}

	private static function get_allowed_ips($posted_settings){

		$value = self::get_raw_value($posted_settings, [S::SECTION_CF_HEADER, S::KEY_ALLOWED_IPS], '');

		$lines = self::get_clean_lines($value);

		$lines = array_filter($lines, static function($ip){

			return filter_var($ip, FILTER_VALIDATE_IP) !== false;

		});

		return array_values($lines);

	}

	private static function get_allowed_user_agents($posted_settings){

		$value = self::get_raw_value($posted_settings, [S::SECTION_CF_HEADER, S::KEY_ALLOWED_USER_AGENT], '');

		$lines = self::get_clean_lines($value);

		$lines = array_map('sanitize_text_field', $lines);

		$lines = array_filter($lines, static function($user_agent){

			return is_string($user_agent) && $user_agent !== '';

		});

		return array_values($lines);

	}

	private static function get_clean_lines($value){

		if(! is_scalar($value))return [];

		$value = wp_unslash((string) $value);

		$lines = preg_split('/\r\n|\r|\n/', $value);

		if( !is_array($lines))return [];

		$lines = array_map('trim', $lines);

		$lines = array_filter($lines, static function($line){

			return is_string($line) && $line !== '';

		});

		return array_values($lines);

	}

	private static function get_days_to_keep($posted_settings){

		if( !is_array($posted_settings))return 0;

		$days_to_keep = self::get_raw_value($posted_settings, [S::SECTION_LOGGING, S::KEY_DAYS_TO_KEEP], 0);

		return absint($days_to_keep);

	}

	private static function get_monitoring_traces($posted_settings){

		$traces = Settings_Defaults::get_monitoring_traces();

		if( !is_array($posted_settings))return $traces;

		$posted_traces = self::get_raw_value($posted_settings, [S::SECTION_LOGGING, S::KEY_MONITORING_TRACES], []);

		if( !is_array($posted_traces))return $traces;

		foreach($traces as $trace_key => $enabled){

			$traces[$trace_key] = empty($posted_traces[$trace_key]) ? '0' : '1';

		}

		return $traces;

	}

	private static function get_bool_value($settings, $path, $empty_value = ''){

		$value = self::get_raw_value($settings, $path, '');

		return empty($value) ? $empty_value : '1';

	}

	private static function get_text_value($settings, $path, $default = ''){

		$value = self::get_raw_value($settings, $path, $default);

		if(! is_scalar($value))return $default;

		return sanitize_text_field(wp_unslash((string) $value));

	}

	private static function get_raw_value($settings, $path, $default = ''){

		if( !is_array($settings))return $default;

		if( !is_array($path) || $path === [])return $default;

		$value = $settings;

		foreach($path as $segment){

			if(! is_int($segment))return $default;

			if( !is_array($value))return $default;

			if(! array_key_exists($segment, $value))return $default;

			$value = $value[$segment];

		}

		return $value;

	}

}
