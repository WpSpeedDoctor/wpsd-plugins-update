<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Settings_Mapper{

	public static function get_section_slug($section){

		return match($section){

			S::SECTION_CF_HEADER => 'cf-header',

			S::SECTION_FALSE_AUTH => 'false-auth',

			S::SECTION_IP_CHANGE => 'ip-change',

			S::SECTION_EARLY_403_404 => 'early-403-404',

			S::SECTION_LOGGING => 'logging',

			default => '',

		};

	}

	public static function get_section_by_slug($slug){

		return match($slug){

			'cf-header' => S::SECTION_CF_HEADER,

			'false-auth' => S::SECTION_FALSE_AUTH,

			'ip-change' => S::SECTION_IP_CHANGE,

			'early-403-404' => S::SECTION_EARLY_403_404,

			'logging' => S::SECTION_LOGGING,

			default => S::SECTION_CF_HEADER,

		};

	}

	public static function get_trace_slug($trace_key){

		return match($trace_key){

			S::TRACE_CF_BYPASS => Log::TRACE_CF_BYPASS,

			S::TRACE_FALSE_AUTH => Log::TRACE_FALSE_AUTH,

			S::TRACE_IP_CHANGED => Log::TRACE_IP_CHANGED,

			S::TRACE_NO_FILE => Log::TRACE_NO_FILE,

			S::TRACE_NO_PAGE => Log::TRACE_NO_PAGE,

			S::TRACE_MALFORMED_COOKIE => Log::TRACE_MALFORMED_COOKIE,

			S::TRACE_BAD_USERNAME => Log::TRACE_BAD_USERNAME,

			S::TRACE_BAD_HASH => Log::TRACE_BAD_HASH,

			S::TRACE_BAD_SESSION_TOKEN => Log::TRACE_BAD_SESSION_TOKEN,

			default => '',

		};

	}

	public static function get_trace_key($trace_slug){

		return match($trace_slug){

			Log::TRACE_CF_BYPASS => S::TRACE_CF_BYPASS,

			Log::TRACE_FALSE_AUTH => S::TRACE_FALSE_AUTH,

			Log::TRACE_IP_CHANGED => S::TRACE_IP_CHANGED,

			Log::TRACE_NO_FILE => S::TRACE_NO_FILE,

			Log::TRACE_NO_PAGE => S::TRACE_NO_PAGE,

			Log::TRACE_MALFORMED_COOKIE => S::TRACE_MALFORMED_COOKIE,

			Log::TRACE_BAD_USERNAME => S::TRACE_BAD_USERNAME,

			Log::TRACE_BAD_HASH => S::TRACE_BAD_HASH,

			Log::TRACE_BAD_SESSION_TOKEN => S::TRACE_BAD_SESSION_TOKEN,

			default => false,

		};

	}

}