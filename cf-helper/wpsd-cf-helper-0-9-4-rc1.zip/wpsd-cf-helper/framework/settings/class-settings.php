<?php

namespace WPSD\cf_helper;

class Settings{

	public const INPUT_ROOT = 'settings';

	public const SECTION_CF_HEADER = 0;

	public const SECTION_FALSE_AUTH = 1;

	public const SECTION_IP_CHANGE = 2;

	public const SECTION_EARLY_403_404 = 3;

	public const SECTION_LOGGING = 4;

	public const KEY_ENABLED = 0;

	public const KEY_HEADER_VALUE = 2;

	public const KEY_ALLOWED_IPS = 3;

	public const KEY_ALLOWED_USER_AGENT = 4;

	public const KEY_LOG = 5;

	public const KEY_BLOCK_ATTEMPT = 1;

	public const KEY_ALLOW_IP_CHANGE_COUNTRY = 2;

	public const KEY_ALLOW_IP_CHANGE_ASN = 3;

	public const KEY_SELECT_NO_FILE = 2;

	public const KEY_SELECT_NO_PAGE = 3;

	public const KEY_DAYS_TO_KEEP = 0;

	public const KEY_SECRET_TOKEN = 1;

	public const KEY_MONITORING_TRACES = 2;

	public const TRACE_CF_BYPASS = 0;

	public const TRACE_FALSE_AUTH = 1;

	public const TRACE_IP_CHANGED = 2;

	public const TRACE_NO_FILE = 3;

	public const TRACE_NO_PAGE = 4;

	public const TRACE_MALFORMED_COOKIE = 6;

	public const TRACE_BAD_USERNAME = 7;

	public const TRACE_BAD_HASH = 8;

	public const TRACE_BAD_SESSION_TOKEN = 9;

	public const KEY_OPTION_DEFAULT = 'default';

	public const KEY_OPTION_SIMPLE_404 = 'simple_404';

	public const KEY_OPTION_CACHED = 'cached';

	public const KEY_OPTION_403 = '403';

	public const STORAGE_SQLITE = 'sqlite';

	public const STORAGE_WP_DB = 'wp-db';

	private static array $settings;

	public static function get(){

		if(!isset(self::$settings)){

			self::$settings = self::get_wpsd_option(Consts::OPTION_KEY_SETTINGS) ?: self::merge_with_defaults(false);

		}

		return self::$settings;

	}

	public static function save($settings){

		if(!is_array($settings)){

			return false;
		}

		self::$settings = self::merge_with_defaults($settings);

		return self::update_wpsd_option(Consts::OPTION_KEY_SETTINGS, $settings, $autoload = 'on');

	}

	private static function merge_with_defaults($settings){

		require_plugin_files();

		if(!is_array($settings)){
			
			return Settings_Defaults::get();
		} 

		return array_replace_recursive(Settings_Defaults::get(), $settings);

	}

	public static function uninstall_settings(){

		is_multisite() ? delete_site_option(Consts::OPTION_KEY_SETTINGS) : delete_option(Consts::OPTION_KEY_SETTINGS);

	}

	public static function get_wpsd_option($name){

		return is_multisite() ? get_site_option( $name ) : get_option( $name );
	}

	public static function update_wpsd_option( $name, $value, $autoload = 'off' ){

		return is_multisite() ? update_site_option( $name, $value ) : update_option( $name, $value, $autoload);
	}

}
