<?php

namespace WPSD\cf_helper;
/**
 * Not in use, maybe in future release
 */
class Remote_Logging_Options{

	public static function get(){

		$options = apply_filters(__NAMESPACE__ . '\\remote_logging_options', []);

		if( !is_array($options))return [];

		$clean_options = [];

		foreach($options as $option_key => $option_label){

			if(! is_string($option_key) || $option_key === '')continue;

			if(! is_scalar($option_label))continue;

			$clean_options[$option_key] = (string) $option_label;

		}

		return $clean_options;

	}

}