<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Settings_Save_Controller{

	public static function save_post(){

		if(! self::can_save_post())return false;

		$posted_settings = self::get_posted_settings();

		$settings = Settings_Sanitizer::sanitize($posted_settings);

		S::save($settings);

		self::after_save();

		return true;

	}

	private static function can_save_post(){

		if(! isset($_POST[Consts::NONCE]))return false;

		$nonce = sanitize_text_field(wp_unslash($_POST[Consts::NONCE]));

		if(! wp_verify_nonce($nonce, Consts::NONCE))return false;

		if(! current_user_can('manage_options'))return false;

		return true;

	}

	private static function get_posted_settings(){

		$posted_settings = $_POST[S::INPUT_ROOT] ?? [];

		if( !is_array($posted_settings))return [];

		return $posted_settings;

	}

	private static function after_save(){

		MU_Setup::create_mu_plugin($forced = true);

		Htaccess::place_insert();

	}

}