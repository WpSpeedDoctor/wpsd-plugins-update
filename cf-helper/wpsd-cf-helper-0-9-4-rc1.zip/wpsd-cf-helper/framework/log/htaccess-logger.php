<?php

namespace WPSD\cf_helper;

define('WP_START_TIMESTAMP',microtime(true));

require __DIR__.'/class-log.php';

header ( 'Content-Type: text/html; charset=UTF-8' );

//continue here, investigate why function fails to load get_server_value_from_log_constant()
if(Log::get_server_value_from_log_constant(Log::HTACCESS_KEY_RESPONSE_CODE)==='404'){

	Log::display_404();

} else {

	Log::display_403();

}

Log::store_locally(Log::get_server_value_from_log_constant(Log::HTACCESS_KEY_TRACE));

die;
