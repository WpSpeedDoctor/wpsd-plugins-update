<?php

namespace WPSD\cf_helper;

/**
 * Class Log
 * important: Can use only class Consts and cannot use other classes or other's classes constants
 * as it's called from htaccess logger that is not loading the map of classes
 * for performance purposes.
 */
class Log {

	public const WPSD_LOG_KEY = 'CF-Helper';

	public const HTACCESS_KEY_HASH = 'CFH_HASH';
	public const HTACCESS_KEY_RESPONSE_CODE = 'CFH_CODE';
	public const HTACCESS_KEY_TRACE = 'CFH_TRACE';

	/**
	 * @var string the start of the trace filename
	 * it's located here because Trace_Controller class is not available when
	 * this file is loaded from htaccess
	 * 
	 */
	public const TRACE_PREFIX = '.ht-trace-';

	public const TRACE_RETRIEVE			= 'retrieve';
	public const TRACE_NO_FILE			= 'no-file';
	public const TRACE_FALSE_AUTH		= 'false-auth';
	public const TRACE_NO_PAGE			= 'no-page';
	public const TRACE_CF_BYPASS		= 'cf-bypass';
	public const TRACE_IP_CHANGED		= 'ip-changed';
	public const TRACE_MALFORMED_COOKIE	= 'malformed-cookie';
	public const TRACE_BAD_USERNAME		= 'bad-username';
	public const TRACE_BAD_HASH			= 'bad-hash';
	public const TRACE_BAD_SESSION_TOKEN= 'bad-session-token';

	public const KEY_TIMESTAMP		= 0;
	public const KEY_URI_PATH		= 1;
	public const KEY_QUERY_STRING	= 2;
	public const KEY_REMOTE_IP		= 3;
	public const KEY_COUNTRY		= 4;
	public const KEY_ASN			= 5;
	public const KEY_POST			= 6;
	public const KEY_USER_ID		= 7;
	public const KEY_USER_AGENT		= 8;
	public const KEY_HTTP_RESPONSE	= 9;
	public const KEY_REQUEST_TYPE	= 10;
	public const KEY_META			= 11;

	public const DB_LOCAL_PATH		= '/database/wpsd-cf-helper/';
	
	//as we don't write own sqlite db, skip buffer dir and write buffer into database dir, might change in the future.
	public const DB_BUFFER_PATH		= self::DB_LOCAL_PATH;

	
	/**
	 * Store the log
	 * 
	 * @param int $trace
	 * @param string $custom_meta
	 */

	public static function store($trace, $custom_meta = ''){

		self::store_locally($trace, $custom_meta);

		//maybe in future store remotelly
	}

	public static function get_event_4_local_json($custom_meta){
	
		$event = [
		
			self::KEY_TIMESTAMP		=> WP_START_TIMESTAMP,

			self::KEY_URI_PATH 		=> isset($_SERVER['REQUEST_URI']) ? strtok($_SERVER['REQUEST_URI'], '?') : '',
		
			self::KEY_QUERY_STRING	=> $_SERVER['QUERY_STRING'] ?? '',
		
			self::KEY_REMOTE_IP		=> $_SERVER['REMOTE_ADDR'] ?? '',
		
			self::KEY_COUNTRY		=> $_SERVER['HTTP_CF_IPCOUNTRY']??'',
		
			self::KEY_ASN			=> intval($_SERVER['HTTP_'.Consts::CF_HEADER_ASN]??0),
		
			self::KEY_POST			=> self::get_truncated_post(),
		
			self::KEY_USER_ID		=> self::get_user_name(),
		
			self::KEY_USER_AGENT	=> is_callable( 'wp_unslash') ? wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? '') : stripslashes($_SERVER['HTTP_USER_AGENT'] ?? ''),
		
			self::KEY_HTTP_RESPONSE => http_response_code(),
		
			self::KEY_REQUEST_TYPE	=> defined( 'WPSD_REQUEST_TYPE' ) ? WPSD_REQUEST_TYPE : '',
		
			self::KEY_META			=> $custom_meta === false ? '[]': json_encode($custom_meta, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),	

		];
		
		return json_encode($event, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE).PHP_EOL;

	}

	public static function get_user_name(){
		
		$server_value = self::get_server_value_from_log_constant(Log::HTACCESS_KEY_HASH);

		$hash = defined( 'COOKIEHASH' ) ? COOKIEHASH : $server_value;

		if(empty($hash) || !is_string($hash)){
			return '';
		}

		$cookie_value = $_COOKIE['wordpress_logged_in_'.$hash] ?? $_COOKIE['wordpress_'.$hash]??'';

		if(empty($cookie_value) || !is_string($cookie_value)){
			return '';
		}

		return strstr($cookie_value,'|',true ) ?: '';
	}

	public static function get_server_value_from_log_constant($constant_key){

		return $_SERVER["HTTP_{$constant_key}"] ?? $_SERVER["REDIRECT_{$constant_key}"] ?? '';
		
	}


	public static function get_truncated_post(){

		if( ($_SERVER['REQUEST_METHOD']??'') !== 'POST' ){

			return empty( $_POST ) ? '' : ['WARNING' => 'Data in $_POST'];
		}

		return self::get_truncated_array( $_POST );
	}

	public static function get_truncated_array($array){
		
		$result=[];

		foreach( $array as $key => $value ){

			//excluded keys
			switch(true){
				case str_contains( $key, 'nonce' ):
				case str_contains( $key, 'pwd' ):
				case str_contains( $key, 'passw' ):
					continue 2;
			}

			$result[$key] = self::get_truncated_input( $value );
		}

		//sanitize when added into the DB
		return empty($result) ? null : $result;
		
	}

	public static function get_truncated_input( $value ){

		if( is_numeric($value) ) return $value;

		if( is_string($value) ) return self::get_truncated_line( (string) $value );

		return self::get_truncated_array($value);
	}

	public static function get_truncated_line( $line ){

		// 100 is max length
		return strlen($line)>=103 ? substr( $line,0 , 100).'...': $line;

	}



	public static function get_buffer_dir(){
	
		$wp_content_dir = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : realpath( dirname(__DIR__, 4) );
		
		return $wp_content_dir . self::DB_BUFFER_PATH;
	}

	/**
	 * event data is written into buffer file by appending it on the end. If already another process is writing,
	 * it will be skipped and tries to write to next index buffer file.
	 * With 16 core CPU never was written more than 3 distinct buffer files
	 */


	public static function store_locally($trace, $custom_meta=false){
		
		$ip_number = self::get_server_last_ip_number();
		
		$event_json = self::get_event_4_local_json($custom_meta);
				
		$buffer_path = self::get_buffer_dir();
		
		if(empty($trace)){
			$trace = 'unknown';
		}

		file_put_contents( $buffer_path.self::get_trace_filename($trace,$ip_number), $event_json, FILE_APPEND );
		
	}

	public static function get_trace_filename($trace,$ip_number){
	
		return self::TRACE_PREFIX."{$trace}{$ip_number}";
	}

	/**
	 * Returns "." + last ip number of the server
	 * example: 127.0.0.1 => ".1"
	 * example:  ::3e25 => ".3e25"
	 */
	
	static function get_server_last_ip_number(){

		$server_ip = $_SERVER['SERVER_ADDR'] ?? '.0';
		
		$pos = strrpos( $server_ip, '.' ) ?: strrpos( $server_ip, ':' );
		
		return '.'.substr( $server_ip, $pos + 1 );

	}

	public static function display_404(){
	
		http_response_code(404);

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL was not found on this server.</p>
</body></html><?php
			
	}

	public static function display_403(){
	
	http_response_code(403);
	
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<title>403 Forbidden</title>
</head><body>
<h1>Forbidden</h1>
<p>You don't have permission to access this resource.</p>
</body></html><?php
		
	}
	
}