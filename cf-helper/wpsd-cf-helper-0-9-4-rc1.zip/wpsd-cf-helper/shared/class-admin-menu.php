<?php

namespace WPSD\shared;

defined( 'ABSPATH' ) || exit;

class Admin_Menu {

	public const FILTER_CONTENT = 'wpsd-main-page-content';

	public const FILTER_SUBMENUS = 'wpsd-plugins-submenus';

	public const KEY_SUBMENU_TITLE = 0;

	public const KEY_SUBMENU_SLUG = 1;

	public const KEY_SUBMENU_CALLABLE = 2;

	private static string $relase_date = '';

	private static string $main_menu_title = '';

	static function add_shared_wpsd_menu(){

		global $menu;

		if( in_array('wpsd', array_column($menu, 2)) ){

			return;
		}

		add_menu_page(
			self::$main_menu_title,
			self::$main_menu_title,
			'manage_options',
			'wpsd',
			[self::class, 'wpsd_main_page'],
			'dashicons-code-standards',
			30
		);

		$plugins_submenus = apply_filters(self::FILTER_SUBMENUS, []);

		foreach( $plugins_submenus as $submenu ){

			add_submenu_page(
				'wpsd',
				$submenu[self::KEY_SUBMENU_TITLE],
				$submenu[self::KEY_SUBMENU_TITLE],
				'administrator',
				$submenu[self::KEY_SUBMENU_SLUG],
				$submenu[self::KEY_SUBMENU_CALLABLE]
			);
		}
	}

	static function wpsd_main_page(){

		$page_content = apply_filters(self::FILTER_CONTENT, self::$relase_date);

		if( str_contains($page_content, 'script') ){

			wp_die('Illegal content');
		}

		foreach( explode('http', $page_content) as $key => $piece ){

			if( $key === 0 ){

				continue;
			}

			if( !str_starts_with($piece, 's://wpspeeddoctor.com/') ){

				wp_die('Illegal content');
			}
		}

		echo <<<HTML
		<div class="wrap">
		{$page_content}
		</div>
		HTML;
	}

	static function set_data($translated_title, $release_date){

		if( self::$relase_date < $release_date ){

			self::$relase_date = $release_date;
		}

		self::set_title($translated_title);
	}

	static function set_release_date($release_date){

		if( self::$relase_date < $release_date ){

			self::$relase_date = $release_date;
		}
	}

	static function set_title($translated_title){

		if( self::$main_menu_title !== '' ){

			return;
		}

		self::$main_menu_title = $translated_title;
	}
}
