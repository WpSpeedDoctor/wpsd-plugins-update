<?php

namespace WPSD\cf_helper;
//has to be in the main folder as it relies on __DIR__ constant

abstract class Consts {

	public const DIR = __DIR__.DIRECTORY_SEPARATOR;
	
	public const VER = '0.9.4 RC1';

	public const SLUG = 'wpsd-cf-helper';

	public const NONCE = Consts::SLUG.'-nonce';

	public const MAP_CLASSES = self::DIR.'framework/map-class/map-classes.php';

	public const LOADER_FILEPATH = self::DIR.'framework/map-class/map-loader.php';

	public const OPTION_KEY_SETTINGS = self::SLUG.'-settings';

	public const ADMIN_PAGE = 'admin.php';

	public const ADMIN_SUBPAGE = 'wpsd-cf-helper';

	public const CF_HEADER_ASN = 'IP_ASN_CF';

	public const CF_HEADER_NAME = 'ID_CF';

	public const CF_HEADER_URI_PATH = 'URI_PATH_CF';

	public const CF_HEADER_FILE_EXT = 'FILE_EXT_CF';

}
