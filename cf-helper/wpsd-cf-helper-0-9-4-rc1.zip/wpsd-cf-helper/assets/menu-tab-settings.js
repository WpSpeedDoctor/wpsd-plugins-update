(function(){
	'use strict';

	function setCookie(name, value, path){
		document.cookie = `${name}=${encodeURIComponent(value)}; path=${path || '/'}`;
	}

	function getCookie(name){
		const value = `; ${document.cookie}`;
		const parts = value.split(`; ${name}=`);
		if(parts.length === 2){
			return decodeURIComponent(parts.pop().split(';').shift());
		}
		return null;
	}

	const form = document.querySelector('.settings-menu');
	if(!form){
		return;
	}

	const tabs = form.querySelectorAll('.settings-menu__tabs');
	const path = window.location.pathname;

	tabs.forEach((tab) => {
		tab.addEventListener('change', function(){
			const id = this.id;
			const tabName = id.replace(/^settings-tab-/, '');
			setCookie('wpsd-cfh-tab-settings', tabName, path);
		});
	});

	function restoreTab(){
		const savedTab = getCookie('wpsd-cfh-tab-settings');
		if(savedTab){
			const radio = form.querySelector(`#settings-tab-${savedTab.replace(/[ ^a-z0-9_-]/gi, '')}`);
			if(radio){
				radio.checked = true;
			}
		}
	}

	if(document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', restoreTab);
	}else{
		restoreTab();
	}
})();