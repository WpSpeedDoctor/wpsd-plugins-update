<?php

namespace WPSD\cf_helper;

/*
* Plugin Name: WPSD Cloudflare Helper
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Reinforced security on WP level suplementing Cloudflare firewall.
* Version: 0.9.4 RC1
* Network: true
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-cf-helper
* Domain Path: /languages/
* Last Update: 2026-06-30
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 8.0
*/


/**
 * Essentials
 */
require_once __DIR__.'/class-consts.php';

defined( 'WPSD_REQUEST_TYPE' ) || require Consts::DIR.'framework/request/wp-request-type.php';

//This function can be declared in mu-plugin
if( !function_exists( __NAMESPACE__.'\require_plugin_files') ){
	function require_plugin_files(){

		if(!is_callable('WPSD\cf_helper\autoload_class')){
			require_once Consts::LOADER_FILEPATH;
		}
		
		//on this point all the files are loaded or fatal error.
		return true;
	}	
}

main();

function main(){

	/**
	 * Main code branching
	 */

	switch( WPSD_REQUEST_TYPE ) {

		case REQUEST_REST:

			require Consts::DIR.'framework/request/request-rest.php';
				
		case REQUEST_AJAX:
		case REQUEST_CLI:

			plugin_start_stop_hooks();
			break;
			
		case REQUEST_ADMIN:
			
			$plugin_filepath =__FILE__;//required for the plugin menu

			require Consts::DIR.'framework/request/request-admin.php';

			plugin_start_stop_hooks();

			// load_language_domain(); 
			add_action('init', __NAMESPACE__.'\load_language_domain');
			break;

	}

	/**
	 * Hook based branching
	 */

		/**
	 * Not using autoload as maybe only this class is needed for general request
	 */
	require_once Consts::DIR.'framework/settings/class-settings.php';

	$settings = Settings::get();

	/**
	 * Login control
	 */

	if($settings[Settings::SECTION_FALSE_AUTH][Settings::KEY_ENABLED] === '1'){

		add_action('wp_login', __NAMESPACE__.'\user_login',99,2);
	}

	/**
	 * IP and ASN verification
	 */

	if(should_verify_user_ip_change($settings)){
		
		//first hook when logged in user is authenticated
		add_action( 'set_current_user', __NAMESPACE__.'\verify_user_ip_change' );
	}


	/**
	 *  Automatic plugin UPDATE from github
	 */

	add_filter('pre_set_site_transient_update_plugins', __NAMESPACE__.'\\enable_plugin_auto_update');

	add_filter('plugins_api', __NAMESPACE__.'\\custom_plugin_api_handler', 10, 3);

}

/**
 * Only essential functions beyond this point
 */

function load_language_domain(){

	load_plugin_textdomain('wpsd-cf-helper', false, basename(__DIR__) . '/languages/');

}

function custom_plugin_api_handler($false, $action, $args){
	
	require_plugin_files();

	return Update::custom_plugin_api_handler($false, $action, $args,__FILE__);

}	
function enable_plugin_auto_update($transient){
	
	require_plugin_files();

	return Update::enable_plugin_auto_update($transient,__FILE__);

}

function should_verify_user_ip_change($settings) {
	
	switch (true) {
		case !isset($_COOKIE[LOGGED_IN_COOKIE]) && !isset($_COOKIE[AUTH_COOKIE]):
		case !isset($settings[Settings::SECTION_IP_CHANGE][Settings::KEY_ENABLED]):
			return false;
		
		default:
			return $settings[Settings::SECTION_IP_CHANGE][Settings::KEY_ENABLED] === '1';
		
	}
	
}

function plugin_start_stop_hooks(){

	register_activation_hook( __FILE__, __NAMESPACE__.'\activation_init' );
	register_deactivation_hook( __FILE__, __NAMESPACE__.'\deactivation_init' );
}

function activation_init(){
	
	if( defined( 'WP_ENVIRONMENT_TYPE' ) && WP_ENVIRONMENT_TYPE === 'development' ){
		
		require_once Consts::DIR.'framework/map-class/map-classes-updater.php';
		
		update_class_map();
	}

	require_plugin_files();
	
	Plugin_Setup::activation();
	
}

function deactivation_init(){
	
	require_plugin_files();

	Plugin_Setup::deactivation();
}



function user_login($username,$user){

	require_plugin_files();

	Auth_Control::set_login_data($user);

}

function verify_user_ip_change(){
	
	require_plugin_files();
	
	Auth_Control::logout_user_from_forbidden_location();
	
}
