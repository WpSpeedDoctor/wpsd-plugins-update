<?php

namespace WPSD\cf_helper;

class Tab_Home implements Tab_Interface{

public function render(){

	$from_midnight = strtotime('today', time());

	$now = time();

	$events = Trace_Controller::get_breach_events($from_midnight, $now);

	if(empty($events)) return $this->render_empty_events();

	$html = $this->get_events_html($events);

	echo $html;

}

private function render_empty_events(){

	$texts = $this->get_texts();

	$html = <<<HTML
		<div class="wrap">

			<h1>{$texts['title']}</h1>

			<p>{$texts['no_events']}</p>

		</div>
		HTML;

	echo $html;

}

private function get_events_html(array $events){

	if(empty($events)) return false;

	$texts = $this->get_texts();

	$html = <<<HTML
		<div class="wrap">

			<h1>{$texts['title_today']}</h1>
		HTML;

	foreach($events as $type_key => $type_events){

		if(empty($type_events)) continue;

		$html .= $this->get_event_type_html($type_key, $type_events);

	}

	$html .= <<<HTML

</div>
HTML;

	return $html;

}

private function get_event_type_html($type_key, array $type_events){

	if(empty($type_events)) return false;

	$type_label = $this->get_event_type_label($type_key);

	$type_count = count($type_events);

	$display_events = $this->get_sorted_events($type_events);

	$table_rows = $this->get_event_rows_html($display_events);

	$texts = $this->get_texts();

	$html = <<<HTML

	<h2>{$type_label} ({$type_count} {$texts['events']})</h2>

	<table class="wp-list-table widefat fixed striped">

		<thead>

			<tr>

				<th>{$texts['time']}</th>

				<th>{$texts['timestamp']}</th>

				<th>{$texts['ip']}</th>

				<th>{$texts['country']}</th>

				<th>{$texts['asn']}</th>

				<th>{$texts['user_id']}</th>

				<th>{$texts['path']}</th>

				<th>{$texts['request_type']}</th>

			</tr>

		</thead>

		<tbody>

			{$table_rows}

		</tbody>

	</table>
HTML;

	return $html;

}

private function get_event_rows_html(array $events){

	if(empty($events)) return false;

	$html = '';

	foreach($events as $event){

		$html .= $this->get_event_row_html($event);

	}

	return $html;

}

private function get_event_row_html(array $event){

	if(empty($event)) return false;

	$timestamp = $event[Log::KEY_TIMESTAMP] ?? 0;

	$timestamp_value = esc_html(strval($timestamp));

	$time = esc_html(date('Y-m-d H:i:s', intval($timestamp)));

	$ip = esc_html($event[Log::KEY_REMOTE_IP] ?? '');

	$country = esc_html($event[Log::KEY_COUNTRY] ?? '');

	$asn = esc_html($event[Log::KEY_ASN] ?? '');

	$user_id = esc_html($event[Log::KEY_USER_ID] ?? '');

	$path = esc_html($event[Log::KEY_URI_PATH] ?? '');

	$query = $this->get_query_string_html($event);

	$request_type_name = self::get_request_code_name($event[Log::KEY_REQUEST_TYPE] ?? '');

	$request_type = esc_html($request_type_name);

	$html = <<<HTML

			<tr>

				<td>{$time}</td>

				<td>{$timestamp_value}</td>

				<td>{$ip}</td>

				<td>{$country}</td>

				<td>{$asn}</td>

				<td>{$user_id}</td>

				<td>{$path}{$query}</td>

				<td>{$request_type}</td>

			</tr>
HTML;

	return $html;

}


private function get_query_string_html(array $event){

	if(empty($event[Log::KEY_QUERY_STRING])) return '';

	$query_string = esc_html($event[Log::KEY_QUERY_STRING]);

	return "?{$query_string}";

}

private function get_sorted_events(array $events){

	if(empty($events)) return [];

	usort($events, static function($a, $b){

		$a_timestamp = $a[Log::KEY_TIMESTAMP] ?? 0;

		$b_timestamp = $b[Log::KEY_TIMESTAMP] ?? 0;

		return $b_timestamp <=> $a_timestamp;

	});

	return $events;

}

private function get_event_type_label($type_key){

	$labels = $this->get_event_type_labels();

	if(isset($labels[$type_key])) return esc_html($labels[$type_key]);

	$type_label = ucwords(str_replace('-', ' ', $type_key));

	return esc_html($type_label);

}

private function get_event_type_labels(){

	return [

		Log::TRACE_BAD_HASH => __('Bad Authentication Hash', 'wpsd-cf-helper'),

		Log::TRACE_BAD_USERNAME => __('Bad Username', 'wpsd-cf-helper'),

		Log::TRACE_MALFORMED_COOKIE => __('Malformed Cookie', 'wpsd-cf-helper'),

		Log::TRACE_BAD_SESSION_TOKEN => __('Bad Session Token', 'wpsd-cf-helper'),

		Log::TRACE_CF_BYPASS => __('Cloudflare Bypass', 'wpsd-cf-helper'),

		Log::TRACE_IP_CHANGED => __('IP Changed', 'wpsd-cf-helper'),

		Log::TRACE_FALSE_AUTH => __('False Auth', 'wpsd-cf-helper'),

		Log::TRACE_NO_PAGE => __('No Page', 'wpsd-cf-helper'),

		Log::TRACE_NO_FILE => __('No File', 'wpsd-cf-helper'),

	];

}

private function get_texts(){

	return [

		'title' => __('Security Breach Events', 'wpsd-cf-helper'),

		'title_today' => __('Security Breach Events Today', 'wpsd-cf-helper'),

		'no_events' => __('No breach events found for today.', 'wpsd-cf-helper'),

		'events' => __('events', 'wpsd-cf-helper'),

		'time' => __('Time', 'wpsd-cf-helper'),

		'timestamp' => __('Timestamp', 'wpsd-cf-helper'),

		'ip' => __('IP', 'wpsd-cf-helper'),

		'country' => __('Country', 'wpsd-cf-helper'),

		'asn' => __('ASN', 'wpsd-cf-helper'),

		'user_id' => __('User ID', 'wpsd-cf-helper'),

		'path' => __('Path', 'wpsd-cf-helper'),

		'request_type' => __('Request Type', 'wpsd-cf-helper'),

	];

}
	static public function get_request_code_name($code){
		return match($code){
			REQUEST_FRONTEND =>	__('Frontend', 'wpsd-cf-helper'),
			REQUEST_AJAX =>		__('Ajax', 'wpsd-cf-helper'),
			REQUEST_ADMIN =>	__('Admin', 'wpsd-cf-helper'),
			REQUEST_CRON =>		__('Cron', 'wpsd-cf-helper'),
			REQUEST_LOGIN =>	__('Login', 'wpsd-cf-helper'),
			REQUEST_XMLRPC =>	__('XML-RPC', 'wpsd-cf-helper'),
			REQUEST_EMPTY =>	__('Empty', 'wpsd-cf-helper'),
			REQUEST_REST =>		__('REST API', 'wpsd-cf-helper'),
			REQUEST_SITEMAP =>	__('Sitemap', 'wpsd-cf-helper'),
			REQUEST_DIRECT =>	__('Direct', 'wpsd-cf-helper'),
			REQUEST_404 =>		__('404 Error', 'wpsd-cf-helper'),
			REQUEST_FEED =>		__('Feed', 'wpsd-cf-helper'),
			REQUEST_CLI =>		__('CLI', 'wpsd-cf-helper'),
			default =>			__('Unknown', 'wpsd-cf-helper'),
		};
	}
}