<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Tab_Settings_Value_Resolver{

	private array $settings;

	public function __construct(array $settings = []){

		$this->settings = $settings;

	}

	public function get_field_path(array $field){

		$path = $field[Tab_Settings::KEY_PATH] ?? [];

		return $this->sanitize_path($path);

	}

	public function sanitize_path($path){

		if( !is_array($path) || $path === [])return [];

		$clean_path = [];

		foreach($path as $segment){

			if(! is_int($segment))continue;

			$clean_path[] = $segment;

		}

		return $clean_path;

	}

	public function get_setting_value($path){

		$path = $this->sanitize_path($path);

		if($path === [])return '';

		$value = $this->settings;

		foreach($path as $segment){

			if( !is_array($value))return '';

			if(! array_key_exists($segment, $value))return '';

			$value = $value[$segment];

		}

		return $value;

	}

	public function get_scalar_value($path){

		$value = $this->get_setting_value($path);

		if(! is_scalar($value))return '';

		return esc_attr((string) $value);

	}

	public function get_absint_value($path){

		$value = $this->get_setting_value($path);

		return esc_attr((string) absint($value));

	}

	public function get_checked($path){

		$value = $this->get_setting_value($path);

		return checked((string) $value, '1', false);

	}

	public function get_textarea_lines_value($path){

		$value = $this->get_setting_value($path);

		if( !is_array($value))return '';

		$value = array_filter($value, static function($item){

			return is_scalar($item) && (string) $item !== '';

		});

		$value = array_map('strval', $value);

		return esc_textarea(implode("\n", $value));

	}

	public function get_select_value($path, array $options){

		$value = $this->get_setting_value($path);

		$value = is_scalar($value) ? (string) $value : '';

		foreach($options as $option_value => $option_label){

			if((string) $option_value !== $value)continue;

			return $value;

		}

		$option_keys = array_keys($options);

		$first_key = reset($option_keys);

		return is_scalar($first_key) ? (string) $first_key : '';

	}

	public function get_storage_value($path){

		$value = $this->get_setting_value($path);

		$value = is_scalar($value) ? (string) $value : S::STORAGE_SQLITE;

		switch($value){

			case S::STORAGE_WP_DB:

				return S::STORAGE_WP_DB;

			case S::STORAGE_SQLITE:

				return S::STORAGE_SQLITE;

		}

		return S::STORAGE_SQLITE;

	}

	public function get_trace_checked($trace_key){

		if(! is_int($trace_key))return '';

		$value = $this->get_setting_value([S::SECTION_LOGGING, S::KEY_MONITORING_TRACES, $trace_key]);

		return checked((string) $value, '1', false);

	}

}