<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Settings as S;

class Tab_Settings implements Tab_Interface{

	public const KEY_TAB = 'tab';

	public const KEY_LABEL = 'label';

	public const KEY_TYPE = 'type';

	public const KEY_FIELDS = 'fields';

	public const KEY_PATH = 'path';

	public const KEY_TEXT = 'text';

	public const KEY_SUBSECTIONS = 'subsections';

	public const KEY_TITLE = 'title';

	public const KEY_OPTIONS = 'options';

	public const KEY_MIN = 'min';

	public const KEY_STEP = 'step';

	public const KEY_CLASS = 'class';

	public const KEY_DISABLED = 'disabled';

	public const TYPE_FIELDS = 'fields';

	public const FIELD_TEXT = 'text';

	public const FIELD_TEXTAREA_LINES = 'textarea_lines';

	public const FIELD_CHECKBOX = 'checkbox';

	public const FIELD_NUMBER = 'number';

	public const FIELD_RADIO_GROUP = 'radio_group';

	public const FIELD_SELECT = 'select';

	public const FIELD_TITLE = 'title';

	public const FIELD_TRACE_CHECKBOXES = 'trace_checkboxes';

	public const SECTION_CLASS_PREFIX = 'settings-menu__section settings-menu__section--';

	public const SUBSECTION_CLASS_PREFIX = 'settings-menu__subsection settings-menu__subsection--logging-';

	public const DEFAULT_INPUT_CLASS = 'settings-menu__input';

	public const SMALL_INPUT_CLASS = 'settings-menu__input settings-menu__input--small';

	public const COOKIE_TAB = 'wpsd-cfh-tab-settings';

	private array $settings;

	private Tab_Settings_Value_Resolver $value_resolver;

	public function __construct(){

		$this->settings = S::get();

		$this->value_resolver = new Tab_Settings_Value_Resolver($this->settings);

	}

	public function render(){

		$output_html = $this->get_html();

		echo <<<HTML
{$output_html}
HTML;

	}

	private function get_html(){

		$sections = Tab_Settings_Sections::get_sections();

		$form_action = '';

		$tabs_html = $this->get_tabs_html($sections);

		$nav_html = $this->get_nav_html($sections);

		$sections_html = $this->get_sections_html($sections);

		$actions_html = $this->get_actions_html();

		$script = file_get_contents(Consts::DIR . 'assets/menu-tab-settings.js');

		$html = <<<HTML
			<form class="settings-menu" method="post" action="{$form_action}">
				{$tabs_html}
				<div class="settings-menu__nav">
					{$nav_html}
				</div>
				<div class="settings-menu__content">
					{$sections_html}
					{$actions_html}
				</div>
			</form>
			<script>
			{$script}
			</script>
			HTML;

		return $html;

	}

	public static function get_wpsd_log_text(){

	}

	private function get_tabs_html($sections){

		if( !is_array($sections) || $sections === [])return '';

		$html = '';

		$current_tab = $_COOKIE[self::COOKIE_TAB] ?? Settings_Mapper::get_section_slug(S::SECTION_CF_HEADER);

		foreach($sections as $key => $section){

			if( !is_array($section))continue;

			$tab_slug = Settings_Mapper::get_section_slug($section[self::KEY_TAB] ?? false);

			if($tab_slug === '')continue;

			$tab_id = $this->get_tab_id($tab_slug);

			$checked = $tab_slug === $current_tab ? ' checked' : '';

			$html .= <<<HTML
			<input class="settings-menu__tabs" type="radio" name="settings_tab" id="{$tab_id}"{$checked}>
			HTML;

		}

		return $html;

	}

	private function get_nav_html($sections){

		if( !is_array($sections) || $sections === [])return '';

		$items_html = '';

		foreach($sections as $section){

			if( !is_array($section))continue;

			$tab_slug = Settings_Mapper::get_section_slug($section[self::KEY_TAB] ?? false);

			$label = $section[self::KEY_LABEL] ?? '';

			if($tab_slug === '')continue;

			if(! is_scalar($label) || (string) $label === '')continue;

			$tab_id = $this->get_tab_id($tab_slug);

			$label = esc_html((string) $label);

			$items_html .= <<<HTML
				<li class="settings-menu__nav-item">
					<label class="settings-menu__nav-label" for="{$tab_id}">{$label}</label>
				</li>
				HTML;

						}

						return <<<HTML
				<ul class="settings-menu__nav-list">
					{$items_html}
				</ul>
				HTML;

	}

	private function get_sections_html($sections){

		if( !is_array($sections) || $sections === [])return '';

		$html = '';

		foreach($sections as $section_key => $section){

			if(! is_int($section_key))continue;

			if( !is_array($section))continue;

			$html .= $this->get_section_html($section_key, $section);

		}

		return $html;

	}

	private function get_section_html($section_key, $section){

		$type = $section[self::KEY_TYPE] ?? '';

		if(! is_string($type) || $type === '')return '';

		switch($type){

			case self::TYPE_FIELDS:

				return $this->get_fields_section_html($section_key, $section);

			case S::SECTION_LOGGING:

				return $this->get_logging_section_html($section_key, $section);

		}

		return '';

	}

	private function get_fields_section_html($section_key, $section){

		$fields = $section[self::KEY_FIELDS] ?? [];

		if( !is_array($fields) || $fields === [])return '';

		$fields_html = $this->get_fields_html($fields);

		$section_slug = Settings_Mapper::get_section_slug($section_key);

		$section_class = esc_attr(self::SECTION_CLASS_PREFIX . $section_slug);

		return <<<HTML
			<div class="{$section_class}">
				{$fields_html}
			</div>
			HTML;

	}

	private function get_fields_html($fields){

		if( !is_array($fields) || $fields === [])return '';

		$html = '';

		foreach($fields as $field){

			if( !is_array($field))continue;

			$html .= $this->get_field_html($field);

		}

		return $html;

	}

	private function get_field_html($field){

		return match($field[self::KEY_TYPE] ?? ''){
			self::FIELD_TEXT => $this->get_text_input_html($field),
			self::FIELD_TEXTAREA_LINES => $this->get_textarea_lines_html($field),
			self::FIELD_CHECKBOX => $this->get_checkbox_html($field),
			self::FIELD_NUMBER => $this->get_number_input_html($field),
			self::FIELD_RADIO_GROUP => $this->get_radio_group_html($field),
			self::FIELD_SELECT => $this->get_select_html($field),
			self::FIELD_TITLE => $this->get_title_html($field),
			self::FIELD_TRACE_CHECKBOXES => $this->get_trace_checkboxes_html($field),
			default => '',
		};

	}

	private function get_title_html($field){

		$title = $this->get_field_label($field);

		if($title === '')return '';

		return <<<HTML
			<h3 class="settings-menu__subsection-title">{$title}</h3>
			HTML;

	}

	private function get_trace_checkboxes_html($field){

		$path = $this->value_resolver->get_field_path($field);

		if($path === [])return '';

		$options = Tab_Settings_Sections::get_traces_names();

		$html = '';

		foreach($options as $trace_key => $label){

			if(! is_int($trace_key))continue;

			if(! is_scalar($label) || (string) $label === '')continue;

			$input_path = array_merge($path, [$trace_key]);

			$input_name = $this->get_input_name($input_path);

			$input_id = $this->get_input_id($input_path);

			$label = esc_html((string) $label);

			$checked = $this->value_resolver->get_trace_checked($trace_key);

			$html .= <<<HTML
	<label class="settings-menu__checkbox" for="{$input_id}">
		<input type="checkbox" id="{$input_id}" name="{$input_name}" value="1"{$checked}>
		<span>{$label}</span>
	</label>
	HTML;

		}

		if($html === '')return '';

		return <<<HTML
	<div class="settings-menu__field">
		{$html}
	</div>
	HTML;

	}

	private function get_text_input_html($field){

		$path = $this->value_resolver->get_field_path($field);

		if($path === []){

			$label = isset($field[self::KEY_TEXT]) && is_scalar($field[self::KEY_TEXT]) ? esc_html((string) $field[self::KEY_TEXT]) : '';

			$input_name = isset($field['name']) && is_string($field['name']) ? esc_attr($field['name']) : '';

			$input_id = isset($field['id']) && is_string($field['id']) ? esc_attr($field['id']) : '';

			$value = isset($field['value']) && is_scalar($field['value']) ? esc_attr((string) $field['value']) : '';

		} else {

			$label = $this->get_field_label($field);

			$input_name = $this->get_input_name($path);

			$input_id = $this->get_input_id($path);

			$value = $this->value_resolver->get_scalar_value($path);

		}

		$readonly = ($field['readonly'] ?? false) ? ' readonly' : '';

		return <<<HTML
			<div class="settings-menu__field">
				<label class="settings-menu__label" for="{$input_id}">{$label}</label>
				<input class="settings-menu__input" type="text" id="{$input_id}" name="{$input_name}" value="{$value}"{$readonly}>
			</div>
			HTML;

	}

	private function get_textarea_lines_html($field){

		$path = $this->value_resolver->get_field_path($field);

		if($path === [])return '';

		$label = $this->get_field_label($field);

		$input_name = $this->get_input_name($path);

		$input_id = $this->get_input_id($path);

		$value = $this->value_resolver->get_textarea_lines_value($path);

		return <<<HTML
			<div class="settings-menu__field">
				<label class="settings-menu__label" for="{$input_id}">{$label}</label>
				<textarea class="settings-menu__textarea" id="{$input_id}" name="{$input_name}">{$value}</textarea>
			</div>
			HTML;

	}

	private function get_checkbox_html($field){

		$path = $this->value_resolver->get_field_path($field);

		if($path === [])return '';

		$label = $this->get_field_label($field);

		$input_name = $this->get_input_name($path);

		$input_id = $this->get_input_id($path);

		$checked = $this->value_resolver->get_checked($path);

		return <<<HTML
			<label class="settings-menu__checkbox" for="{$input_id}">
				<input type="checkbox" id="{$input_id}" name="{$input_name}" value="1"{$checked}>
				<span>{$label}</span>
			</label>
			HTML;

	}

	private function get_number_input_html($field){

		$path = $this->value_resolver->get_field_path($field);

		if($path === [])return '';

		$label = $this->get_field_label($field);

		$input_name = $this->get_input_name($path);

		$input_id = $this->get_input_id($path);

		$value = $this->value_resolver->get_absint_value($path);

		$min = isset($field[self::KEY_MIN]) ? esc_attr((string) $field[self::KEY_MIN]) : '0';

		$step = isset($field[self::KEY_STEP]) ? esc_attr((string) $field[self::KEY_STEP]) : '1';

		$class = isset($field[self::KEY_CLASS]) && is_string($field[self::KEY_CLASS]) && $field[self::KEY_CLASS] !== '' ? esc_attr($field[self::KEY_CLASS]) : self::DEFAULT_INPUT_CLASS;

		return <<<HTML
			<div class="settings-menu__field">
				<label class="settings-menu__label" for="{$input_id}">{$label}</label>
				<input class="{$class}" type="number" min="{$min}" step="{$step}" id="{$input_id}" name="{$input_name}" value="{$value}">
			</div>
			HTML;

	}

	private function get_radio_group_html($field){

		$path = $this->value_resolver->get_field_path($field);

		$options = $field[self::KEY_OPTIONS] ?? [];

		if($path === [])return '';

		if( !is_array($options) || $options === [])return '';

		$label = $this->get_field_label($field);

		$input_name = $this->get_input_name($path);

		$current_value = $this->value_resolver->get_storage_value($path);

		$disabled_options = $field[self::KEY_DISABLED] ?? [];

		$disabled_options = is_array($disabled_options) ? $disabled_options : [];

		$options_html = '';

		foreach($options as $option_value => $option_label){

			if(! is_string($option_value) || $option_value === '')continue;

			if(! is_scalar($option_label) || (string) $option_label === '')continue;

			$option_id = $this->get_input_id(array_merge($path, [$option_value]));

			$option_label = esc_html((string) $option_label);

			$option_value_escaped = esc_attr($option_value);

			$checked = checked($current_value, $option_value, false);

			$disabled = in_array($option_value, $disabled_options, true) ? ' disabled' : '';

			$options_html .= <<<HTML
				<label class="settings-menu__checkbox" for="{$option_id}">
					<input type="radio" id="{$option_id}" name="{$input_name}" value="{$option_value_escaped}"{$checked}{$disabled}>
					<span>{$option_label}</span>
				</label>
				HTML;

		}

		if($options_html === '')return '';

		return <<<HTML
			<div class="settings-menu__field">
				<span class="settings-menu__label">{$label}</span>
				{$options_html}
			</div>
			HTML;

	}

	private function get_logging_section_html($section_key, $section){

		$subsections = $section[self::KEY_SUBSECTIONS] ?? [];

		if( !is_array($subsections) || $subsections === [])return '';

		$subsections_html = '';

		foreach($subsections as $subsection_key => $subsection){

			if(! is_string($subsection_key) || $subsection_key === '')continue;

			if( !is_array($subsection))continue;

			$subsections_html .= $this->get_logging_subsection_html($subsection_key, $subsection);

		}

		$section_class = esc_attr(self::SECTION_CLASS_PREFIX . str_replace('_', '-', $section_key));

		return <<<HTML
			<div class="{$section_class}">
				{$subsections_html}
			</div>
			HTML;

	}

	private function get_logging_subsection_html($subsection_key, $subsection){

		$title = $subsection[self::KEY_TITLE] ?? '';

		$fields = $subsection[self::KEY_FIELDS] ?? [];

		if(! is_scalar($title) || (string) $title === '')return '';

		if( !is_array($fields) || $fields === [])return '';

		$title = esc_html((string) $title);

		$fields_html = $this->get_fields_html($fields);

		$subsection_class = esc_attr(self::SUBSECTION_CLASS_PREFIX . str_replace('_', '-', $subsection_key));

		return <<<HTML
			<div class="{$subsection_class}">
				<h3 class="settings-menu__subsection-title">{$title}</h3>
				{$fields_html}
			</div>
			HTML;

	}

	private function get_remote_options_field_html(){

		$remote_options_html = $this->get_remote_options_html();

		return <<<HTML
			<div class="settings-menu__field">
				{$remote_options_html}
			</div>
			HTML;

	}

	private function get_select_html($field){

		$path = $this->value_resolver->get_field_path($field);

		$options = $field[self::KEY_OPTIONS] ?? [];

		if($path === [])return '';

		if( !is_array($options) || $options === [])return '';

		$label = $this->get_field_label($field);

		$input_name = $this->get_input_name($path);

		$input_id = $this->get_input_id($path);

		$current_value = $this->value_resolver->get_select_value($path, $options);

		$options_html = '';

		foreach($options as $option_value => $option_label){

			if(! is_scalar($option_value))continue;

			if(! is_scalar($option_label) || (string) $option_label === '')continue;

			$option_value = (string) $option_value;

			$option_value_escaped = esc_attr($option_value);

			$option_label_escaped = esc_html((string) $option_label);

			$selected = selected($current_value, $option_value, false);

			$options_html .= <<<HTML
				<option value="{$option_value_escaped}"{$selected}>{$option_label_escaped}</option>
				HTML;

		}

		if($options_html === '')return '';

		return <<<HTML
			<div class="settings-menu__field">
				<label class="settings-menu__label" for="{$input_id}">{$label}</label>
				<select class="settings-menu__input" id="{$input_id}" name="{$input_name}">
					{$options_html}
				</select>
			</div>
			HTML;

	}

	private function get_remote_options_html(){

		$options = Remote_Logging_Options::get();

		if($options === []){

			$none = esc_html(__('Provider: Remote logging requires addon plugin.', 'wpsd-cf-helper'));

			return <<<HTML
				<div class="settings-menu__remote-options">{$none}</div>
				HTML;

		}

		$html = '';

		foreach($options as $option_key => $option_label){

			if(! is_string($option_key) || $option_key === '')continue;

			if(! is_string($option_label) || $option_label === '')continue;

			$option_key_escaped = esc_attr($option_key);

			$option_label_escaped = esc_html($option_label);

			$html .= <<<HTML
				<div class="settings-menu__remote-option" data-key="{$option_key_escaped}">{$option_label_escaped}</div>
				HTML;

		}

		if($html === ''){

			$none = esc_html(__('None', 'wpsd-cf-helper'));

			return <<<HTML
				<div class="settings-menu__remote-options">{$none}</div>
				HTML;

		}

		return <<<HTML
			<div class="settings-menu__remote-options">{$html}</div>
			HTML;

	}

	private function get_actions_html(){

		$save_settings = esc_html(__('Save Settings', 'wpsd-cf-helper'));

		$nonce_field = wp_nonce_field(Consts::NONCE, Consts::NONCE, false, false);

		return <<<HTML
			<div class="settings-menu__actions">
				{$nonce_field}
				<button type="submit" class="button button-primary">{$save_settings}</button>
			</div>
			HTML;

	}

	private function get_field_label($field){

		$label = $field[self::KEY_TEXT] ?? '';

		if(! is_scalar($label))return '';

		return esc_html((string) $label);

	}

	private function get_tab_id($tab_slug){

		if(! is_string($tab_slug) || $tab_slug === '')return '';

		return 'settings-tab-' . $tab_slug;

	}

	private function get_input_name($path){

		$path = $this->value_resolver->sanitize_path($path);

		if($path === [])return '';

		$name = S::INPUT_ROOT;

		foreach($path as $segment){

			$name .= '[' . $segment . ']';

		}

		return $name;

	}

	private function get_input_id($path){

		$path = $this->value_resolver->sanitize_path($path);

		if($path === [])return '';

		return S::INPUT_ROOT . '-' . implode('-', $path);

	}
}