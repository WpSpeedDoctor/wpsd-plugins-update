<?php

namespace WPSD\cf_helper;

use WPSD\cf_helper\Tab_Settings as T;
use WPSD\cf_helper\Settings as S;

abstract class Tab_Settings_Sections {

	private static function get_monitor_url(){

		$settings = S::get();

		$secret_token = $settings[S::SECTION_LOGGING][S::KEY_SECRET_TOKEN] ?? '';

		$secret_token = is_scalar($secret_token) ? (string) $secret_token : '';

		if($secret_token === ''){

			$secret_token = bin2hex(random_bytes(10));

		}

		return site_url('/wp-json/cf-helper/v1/monitor/' . rawurlencode($secret_token) . '/');

	}


	public static function get_sections(){

		return [
			S::SECTION_CF_HEADER => [
				T::KEY_TAB => S::SECTION_CF_HEADER,
				T::KEY_LABEL => __('Cloudflare Header', 'wpsd-cf-helper'),
				T::KEY_TYPE => T::TYPE_FIELDS,
				T::KEY_FIELDS => [
					[
						T::KEY_TYPE => T::FIELD_TEXT,
						T::KEY_TEXT => __('Value of ID_CF header', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_CF_HEADER, S::KEY_HEADER_VALUE],
					],
					[
						T::KEY_TYPE => T::FIELD_TEXT,
						T::KEY_TEXT => __('This server IP', 'wpsd-cf-helper'),
						'name' => 'server_ip',
						'value' => $_SERVER['SERVER_ADDR'] ?? '',
						'id' => 'server_ip',
						'readonly' => true,
					],
					[
						T::KEY_TYPE => T::FIELD_TEXTAREA_LINES,
						T::KEY_TEXT => __('Allowed IPs', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_CF_HEADER, S::KEY_ALLOWED_IPS],
					],
					[
						T::KEY_TYPE => T::FIELD_TEXTAREA_LINES,
						T::KEY_TEXT => __('Allowed User Agents', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_CF_HEADER, S::KEY_ALLOWED_USER_AGENT],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Enable', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_CF_HEADER, S::KEY_ENABLED],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Log events', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_CF_HEADER, S::KEY_LOG],
					],
				],
			],
			S::SECTION_FALSE_AUTH => [
				T::KEY_TAB => S::SECTION_FALSE_AUTH,
				T::KEY_LABEL => __('Block False Authentication', 'wpsd-cf-helper'),
				T::KEY_TYPE => T::TYPE_FIELDS,
				T::KEY_FIELDS => [
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Enable', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_FALSE_AUTH, S::KEY_ENABLED],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Block attempt', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_FALSE_AUTH, S::KEY_BLOCK_ATTEMPT],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Log events', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_FALSE_AUTH, S::KEY_LOG],
					],
				],
			],
			S::SECTION_IP_CHANGE => [
				T::KEY_TAB => S::SECTION_IP_CHANGE,
				T::KEY_LABEL => __('Logout on IP Change', 'wpsd-cf-helper'),
				T::KEY_TYPE => T::TYPE_FIELDS,
				T::KEY_FIELDS => [
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Enable', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_IP_CHANGE, S::KEY_ENABLED],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Log events', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_IP_CHANGE, S::KEY_LOG],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Allow IP Change for Country', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_IP_CHANGE, S::KEY_ALLOW_IP_CHANGE_COUNTRY],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Allow IP Change for ASN', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_IP_CHANGE, S::KEY_ALLOW_IP_CHANGE_ASN],
					],
				],
			],
			S::SECTION_EARLY_403_404 => [
				T::KEY_TAB => S::SECTION_EARLY_403_404,
				T::KEY_LABEL => __('Early 403/404', 'wpsd-cf-helper'),
				T::KEY_TYPE => T::TYPE_FIELDS,
				T::KEY_FIELDS => [
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Enable', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_EARLY_403_404, S::KEY_ENABLED],
					],
					[
						T::KEY_TYPE => T::FIELD_CHECKBOX,
						T::KEY_TEXT => __('Log events', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_EARLY_403_404, S::KEY_LOG],
					],
					[
						T::KEY_TYPE => T::FIELD_SELECT,
						T::KEY_TEXT => __("When file doesn't exists", 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_EARLY_403_404, S::KEY_SELECT_NO_FILE],
						T::KEY_OPTIONS => [
							S::KEY_OPTION_DEFAULT => __('Do nothing', 'wpsd-cf-helper'),
							S::KEY_OPTION_403 => __('403 Forbidden page', 'wpsd-cf-helper'),
							S::KEY_OPTION_SIMPLE_404 => __('Simple 404 page', 'wpsd-cf-helper'),
						],
					],
					[
						T::KEY_TYPE => T::FIELD_SELECT,
						T::KEY_TEXT => __('When WP cannot query the the page', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_EARLY_403_404, S::KEY_SELECT_NO_PAGE],
						T::KEY_OPTIONS => [
							S::KEY_OPTION_DEFAULT => __('Do nothing', 'wpsd-cf-helper'),
							S::KEY_OPTION_403 => __('403 Forbidden page', 'wpsd-cf-helper'),
							S::KEY_OPTION_SIMPLE_404 => __('Simple 404 page', 'wpsd-cf-helper'),
							S::KEY_OPTION_CACHED => __('load cached 404', 'wpsd-cf-helper'),
						],
					],
				],
			],
			S::SECTION_LOGGING => [
				T::KEY_TAB => S::SECTION_LOGGING,
				T::KEY_LABEL => __('Logging and Breach Monitoring', 'wpsd-cf-helper'),
				T::KEY_TYPE => T::TYPE_FIELDS,
				T::KEY_FIELDS => [
					[
						T::KEY_TYPE => T::FIELD_NUMBER,
						T::KEY_TEXT => __('Days to keep', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_LOGGING, S::KEY_DAYS_TO_KEEP],
						T::KEY_MIN => '0',
						T::KEY_STEP => '1',
						T::KEY_CLASS => T::SMALL_INPUT_CLASS,
					],
					[
						T::KEY_TYPE => T::FIELD_TITLE,
						T::KEY_TEXT => __('Include in breach monitoring', 'wpsd-cf-helper'),
					],
					[
						T::KEY_TYPE => T::FIELD_TRACE_CHECKBOXES,
						T::KEY_PATH => [S::SECTION_LOGGING, S::KEY_MONITORING_TRACES],
					],
					[
						T::KEY_TYPE => T::FIELD_TEXT,
						T::KEY_TEXT => __('Secret Token', 'wpsd-cf-helper'),
						T::KEY_PATH => [S::SECTION_LOGGING, S::KEY_SECRET_TOKEN],
					],
					[
						T::KEY_TYPE => T::FIELD_TEXT,
						T::KEY_TEXT => __('Monitor URL', 'wpsd-cf-helper'),
						'name' => 'monitor_url',
						'value' => self::get_monitor_url(),
						'id' => 'monitor_url',
						'readonly' => true,
					],
				],
			],
		];

	}

	/**
	 * @param string $trace
	 */
	public static function get_traces_names(){

		return [

			S::TRACE_CF_BYPASS => __('Bypass CF', 'wpsd-cf-helper'),

			S::TRACE_FALSE_AUTH => __('False authentication', 'wpsd-cf-helper'),

			S::TRACE_IP_CHANGED => __('IP changed', 'wpsd-cf-helper'),

			S::TRACE_NO_FILE => __('No file', 'wpsd-cf-helper'),

			S::TRACE_NO_PAGE => __('No page', 'wpsd-cf-helper'),

			S::TRACE_MALFORMED_COOKIE => __('Malformed cookie', 'wpsd-cf-helper'),

			S::TRACE_BAD_USERNAME => __('Bad username', 'wpsd-cf-helper'),

			S::TRACE_BAD_HASH => __('Bad hash', 'wpsd-cf-helper'),

			S::TRACE_BAD_SESSION_TOKEN => __('Bad session token', 'wpsd-cf-helper'),

		];

	}
	
}
