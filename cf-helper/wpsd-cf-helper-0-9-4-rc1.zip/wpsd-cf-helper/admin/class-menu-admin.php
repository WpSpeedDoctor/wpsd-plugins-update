<?php

namespace WPSD\cf_helper;

class Admin_Menu{

	const TAB_HOME		= 'home';
	
	const TAB_SETTINGS	= 'settings';

	const TAB_DEBUG		= 'debug';

	const TAB_GUIDE		= 'guide';

	const KEY_TITLE = 0;

	const KEY_CLASSNAME = 1;

	static function render(){

		self::enqueue_assets();

		$active_tab = sanitize_key( $_GET['tab'] ?? self::TAB_HOME );

		$tabs = self::get_tabs_data();

		if( array_key_exists( $active_tab, $tabs ) ){
			
			self::display_header( $tabs, $active_tab );
			
			$tab_classname = __NAMESPACE__.'\\'.$tabs[ $active_tab ][ self::KEY_CLASSNAME ];
			
			$tab = new $tab_classname();

			$tab->render();
			
		} else {

			echo 'Wrong tab';

		}
		
		self::display_footer();
	}

	static function display_footer(){
	
		echo <<<HTML
			</div>
		</div>
		HTML;
		
	}

	static function display_header($tabs, $active_tab){

		$page_url = admin_url( Consts::ADMIN_PAGE.'?page='.Consts::ADMIN_SUBPAGE );

		$nav_links = '';

		foreach ( $tabs as $slug => $tabs_data ) {

			$active_tab_class = ( $slug === $active_tab ) ? ' nav-tab-active' : '';

			$tab_qs = ( $slug === 'home' ) ? '' : '&tab=' . $slug;
			
			$nav_links .= <<<HTML
				<a href="{$page_url}{$tab_qs}" class="nav-tab{$active_tab_class}">{$tabs_data[self::KEY_TITLE]}</a>
				HTML;
		}

		$title = esc_html__( 'Cloudflare Security Helper', 'wpsd-cf-helper' );

		$slug=Consts::SLUG;
		
		//empty H1 for WP notices being displayd correctly
		echo <<<HTML
		<div class="wrap {$slug}-wrap">
			<h1></h1>
			<header class="{$slug}-header">
				<nav class="menu-tabs">
					{$nav_links}
				</nav>
			<h1 class="{$slug}-title">{$title}</h1>
			</header>
			<div class="{$slug}-body clear">
		HTML;

	}

	static function enqueue_assets(){

		wp_enqueue_style(
			Consts::SLUG,
			plugins_url( 'assets/admin-style.css', Consts::DIR.'a' ),
			[],
			Consts::VER
		);
	}

	static function get_tabs_data(){

		$result =[
			self::TAB_HOME => [
				self::KEY_TITLE 	=> __('Home','wpsd-cf-helper'),
				self::KEY_CLASSNAME => 'Tab_Home',
			],
			self::TAB_SETTINGS => [
				self::KEY_TITLE 	=> __('Settings','wpsd-cf-helper'),
				self::KEY_CLASSNAME => 'Tab_Settings',
			],
			self::TAB_GUIDE => [
				self::KEY_TITLE 	=> __('Guide & Docs','wpsd-cf-helper'),
				self::KEY_CLASSNAME => 'Tab_Guide',
			],
			
		];

		if( defined( 'WP_ENVIRONMENT_TYPE' ) && WP_ENVIRONMENT_TYPE === 'development' ){

			$result[self::TAB_DEBUG] = [
				self::KEY_TITLE 	=> __('Debug','wpsd-cf-helper'),
				self::KEY_CLASSNAME => 'Tab_Debug',
			];
		}

		return $result;
	}
}