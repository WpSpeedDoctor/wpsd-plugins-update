<?php

namespace WPSD\cf_helper;

class Tab_Guide implements Tab_Interface{

	const GUIDE_EDIT_KEY = 'guideedit';

	const GUIDE_EDIT_VALUE = '1';

	const DOCS_FILE = __DIR__.'/docs.data';

	const EDITOR_ID = 'wpsd_cf_helper_guide_editor';

	const NONCE_ACTION = 'wpsd_cf_helper_save_guide';

	const NONCE_NAME = 'wpsd_cf_helper_guide_nonce';

	private $saved = false;

	public function render(){

		$this->maybe_save_document();

		$this->render_notices();

		if ($this->is_editing()){

			$this->render_editor();

		} else {

			$this->render_document();

			$this->render_headers_test();
		}

	}

	private function is_editing(){

		$guideedit = sanitize_text_field(wp_unslash($_GET[self::GUIDE_EDIT_KEY] ?? ''));

		return self::GUIDE_EDIT_VALUE === $guideedit;

	}

	private function maybe_save_document(){

		if(false === $this->is_saving()) return false;

		if(false === current_user_can('manage_options')) return false;

		check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

		$content = wp_kses_post(wp_unslash($_POST['guide_content'] ?? ''));

		file_put_contents(self::DOCS_FILE, $content);

		$this->saved = true;

		return true;

	}

	private function is_saving(){

		$action = sanitize_key($_POST['guide_action'] ?? '');

		return 'save_guide' === $action;

	}

	private function render_notices(){

		if(false === $this->saved) return false;

		$texts = $this->get_texts();

		$html = <<<HTML
			<div class="notice notice-success is-dismissible">

				<p>{$texts['saved']}</p>

			</div>
			HTML;

		echo $html;

		return true;

	}

	private function render_document(){

		$texts = $this->get_texts();

		$content = $this->get_document_raw_content();

		$content = apply_filters('the_content', $content);

		$html = <<<HTML
			<style>
				.wpsd-cf-helper-guide-content ul{
				list-style: disc;
				margin: 0 0 1em 1.5em;
				padding: 0;
			}

			.wpsd-cf-helper-guide-content ol{
				list-style: decimal;
				margin: 0 0 1em 1.5em;
				padding: 0;
			}

			.wpsd-cf-helper-guide-content li{
				margin: 0 0 .4em 0;
			}

			.wpsd-cf-helper-guide-content h2{
				margin: 1.5em 0 .6em;
			}

			.wpsd-cf-helper-guide-content h3{
				margin: 1.2em 0 .5em;
			}

			.wpsd-cf-helper-guide-content p{
				margin: 0 0 1em;
			}

			.wpsd-cf-helper-guide-content code{
				background: #f0f0f1;
				padding: 2px 4px;
				border-radius: 3px;
			}
			</style>

			<div class="wrap wpsd-cf-helper-guide">

			{$texts['edit_markup']}

				<div class="wpsd-cf-helper-guide-content">

					{$content}

				</div>

			</div>
			HTML;

		echo $html;

	}

	private function render_editor(){

		$texts = $this->get_texts();

		$content = $this->get_document_raw_content();

		$view_url = esc_url(remove_query_arg(self::GUIDE_EDIT_KEY));

		$nonce = wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME, true, false);

		$editor_name = 'guide_content';

		$html_before = <<<HTML
			<div class="wrap wpsd-cf-helper-guide">

				<h1>{$texts['edit_title']}</h1>

				<form method="post">

					{$nonce}

					<input type="hidden" name="guide_action" value="save_guide">
			HTML;

		echo $html_before;

		wp_editor(
			$content,
			self::EDITOR_ID,
			array(
				'textarea_name' => $editor_name,
				'media_buttons' => false,
				'textarea_rows' => 24,
				'teeny' => false,
				'quicktags' => true,
				'tinymce' => true,
			)
		);

		$html_after = <<<HTML
		<p class="submit">

			<button type="submit" class="button button-primary">{$texts['save']}</button>

			<a href="{$view_url}" class="button">{$texts['cancel']}</a>

		</p>

	</form>

</div>
HTML;

		echo $html_after;

	}

	private function get_document_raw_content(){

		if(false === file_exists(self::DOCS_FILE)) return '';

		$content = file_get_contents(self::DOCS_FILE);

		if(false === $content) return '';

		return $content;

	}

	private function get_texts(){

		$texts = array(
			'edit_title' => esc_html__('Edit Plugin Guide', 'plugin-domain'),
			'edit' => esc_html__('Edit guide', 'plugin-domain'),
			'save' => esc_html__('Save guide', 'plugin-domain'),
			'cancel' => esc_html__('Cancel', 'plugin-domain'),
			'saved' => esc_html__('Guide saved.', 'plugin-domain'),
		);

		if( defined( 'WP_ENVIRONMENT_TYPE' ) && WP_ENVIRONMENT_TYPE === 'development' ){
			$edit_url = esc_url(add_query_arg(self::GUIDE_EDIT_KEY, self::GUIDE_EDIT_VALUE));
			$texts['edit_markup'] = <<<HTML
			<div class="wpsd-cf-helper-guide__header">

				<a href="{$edit_url}" class="button button-primary">{$texts['edit']}</a>

			</div>
			HTML;
		}

		return $texts;

	}

	private function render_headers_test(){
	
		$headers_makrup = (object)[

			'cf'	=> $this->get_outcome_icon( isset( $_SERVER['HTTP_CF_RAY'] ) ),

			'cf_id_header'	=> $this->get_outcome_icon( isset( $_SERVER['HTTP_'.Consts::CF_HEADER_NAME] ) ),

			'cf_id'	=> esc_html($_SERVER['HTTP_'.Consts::CF_HEADER_NAME]??'-'),

			'file_ext'		=> $this->get_outcome_icon( isset( $_SERVER['HTTP_'.Consts::CF_HEADER_FILE_EXT] ) ),

			'asn'			=> $this->get_outcome_icon( isset( $_SERVER['HTTP_'.Consts::CF_HEADER_ASN] ) ),

			'uri_path'		=> $this->get_outcome_icon( isset( $_SERVER['HTTP_'.Consts::CF_HEADER_URI_PATH] ) ),

			'label_cf'	=> __( 'Cloudflare present', 'wpsd-cf-helper' ),

			'label_cf_id'	=> __( 'Cloudflare ID header present', 'wpsd-cf-helper' ),

			'label_file_ext'	=> __( 'File extension', 'wpsd-cf-helper' ),

			'label_asn'			=> __( 'ASN', 'wpsd-cf-helper' ),

			'label_uri_path'	=> __( 'URI path', 'wpsd-cf-helper' ),

		];

		$html = <<<HTML
		<h2>Headers test</h2>

		<ol>
			<li>{$headers_makrup->label_cf} {$headers_makrup->cf}</li>

			<li>{$headers_makrup->label_cf_id} {$headers_makrup->cf_id_header} <input type="text" value="{$headers_makrup->cf_id}" readonly></li>

			<li>{$headers_makrup->label_file_ext} {$headers_makrup->file_ext}</li>

			<li>{$headers_makrup->label_asn} {$headers_makrup->asn}</li>

			<li>{$headers_makrup->label_uri_path} {$headers_makrup->uri_path}</li>
		</ol>
		HTML;

		echo $html;
		
	}

	private function get_outcome_icon($bool){
	
		return $bool ? '<span style="color:green;margin:0 5px">✔</span>' : '<span style="color:brown;margin:0 5px">✘</span>';
		
	}
}