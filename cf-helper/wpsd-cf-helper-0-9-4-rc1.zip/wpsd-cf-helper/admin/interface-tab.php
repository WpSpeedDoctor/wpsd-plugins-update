<?php

namespace WPSD\cf_helper;

interface Tab_Interface{
	public function render();
}