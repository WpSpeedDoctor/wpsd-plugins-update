<?php

namespace WPSD\cf_helper;

class Tab_Debug implements Tab_Interface{

	private string $html;

	private object $key;

	private string $result;

	public function __construct(){
	
		$this->html = $this->result = '';

		$this->key = (object)[

			'ip' => Auth_Control::USER_IP,

			'asn' => Auth_Control::USER_ASN,

			'country' => Auth_Control::USER_COUNTRY,
		];
		
	}

	public function render(){

		$this->get_tokens();

		$this->do_remote_user();
	
		$this->do_display_settings();

		echo $this->html;

	}

private function do_display_settings(){

	$settings = Settings::get();

	$settings = $this->get_readable_settings($settings);

	ob_start();

	var_dump($settings);

	$var_dump_rendered = htmlentities(str_replace("]=>\n ", '] =>', ob_get_clean()));

	$this->html .= <<<HTML
	<br><div style="white-space: break-spaces;line-height: 2;font-family: monospace;">
	{$var_dump_rendered}
	<div><br>
	HTML;

}

private function get_readable_settings($settings){

	if( !is_array($settings))return $settings;

	$readable_settings = [];

	$sections = Tab_Settings_Sections::get_sections();

	foreach($settings as $section_key => $section_settings){

		$readable_section_key = $this->get_readable_section_key($section_key);

		$readable_settings[$readable_section_key] = $this->get_readable_section_settings($section_key, $section_settings, $sections);

	}

	return $readable_settings;

}

private function get_readable_section_key($section_key){

	if(! is_int($section_key))return $section_key;

	$section_slug = Settings_Mapper::get_section_slug($section_key);

	if($section_slug === '')return $section_key;

	return $section_slug;

}

private function get_readable_section_settings($section_key, $section_settings, $sections){

	if( !is_array($section_settings))return $section_settings;

	$readable_settings = [];

	$field_map = $this->get_section_field_map($section_key, $sections);

	foreach($section_settings as $setting_key => $setting_value){

		$readable_key = $field_map[$setting_key] ?? $setting_key;

		$readable_settings[$readable_key] = $this->get_readable_setting_value($readable_key, $setting_value);

	}

	return $readable_settings;

}

	private function get_section_field_map($section_key, $sections){

		if(! is_int($section_key))return [];

		if(! isset($sections[$section_key]))return [];

		if( !is_array($sections[$section_key]))return [];

		$fields = $this->get_section_fields($sections[$section_key]);

		if($fields === [])return [];

		$field_map = [];

		foreach($fields as $field){

			if( !is_array($field))continue;

			$path = $field[Tab_Settings::KEY_PATH] ?? [];

			if( !is_array($path) || $path === [])continue;

			$field_key = end($path);

			if(! is_int($field_key))continue;

			$readable_key = $this->get_readable_field_key($field);

			if($readable_key === '')continue;

			$field_map[$field_key] = $readable_key;

		}

		return $field_map;

	}

	private function get_readable_field_key($field){

	if( !is_array($field))return '';

	$type = $field[Tab_Settings::KEY_TYPE] ?? '';

	switch($type){

		case Tab_Settings::FIELD_TRACE_CHECKBOXES:

			return 'monitoring-traces';

	}

	$label = $field[Tab_Settings::KEY_TEXT] ?? '';

	if(! is_scalar($label) || (string) $label === '')return '';

	return sanitize_title((string) $label);

}

private function get_section_fields($section){

	if( !is_array($section))return [];

	$fields = $section[Tab_Settings::KEY_FIELDS] ?? [];

	if(is_array($fields) && $fields !== [])return $fields;

	$subsections = $section[Tab_Settings::KEY_SUBSECTIONS] ?? [];

	if( !is_array($subsections) || $subsections === [])return [];

	$result = [];

	foreach($subsections as $subsection){

		if( !is_array($subsection))continue;

		$subsection_fields = $subsection[Tab_Settings::KEY_FIELDS] ?? [];

		if( !is_array($subsection_fields))continue;

		$result = array_merge($result, $subsection_fields);

	}

	return $result;

}

private function get_readable_setting_value($readable_key, $setting_value){

	if($readable_key !== 'monitoring-traces')return $setting_value;

	if( !is_array($setting_value))return $setting_value;

	$trace_names = Tab_Settings_Sections::get_traces_names();

	$readable_traces = [];

	foreach($setting_value as $trace_key => $trace_value){

		$trace_name = $trace_names[$trace_key] ?? $trace_key;

		if(is_scalar($trace_name)){

			$trace_name = sanitize_title((string) $trace_name);

		}

		$readable_traces[$trace_name] = $trace_value;

	}

	return $readable_traces;

}
	private function get_tokens(){
	
		$user_id = get_current_user_id();

		$user_sessions = get_user_meta( $user_id, 'session_tokens', true );

		if(empty($user_sessions)){
			
			$this->html .= 'No tokens found<br><br>';
			return;
		}

		$this->result = 'Tokens:<br>';
		foreach($user_sessions as $key => $session){
		
			$this->result .= $this->get_user_data_markup($session).'<br>';	
		
		}

		$this->wrap_to_html($this->result);
	}

	private function wrap_to_html($string){
	
		$this->html .= <<<HTML
		<div class="wrap">
		{$string}
		</div>
		HTML;
		
	}

	private function do_remote_user(){
	
		$stored_user_data = Auth_Control::get_stored_user_data();
		
		$remote_user_data = Auth_Control::get_user_remote_data();
		
		$this->result = 'Stored: '. $this->get_user_data_markup($stored_user_data).'<br>';
		
		$this->result .= 'Remote: '. $this->get_user_data_markup($remote_user_data).'<br>';
		
		$this->wrap_to_html($this->result);
	}

	/**
	 * @param array $user_data
	 * @return string
	 */

	private function get_user_data_markup($user_data){
	
		$ip = ($user_data[$this->key->ip] ?? null) ?: 'NULL';

		$country = ($user_data[$this->key->country] ?? null) ?: 'NULL';

		$asn = ($user_data[$this->key->asn] ?? null) ?: 'NULL';

		return <<<HTML
			<pre>{$ip} {$country} {$asn}</pre>
			HTML;
	}
}