<?php

namespace WPSD\cf_helper;


/*
* Plugin Name: TEST Cloudflare Helper
* Plugin URI: https://wpspeeddoctor.com/plugins/
* Description: Reinforced security on WP level suplementing Cloudflare firewall.
* Version: 8.0
* Author: WP Speed Doctor
* Author URI: https://wpspeeddoctor.com/
* Text Domain: wpsd-cf-h
* Domain Path: /languages/
* Last Update: 2026-3-13
* License: GPLv3
* Requires at least: 5.9
* Requires PHP: 8.0
*/

//do nothing