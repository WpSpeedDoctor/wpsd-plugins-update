<?php

/*
* Plugin Name: Record all Query String keys on the front page
* Plugin URI: https://wpspeeddoctor.com/
* Description: Advanced plugin filer helper plugin
* Version: 1.0.0
* Author: Jaro Kurimsky
* Author URI: https://wpspeeddoctor.com/
* Text Domain: save-qs-keys
* Domain Path: /languages/
* License: GPLv3
* Requires at least: 5.0
* Requires PHP: 7.0.0
*/	

defined( 'ABSPATH' ) || exit;

main();

function main() {

	$uri = $_SERVER['REQUEST_URI'] ?? '';

	$qs = $_SERVER['QUERY_STRING']??'';

	$uri_path = $qs === '' ? $uri : strstr($uri, '?', true);

	if( $uri_path !== '/' ) return;

	if( empty($qs) ) return;

	$qs_keys = array_keys($_GET);

	foreach( $qs_keys as $qs_key ){

		$qs_key_log_filepath = __DIR__."/logs/{$qs_key}";

		if( file_exists( $qs_key_log_filepath ) ) continue;

		file_put_contents( $qs_key_log_filepath, '' );
	}
}